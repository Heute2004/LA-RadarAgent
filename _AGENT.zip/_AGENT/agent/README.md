# AGENT-JSAC Minimal Reproduction

## Observation-Evidence Candidate Release

This directory is a separate candidate package, not the immutable historical
release. The UAV observer extension connects cached real InternVL observations,
real Qwen tool selection, typed memory, registered training products, numeric
Support-dev evaluation, shadow checking, and isolated target-site registration.
Human and UAV retain separate supervision and metric contracts. UAV has no
expert library.

The numeric-policy lifecycle completed thirteen tool steps and registered the
adapted model for its authorized target site. It reused an existing real training
product; this execution did not train a model, measure live InternVL latency, or
establish a new learning gain attributable to Qwen. The earlier failed receipt
schema attempt remains part of the execution record. Locked Test was not read.

See `docs/Observation-Evidence-Lifecycle.md` for the current entry point,
external resource requirements, evidence identities and reproduction limits.
The sections below document inherited preparation and historical replay modes;
their training-interception statements do not replace the separately authorized
UAV numeric-policy execution contract.

## Current Toolbox Entry Point

The active toolbox separates `task=human` and `task=uav`. Human has 40 original
expert catalog entries; UAV uses the adopted source/adaptation/routing handoff
and has no expert library. Models, sensor data and the Python environment are
external resources, not interchangeable with archived result receipts.

Start with:

- `docs/pretraining_completion_plan.md`: full pretraining gates and current scope.
- `docs/pretraining_acceptance_report_zh.md`: current Chinese acceptance status,
  followed by explicitly historical audit notes.
- `artifacts/pretraining_acceptance/HUMAN_ACTIVE_CHAIN_ACCEPTANCE_20260910.md`:
  verified real-Qwen six-stage preparation, without sensing training.
- `docs/uav_original_handoff_authority.md`: adopted UAV protocol and exclusions.
- `docs/ris_codebook_provenance_blocker_audit_20260910.md`: unresolved receiver
  provenance; no quarantine bypass or fabricated five-candidate RIS shortlist.

All training requests remain intercepted. A successful simulated lifecycle or
native preparation does not authorize training, promotion, checkpoint reuse,
Locked Test access, or a numerical reproduction claim. The result-replay material
below is preserved historical evidence, not a command to launch new training.

## Historical Result-Replay Package

这是 AGENT-JSAC 自进化感知 Agent 的最小复现项目。结果级核心快照不依赖原始 RA、RA-MTI、RGB、ADC、深度、Final-BEV、模型权重或训练数据，只冻结：

- Agent 架构和安全合同；
- CORA-EvoLabel 标签、预测与伪标签晋级合同；
- 专家语义库与生命周期参考实现；
- CORA0/CORA-SE1/CORA-SE2、CSS、五条路线专家和 RIS V21 的结果文件；
- 结果哈希；
- 可运行的确定性 Agent 生命周期回放。

## 模型级冻结复刻

`artifacts/model_level_replay_v1` 在结果级回放之外，进一步绑定了真实冻结 checkpoint、Development 预测归档和路线执行合同。当前已完成 31 个序列、9300 帧的统一 AgentBEV 复刻，并在实验室服务器独立重算 RIS V21 的 2100 帧。

```powershell
D:\anaconda3\envs\pytorch_env\python.exe scripts\run_model_level_development_replay.py `
  --replay-root artifacts\model_level_replay_v1 `
  --output-dir artifacts\model_level_replay_v1\REPRO_RUN
D:\anaconda3\envs\pytorch_env\python.exe scripts\audit_model_level_development_replay.py `
  --replay-root artifacts\model_level_replay_v1 `
  --runtime-dir artifacts\model_level_replay_v1\REPRO_RUN `
  --output artifacts\model_level_replay_v1\REPRO_RUN\FINAL_AUDIT.json
D:\anaconda3\envs\pytorch_env\python.exe scripts\audit_server_ris_replay_parity.py --help
```

完整结论见 `artifacts/model_level_replay_v1/RUNTIME_V1/模型级端到端复刻报告_中文.md`。该执行链只覆盖 V4 雷达自进化资产，不引入 IF 的 VLM/RVFusion；Locked Test 始终不读取。

## 可复现边界

本包复现的是：

```text
Site commissioning
-> result evidence buffering
-> shadow candidate creation
-> frozen audit replay
-> promotion or identity fallback
-> conditional RIS request
```

它不重新训练神经网络，也不声称仅凭这些小型结果文件复现原始模型指标。默认回放仍不加载模型；可选的 live-integration smoke 可绑定外部冻结权重并加载本地 Qwen。无论哪种模式，语言模型都只能给已注册动作排序，只有 `ToolDispatcher` 可以写记忆、执行工具、晋级或回滚。

当前冻结结果反求解只认 V4 自进化雷达链。IF 的 VLM/RVFusion 指标不进入权威配置；
相关辅助代码可以保留，但不能用于解释本包中的 CORA 或专家增益。

## 目录

```text
configs/                 冻结合同、结果源清单、注册工具
docs/contracts/          标签、预测和弱监督谱系的权威说明
snapshot/contracts/      冻结架构和 RIS 合同
snapshot/evidence/       仅结果 JSON/Markdown
snapshot/replay_cases/   七个生命周期回放 episode
src/agent_jsac/          Agent 最小实现
scripts/                 快照、验证、回放和审计入口
tests/                   单元与端到端测试
```

## 标签与预测口径

权威说明见：

- `docs/contracts/cora_evolabel_lineage_contract_zh.md`
- `configs/cora_evolabel_contract.json`

公开名称固定为：

```text
SourceBEV / EmptyGuard / CrossAnchor
RadarCandidateSet / RoutePosterior / RISEcho

BaseBEV -> BaseSeed
AdaptedBEV -> AdaptedTrack
EvolvedBEV -> EvolvedPosterior
RouteBEV -> AgentBEV
```

历史实验编号只允许保存在 `lineage_id` 等审计字段中。模型原始预测不能直接作为
训练标签，必须经过独立物理、时序和 split 审计。

## 运行

安装：

```powershell
D:\anaconda3\envs\pytorch_env\python.exe -m pip install -e .
```

核验冻结结果：

```powershell
D:\anaconda3\envs\pytorch_env\python.exe scripts\verify_snapshot.py
```

生成完整冻结 Agent 配置、结果矩阵和九案例回放：

```powershell
$env:PYTHONPATH='src'
python scripts\verify_frozen_result_agent.py `
  --project-root H:\Project\AGENT-JSAC `
  --output H:\Project\AGENT-JSAC\artifacts\frozen_result_agent_v2
```

回放全部 Agent episode：

```powershell
D:\anaconda3\envs\pytorch_env\python.exe scripts\run_agent_replay.py --all
```

回放统一三闭环 Agent：

```powershell
D:\anaconda3\envs\pytorch_env\python.exe scripts\run_tri_loop_replay.py
```

该命令固定复现：

```text
15帧 10 Hz 感知环
-> 3次 2 Hz 战术决策
-> Episode封存
-> 5步 Shadow / Audit / Promote / Load 进化环
```

输出位于 `artifacts/tri_loop_replay/tri-loop-indoor-clutter/`：

- `tri_loop_events.jsonl`：三个闭环共用的逐事件日志；
- `summary.json`：机器可读最终状态；
- `summary.md`：人类可读摘要。

这是冻结结果级回放，不运行真实神经网络、Qwen推理或训练作业。

### 真实资产接入 Smoke

权威边界见 `docs/contracts/live_asset_and_qwen_integration_zh.md`。先绑定旧 V4 资产根目录：

```powershell
$env:JSAC_V4_ROOT='F:\NET\JSAC-AGENT-V4'
$env:PYTHONPATH='src'
D:\anaconda3\envs\vlm3b\python.exe scripts\verify_live_assets.py
```

验证真实冻结观测流：

```powershell
D:\anaconda3\envs\vlm3b\python.exe scripts\validate_live_observations.py artifacts\live_integration\seq_096_observations.jsonl
```

运行本地 Qwen 受限决策与 Development 三环：

```powershell
D:\anaconda3\envs\vlm3b\python.exe scripts\run_live_tri_loop.py `
  --observations artifacts\live_integration\seq_096_observations.jsonl `
  --model-dir F:\NET\JSAC-AGENT-V4\models\Qwen2.5-0.5B-Instruct `
  --site-id site-outdoor-dry-a `
  --route outdoor_dry_complex `
  --sequence-id seq_096 `
  --split development `
  --device cuda
```

当前 CORA0、SE1、SE2、视觉、Sentinel 和 Qwen 哈希均通过。InternVL Observer 使用实验室服务器冻结 V4 checkpoint，通过仅绑定 localhost 的服务和 SSH 隧道接入；服务或隧道未就绪时不会被当作可用 Observer。

已完成的全链路 Development smoke 使用 `seq_096` 的 15 帧冻结雷达候选、冻结视觉运行结果和 3 次真实 InternVL 推理。受限 Qwen 的三个战术动作依次为：

```text
frame 1  -> CORA-SE2
frame 6  -> bounded_visual_assist
frame 11 -> bounded_visual_assist
```

Development 只运行感知环和战术环，进化事件数严格为 `0`。

执行可复现审计：

```powershell
D:\anaconda3\envs\pytorch_env\python.exe scripts\audit_reproducibility.py
```

运行测试：

```powershell
$env:PYTHONPATH='src'
D:\anaconda3\envs\pytorch_env\python.exe -m pytest -q
```

## 预期结果

- R34C、R24、R55：按冻结审计晋级；
- R54：审计拒绝并保持 CORA-SE2 恒等回退；
- seq106：保持 Identity；
- RIS V21：合同匹配时允许请求，不匹配时拒绝；
- 未晋级候选的执行权重严格为 `0`；
- Locked Test 不进入任何 replay case。

### Qwen 注册工具执行

Qwen 已可在闭集动作合同内请求真实工具。最终控制面覆盖：

```text
commission -> collect -> spawn -> train -> audit -> canary -> promote -> rollback
```

Qwen 不生成命令、路径或训练参数；实际文件写入和子进程只由
`SafetyShield -> ToolDispatcher -> EvolutionToolBackend` 执行。生命周期 LoRA 仅在
`hold / 当前合法阶段动作` 二选一时启用，其他 Agent 决策仍使用原始 Qwen。

完整命令、哈希、负结果和安全边界见：
`docs/status/2026-08-24-qwen-registered-tool-execution.md`。

### Qwen 雷达领域闭环

Qwen 已进一步接入真实 R31/SCAA 领域训练器。Canonical 运行：

```text
artifacts/qwen_scaa_domain_cycle/domain-indoor-clutter-v2-20260824-r2
```

该运行将哈希冻结的 `TECS` 专家语义模板映射到注册 SCAA 实现，完成
`commission -> collect -> spawn -> train -> audit`。审计因 `physical_support=0`
拒绝候选，未进入 Canary，执行权重保持 0 并安全回退 CORA。这是完整工具闭环的
正结果和候选专家的科学 NO-GO，二者不可混写。

独立结果核验入口：

```powershell
python scripts\verify_qwen_scaa_domain_cycle.py `
  --summary artifacts\qwen_scaa_domain_cycle\domain-indoor-clutter-v2-20260824-r2\qwen_tool_cycle_summary.json `
  --split-manifest-sha256 d0f5ec3a76b621a77ab2f2f09390189f9bf3fe1f3c1e554804d0ada9a5a72e64 `
  --semantic-library-sha256 42e67797ed3226a6b342c7e273070438ab06b3fee623a132d05946bff85abd99
```

完整记录见 `docs/status/2026-08-24-qwen-scaa-domain-cycle.md`。
