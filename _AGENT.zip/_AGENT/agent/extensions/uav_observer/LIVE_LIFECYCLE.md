# Observation-Decision Agent: Live Execution Contract

## Existing Evidence

The accepted archive remains immutable. Its UAV training preflight and teacher
handoff are interception/simulation interfaces, not executed training. The new
observer branch has separately verified real image inference, Qwen requests,
persistent memory retrieval, and native radar model inference. These results do
not certify training, teacher quality, adaptation gains or promotion.

## Workflow Binding

Reuse `tasks/uav/workflow.json` and its permitted tools. Keep Human workflows,
metrics and experts independent. UAV has no expert stage. Each tool must return
its own completed result before the workflow advances; language-model output is
only a request. A tool request, prepared command or cached simulated receipt must
never be converted into a successful execution receipt.

The runtime inference menu is separate from the adaptation lifecycle. Source or
unknown sites may use the source model without initiating adaptation. Registered
target sites may use a verified adapted asset. Image content cannot grant model
eligibility, target-label permission or site identity.

## Training Permission and Dependencies

1. Pin the package training implementation, recovered native parameters, manifest,
   source checkpoint, target label artifact and producer receipt hashes.
2. Buffer only permitted support-training episodes. Source supervised replay is
   allowed. Support-development truth is allowed only by the existing UAV
   checkpoint-selection contract, not as target training supervision.
3. Build target labels with the existing radar-only measurement teacher. New VLM
   scene fields are observations for decision-making, not UAV position labels.
4. Require an actual successful teacher process receipt bound to the same parent,
   manifest, output file and producer run. Historical simulated fixture receipts
   are ineligible for this live handoff. Existing genuine historical products may
   be reused only with their actual producer identity, never relabeled as newly
   generated Agent outputs.

   The implemented reuse path is `reuse_uav_teacher.py`: it validates the accepted
   package evidence manifest, native teacher report, adaptation parameters,
   parent/manifest/label hashes and support-training membership, then materializes
   the exact registered CSV. Its receipt explicitly says
   `execution_kind=registered_artifact_reuse`, `new_teacher_inference=false` and
   has no subprocess exit code. A real copy/validation tool is not a new teacher
   inference job and is never reported as one.
5. Compile the native training command without policy overrides. Explicitly limit
   postfit roles to source_development, support_dev and development_query. Never
   rely on historical script defaults that included source_test.
6. The trusted executor, not Qwen, creates subprocesses and the completion receipt.
   Record command, executable/script/input hashes, process identity, exit status,
   timestamps, output hashes, device and resource usage. Failure is not promotion.

## Feedback and Promotion

Qwen receives training/audit summaries only in the phases permitted by the task
contract. Development-query metrics cannot be fed back into teacher construction
or checkpoint selection. Promotion uses the existing task-specific acceptance
rules; it is not inferred from image weather or model confidence alone.

Persist actual tool results and state transitions. Reloaded memory must recover
the same run, state, parent and artifact hashes. An incomplete process is polled,
not restarted because a console wait expired. Missing or mismatched artifacts
stop that branch and retain the registered source fallback.

## Outstanding Live Acceptance

The accepted-label reuse tool has executed successfully on the server for 600
labels. `request_live_training.py` has made a real Qwen tool request and started
native adaptation through `execute_uav_training.py`. This real adaptation has
completed: four epochs, best checkpoint selected at epoch three by Support-dev
OLS 30-70. Its integration scope is
the training stage from registered evidence; it does not yet certify a fresh
source-to-deployment lifecycle. `live_workflow_driver.py` adds durable one-step
advancement and refuses simulated/unbound receipts or unresolved started steps.
It still needs bindings for every live workflow tool before complete-loop use.

`execute_uav_training.py` now provides the live adapter around the accepted
native command compiler. It checks the real teacher handoff, support-training
label membership, exact non-Test postfit roles and the Dispatcher run identity.
It records actual subprocess completion and checkpoint hashes without granting
promotion. The executed entry-point snapshot is retained separately under
`qwen_live_training_acceptance/executed_training_sources`; subsequent hardening
must not be attributed retroactively to that run. Its receipt flags describe the audited code/role
contract, not an independently collected operating-system read trace.

- Bind and execute native buffer/teacher tools under the audited manifest.
- Connect genuine producer receipts to the training entry point.
- Run permitted native adaptation, candidate audit, zero-weight canary and
  promotion/fallback, with Qwen requesting each workflow tool.
- Verify resume behavior and denied cross-task/Test/changed-file cases.
- Package the final independent overlay with pinned external model/data bindings.

The complete lifecycle bindings and acceptance remain pending; the registered
teacher reuse and real training stage are complete. Component tests and historical prediction replay
cannot substitute for this full lifecycle acceptance.

## Completed Training Evidence

The checkpoint SHA256 is
`5b7421d4fbe4d58682e51bee3169941acb08a874b86d6f176cf4ec3b2d8e1844`.
Support-dev OLS 30-70 is `0.5767114295937303`; the initial source score is
`0.4179595381852417`. These are UAV selection metrics, not Human AP.
Postfit Query results are reporting-only and are omitted from the Agent's
selection view. Training success does not authorize deployment. Until a general
numeric promotion profile is explicitly approved, candidate audit must return
`promotion_authorized=false` and retain source fallback.

## Shadow And Recovery Evidence

`probe_training_shadow.py` executed on the server using the three Support-dev
prediction pairs from the completed training (900 frames). It loaded only
prediction arrays and retained byte-value-equivalent source outputs with zero
candidate weight. The receipt is `training_shadow_acceptance/receipt.json`.
This is offline saved-prediction shadow validation, not an online canary or a
quality/promotion test. Hashing the input archives binds their identities; it
does not make their stored truth arrays inputs to the shadow calculation.

`recover_step` resolves an interrupted started step through the backend's
`recover_registered` method using the recorded tool and run ID. It never
resubmits a training command; absent terminal evidence leaves the step pending.
Unit tests cover pending/completed handling. Actual backend recovery bindings
and a server restart/resume acceptance remain to be verified.

## Server Preparation Prefix

`preparation_lifecycle_single_registration/receipt.json` records real CPU Qwen
requests and native TypedMemory writes for six steps: preflight, commissioning,
observe, diagnose, retrieve_memory and buffer_support. The workflow reached
weak_evidence; reloaded ledger equality passed. Observation uses cached real VLM
output. Diagnosis is explicitly an observation summary, not inferred radar
failure. Each of these states has one legal tool, so this proves execution
integration, not comparative decision quality. No training or promotion occurred
in this prefix. The first attempt exposed duplicate site registration and is
retained separately; the successful run registers once after strategy validation.

The same persisted lifecycle was then continued by
`continue_lifecycle_teacher.py`. Real Qwen requested the native registered
teacher-reuse tool through EvolutionToolBackend. The tool materialized and
verified 600 labels, with a fresh run-bound receipt and explicit
`registered_artifact_reuse` identity. The seventh completed step reached
`branch_selection`; it performed no new teacher inference or training. This
continuation does not relabel the earlier independent training run as a child
of this newly materialized receipt.

The same lifecycle subsequently reached `zero_weight_canary` after source-parent
selection, explicit completed-training-product reuse and Support-dev-only audit.
Actual server integration exposed relative producer paths and reserved ledger
hash fields during recovery. The consumer now resolves relative paths against an
explicit trusted artifact root without changing the original receipt, and ledger
completion projects only lifecycle fields before adding a fresh hash-chain entry.
The interrupted read-only verification resumed under its recorded run ID, without
retraining. Query metrics were not included in the Qwen audit summary.

`closure_receipt.json` in the same run records 13 completed real tool steps and
return to `observe`. The canary rechecked 900 prediction pairs. Promotion was
rejected because no general numeric promotion policy was authorized; the real
rollback tool wrote an isolated source-only runtime registry. Restored memory
matched. This proves the reuse-and-rejection lifecycle, not the promotion branch,
fresh end-to-end training, comparative reasoning value, or production deployment.
All earlier immutable training and model evidence retains its original identity.

## Independently Inspectable Invocation

`audited_lifecycle_invocation/invocation_finished.json` records the actual child
process command, UTC start/end, exit code 0, elapsed time 32.2897 s, stdout/stderr
hashes and closure hash. This fresh run again used registered training products;
it did not repeat radar training. The earlier invocation records remain unchanged.

Each `lifecycle/qwen_traces/decision_*.json` records the full pre-scoring prompt,
legal menu, actual conditional log-probability scores, selected tool and model,
tokenizer and native scorer-code hashes. The native scorer appends rotated menu
labels before scoring; its pinned implementation specifies that transformation.
Qwen ranks options with a forward pass rather than generating a free-text answer.
These scores are not calibrated action probabilities. Singleton workflow menus
still demonstrate execution integration, not comparative reasoning or Agent gain.

Support-dev selection evidence is visible at candidate auditing. Postfit Query
metrics are omitted by the selection-view function; the retained full prompts
allow independent review of this exclusion rather than reliance on input hashes.

## Registered Runtime Choices

`audited_runtime_choices/receipt.json` binds two permitted Train episodes to real
server CPU inference and full Qwen score traces. Source episode 5 loaded exact
source U0. Registered target episode 43 offered both source and the previously
promoted adapted model; Qwen selected adapted and its exact registered checkpoint
was loaded. One radar frame was executed per episode without a truth reader.

This is an actual multi-option runtime integration check for the already approved
historical deployment registry. It is not promotion of the new training product,
not a new performance result and not an ablation proving the observer caused
the decision. VLM input is an episode-level cached observation in both cases.
