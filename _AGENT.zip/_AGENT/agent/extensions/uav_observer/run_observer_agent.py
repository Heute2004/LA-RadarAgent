"""One invocation of the registered UAV observation/reuse lifecycle.

All machine paths and task assets come from a hash-approved external config.
This entry point currently validates the rejection/fallback cycle; it does not
authorize a candidate promotion or label cached observations as live inference.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import sys


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--config-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if sha(args.config)!=args.config_sha256: raise ValueError('Unapproved runtime config')
    config=json.loads(args.config.read_text())
    if config['task']!='uav': raise ValueError('Wrong task')
    root=Path(config['artifact_root']).resolve()
    package=Path(config['package_root']).resolve()
    output=args.output.resolve()
    if not output.is_relative_to(root): raise ValueError('Output outside runtime root')
    os.chdir(root)
    sys.path.insert(0,str(package/'src'))
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice,TransformersQwenChoiceScorer
    from agent_jsac.tools.evolution import EvolutionToolBackend
    from lifecycle_runner import run_lifecycle
    from lifecycle_dispatcher import LifecycleDispatcher
    from preparation_tools import PreparationTools
    from post_training_tools import PostTrainingTools
    from uav_observation import bind_condition
    for spec in (config['manifest'],config['responses']):
        if sha(spec['path'])!=spec['sha256']: raise ValueError('Changed input')
    with Path(config['manifest']['path']).open(encoding='utf-8-sig',newline='') as handle:
        rows=list(csv.DictReader(handle))
    matching=[row for row in rows if row['sequence']==config['episode_id']]
    if len(matching)!=1: raise ValueError('Unknown episode')
    row=matching[0]
    if row['outer_split']!='train' or row['agent_role']!='support_train':
        raise ValueError('Only Support-train adaptation is allowed')
    response=next(json.loads(line) for line in Path(config['responses']['path']).read_text().splitlines()
        if json.loads(line)['sequence']==row['sequence'])
    if response['schema_error'] is not None: raise ValueError('Invalid observer record')
    observation=bind_condition(response['prediction'],task='uav',site_id=row['physical_site'],
        episode_id=row['sequence'],observed_at=0,mode='cached',image_sha256=response['image_sha256'],
        observer_sha256=response['model_weights_sha256'])
    output.mkdir(parents=True,exist_ok=False)
    memory=TypedMemory(output/'memory')
    preparation=PreparationTools(rows=rows,memory=memory,observation=observation,
        artifacts={'manifest':config['manifest'],'responses':config['responses']},background=config['background'])
    profile=config['post_training_profile']
    profile.update(site_id=row['physical_site'],episode_id=row['sequence'],runtime_registry=str(output/'runtime_route.json'))
    post=PostTrainingTools(profile,artifact_root=root)
    registry_text=json.dumps(config['teacher_registry']).replace('{run_root}',output.relative_to(root).as_posix())
    registry_path=output/'native_teacher_registry.json'
    registry_path.write_text(registry_text)
    native=EvolutionToolBackend(root,registry_path)

    class TeacherTool:
        def execute_registered(self,tool,payload,*,run_id):
            result=native.execute_registered(tool,payload,run_id=run_id)
            receipt=root/native.tools[tool]['result_json']
            profile['artifacts']['teacher']={'path':str(receipt),'sha256':sha(receipt)}
            return result

    class Monitor:
        def execute_registered(self,tool,payload,*,run_id):
            from agent_jsac.contracts import ToolResult
            route=json.loads(Path(profile['runtime_registry']).read_text())
            valid=(route['task']=='uav' and route['site_id']==row['physical_site']
                and sha(route['checkpoint'])==route['checkpoint_sha256'])
            return ToolResult(valid,'runtime_registry_checked',{'task':'uav','simulation':False,
                'tool_run_id':run_id,'locked_test_read':False,'scope':'registry_health_not_model_inference'})

    handlers={tool:preparation for tool in ('verify_preflight','commission_background','observe_episode',
        'diagnose_condition','retrieve_experience','buffer_support')}
    handlers.update({tool:post for tool in ('select_parent_branch','shadow_train','audit_candidate',
        'zero_weight_canary','promote_or_reject','rollback_identity')})
    handlers.update(construct_weak_evidence=TeacherTool(),monitor_runtime=Monitor())
    backend=LifecycleDispatcher(handlers,output/'tool_receipts')
    workflow=json.loads((package/'tasks/uav/workflow.json').read_text())
    choices=[RankedChoice(tool,tool.replace('_',' '),()) for tool in sorted(handlers)]
    from audited_scorer import AuditedChoiceScorer
    qwen_root=Path(config['qwen'])
    identity={name:sha(qwen_root/name) for name in ('model.safetensors','config.json','tokenizer.json')}
    identity['scorer_source_sha256']=sha(package/'src/agent_jsac/qwen_policy.py')
    scorer=AuditedChoiceScorer(
        TransformersQwenChoiceScorer(qwen_root,device=config.get('qwen_device','cpu')),
        output/'qwen_traces',identity)
    def context(state,mem,last):
        retrieved=any(item.get('tool')=='retrieve_experience' and item.get('step_status')=='completed'
            and item['tool_result']['success'] for item in mem.ledger_records())
        return dict(task='uav',site_id=row['physical_site'],episode_id=row['sequence'],observation=observation,
            now=0,max_age_s=10,radar_health={'status':'not_measured'},memory_summary=mem.episode_records(),
            last_tool_result=last,deployment={'task':'uav','site_id':row['physical_site'],
                'registered':mem.site(row['physical_site']) is not None,'retrieval_complete':retrieved,
                'eligible_models':['source']})
    result=run_lifecycle(workflow=workflow,backend=backend,scorer=scorer,choices=choices,memory=memory,
        context_provider=context,lifecycle_id='observer-adaptation-cycle')
    from lifecycle_outcome import execution_outcome
    result.update(execution_outcome(memory.ledger_records(),'observer-adaptation-cycle'))
    result.update(config_sha256=args.config_sha256,real_qwen_inference=True,vlm_mode='cached',
        scope='single_invocation_registered_uav_lifecycle',locked_test_read=False)
    (output/'closure_receipt.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))


if __name__=='__main__': main()
