"""Task-scoped authorization between model requests and actual inference."""


def authorize_model_request(tool, context):
    mapping = {'infer_source': 'source', 'infer_adapted': 'adapted'}
    deployment = context['deployment']
    alias = mapping.get(tool)
    if deployment.get('task') != 'uav' or alias not in deployment['eligible_models']:
        raise PermissionError('Requested model is not authorized for this deployment')
    if alias not in context['assets']:
        raise PermissionError('Requested model has no verified asset')
    return alias, dict(context['assets'][alias])


def resolve_architecture(config, source_config, source_sha256):
    keys = ('base_channels', 'state_channels', 'attention_heads')
    if all(key in config for key in keys):
        return {key: int(config[key]) for key in keys}
    if config.get('u0_checkpoint_sha256') != source_sha256:
        raise ValueError('Incomplete model config lacks an exact parent binding')
    return {key: int(source_config[key]) for key in keys}
