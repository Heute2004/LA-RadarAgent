"""Audit retained Qwen ranking inputs against request receipts and selection scope."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(data): return hashlib.sha256(data).hexdigest()


def inspect_state(value, path=()):
    if isinstance(value, dict):
        for key, item in value.items():
            location=path+(key,)
            if 'query' in key.lower() or 'test' in key.lower():
                if item is not False:
                    raise ValueError('Unexpected evaluation content at '+'.'.join(location))
            if key == 'metrics':
                if not path or path[-1]!='selection_evidence':
                    raise ValueError('Metric feedback outside selection evidence')
                if value.get('selection_role')!='support_dev':
                    raise ValueError('Metric feedback from wrong role')
                if set(item)!={'ols_mid_map_30_70','ols_coarse_map_20_50','hit_at_1p5m'}:
                    raise ValueError('Unexpected selection metric')
            inspect_state(item,location)
    elif isinstance(value,list):
        for index,item in enumerate(value): inspect_state(item,path+(str(index),))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--invocation',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    root=args.invocation
    invocation=json.loads((root/'invocation_finished.json').read_text())
    closure_path=root/'lifecycle/closure_receipt.json'
    closure=json.loads(closure_path.read_text())
    if invocation['exit_code']!=0 or sha(closure_path.read_bytes())!=invocation['closure_sha256']:
        raise ValueError('No successful bound invocation')
    for name in ('stdout','stderr'):
        if sha((root/(name+'.log')).read_bytes())!=invocation[name+'_sha256']:
            raise ValueError('Changed invocation log')
    ledger_path=root/'lifecycle/memory/QwenDecisionLedger.jsonl'
    rows=[json.loads(line) for line in ledger_path.read_text().splitlines() if line.strip()]
    traces=sorted((root/'lifecycle/qwen_traces').glob('decision_*.json'))
    if len(traces)!=len(rows) or len(rows)!=closure['new_steps']:
        raise ValueError('Unmatched trace or request count')
    bindings=[]
    for path,record in zip(traces,rows):
        trace=json.loads(path.read_text())
        prompt_hash=sha(trace['prompt'].encode('utf-8'))
        request=record['request']
        state=json.loads(trace['prompt'].split('\nSTATE_JSON\n',1)[1])
        if (prompt_hash!=trace['prompt_sha256'] or prompt_hash!=request['decision_input_sha256']
            or trace['selected_tool']!=request['requested_tool']
            or state['state']!=request['state'] or state['task']!='uav'
            or request['executed'] is not False
            or trace['selected_tool']!=max(trace['scores'],key=trace['scores'].__getitem__)
            or set(trace['scores'])!={item['id'] for item in state['legal_tools']}):
            raise ValueError('Input, ranking and request mismatch')
        inspect_state(state)
        bindings.append(dict(file=path.name,sha256=sha(path.read_bytes()),
            state=state['state'],tool=request['requested_tool'],choices=len(trace['scores'])))
    report=dict(task='uav',invocation_id=invocation['invocation_id'],
        invocation_sha256=sha((root/'invocation_finished.json').read_bytes()),
        ledger_sha256=sha(ledger_path.read_bytes()),traces=bindings,
        full_prompt_binding_valid=True,selection_metric_scope_valid=True,
        scope='retained_input_and_request_audit_not_os_data_access_trace',
        singleton_menus=sum(item['choices']==1 for item in bindings),
        comparative_reasoning_verified=False,training_performed=False,locked_test_read=False)
    with args.output.open('x',encoding='utf-8') as handle:
        json.dump(report,handle,indent=2)
    print(json.dumps(report))


if __name__=='__main__': main()
