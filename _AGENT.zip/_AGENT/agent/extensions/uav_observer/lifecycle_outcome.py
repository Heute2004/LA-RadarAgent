"""Summarize actual successful tool receipts, without inventing execution."""
import re


def execution_outcome(records, lifecycle_id):
    result=dict(fresh_training=False, registered_training_reused=False,
                promotion_performed=False)
    for row in records:
        if (row.get('lifecycle_id')!=lifecycle_id
                or row.get('step_status')!='completed'):
            continue
        tool_result=row.get('tool_result',{})
        if tool_result.get('success') is not True:
            continue
        payload=tool_result.get('payload',{})
        if row.get('tool')=='shadow_train':
            result['fresh_training'] |= payload.get('training_performed') is True
            result['registered_training_reused'] |= (
                payload.get('training_performed') is False
                and payload.get('original_training_performed') is True)
        if (row.get('tool')=='promote_or_reject'
                and payload.get('promotion_performed') is True):
            digest=payload.get('runtime_registry_sha256')
            if not isinstance(digest,str) or not re.fullmatch('[a-f0-9]{64}',digest):
                raise ValueError('Promotion lacks a bound registry receipt')
            result['promotion_performed']=True
    return result
