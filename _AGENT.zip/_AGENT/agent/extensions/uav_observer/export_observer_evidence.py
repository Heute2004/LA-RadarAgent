"""Export measured observer evidence without changing labels or inference."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics


def binding(path):
    return {'path':str(path), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--validation',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    metrics_path=args.validation/'metrics.json'
    responses_path=args.validation/'responses.jsonl'
    receipt_path=args.validation/'receipt.json'
    metrics=json.loads(metrics_path.read_text())
    receipt=json.loads(receipt_path.read_text())
    responses=[json.loads(line) for line in responses_path.read_text().splitlines() if line.strip()]
    if (len(responses)!=metrics['images'] or receipt['reviewed_images']!=metrics['images']
        or binding(responses_path)['sha256']!=metrics['responses_sha256']
        or any(r['model_weights_sha256']!=receipt['model_weights_sha256'] for r in responses)
        or receipt['locked_test_read'] is not False):
        raise ValueError('Observer evidence mismatch')
    args.output.mkdir(parents=True,exist_ok=False)
    with (args.output/'field_results.csv').open('x',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=['task','field','images','observed_classes',
            'accuracy','macro_f1_observed_union','annotation_source'])
        writer.writeheader()
        for field,values in metrics['fields'].items():
            writer.writerow(dict(task='uav',field=field,images=metrics['images'],
                observed_classes=len(values['confusion']),accuracy=values['accuracy'],
                macro_f1_observed_union=values['macro_f1_observed_union'],
                annotation_source=metrics['annotation_source']))
    elapsed=sorted(float(row['image_pipeline_s']) for row in responses)
    import math
    if not elapsed or any(not math.isfinite(x) or x<0 for x in elapsed):
        raise ValueError('Invalid measured timing')
    def percentile(fraction):
        index=(len(elapsed)-1)*fraction
        lower=int(index)
        upper=min(lower+1,len(elapsed)-1)
        return elapsed[lower]+(index-lower)*(elapsed[upper]-elapsed[lower])
    report=dict(task='uav',sources=[binding(p) for p in (metrics_path,responses_path,receipt_path)],
        model_weights_sha256=receipt['model_weights_sha256'],images=len(responses),
        episodes=len({row['sequence'] for row in responses}),schema_valid_rate=metrics['schema_valid_rate'],
        timing=dict(scope='recorded_single_image_pipeline',samples=len(elapsed),
            p50_seconds=statistics.median(elapsed),p95_seconds=percentile(.95),
            p95_method='linear_interpolation',min_seconds=min(elapsed),max_seconds=max(elapsed),
            separate_model_load_seconds=receipt['load_s'],warmup_samples_excluded=0,
            full_agent_end_to_end=False,peak_vram_bytes=None),
        annotation_source=metrics['annotation_source'],unseen_site_generalization_verified=False,
        weather_capability_verified=False,agent_gain_measured=False,locked_test_read=False)
    (args.output/'observer_audit.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))


if __name__=='__main__':
    main()
