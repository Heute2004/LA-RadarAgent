"""Compose native handlers with durable per-run receipts; never generate tools."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import re
from agent_jsac.contracts import ToolResult


class LifecycleDispatcher:
    def __init__(self, handlers, receipt_root):
        self.handlers=dict(handlers)
        self.supported_tools=set(handlers)
        self.root=Path(receipt_root)
        self.root.mkdir(parents=True,exist_ok=True)

    def _path(self, tool, run_id):
        if tool not in self.handlers or not re.fullmatch('[a-f0-9]{32}',run_id):
            raise ValueError('Unregistered tool or invalid run identity')
        return self.root/(run_id+'.json')

    def execute_registered(self, tool, payload, *, run_id):
        path=self._path(tool,run_id)
        if path.exists(): raise ValueError('Recorded execution exists; recover it instead')
        result=self.handlers[tool].execute_registered(tool,payload,run_id=run_id)
        value=asdict(result)
        if (value['payload'].get('tool_run_id')!=run_id or value['payload'].get('task')!='uav'
            or value['payload'].get('simulation') is not False
            or value['payload'].get('locked_test_read') is not False):
            raise ValueError('Native result lacks live task binding')
        encoded=json.dumps(value,sort_keys=True,allow_nan=False)
        with path.open('x',encoding='utf-8') as handle:
            json.dump({'tool':tool,'run_id':run_id,'result':value,
                'result_sha256':hashlib.sha256(encoded.encode()).hexdigest()},handle,indent=2)
        return result

    def recover_registered(self, tool, *, run_id):
        path=self._path(tool,run_id)
        if not path.is_file(): return None
        record=json.loads(path.read_text(encoding='utf-8'))
        value=record['result']
        encoded=json.dumps(value,sort_keys=True,allow_nan=False)
        if (record.get('tool')!=tool or record.get('run_id')!=run_id
            or record.get('result_sha256')!=hashlib.sha256(encoded.encode()).hexdigest()
            or value['payload'].get('tool_run_id')!=run_id):
            raise ValueError('Changed or cross-tool recovery receipt')
        return ToolResult(**value)
