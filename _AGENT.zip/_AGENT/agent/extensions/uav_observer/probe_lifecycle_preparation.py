"""Server acceptance of the actual Qwen-driven preparation prefix, not full E2E."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser=argparse.ArgumentParser()
    for name in ('package-root','qwen','manifest','responses','background-receipt','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args()
    sys.path.insert(0,str(args.package_root/'src'))
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice,TransformersQwenChoiceScorer
    from preparation_tools import PreparationTools
    from live_workflow_driver import run_step
    from uav_observation import bind_condition
    pins={'manifest':(args.manifest,'9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2'),
        'responses':(args.responses,'22b9696dac512ea8b010d08901e975d7f3f811bd84b75811d430727a1232f2a6'),
        'background':(args.background_receipt,'c02fff83bf9051156bea09b7873337a1bae1ca6726f230adf71177b99064f94c')}
    for name,(path,digest) in pins.items():
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise ValueError('Changed bound input: '+name)
    with args.manifest.open(encoding='utf-8-sig',newline='') as handle:
        rows=list(csv.DictReader(handle))
    row=next(item for item in rows if int(item['sequence_id'])==43)
    if row['agent_role']!='support_train' or row['outer_split']!='train':
        raise ValueError('Acceptance episode outside Support-train')
    response=next(json.loads(line) for line in args.responses.read_text().splitlines()
        if json.loads(line)['sequence']==row['sequence'])
    if response['schema_error'] is not None:
        raise ValueError('Invalid observer response')
    observation=bind_condition(response['prediction'],task='uav',site_id=row['physical_site'],
        episode_id=row['sequence'],observed_at=0,mode='cached',
        image_sha256=response['image_sha256'],observer_sha256=response['model_weights_sha256'])
    args.output.mkdir(parents=True,exist_ok=False)
    memory=TypedMemory(args.output/'memory')
    backend=PreparationTools(rows=rows,memory=memory,observation=observation,
        artifacts={name:{'path':str(path),'sha256':digest} for name,(path,digest) in pins.items()},
        background={'path':str(args.background_receipt),'sha256':pins['background'][1],
            'manifest_sha256':pins['manifest'][1],
            'source_temporal_report_sha256':'1244000dca875d7bd462eef916672d20d884d39796ab3717df399a2c09e0529c'})
    workflow=json.loads((args.package_root/'tasks/uav/workflow.json').read_text())
    choices=[RankedChoice(tool,tool.replace('_',' '),())
        for tool in sorted({tool for state in workflow['states'].values() for tool in state['allowed_tools']})]
    scorer=TransformersQwenChoiceScorer(args.qwen,device='cpu')
    context=dict(task='uav',site_id=row['physical_site'],episode_id=row['sequence'],
        observation=observation,now=0,max_age_s=10,radar_health={'status':'not_measured'},
        memory_summary=[],last_tool_result=None,
        deployment={'task':'uav','site_id':row['physical_site'],'registered':False,
                    'retrieval_complete':False,'eligible_models':['source']})
    state=workflow['initial_state']
    for _ in range(6):
        state,result=run_step(workflow=workflow,state=state,scorer=scorer,choices=choices,
            context=context,backend=backend,memory=memory,lifecycle_id='preparation-acceptance')
        if not result['success']:
            raise RuntimeError('Preparation failed: '+json.dumps(result))
        context['last_tool_result']=result
        context['memory_summary']=memory.episode_records()
        context['deployment']['registered']=memory.site(row['physical_site']) is not None
        context['deployment']['retrieval_complete']=state in {'buffer_support','weak_evidence'}
        print(json.dumps({'next_state':state}),flush=True)
    restored=TypedMemory(args.output/'memory')
    receipt={'task':'uav','scope':'real_preparation_prefix','real_qwen_inference':True,
        'vlm_mode':'cached','state':state,'tool_steps':6,'single_legal_tool_per_state':True,
        'restored_ledger_equal':restored.ledger_records()==memory.ledger_records(),
        'training_performed':False,'promotion_performed':False,'locked_test_read':False,
        'full_lifecycle_verified':False}
    (args.output/'receipt.json').write_text(json.dumps(receipt,indent=2))
    if state!='weak_evidence' or not receipt['restored_ledger_equal']:
        raise RuntimeError('Preparation acceptance did not reach expected evidence state')


if __name__=='__main__':
    main()
