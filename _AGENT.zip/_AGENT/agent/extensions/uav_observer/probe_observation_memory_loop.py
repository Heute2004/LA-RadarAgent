"""Server component acceptance: real cached VLM, Qwen, memory and tool receipt.

No model selection, training, promotion or sensing evaluation is performed.
The two-step probe is explicitly not the complete Agent lifecycle.
"""

import argparse
import csv
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    for key in ('package-root', 'model', 'manifest', 'responses', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.package_root / 'src'))
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice, TransformersQwenChoiceScorer
    from observation_memory_tools import ObservationMemoryTools
    from qwen_observer_bridge import choose_tool, workflow_choices, next_workflow_state
    from uav_observation import bind_condition

    if args.output.exists():
        raise ValueError('Refuse to overwrite an earlier probe')
    expected = '9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2'
    if hashlib.sha256(args.manifest.read_bytes()).hexdigest() != expected:
        raise ValueError('Non-test manifest differs from audited authority')
    with args.manifest.open(encoding='utf-8-sig', newline='') as handle:
        allowed = {row['sequence']: row for row in csv.DictReader(handle)
                   if row['outer_split'] == 'train'
                   and row['agent_role'] in {'source_supervised_train', 'support_train'}}
    with args.responses.open(encoding='utf-8') as handle:
        response = next(json.loads(line) for line in handle if line.strip())
    identity = allowed.get(response['sequence'])
    if identity is None or response['schema_error'] is not None:
        raise ValueError('Response lacks allowed training identity or valid schema')
    site, episode = identity['physical_site'], identity['sequence']
    observation = bind_condition(response['prediction'], task='uav', site_id=site,
                                 episode_id=episode, observed_at=0, mode='cached',
                                 image_sha256=response['image_sha256'],
                                 observer_sha256=response['model_weights_sha256'])
    args.output.mkdir(parents=True)
    memory = TypedMemory(args.output / 'memory')
    # Registration identity comes from the audited manifest, never from VLM text.
    memory.commission_site(site, {'task': 'uav', 'manifest_sha256': expected,
                                  'mode': 'component_acceptance'})
    scorer = TransformersQwenChoiceScorer(args.model, device='cuda:0')
    workflow_path = args.package_root / 'tasks/uav/workflow.json'
    workflow = json.loads(workflow_path.read_text(encoding='utf-8'))
    registered = [RankedChoice('retrieve_experience', 'Retrieve registered site memory', ()),
                  RankedChoice('buffer_support', 'Request construction of an allowed support buffer', ()),
                  RankedChoice('rollback_identity', 'Request safe fallback after failed retrieval', ())]
    state = 'retrieve_memory'
    choices = workflow_choices(workflow, state, registered)
    request = choose_tool(scorer, choices=choices, task='uav', state=state,
                          site_id=site, episode_id=episode, observation=observation,
                          now=0, max_age_s=10, radar_health={'status': 'not_measured'},
                          memory_summary=[], last_tool_result=None,
                          deployment={'task': 'uav', 'site_id': site, 'registered': True,
                                      'retrieval_complete': False, 'eligible_models': ['source']})
    memory.append_qwen_decision({'task': 'uav', 'site_id': site, 'request': request})
    result = ObservationMemoryTools(memory).execute(request['requested_tool'],
                                                    {'task': 'uav', 'site_id': site})
    memory.append_ledger({'task': 'uav', 'site_id': site, 'episode_id': episode,
                          'probe_only': True, 'tool_result': asdict(result)})
    restored = TypedMemory(args.output / 'memory')
    receipt = restored.ledger_records()[-1]['tool_result']
    next_state = next_workflow_state(workflow, state, request['requested_tool'], receipt)
    next_choices = workflow_choices(workflow, next_state, registered)
    followup = choose_tool(scorer, choices=next_choices, task='uav', state=next_state,
                           site_id=site, episode_id=episode, observation=observation,
                           now=1, max_age_s=10, radar_health={'status': 'not_measured'},
                           memory_summary=receipt['payload'].get('episodes', []),
                           last_tool_result=receipt,
                           deployment={'task': 'uav', 'site_id': site, 'registered': True,
                                       'retrieval_complete': receipt['success'],
                                       'eligible_models': ['source']})
    restored.append_qwen_decision({'task': 'uav', 'site_id': site, 'request': followup,
                                   'not_executed': True})
    report = {'real_qwen_inference': True, 'vlm_mode': 'cached_real_pilot_prediction',
              'tool_result': receipt, 'first_request': request, 'followup_request': followup,
              'restart_receipt_equal': receipt == asdict(result),
              'decision_records': len(restored.qwen_decision_records()),
              'complete_lifecycle_verified': False, 'training_performed': False,
              'sensing_inference_performed': False, 'locked_test_read': False,
              'manifest_sha256': expected,
              'workflow_sha256': hashlib.sha256(workflow_path.read_bytes()).hexdigest(),
              'state_transition': [state, next_state],
              'single_legal_tool_per_state': True, 'decision_quality_experiment': False,
              'response_file_sha256': hashlib.sha256(args.responses.read_bytes()).hexdigest()}
    (args.output / 'receipt.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
