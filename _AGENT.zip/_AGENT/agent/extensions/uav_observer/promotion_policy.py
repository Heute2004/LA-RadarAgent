"""Default-deny numeric promotion policy evaluation.

The policy is an external, hash-bound receipt. This module only evaluates
already-produced Support-dev evidence; it does not train, infer, write a
registry, or perform a promotion.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Any


_POLICY_SCHEMA = "numeric_promotion_policy"
_POLICY_FIELDS = frozenset(
    {"schema", "task", "authorization", "identity", "thresholds"}
)
_AUTHORIZATION_FIELDS = frozenset({"authorized", "task", "split_role"})
_IDENTITY_FIELDS = frozenset(
    {"parent_checkpoint_sha256", "candidate_checkpoint_sha256", "manifest_sha256"}
)
_THRESHOLD_FIELDS = frozenset(
    {"min_mid_gain", "max_coarse_degradation", "max_hit_degradation"}
)
_THRESHOLD_MIN = -1.0
_THRESHOLD_MAX = 1.0
_METRIC_FIELDS = frozenset(
    {"split_role", "ols_mid_map_30_70", "ols_coarse_map_20_50", "hit_at_1p5m"}
)
_SHA256 = re.compile(r"^[a-f0-9]{64}$")


class PromotionPolicyError(ValueError):
    """Internal validation failure converted to a denied decision."""


class _DuplicateKeyError(ValueError):
    pass


@dataclass(frozen=True)
class PromotionDecision:
    """Pure policy judgment; it never claims a registry side effect."""

    allowed: bool
    status: str
    reason: str
    policy_sha256: str | None = None
    registry_written: bool = False
    promotion_performed: bool = False
    identity: dict[str, str] | None = None
    metrics: dict[str, dict[str, float | str]] | None = None
    gates: dict[str, dict[str, Any]] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "status": self.status,
            "reason": self.reason,
            "policy_sha256": self.policy_sha256,
            "registry_written": self.registry_written,
            "promotion_performed": self.promotion_performed,
            "identity": self.identity,
            "metrics": self.metrics,
            "gates": self.gates,
        }


def _is_sha256(value: object) -> bool:
    return isinstance(value, str) and _SHA256.fullmatch(value) is not None


def _is_finite_number(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant: {value}")


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise _DuplicateKeyError(f"duplicate JSON key: {key}")
        value[key] = item
    return value


def _load_external_policy(path: Path, expected_sha256: str) -> tuple[dict[str, Any], str]:
    if not _is_sha256(expected_sha256):
        raise PromotionPolicyError("policy_hash_missing_or_invalid")
    try:
        raw = path.read_bytes()
    except (OSError, TypeError) as error:
        raise PromotionPolicyError("policy_missing_or_unreadable") from error
    actual_sha256 = hashlib.sha256(raw).hexdigest()
    if actual_sha256 != expected_sha256:
        raise PromotionPolicyError("policy_hash_mismatch")
    try:
        value = json.loads(
            raw.decode("utf-8-sig"),
            parse_constant=_reject_constant,
            object_pairs_hook=_reject_duplicate_keys,
        )
    except _DuplicateKeyError as error:
        raise PromotionPolicyError("policy_json_duplicate_key") from error
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise PromotionPolicyError("policy_json_invalid") from error
    if not isinstance(value, dict):
        raise PromotionPolicyError("policy_must_be_an_object")
    return value, actual_sha256


def _validate_policy(policy: Mapping[str, Any]) -> None:
    if set(policy) != _POLICY_FIELDS:
        raise PromotionPolicyError("policy_fields_incomplete_or_unexpected")
    if policy["schema"] != _POLICY_SCHEMA:
        raise PromotionPolicyError("policy_schema_mismatch")
    if policy["task"] != "uav":
        raise PromotionPolicyError("policy_task_mismatch")

    authorization = policy["authorization"]
    if not isinstance(authorization, Mapping) or set(authorization) != _AUTHORIZATION_FIELDS:
        raise PromotionPolicyError("policy_authorization_incomplete")
    if (
        authorization["authorized"] is not True
        or authorization["task"] != "uav"
        or authorization["split_role"] != "support_dev"
    ):
        raise PromotionPolicyError("policy_support_dev_authorization_invalid")

    identity = policy["identity"]
    if not isinstance(identity, Mapping) or set(identity) != _IDENTITY_FIELDS:
        raise PromotionPolicyError("policy_identity_binding_incomplete")
    if not all(_is_sha256(identity[key]) for key in _IDENTITY_FIELDS):
        raise PromotionPolicyError("policy_identity_hash_invalid")

    thresholds = policy["thresholds"]
    if not isinstance(thresholds, Mapping) or set(thresholds) != _THRESHOLD_FIELDS:
        raise PromotionPolicyError("policy_thresholds_incomplete_or_unexpected")
    if not all(_is_finite_number(thresholds[key]) for key in _THRESHOLD_FIELDS):
        raise PromotionPolicyError("policy_threshold_non_finite")
    if not all(
        _THRESHOLD_MIN <= float(thresholds[key]) <= _THRESHOLD_MAX
        for key in _THRESHOLD_FIELDS
    ):
        raise PromotionPolicyError("policy_threshold_out_of_range")


def _validate_authorization(authorization: Mapping[str, Any] | None) -> None:
    if not isinstance(authorization, Mapping):
        raise PromotionPolicyError("missing_authorization")
    if set(authorization) != _AUTHORIZATION_FIELDS:
        raise PromotionPolicyError("authorization_fields_incomplete_or_unexpected")
    if (
        authorization["authorized"] is not True
        or authorization["task"] != "uav"
        or authorization["split_role"] != "support_dev"
    ):
        raise PromotionPolicyError("support_dev_authorization_invalid")


def _validate_identity(
    policy: Mapping[str, Any],
    parent: Mapping[str, Any] | None,
    candidate: Mapping[str, Any] | None,
    manifest: Mapping[str, Any] | None,
) -> dict[str, str]:
    if not isinstance(parent, Mapping) or not _is_sha256(parent.get("checkpoint_sha256")):
        raise PromotionPolicyError("parent_identity_missing_or_invalid")
    if not isinstance(candidate, Mapping) or not _is_sha256(candidate.get("checkpoint_sha256")):
        raise PromotionPolicyError("candidate_identity_missing_or_invalid")
    if not isinstance(manifest, Mapping) or not _is_sha256(manifest.get("manifest_sha256")):
        raise PromotionPolicyError("manifest_identity_missing_or_invalid")

    identity = policy["identity"]
    actual = {
        "parent_checkpoint_sha256": parent["checkpoint_sha256"],
        "candidate_checkpoint_sha256": candidate["checkpoint_sha256"],
        "manifest_sha256": manifest["manifest_sha256"],
    }
    for key, value in actual.items():
        if identity[key] != value:
            raise PromotionPolicyError(f"{key}_mismatch")
    return actual


def _validate_metrics(metrics: Mapping[str, Any] | None, label: str) -> dict[str, float | str]:
    if not isinstance(metrics, Mapping):
        raise PromotionPolicyError(f"missing_{label}_metrics")
    forbidden = {
        str(key)
        for key in metrics
        if any(token in str(key).lower() for token in ("query", "test", "locked"))
    }
    if forbidden:
        raise PromotionPolicyError("query_or_test_metric_forbidden")
    if set(metrics) != _METRIC_FIELDS:
        raise PromotionPolicyError(f"{label}_metrics_incomplete_or_unexpected")
    if metrics["split_role"] != "support_dev":
        raise PromotionPolicyError(f"{label}_metrics_not_support_dev")
    for key in ("ols_mid_map_30_70", "ols_coarse_map_20_50", "hit_at_1p5m"):
        value = metrics[key]
        if not _is_finite_number(value):
            raise PromotionPolicyError(f"{label}_{key}_non_finite")
        if not 0.0 <= float(value) <= 1.0:
            raise PromotionPolicyError(f"{label}_{key}_out_of_range")
    return {
        "split_role": str(metrics["split_role"]),
        "ols_mid_map_30_70": float(metrics["ols_mid_map_30_70"]),
        "ols_coarse_map_20_50": float(metrics["ols_coarse_map_20_50"]),
        "hit_at_1p5m": float(metrics["hit_at_1p5m"]),
    }


def _denied(reason: str, policy_sha256: str | None = None) -> PromotionDecision:
    return PromotionDecision(
        allowed=False,
        status="policy_rejected",
        reason=reason,
        policy_sha256=policy_sha256,
        registry_written=False,
        promotion_performed=False,
    )


def evaluate_promotion(
    *,
    policy_path: str | Path,
    policy_sha256: str,
    authorization: Mapping[str, Any] | None,
    parent: Mapping[str, Any] | None,
    candidate: Mapping[str, Any] | None,
    manifest: Mapping[str, Any] | None,
    parent_metrics: Mapping[str, Any] | None,
    candidate_metrics: Mapping[str, Any] | None,
) -> PromotionDecision:
    """Evaluate an externally authorized Support-dev promotion request.

    No policy values are supplied by this function. Every threshold and every
    identity must be present in the hash-bound external policy and in the
    corresponding runtime evidence.
    """

    try:
        policy, bound_sha256 = _load_external_policy(Path(policy_path), policy_sha256)
        _validate_policy(policy)
        _validate_authorization(authorization)
        policy_authorization = policy["authorization"]
        if dict(authorization) != dict(policy_authorization):
            raise PromotionPolicyError("authorization_policy_mismatch")
        identity = _validate_identity(policy, parent, candidate, manifest)
        parent_value = _validate_metrics(parent_metrics, "parent")
        candidate_value = _validate_metrics(candidate_metrics, "candidate")
        thresholds = policy["thresholds"]
    except (PromotionPolicyError, OSError, TypeError, ValueError) as error:
        policy_sha = policy_sha256 if _is_sha256(policy_sha256) else None
        return _denied(str(error), policy_sha)

    mid_gain = candidate_value["ols_mid_map_30_70"] - parent_value["ols_mid_map_30_70"]
    coarse_degradation = parent_value["ols_coarse_map_20_50"] - candidate_value["ols_coarse_map_20_50"]
    hit_degradation = parent_value["hit_at_1p5m"] - candidate_value["hit_at_1p5m"]
    gates = {
        "mid_gain": {
            "observed": mid_gain,
            "threshold": float(thresholds["min_mid_gain"]),
            "operator": ">=",
            "passed": mid_gain >= thresholds["min_mid_gain"],
        },
        "coarse_degradation": {
            "observed": coarse_degradation,
            "threshold": float(thresholds["max_coarse_degradation"]),
            "operator": "<=",
            "passed": coarse_degradation <= thresholds["max_coarse_degradation"],
        },
        "hit_degradation": {
            "observed": hit_degradation,
            "threshold": float(thresholds["max_hit_degradation"]),
            "operator": "<=",
            "passed": hit_degradation <= thresholds["max_hit_degradation"],
        },
    }
    allowed = all(value["passed"] for value in gates.values())
    return PromotionDecision(
        allowed=allowed,
        status="policy_passed" if allowed else "policy_rejected",
        reason="all_numeric_gates_passed" if allowed else "numeric_gate_failed",
        policy_sha256=bound_sha256,
        registry_written=False,
        promotion_performed=False,
        identity=identity,
        metrics={"parent": parent_value, "candidate": candidate_value},
        gates=gates,
    )


__all__ = ["PromotionDecision", "PromotionPolicyError", "evaluate_promotion"]
