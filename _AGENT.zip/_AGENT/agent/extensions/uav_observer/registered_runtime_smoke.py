"""Run a bounded registered-model runtime smoke without evaluation.

This is a thin adapter around the existing isolated runtime data/model path.
The source-only ``validate_registry`` guard remains unchanged; this entry
accepts an explicitly registered source or adapted model and still requires a
Train support row, exact hashes, CPU execution, and a strict state-dict load.
"""

import argparse
import csv
import json
import re
import sys
import time
from pathlib import Path


_HEX64 = re.compile(r'[a-f0-9]{64}')
_HEX32 = re.compile(r'[a-f0-9]{32}')
_REGISTERED_MODELS = {'source', 'adapted'}
_DEFAULT_ROLES = {'support_train', 'source_supervised_train'}


def validate_registered_registry(record, row, allowed_roles=None):
    roles = _DEFAULT_ROLES if allowed_roles is None else set(allowed_roles)
    if (
        record.get('task') != 'uav'
        or record.get('model') not in _REGISTERED_MODELS
        or record.get('scope') != 'isolated_candidate_runtime'
        or row.get('outer_split') != 'train'
        or row.get('agent_role') not in roles
        or row.get('physical_site') != record.get('site_id')
        or not _HEX64.fullmatch(record.get('checkpoint_sha256', ''))
        or not _HEX32.fullmatch(record.get('tool_run_id', ''))
    ):
        raise ValueError('Unapproved registered runtime, task, site or episode role')
    return dict(record)


def resolve_registered_asset(record, assets):
    alias = record.get('model')
    if alias not in assets:
        raise ValueError('Registered model has no verified asset')
    asset = dict(assets[alias])
    if (
        asset.get('path') != record.get('checkpoint')
        or asset.get('sha256') != record.get('checkpoint_sha256')
    ):
        raise ValueError('Registered model asset does not match its registry')
    return alias, asset


def main():
    parser = argparse.ArgumentParser()
    for name in ('registry', 'manifest', 'package-root', 'source-checkpoint', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--registry-sha256', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--source-checkpoint-sha256', required=True)
    parser.add_argument('--sequence-id', type=int, required=True)
    parser.add_argument('--agent-role', required=True)
    parser.add_argument('--frames', type=int, default=3)
    parser.add_argument('--device', choices=('cpu',), default='cpu')
    args = parser.parse_args()

    if args.output.exists() or args.frames != 3:
        raise ValueError('Runtime smoke requires a fresh output and exactly 3 frames')

    extension_root = args.package_root / 'extensions' / 'uav_observer'
    sys.path.insert(0, str(extension_root))
    sys.path.insert(0, str(args.package_root / 'src'))
    from isolated_registry_runtime import digest
    from runtime_model_request import authorize_model_request, resolve_architecture

    if digest(args.registry) != args.registry_sha256:
        raise ValueError('Changed runtime registry')
    if digest(args.manifest) != args.manifest_sha256:
        raise ValueError('Changed manifest')
    if digest(args.source_checkpoint) != args.source_checkpoint_sha256:
        raise ValueError('Changed source architecture checkpoint')

    with args.manifest.open(encoding='utf-8-sig', newline='') as handle:
        rows = [
            row
            for row in csv.DictReader(handle)
            if int(row['sequence_id']) == args.sequence_id
        ]
    if len(rows) != 1:
        raise ValueError('Episode is not unique in manifest')
    row = rows[0]
    if row.get('agent_role') != args.agent_role:
        raise ValueError('Episode role does not match requested smoke role')

    record = validate_registered_registry(
        json.loads(args.registry.read_text(encoding='utf-8')),
        row,
        allowed_roles={args.agent_role},
    )
    alias, asset = resolve_registered_asset(
        record,
        {record['model']: {
            'path': record['checkpoint'],
            'sha256': record['checkpoint_sha256'],
        }},
    )
    authorized_alias, authorized_asset = authorize_model_request(
        'infer_' + alias,
        {
            'deployment': {
                'task': 'uav',
                'eligible_models': ['source', 'adapted'],
            },
            'assets': {alias: asset},
        },
    )
    if authorized_alias != alias or authorized_asset != asset:
        raise ValueError('Registered model authorization changed')
    if digest(asset['path']) != asset['sha256']:
        raise ValueError('Registered checkpoint changed')

    import numpy as np
    import torch
    from agent_jsac.cora_u_radar_only import (
        CoraURadarOnlyGlobalPolar,
        FrozenUavGlobalPolarInferenceDataset,
        predict_cora_u_global_model,
    )

    torch.set_num_threads(4)
    target_payload = torch.load(asset['path'], map_location='cpu', weights_only=False)
    source_payload = torch.load(
        args.source_checkpoint, map_location='cpu', weights_only=False
    )
    target_config = target_payload['config']
    architecture = resolve_architecture(
        target_config, source_payload['config'], args.source_checkpoint_sha256
    )
    model = CoraURadarOnlyGlobalPolar(**architecture, causal=True).eval()
    model.load_state_dict(target_payload['state_dict'], strict=True)

    norm = target_config.get('source_normalization', source_payload['config']['source_normalization'])
    dataset = FrozenUavGlobalPolarInferenceDataset(
        manifest_path=args.manifest,
        window_size=16,
        temporal_mode='causal',
        channel_mean=tuple(norm['mean']),
        channel_std=tuple(norm['std']),
        allowed_roles={args.agent_role},
        allowed_sequence_ids={args.sequence_id},
    )
    if len(dataset.records) < args.frames:
        raise ValueError('Episode has fewer than 3 runtime frames')
    indices = np.unique(
        np.linspace(0, len(dataset.records) - 1, args.frames, dtype=int)
    )
    if len(indices) != args.frames:
        raise ValueError('Runtime frame selection was not exactly 3 frames')
    dataset.records = [dataset.records[index] for index in indices]

    started = time.perf_counter()
    with torch.inference_mode():
        predictions = predict_cora_u_global_model(
            model, dataset, device=torch.device(args.device), batch_size=1
        )
    elapsed = time.perf_counter() - started
    values = predictions.get(args.sequence_id)
    if not values or any(not np.isfinite(np.asarray(array)).all() for array in values.values()):
        raise ValueError('Non-finite runtime prediction')

    args.output.mkdir(parents=True)
    receipt = {
        'task': 'uav',
        'scope': 'runtime-smoke',
        'model': alias,
        'registered_candidate': alias == 'adapted',
        'checkpoint_sha256': asset['sha256'],
        'source_checkpoint_sha256': args.source_checkpoint_sha256,
        'registry_sha256': args.registry_sha256,
        'route_tool_run_id': record['tool_run_id'],
        'manifest_sha256': args.manifest_sha256,
        'sequence_id': args.sequence_id,
        'agent_role': args.agent_role,
        'frames': len(dataset),
        'prediction_shapes': {
            key: list(np.asarray(array).shape) for key, array in values.items()
        },
        'execution_seconds': elapsed,
        'device': 'server_cpu',
        'strict_state_dict': True,
        'real_radar_inference': True,
        'training_performed': False,
        'truth_read': False,
        'test_payload_read': False,
        'locked_test_read': False,
        'performance_evaluation': False,
        'accuracy_evaluated': False,
        'promotion_performed': False,
        'registry_written': False,
    }
    (args.output / 'receipt.json').write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + '\n', encoding='utf-8'
    )
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
