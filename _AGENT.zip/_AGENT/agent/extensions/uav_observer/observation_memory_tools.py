"""Read-only UAV memory tool backend; no training or promotion authorization.

This backend reuses TypedMemory persistence and the native ToolResult contract.
It must be registered explicitly in the candidate dispatcher, not treated as a
replacement for the sensing training backend.
"""

import hashlib
import json

from agent_jsac.contracts import ToolResult


class ObservationMemoryTools:
    def __init__(self, memory):
        self.memory = memory

    def execute(self, tool_id, payload):
        if tool_id != 'retrieve_experience':
            return ToolResult(False, 'unsupported_tool', {})
        if (not isinstance(payload, dict) or set(payload) != {'task', 'site_id'}
                or payload['task'] != 'uav'
                or not isinstance(payload['site_id'], str) or not payload['site_id'].strip()):
            return ToolResult(False, 'invalid_task_context', {})
        site = self.memory.site(payload['site_id'])
        if site is None:
            return ToolResult(False, 'unregistered_site', {})
        if site.get('task') != payload['task']:
            return ToolResult(False, 'memory_task_mismatch', {})
        episodes = [record for record in self.memory.episode_records()
                    if record.get('task') == payload['task']
                    and record.get('site_id') == payload['site_id']]
        evidence = {'task': payload['task'], 'site_id': payload['site_id'],
                    'site': site, 'episodes': episodes}
        digest = hashlib.sha256(json.dumps(evidence, sort_keys=True, allow_nan=False,
                                           ensure_ascii=False).encode('utf-8')).hexdigest()
        return ToolResult(True, 'memory_retrieved',
                          {**evidence, 'evidence_sha256': digest, 'authorizes_promotion': False})
