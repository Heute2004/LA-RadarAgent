"""UAV lifecycle preparation using audited identities, real memory and files.

Commissioning here registers the deployment identity. It does not manufacture
background measurements. Support buffering builds an index, not new labels.
"""
import hashlib
import json
import re
from pathlib import Path
from agent_jsac.contracts import ToolResult
from observation_memory_tools import ObservationMemoryTools
from uav_registry_context import ROLE_SPLITS
from uav_observation import decision_evidence


class PreparationTools:
    def __init__(self, *, rows, memory, observation, artifacts, now=0, max_age_s=10, background=None):
        self.rows=rows
        self.memory=memory
        self.observation=observation
        self.artifacts=artifacts
        self.now=now
        self.max_age_s=max_age_s
        self.background=background

    def execute_registered(self, tool, payload, *, run_id):
        if (set(payload)!={'task','site_id','episode_id'} or payload['task']!='uav'
            or not re.fullmatch('[a-f0-9]{32}',run_id)):
            raise ValueError('Invalid task or request identity')
        rows=[row for row in self.rows if row['sequence']==payload['episode_id']]
        if len(rows)!=1:
            raise ValueError('Episode identity missing or ambiguous')
        row=rows[0]
        role=row['agent_role']
        if (role not in ROLE_SPLITS or row['outer_split']!=ROLE_SPLITS[role]
            or row['physical_site']!=payload['site_id']):
            raise ValueError('Forbidden split or wrong site')
        result={'task':'uav','tool_run_id':run_id,'simulation':False,'locked_test_read':False}
        success=True
        if tool=='verify_preflight':
            if not self.artifacts:
                raise ValueError('Preflight requires pinned assets')
            checked={}
            for name,spec in self.artifacts.items():
                digest=hashlib.sha256(Path(spec['path']).read_bytes()).hexdigest()
                if digest!=spec['sha256']:
                    raise ValueError('Changed artifact: '+name)
                checked[name]=digest
            result['verified_artifacts']=checked
        elif tool=='commission_background':
            registration={'task':'uav','commissioning_mode':'audited_manifest_registration'}
            # Registration alone cannot satisfy background commissioning.
            success=False
            result.update(background_signal_processed=False,site_registered=True,
                          reason='native_background_commissioning_binding_required')
            if self.background is not None:
                from background_binding import validate_background
                strategy=validate_background(self.background,self.rows)
                registration={'task':'uav',
                    'commissioning_mode':'registered_native_background_strategy',
                    'background_strategy':strategy}
                result.update(background_strategy=strategy,reason='registered_strategy_verified')
                success=True
            self.memory.commission_site(payload['site_id'],registration)
        elif tool=='observe_episode':
            evidence=decision_evidence(self.observation,now=self.now,max_age_s=self.max_age_s,
                site_id=payload['site_id'],episode_id=payload['episode_id'])
            success=evidence['status']=='fresh'
            result.update(observation=evidence,authorizes_promotion=False)
            if success:
                self.memory.append_episode({'task':'uav','site_id':payload['site_id'],
                    'episode_id':payload['episode_id'],'tool_run_id':run_id,
                    'observation':evidence})
        elif tool=='diagnose_condition':
            observations=[item for item in self.memory.episode_records()
                if item.get('task')=='uav' and item.get('site_id')==payload['site_id']
                and item.get('episode_id')==payload['episode_id'] and 'observation' in item]
            success=bool(observations)
            result.update(diagnosis_scope='observed_condition_summary',
                condition=observations[-1]['observation']['condition'] if observations else None,
                radar_failure_inferred=False,requires_memory_retrieval=True,
                authorizes_training=False,authorizes_promotion=False)
        elif tool=='retrieve_experience':
            value=ObservationMemoryTools(self.memory).execute(tool,
                {'task':'uav','site_id':payload['site_id']})
            success=value.success
            result.update(value.payload)
        elif tool=='buffer_support':
            support=[item['sequence'] for item in self.rows
                if item['physical_site']==payload['site_id']
                and item['agent_role']=='support_train' and item['outer_split']=='train']
            if not support or len(support)!=len(set(support)):
                raise ValueError('Support index empty or duplicated')
            result.update(support_episodes=support,buffer_kind='manifest_index',
                labels_generated=False,index_sha256=hashlib.sha256(
                    json.dumps(support,sort_keys=True).encode()).hexdigest())
        else:
            raise ValueError('Unregistered preparation tool: '+tool)
        return ToolResult(success,'preparation_completed' if success else 'preparation_rejected',result)
