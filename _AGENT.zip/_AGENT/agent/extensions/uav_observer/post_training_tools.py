"""Audited UAV product reuse, selection-only feedback and explicit fallback."""
from collections.abc import Mapping
import hashlib
import json
from pathlib import Path
import re
from agent_jsac.contracts import ToolResult
from training_product_reuse import validate_product_metadata
from audit_uav_candidate import selection_view
from live_training_authority import validate_live_handoff
from promotion_policy import evaluate_promotion


_PROMOTION_METRICS = frozenset({
    'ols_mid_map_30_70', 'ols_coarse_map_20_50', 'hit_at_1p5m',
})
_SHA256 = re.compile(r'^[a-f0-9]{64}$')


class PostTrainingTools:
    def __init__(self, profile, *, artifact_root=None):
        self.profile=profile
        self.artifact_root=Path(artifact_root).resolve() if artifact_root else None

    def recover_registered(self, tool, *, run_id):
        if tool not in {'select_parent_branch','shadow_train','audit_candidate'}:
            raise ValueError('Only read-only product verification can be rechecked')
        return self.execute_registered(tool,{'task':'uav','site_id':self.profile['site_id'],
            'episode_id':self.profile['episode_id']},run_id=run_id)

    def _pinned(self, name, *, parse=True):
        spec=self.profile['artifacts'][name]
        data=Path(spec['path']).read_bytes()
        if hashlib.sha256(data).hexdigest()!=spec['sha256']:
            raise ValueError('Changed registered artifact: '+name)
        return json.loads(data) if parse else spec

    def _parent_support_metrics(self, source):
        receipt=self._pinned('parent_support_metrics')
        required={'task','split_role','manifest_sha256',
                  'source_checkpoint_sha256','metrics'}
        if not isinstance(receipt,Mapping) or not required.issubset(receipt):
            raise ValueError('parent_support_metrics_incomplete')
        if receipt.get('task')!='uav' or receipt.get('split_role')!='support_dev':
            raise ValueError('parent_support_metrics_not_support_dev')
        manifest_sha256=self.profile.get('manifest_sha256')
        if (not isinstance(manifest_sha256,str) or not _SHA256.fullmatch(manifest_sha256)
                or receipt['manifest_sha256']!=manifest_sha256):
            raise ValueError('parent_support_metrics_manifest_mismatch')
        if receipt['source_checkpoint_sha256']!=source['sha256']:
            raise ValueError('parent_support_metrics_source_mismatch')
        metrics=receipt['metrics']
        if not isinstance(metrics,Mapping) or set(metrics)!=_PROMOTION_METRICS:
            raise ValueError('parent_support_metrics_incomplete')
        return {'split_role':'support_dev',**dict(metrics)}

    def _audit_evidence(self, audit_payload, source, candidate):
        if (audit_payload.get('execution_kind')!='registered_training_product_reuse'
                or audit_payload.get('simulation') is not False
                or audit_payload.get('locked_test_read') is not False
                or audit_payload.get('profile_sha256')!=self.profile.get('training_profile_sha256')
                or audit_payload.get('candidate_checkpoint_sha256')!=candidate['sha256']):
            raise ValueError('audit_candidate_product_binding_incomplete')
        lineage=audit_payload.get('lineage')
        if (not isinstance(lineage,Mapping)
                or lineage.get('manifest_sha256')!=self.profile.get('manifest_sha256')
                or lineage.get('u0_checkpoint_sha256')!=source['sha256']
                or not _SHA256.fullmatch(str(lineage.get('pseudolabel_sha256','')))):
            raise ValueError('audit_candidate_lineage_mismatch')
        selection=audit_payload.get('selection_evidence')
        if (not isinstance(selection,Mapping)
                or selection.get('selection_role')!='support_dev'
                or selection.get('postfit_query_metrics_exposed') is not False
                or selection.get('promotion_authorized') is not False):
            raise ValueError('audit_candidate_support_dev_binding_incomplete')
        metrics=selection.get('metrics')
        if not isinstance(metrics,Mapping) or set(metrics)!=_PROMOTION_METRICS:
            raise ValueError('audit_candidate_metrics_incomplete')
        return {'candidate_checkpoint_sha256':candidate['sha256'],
                'candidate_metrics':{'split_role':'support_dev',**dict(metrics)},
                'selection_evidence':dict(selection),
                'lineage':dict(lineage)}

    def _validate_canary_identity(self, receipt, source, candidate):
        if (receipt.get('parent_checkpoint_sha256')!=source['sha256']
                or receipt.get('candidate_checkpoint_sha256')!=candidate['sha256']):
            raise ValueError('Canary checkpoint identity is missing or differs')

    def _promotion_rejection(self, run_id, reason, **details):
        payload={'task':'uav','tool_run_id':run_id,'simulation':False,
                 'locked_test_read':False,'promotion_authorized':False,
                 'promotion_performed':False,'reason':reason}
        payload.update(details)
        return ToolResult(False,'promotion_rejected',payload)

    def _promote_or_reject(self, payload, *, run_id):
        artifacts=self.profile.get('artifacts')
        if not isinstance(artifacts,Mapping) or 'promotion_policy' not in artifacts:
            return self._promotion_rejection(
                run_id,'numeric_promotion_policy_not_authorized')
        audit_evidence=None
        canary_evidence=None
        try:
            policy=self._pinned('promotion_policy',parse=False)
            source=self._pinned('source',parse=False)
            candidate=self._pinned('candidate',parse=False)
            parent_metrics=self._parent_support_metrics(source)
            audit=self.execute_registered('audit_candidate',payload,run_id=run_id)
            if not audit.success:
                return self._promotion_rejection(
                    run_id,'audit_candidate_rejected',audit_evidence=audit.payload)
            audit_evidence=self._audit_evidence(audit.payload,source,candidate)
            shadow_receipt=self._pinned('shadow_receipt')
            self._validate_canary_identity(shadow_receipt,source,candidate)
            canary=self.execute_registered('zero_weight_canary',payload,run_id=run_id)
            if not canary.success:
                return self._promotion_rejection(
                    run_id,'zero_weight_canary_rejected',canary_evidence=canary.payload,
                    audit_evidence=audit_evidence)
            canary_evidence=canary.payload
            decision=evaluate_promotion(
                policy_path=policy['path'],policy_sha256=policy['sha256'],
                authorization=self.profile.get('promotion_authorization'),
                parent={'checkpoint_sha256':source['sha256']},
                candidate={'checkpoint_sha256':candidate['sha256']},
                manifest={'manifest_sha256':self.profile.get('manifest_sha256')},
                parent_metrics=parent_metrics,
                candidate_metrics=audit_evidence['candidate_metrics'])
        except (KeyError,TypeError,OSError,ValueError) as error:
            return self._promotion_rejection(
                run_id,str(error),audit_evidence=audit_evidence,
                canary_evidence=canary_evidence)

        decision_payload=decision.to_dict()
        if not decision.allowed:
            return self._promotion_rejection(
                run_id,decision.reason,audit_evidence=audit_evidence,
                canary_evidence=canary_evidence,promotion_decision=decision_payload)

        try:
            registry=Path(self.profile['runtime_registry'])
            record={'task':'uav','site_id':payload['site_id'],'model':'adapted',
                    'checkpoint':candidate['path'],'checkpoint_sha256':candidate['sha256'],
                    'tool_run_id':run_id,'policy_sha256':decision.policy_sha256,
                    'scope':'isolated_candidate_runtime'}
            with registry.open('x',encoding='utf-8') as handle:
                json.dump(record,handle,indent=2,sort_keys=True)
                handle.write('\n')
            registry_sha256=hashlib.sha256(registry.read_bytes()).hexdigest()
        except (KeyError,TypeError,OSError,ValueError) as error:
            return self._promotion_rejection(
                run_id,'runtime_registry_write_failed:'+str(error),
                audit_evidence=audit_evidence,canary_evidence=canary_evidence,
                promotion_decision=decision_payload)

        result={'task':'uav','tool_run_id':run_id,'simulation':False,
                'locked_test_read':False,'promotion_authorized':True,
                'promotion_performed':True,'runtime_registry_written':True,
                'runtime_registry':str(registry),
                'runtime_registry_sha256':registry_sha256,
                'audit_evidence':audit_evidence,'canary_evidence':canary_evidence,
                'promotion_decision':decision_payload}
        return ToolResult(True,'tool_completed',result)

    def execute_registered(self, tool, payload, *, run_id):
        if (payload.get('task')!='uav' or set(payload)!={'task','site_id','episode_id'}
            or payload['site_id']!=self.profile.get('site_id')
            or payload['episode_id']!=self.profile.get('episode_id')
            or not re.fullmatch('[a-f0-9]{32}',run_id)):
            raise ValueError('Unapproved task, site or run identity')
        result={'task':'uav','tool_run_id':run_id,'simulation':False,
                'locked_test_read':False,'promotion_authorized':False}
        success=True
        if tool=='promote_or_reject':
            return self._promote_or_reject(payload,run_id=run_id)
        elif tool=='select_parent_branch':
            source=self._pinned('source',parse=False)
            teacher=self._pinned('teacher')
            if teacher.get('parent_checkpoint_sha256')!=source['sha256']:
                raise ValueError('Teacher belongs to another parent')
            result.update(selected_parent='source',parent_sha256=source['sha256'],
                          selection_basis='registered_source_initialization_contract')
        elif tool in {'shadow_train','audit_candidate'}:
            execution=self._pinned('training_execution')
            native=self._pinned('native_complete')
            teacher=self._pinned('teacher')
            source=self._pinned('source',parse=False)
            candidate=self._pinned('candidate',parse=False)
            for binding in ('source_authority','output'):
                path=Path(teacher[binding]['path'])
                if not path.is_absolute():
                    if self.artifact_root is None:
                        raise ValueError('Relative receipt requires explicit artifact root')
                    path=(self.artifact_root/path).resolve()
                    if not path.is_relative_to(self.artifact_root):
                        raise ValueError('Relative receipt escapes artifact root')
                    teacher[binding]['path']=str(path)
            validate_live_handoff(teacher,parent_sha256=source['sha256'],
                manifest_sha256=self.profile['manifest_sha256'],labels_path=teacher['output']['path'])
            if (execution['checkpoint_sha256']!=candidate['sha256']
                or native['checkpoint_sha256']!=candidate['sha256']):
                raise ValueError('Completed training checkpoint differs')
            lineage={'manifest_sha256':teacher['manifest_sha256'],
                'u0_checkpoint_sha256':source['sha256'],
                'pseudolabel_sha256':teacher['output']['sha256']}
            result.update(validate_product_metadata(execution,native,lineage,self.profile['training_profile_sha256']))
            if tool=='audit_candidate':
                result.update(candidate_checkpoint_sha256=candidate['sha256'])
                result['selection_evidence']=selection_view(native,self._pinned('history'))
            else:
                result.update(candidate_checkpoint_sha256=candidate['sha256'],
                    training_performed=False,original_training_performed=True)
        elif tool=='zero_weight_canary':
            from zero_weight_canary import read_predictions,compare_predictions
            receipt=self._pinned('shadow_receipt')
            if (receipt.get('task')!='uav' or receipt.get('simulation') is not False
                or receipt.get('locked_test_read') is not False or not receipt.get('sequences')):
                raise ValueError('Unapproved shadow receipt')
            pairs=receipt['sequences']
            if sorted(item['sequence_id'] for item in pairs)!=sorted(self.profile['canary_support_sequences']):
                raise ValueError('Canary scope differs from registered Support-dev')
            counts=[]
            for item in pairs:
                for kind in ('source','candidate'):
                    if hashlib.sha256(Path(item[kind+'_path']).read_bytes()).hexdigest()!=item[kind+'_sha256']:
                        raise ValueError('Canary predictions changed')
                _,comparison=compare_predictions(read_predictions(item['source_path']),
                    read_predictions(item['candidate_path']))
                counts.append(comparison['frames'])
            result.update(frames=sum(counts),source_output_exact=True,candidate_weight=0.0,
                scope='offline_saved_prediction_shadow',truth_arrays_loaded=False)
        elif tool=='rollback_identity':
            source=self._pinned('source',parse=False)
            path=Path(self.profile['runtime_registry'])
            record={'task':'uav','site_id':payload['site_id'],'model':'source',
                'checkpoint':source['path'],'checkpoint_sha256':source['sha256'],
                'tool_run_id':run_id,'scope':'isolated_candidate_runtime'}
            with path.open('x',encoding='utf-8') as handle:
                json.dump(record,handle,indent=2)
            result.update(runtime_registry=str(path),selected_model='source',
                runtime_registry_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        else:
            raise ValueError('Unregistered UAV post-training tool: '+tool)
        return ToolResult(success,'tool_completed' if success else 'promotion_rejected',result)
