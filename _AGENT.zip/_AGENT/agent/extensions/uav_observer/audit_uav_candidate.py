"""Expose selection-role evidence, not postfit-query metrics, to the Agent."""
import math


def selection_view(receipt, history):
    if (receipt.get('best_checkpoint_selection_role')!='support_dev'
        or receipt.get('best_checkpoint_selection_metric')!='ols_mid_map_30_70'
        or receipt.get('locked_test_read') is not False
        or receipt.get('development_query_read_for_checkpoint_selection') is not False):
        raise ValueError('Candidate selection authority mismatch')
    selection=receipt['evaluation']['support_dev']
    keys=('ols_mid_map_30_70','ols_coarse_map_20_50','hit_at_1p5m')
    metrics={key:selection[key] for key in keys}
    if any(type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=1 for value in metrics.values()):
        raise ValueError('Selection metrics invalid')
    initial=next(item for item in history if item.get('epoch')==0)
    baseline=initial['support_dev_ols_mid_map_30_70']
    if type(baseline) not in (int,float) or not math.isfinite(baseline) or not 0<=baseline<=1:
        raise ValueError('Parent selection metric invalid')
    if metrics['ols_mid_map_30_70']!=receipt['best_checkpoint_selection_score']:
        raise ValueError('Postfit selection score differs from selected checkpoint score')
    return {'task':'uav','selection_role':'support_dev','metrics':metrics,
            'parent_mid_ols':baseline,'mid_ols_gain':metrics['ols_mid_map_30_70']-baseline,
            'selected_epoch':receipt['best_epoch_by_selection'],
            'promotion_authorized':False,'numeric_promotion_policy_required':True,
            'postfit_query_metrics_exposed':False}
