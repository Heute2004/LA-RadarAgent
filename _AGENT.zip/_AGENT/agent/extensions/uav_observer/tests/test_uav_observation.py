import copy
import unittest

from uav_observation import validate_observation, decision_evidence, build_observer_prompt, bind_condition


def observation():
    return {
        "task": "uav", "site_id": "site_a", "episode_id": "episode_a",
        "observed_at": 100.0, "image_sha256": "a" * 64,
        "observer_sha256": "b" * 64, "mode": "live",
        "condition": {
            "scene_layout": "open", "illumination": "night",
            "visual_condition": "low_light", "weather_evidence": "unknown",
            "observation_quality": "limited", "evidence_summary": "The scene is dark."
        }
    }


class ObservationTests(unittest.TestCase):
    def test_prompt_has_image_and_no_site_answer(self):
        prompt = build_observer_prompt()
        self.assertIn("<image>", prompt)
        self.assertIn("unknown", prompt)
        self.assertNotIn("site_wlhk", prompt)

    def test_model_cannot_write_envelope_identity(self):
        raw = observation()
        condition = raw.pop("condition")
        envelope = dict(raw)
        result = bind_condition(condition, **envelope)
        self.assertEqual(result["site_id"], "site_a")
        condition["site_id"] = "malicious"
        with self.assertRaises(ValueError):
            bind_condition(condition, **envelope)

    def test_valid_and_detached(self):
        raw = observation()
        result = validate_observation(raw)
        result["condition"]["illumination"] = "day"
        self.assertEqual(raw["condition"]["illumination"], "night")

    def test_forbidden_model_route_fields(self):
        for key in ("route", "target_xy", "best_model", "promotion"):
            raw = observation()
            raw["condition"][key] = "adapted"
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_observation(raw)

    def test_wrong_task_and_nonfinite_time(self):
        for key, value in (("task", "human"), ("observed_at", float("nan")),
                           ("observed_at", True), ("image_sha256", "bad")):
            raw = observation()
            raw[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_observation(raw)

    def test_fresh_context_has_no_model_eligibility(self):
        result = decision_evidence(observation(), now=105, max_age_s=10,
                                   site_id="site_a", episode_id="episode_a")
        self.assertEqual(result["status"], "fresh")
        self.assertEqual(result["condition"]["illumination"], "night")
        self.assertNotIn("allowed_models", result)
        self.assertTrue(result["observation_only"])

    def test_stale_future_wrong_site_and_episode_drop_condition(self):
        for changes, now in (({}, 120), ({}, 99), ({"site_id": "other"}, 105),
                             ({"episode_id": "other"}, 105)):
            raw = copy.deepcopy(observation())
            raw.update(changes)
            result = decision_evidence(raw, now=now, max_age_s=10,
                                       site_id="site_a", episode_id="episode_a")
            self.assertNotEqual(result["status"], "fresh")
            self.assertIsNone(result["condition"])

    def test_missing_invalid_and_unusable_are_not_fresh(self):
        unusable = observation()
        unusable["condition"]["observation_quality"] = "unavailable"
        for raw in (None, {}, unusable):
            result = decision_evidence(raw, now=105, max_age_s=10,
                                       site_id="site_a", episode_id="episode_a")
            self.assertIsNone(result["condition"])

    def test_bad_freshness_config_rejected(self):
        for ttl in (-1, 0, float("inf"), True):
            with self.assertRaises(ValueError):
                decision_evidence(observation(), now=105, max_age_s=ttl,
                                  site_id="site_a", episode_id="episode_a")


if __name__ == "__main__":
    unittest.main()
