import unittest
from test_qwen_observer_bridge import Choice, CaptureScorer
from qwen_observer_bridge import workflow_choices, next_workflow_state


class WorkflowBridgeTests(unittest.TestCase):
    def setUp(self):
        self.workflow = {'task': 'uav', 'states': {
            'retrieve_memory': {'allowed_tools': ['retrieve_experience'],
                                'success_transition': 'buffer_support',
                                'failure_transition': 'rollback'},
            'buffer_support': {'allowed_tools': ['buffer_support']},
            'rollback': {'allowed_tools': ['rollback_identity']}}}

    def test_menu_uses_current_workflow_not_probe_options(self):
        choices = [Choice('retrieve_experience', 'Read memory'),
                   Choice('select_parent_branch', 'Choose parent')]
        selected = workflow_choices(self.workflow, 'retrieve_memory', choices)
        self.assertEqual([c.choice_id for c in selected], ['retrieve_experience'])

    def test_success_advances_to_buffer_not_parent_selection(self):
        state = next_workflow_state(self.workflow, 'retrieve_memory',
                                    'retrieve_experience', {'success': True})
        self.assertEqual(state, 'buffer_support')

    def test_failure_is_not_success_and_wrong_tool_cannot_advance(self):
        self.assertEqual(next_workflow_state(self.workflow, 'retrieve_memory',
                         'retrieve_experience', {'success': False}), 'rollback')
        for tool, result in [('shadow_train', {'success': True}),
                             ('retrieve_experience', {'success': 'true'})]:
            with self.assertRaises(ValueError):
                next_workflow_state(self.workflow, 'retrieve_memory', tool, result)


if __name__ == '__main__':
    unittest.main()
