import unittest
import numpy as np
from zero_weight_canary import compare_predictions


class CanaryTests(unittest.TestCase):
    def sample(self):
        return {'frame_id': np.array([0, 1]),
                'prediction_range_m': np.array([2., 3.]),
                'prediction_angle_deg': np.array([1., 2.]),
                'prediction_score': np.array([.8, .9])}

    def test_shadow_does_not_replace_source(self):
        source = self.sample()
        candidate = self.sample()
        candidate['prediction_range_m'] += 1
        output, receipt = compare_predictions(source, candidate)
        np.testing.assert_array_equal(output['prediction_range_m'], source['prediction_range_m'])
        self.assertFalse(receipt['promotion_authorized'])
        self.assertEqual(receipt['frames'], 2)

    def test_mismatched_frames_rejected(self):
        candidate = self.sample()
        candidate['frame_id'] = np.array([1, 2])
        with self.assertRaises(ValueError):
            compare_predictions(self.sample(), candidate)

    def test_nonfinite_shadow_rejected(self):
        candidate = self.sample()
        candidate['prediction_score'][0] = np.nan
        with self.assertRaises(ValueError):
            compare_predictions(self.sample(), candidate)

    def test_duplicate_frames_rejected(self):
        source = self.sample()
        source['frame_id'] = np.array([0, 0])
        with self.assertRaises(ValueError):
            compare_predictions(source, source)
