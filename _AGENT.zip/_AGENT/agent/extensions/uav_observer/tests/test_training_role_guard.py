import tempfile
import unittest
from pathlib import Path
from execute_uav_training import verify_training_label_roles


class TrainingRoleGuardTests(unittest.TestCase):
    def test_role_exclusion_and_duplicates(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            manifest=root/'manifest.csv'
            labels=root/'labels.csv'
            manifest.write_text('sequence_id,agent_role,outer_split\n40,support_train,train\n5,source_test,test\n46,development_query,development\n',encoding='utf-8')
            labels.write_text('sequence_id,frame_id\n40,0\n',encoding='utf-8')
            self.assertEqual(verify_training_label_roles(manifest,labels),1)
            for rows in ['5,0\n','46,0\n','40,0\n40,0\n','40,-1\n']:
                labels.write_text('sequence_id,frame_id\n'+rows,encoding='utf-8')
                with self.assertRaises(PermissionError):
                    verify_training_label_roles(manifest,labels)


if __name__ == '__main__':
    unittest.main()
