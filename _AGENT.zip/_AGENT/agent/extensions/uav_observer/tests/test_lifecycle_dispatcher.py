import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from agent_jsac.contracts import ToolResult
from lifecycle_dispatcher import LifecycleDispatcher


class DispatcherTests(unittest.TestCase):
    def test_persists_result_and_recovers_without_reexecution(self):
        with tempfile.TemporaryDirectory() as directory:
            calls=[]
            def execute(tool,payload,run_id):
                calls.append(tool)
                return ToolResult(True,'done',{'task':'uav','tool_run_id':run_id,
                    'simulation':False,'locked_test_read':False})
            dispatcher=LifecycleDispatcher({'tool':SimpleNamespace(execute_registered=execute)},Path(directory))
            first=dispatcher.execute_registered('tool',{'task':'uav'},run_id='a'*32)
            self.assertEqual(first,dispatcher.recover_registered('tool',run_id='a'*32))
            self.assertEqual(calls,['tool'])

    def test_unregistered_tool_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                LifecycleDispatcher({},Path(directory)).execute_registered('tool',{},run_id='a'*32)
