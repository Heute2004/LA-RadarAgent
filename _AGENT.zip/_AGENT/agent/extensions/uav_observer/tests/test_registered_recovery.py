import tempfile
import json
import unittest
from pathlib import Path
from types import SimpleNamespace
from registered_recovery import RecoverableTools
from agent_jsac.tools.evolution import EvolutionToolBackend


class RecoveryTests(unittest.TestCase):
    def test_native_cpu_tool_recovers_without_second_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'output').mkdir()
            (root/'tool.py').write_text(
                'import json,os\nfrom pathlib import Path\n'
                'with Path("output/count").open("a") as f: f.write("executed\\n")\n'
                'Path("output/receipt.json").write_text(json.dumps({"task":"uav",'
                '"simulation":False,"locked_test_read":False,'
                '"tool_run_id":os.environ["AGENT_JSAC_TOOL_RUN_ID"]}))\n')
            registry={'schema_version':'agent_jsac_registered_tools_v1','evolution_tools':{
                'audit':{'script':'tool.py','fixed_args':[],
                         'result_json':'output/receipt.json','allowed_output_root':'output',
                         'allowed_payload_fields':[],'require_run_id':True}}}
            (root/'registry.json').write_text(json.dumps(registry))
            tools=RecoverableTools(EvolutionToolBackend(root,root/'registry.json'))
            original=tools.execute_registered('audit',{},run_id='a'*32)
            recovered=tools.recover_registered('audit',run_id='a'*32)
            self.assertEqual(original,recovered)
            self.assertEqual((root/'output/count').read_text(),'executed\n')

    def test_missing_receipt_never_executes(self):
        with tempfile.TemporaryDirectory() as directory:
            calls=[]
            backend=SimpleNamespace(project_root=Path(directory),
                tools={'audit':{'result_json':'output/receipt.json','require_run_id':True}},
                execute_registered=lambda *args,**kwargs:calls.append(args))
            self.assertIsNone(RecoverableTools(backend).recover_registered('audit',run_id='a'*32))
            self.assertEqual(calls,[])

    def test_unbound_receipt_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'receipt.json'
            path.write_text('{"tool_run_id":"wrong"}')
            backend=SimpleNamespace(project_root=Path(directory),
                tools={'audit':{'result_json':'receipt.json','require_run_id':True}})
            with self.assertRaises(ValueError):
                RecoverableTools(backend).recover_registered('audit',run_id='a'*32)

    def test_unprotected_registration_rejected(self):
        backend=SimpleNamespace(tools={'audit':{'require_run_id':False}})
        with self.assertRaises(ValueError):
            RecoverableTools(backend)
