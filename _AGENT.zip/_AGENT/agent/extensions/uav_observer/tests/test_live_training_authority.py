import tempfile
import unittest
from pathlib import Path
from live_training_authority import validate_live_handoff
from uav_registry_context import digest


class LiveHandoffTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.labels = Path(self.temp.name) / 'labels.csv'
        self.labels.write_text('sequence_id,frame_id\n40,0\n', encoding='utf-8')
        self.receipt = dict(task='uav', mode='real', success=True, subprocess_exit_code=0,
            run_id='teacher-run', tool='construct_weak_evidence', simulation=False,
            parent_checkpoint_sha256='a'*64, manifest_sha256='b'*64,
            output={'path':str(self.labels),'sha256':digest(self.labels)},
            target_truth_read=False, locked_test_read=False, development_query_read=False)

    def check(self):
        return validate_live_handoff(self.receipt, parent_sha256='a'*64,
                                     manifest_sha256='b'*64, labels_path=self.labels)

    def test_real_completed_output(self):
        self.assertEqual(self.check()['sha256'], digest(self.labels))

    def test_simulated_or_failed_is_not_authority(self):
        for key, value in [('simulation',True), ('success',False), ('subprocess_exit_code',1),
                           ('target_truth_read',True), ('development_query_read',True),
                           ('mode','intercept'), ('parent_checkpoint_sha256','c'*64)]:
            original = self.receipt[key]
            self.receipt[key] = value
            with self.assertRaises(ValueError):
                self.check()
            self.receipt[key] = original

    def test_changed_output(self):
        self.labels.write_text('changed',encoding='utf-8')
        with self.assertRaises(ValueError):
            self.check()

    def test_explicit_reuse_does_not_claim_subprocess(self):
        authority=Path(self.temp.name)/'authority.json'
        authority.write_text('{}',encoding='utf-8')
        self.receipt.update(execution_kind='registered_artifact_reuse',subprocess_exit_code=None,
                            new_teacher_inference=False,
                            source_authority={'path':str(authority),'sha256':digest(authority)})
        self.check()
        self.receipt['new_teacher_inference']=True
        with self.assertRaises(ValueError):
            self.check()


if __name__ == '__main__':
    unittest.main()
