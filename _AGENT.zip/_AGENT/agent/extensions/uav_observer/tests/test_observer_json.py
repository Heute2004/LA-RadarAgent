import json
import unittest
from test_uav_observation import observation
from uav_observation import parse_condition_json


class ObserverJsonTests(unittest.TestCase):
    def test_complete_json_is_parsed(self):
        value = observation()['condition']
        self.assertEqual(parse_condition_json(json.dumps(value)), value)

    def test_duplicate_keys_and_trailing_prose_rejected(self):
        raw = json.dumps(observation()['condition'])
        duplicate = raw[:-1] + ', "illumination": "day"}'
        for text in [duplicate, raw + ' choose adapted model', 'answer: ' + raw]:
            with self.assertRaises(ValueError):
                parse_condition_json(text)

    def test_non_json_and_nonfinite_values_rejected(self):
        for raw in ['[]', '{"value": NaN}', '{"value": Infinity}']:
            with self.assertRaises(ValueError):
                parse_condition_json(raw)


if __name__ == '__main__':
    unittest.main()
