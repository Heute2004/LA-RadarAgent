"""Runtime model authority and native checkpoint compatibility tests."""
import unittest
from runtime_model_request import authorize_model_request, resolve_architecture


class RuntimeModelRequestTests(unittest.TestCase):
    def test_registered_request(self):
        context = {'deployment': {'task': 'uav', 'eligible_models': ['source', 'adapted']},
                   'assets': {'source': {'path': 'source'}, 'adapted': {'path': 'adapted'}}}
        self.assertEqual(authorize_model_request('infer_adapted', context), ('adapted', {'path': 'adapted'}))

    def test_no_visual_permission_escalation(self):
        context = {'deployment': {'task': 'uav', 'eligible_models': ['source']},
                   'assets': {'source': {'path': 'source'}, 'adapted': {'path': 'adapted'}}}
        with self.assertRaises(PermissionError):
            authorize_model_request('infer_adapted', context)

    def test_cross_task_and_unknown_tool(self):
        for task, tool in [('human', 'infer_source'), ('uav', 'train_expert')]:
            with self.assertRaises(PermissionError):
                authorize_model_request(tool, {'deployment': {'task': task, 'eligible_models': ['source']},
                                               'assets': {'source': {'path': 'source'}}})

    def test_adapted_uses_bound_source_architecture(self):
        source = {'base_channels': 8, 'state_channels': 16, 'attention_heads': 4}
        self.assertEqual(resolve_architecture({'u0_checkpoint_sha256': 'a'}, source, 'a'), source)
        with self.assertRaises(ValueError):
            resolve_architecture({'u0_checkpoint_sha256': 'b'}, source, 'a')


if __name__ == '__main__':
    unittest.main()
