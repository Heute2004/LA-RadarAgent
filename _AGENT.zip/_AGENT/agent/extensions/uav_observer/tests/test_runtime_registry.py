import unittest
from isolated_registry_runtime import validate_registry


class RegistryValidationTest(unittest.TestCase):
    def setUp(self):
        self.record = dict(task='uav', site_id='site', model='source',
                           checkpoint='/models/source.pt', checkpoint_sha256='a'*64,
                           scope='isolated_candidate_runtime', tool_run_id='b'*32)
        self.row = dict(physical_site='site', outer_split='train', agent_role='support_train')

    def test_registered_source(self):
        self.assertEqual(validate_registry(self.record, self.row)['model'], 'source')

    def test_test_and_wrong_site_rejected(self):
        for changes in ({'outer_split':'test'}, {'agent_role':'source_test'},
                        {'physical_site':'another'}):
            with self.assertRaises(ValueError):
                validate_registry(self.record, dict(self.row, **changes))

    def test_unapproved_adapted_rejected(self):
        with self.assertRaises(ValueError):
            validate_registry(dict(self.record, model='adapted'), self.row)

    def test_cross_task_rejected(self):
        with self.assertRaises(ValueError):
            validate_registry(dict(self.record, task='human'), self.row)
