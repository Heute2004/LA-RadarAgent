import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from registered_runtime_smoke import (
    resolve_registered_asset,
    validate_registered_registry,
)


class RegisteredRuntimeSmokeTest(unittest.TestCase):
    def setUp(self):
        self.record = dict(
            task='uav',
            site_id='site_scut14',
            model='adapted',
            checkpoint='/models/adapted.pt',
            checkpoint_sha256='a' * 64,
            scope='isolated_candidate_runtime',
            tool_run_id='b' * 32,
        )
        self.row = dict(
            physical_site='site_scut14',
            outer_split='train',
            agent_role='support_train',
        )

    def test_unknown_site_is_rejected(self):
        with self.assertRaises(ValueError):
            validate_registered_registry(
                self.record, dict(self.row, physical_site='unknown_site')
            )

    def test_source_registry_stays_source(self):
        record = dict(
            self.record,
            model='source',
            checkpoint='/models/source.pt',
            checkpoint_sha256='c' * 64,
        )
        validated = validate_registered_registry(record, self.row)
        alias, asset = resolve_registered_asset(
            validated,
            {
                'source': {'path': '/models/source.pt', 'sha256': 'c' * 64},
                'adapted': {'path': '/models/adapted.pt', 'sha256': 'a' * 64},
            },
        )
        self.assertEqual(alias, 'source')
        self.assertEqual(asset['path'], '/models/source.pt')

    def test_registered_adapted_model_is_allowed(self):
        self.assertEqual(
            validate_registered_registry(self.record, self.row)['model'],
            'adapted',
        )
