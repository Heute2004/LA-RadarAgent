import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from audited_scorer import AuditedChoiceScorer


class AuditedScorerTest(unittest.TestCase):
    def test_real_delegate_trace(self):
        class Delegate:
            last_scores = {'keep': -0.2}
            last_adapter_active = False
            def choose(self, prompt, choices):
                return 'keep'
        with tempfile.TemporaryDirectory() as directory:
            scorer=AuditedChoiceScorer(Delegate(), Path(directory)/'traces', {'weights_sha256':'a'*64})
            self.assertEqual(scorer.choose('allowed evidence', [SimpleNamespace(choice_id='keep',description_zh='keep')]),'keep')
            trace=json.loads((Path(directory)/'traces/decision_0001.json').read_text())
            self.assertEqual(trace['prompt_sha256'],hashlib.sha256(b'allowed evidence').hexdigest())
            self.assertEqual(trace['prompt'],'allowed evidence')
            self.assertEqual(trace['scores'],{'keep':-0.2})
            self.assertEqual(trace['selected_tool'],'keep')
            self.assertFalse(trace['free_text_generation'])

    def test_unbound_scores_rejected(self):
        class Delegate:
            last_scores = {}
            def choose(self, prompt, choices): return 'keep'
        with tempfile.TemporaryDirectory() as directory:
            scorer=AuditedChoiceScorer(Delegate(),Path(directory)/'traces',{})
            with self.assertRaises(ValueError):
                scorer.choose('state',[SimpleNamespace(choice_id='keep',description_zh='keep')])
