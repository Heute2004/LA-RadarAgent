import tempfile
import unittest
from pathlib import Path

from agent_jsac.memory import TypedMemory
from observation_memory_tools import ObservationMemoryTools


class MemoryToolTests(unittest.TestCase):
    def test_retrieval_uses_persisted_task_scoped_memory(self):
        with tempfile.TemporaryDirectory() as directory:
            memory = TypedMemory(Path(directory))
            memory.commission_site('yard', {'task': 'uav', 'context': 'registered site'})
            memory.append_episode({'task': 'uav', 'site_id': 'yard', 'episode_id': 'old'})
            memory.append_episode({'task': 'human', 'site_id': 'yard', 'episode_id': 'wrong'})
            tool = ObservationMemoryTools(TypedMemory(Path(directory)))
            result = tool.execute('retrieve_experience', {'task': 'uav', 'site_id': 'yard'})
            self.assertTrue(result.success)
            self.assertEqual([x['episode_id'] for x in result.payload['episodes']], ['old'])
            self.assertEqual(result.status, 'memory_retrieved')
            self.assertNotIn('eligible_models', result.payload)

    def test_cross_task_site_is_not_reported_as_success(self):
        with tempfile.TemporaryDirectory() as directory:
            memory = TypedMemory(Path(directory))
            memory.commission_site('yard', {'task': 'human'})
            result = ObservationMemoryTools(memory).execute(
                'retrieve_experience', {'task': 'uav', 'site_id': 'yard'})
            self.assertFalse(result.success)

    def test_unknown_site_and_unsupported_action_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            tool = ObservationMemoryTools(TypedMemory(Path(directory)))
            for action in ['retrieve_experience', 'shadow_train']:
                result = tool.execute(action, {'task': 'uav', 'site_id': 'unknown'})
                self.assertFalse(result.success)


if __name__ == '__main__':
    unittest.main()
