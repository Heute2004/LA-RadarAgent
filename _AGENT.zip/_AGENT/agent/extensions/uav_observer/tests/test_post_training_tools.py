import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np


_WORKSPACE = Path(__file__).resolve().parents[1]
_PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(_WORKSPACE))
sys.path.insert(
    0,
    str(_PROJECT_ROOT / "candidates" / "Observation-Decision-Agent" / "src"),
)

from post_training_tools import PostTrainingTools


RUN_ID = "a" * 32


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class SyntheticPromotionFixture:
    def __init__(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.registry = self.root / "runtime_registry.json"
        self.manifest = self.root / "support_dev_manifest.csv"
        self.manifest.write_text("sequence_id,agent_role\n1,support_dev\n", encoding="utf-8")
        self.source = self.root / "parent.pt"
        self.source.write_bytes(b"synthetic-parent-checkpoint")
        self.candidate = self.root / "candidate.pt"
        self.candidate.write_bytes(b"synthetic-candidate-checkpoint")
        self.labels = self.root / "teacher_labels.csv"
        self.labels.write_text("frame_id,label\n0,0\n", encoding="utf-8")
        self.source_sha256 = _sha256(self.source)
        self.candidate_sha256 = _sha256(self.candidate)
        self.manifest_sha256 = _sha256(self.manifest)
        self.labels_sha256 = _sha256(self.labels)
        self.training_profile = self.root / "training_profile.json"
        self.training_profile.write_text("{\"synthetic\":true}\n", encoding="utf-8")
        self.training_profile_sha256 = _sha256(self.training_profile)
        self.prediction_source = self.root / "source_predictions.npz"
        self.prediction_candidate = self.root / "candidate_predictions.npz"
        prediction = {
            "frame_id": np.array([0, 1]),
            "prediction_range_m": np.array([2.0, 3.0]),
            "prediction_angle_deg": np.array([1.0, 2.0]),
            "prediction_score": np.array([0.8, 0.9]),
        }
        np.savez_compressed(self.prediction_source, **prediction)
        np.savez_compressed(self.prediction_candidate, **prediction)
        self._write_receipts()
        self._write_policy()

    def close(self):
        self.temp.cleanup()

    def spec(self, path):
        return {"path": str(path), "sha256": _sha256(path)}

    def _write_receipts(self):
        self.teacher = self.root / "teacher_receipt.json"
        teacher = {
            "task": "uav",
            "mode": "real",
            "tool": "construct_weak_evidence",
            "parent_checkpoint_sha256": self.source_sha256,
            "manifest_sha256": self.manifest_sha256,
            "success": True,
            "execution_kind": "registered_artifact_reuse",
            "subprocess_exit_code": None,
            "new_teacher_inference": False,
            "source_authority": {
                "path": str(self.source),
                "sha256": self.source_sha256,
            },
            "output": {"path": str(self.labels), "sha256": self.labels_sha256},
            "run_id": RUN_ID,
            "simulation": False,
            "target_truth_read": False,
            "locked_test_read": False,
            "development_query_read": False,
        }
        self.teacher.write_text(json.dumps(teacher, sort_keys=True), encoding="utf-8")

        self.training_execution = self.root / "training_execution.json"
        execution = {
            "task": "uav",
            "mode": "real",
            "success": True,
            "simulation": False,
            "training_performed": True,
            "subprocess_exit_code": 0,
            "profile_sha256": self.training_profile_sha256,
            "checkpoint_sha256": self.candidate_sha256,
        }
        self.training_execution.write_text(
            json.dumps(execution, sort_keys=True), encoding="utf-8"
        )

        self.native_complete = self.root / "native_complete.json"
        native = {
            "task": "uav",
            "checkpoint_sha256": self.candidate_sha256,
            "manifest_sha256": self.manifest_sha256,
            "u0_checkpoint_sha256": self.source_sha256,
            "pseudolabel_sha256": self.labels_sha256,
            "best_checkpoint_selection_role": "support_dev",
            "best_checkpoint_selection_metric": "ols_mid_map_30_70",
            "best_checkpoint_selection_score": 0.60,
            "best_epoch_by_selection": 1,
            "locked_test_read": False,
            "target_ground_truth_used_for_training": False,
            "target_truth_read_for_pseudolabels": False,
            "support_dev_read_for_training_loss": False,
            "development_query_read_for_checkpoint_selection": False,
            "development_query_read": False,
            "evaluation": {
                "support_dev": {
                    "ols_mid_map_30_70": 0.60,
                    "ols_coarse_map_20_50": 0.71,
                    "hit_at_1p5m": 0.61,
                }
            },
        }
        self.native_complete.write_text(
            json.dumps(native, sort_keys=True), encoding="utf-8"
        )

        self.history = self.root / "train_history.json"
        self.history.write_text(
            json.dumps(
                [{"epoch": 0, "support_dev_ols_mid_map_30_70": 0.50}],
                sort_keys=True,
            ),
            encoding="utf-8",
        )

        self.parent_support_metrics = self.root / "parent_support_metrics.json"
        parent_metrics = {
            "task": "uav",
            "split_role": "support_dev",
            "manifest_sha256": self.manifest_sha256,
            "source_checkpoint_sha256": self.source_sha256,
            "metrics": {
                "ols_mid_map_30_70": 0.50,
                "ols_coarse_map_20_50": 0.70,
                "hit_at_1p5m": 0.60,
            },
        }
        self.parent_support_metrics.write_text(
            json.dumps(parent_metrics, sort_keys=True), encoding="utf-8"
        )

        self.shadow_receipt = self.root / "shadow_receipt.json"
        shadow = {
            "task": "uav",
            "scope": "offline_saved_prediction_shadow",
            "simulation": False,
            "locked_test_read": False,
            "promotion_authorized": False,
            "parent_checkpoint_sha256": self.source_sha256,
            "candidate_checkpoint_sha256": self.candidate_sha256,
            "sequences": [
                {
                    "task": "uav",
                    "scope": "offline_saved_prediction_shadow",
                    "sequence_id": 1,
                    "candidate_weight": 0.0,
                    "source_output_exact": True,
                    "truth_arrays_loaded": False,
                    "source_path": str(self.prediction_source),
                    "source_sha256": _sha256(self.prediction_source),
                    "candidate_path": str(self.prediction_candidate),
                    "candidate_sha256": _sha256(self.prediction_candidate),
                }
            ],
        }
        self.shadow_receipt.write_text(
            json.dumps(shadow, sort_keys=True), encoding="utf-8"
        )

    def _write_policy(self):
        self.policy = self.root / "promotion_policy.json"
        policy = {
            "schema": "numeric_promotion_policy",
            "task": "uav",
            "authorization": {
                "authorized": True,
                "task": "uav",
                "split_role": "support_dev",
            },
            "identity": {
                "parent_checkpoint_sha256": self.source_sha256,
                "candidate_checkpoint_sha256": self.candidate_sha256,
                "manifest_sha256": self.manifest_sha256,
            },
            "thresholds": {
                "min_mid_gain": 0.05,
                "max_coarse_degradation": 0.02,
                "max_hit_degradation": 0.02,
            },
        }
        self.policy.write_text(
            json.dumps(policy, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )

    def profile(self):
        return {
            "site_id": "synthetic-site",
            "episode_id": "synthetic-episode",
            "manifest_sha256": self.manifest_sha256,
            "training_profile_sha256": self.training_profile_sha256,
            "canary_support_sequences": [1],
            "runtime_registry": str(self.registry),
            "promotion_authorization": {
                "authorized": True,
                "task": "uav",
                "split_role": "support_dev",
            },
            "artifacts": {
                "source": self.spec(self.source),
                "teacher": self.spec(self.teacher),
                "candidate": self.spec(self.candidate),
                "native_complete": self.spec(self.native_complete),
                "history": self.spec(self.history),
                "training_execution": self.spec(self.training_execution),
                "parent_support_metrics": self.spec(self.parent_support_metrics),
                "shadow_receipt": self.spec(self.shadow_receipt),
                "promotion_policy": self.spec(self.policy),
            },
        }


class PostTrainingTests(unittest.TestCase):
    def setUp(self):
        self.fixture = SyntheticPromotionFixture()
        self.addCleanup(self.fixture.close)

    def test_wrong_task_never_reads_assets(self):
        with self.assertRaises(ValueError):
            PostTrainingTools({}).execute_registered(
                "shadow_train",
                {"task": "human", "site_id": "x", "episode_id": "y"},
                run_id=RUN_ID,
            )

    def test_missing_promotion_policy_preserves_old_rejection(self):
        profile = {"site_id": "x", "episode_id": "y"}
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": "x", "episode_id": "y"},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertFalse(result.payload["promotion_authorized"])
        self.assertEqual(result.payload["reason"], "numeric_promotion_policy_not_authorized")

    def test_no_expert_tool_for_uav(self):
        with self.assertRaises(ValueError):
            PostTrainingTools({"site_id": "x", "episode_id": "y"}).execute_registered(
                "train_expert",
                {"task": "uav", "site_id": "x", "episode_id": "y"},
                run_id=RUN_ID,
            )

    def test_canary_requires_bound_prediction_receipt(self):
        with self.assertRaises(KeyError):
            PostTrainingTools(
                {"site_id": "x", "episode_id": "y", "artifacts": {}}
            ).execute_registered(
                "zero_weight_canary",
                {"task": "uav", "site_id": "x", "episode_id": "y"},
                run_id=RUN_ID,
            )

    def test_successful_promotion_writes_adapted_isolated_registry(self):
        profile = self.fixture.profile()
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {
                "task": "uav",
                "site_id": profile["site_id"],
                "episode_id": profile["episode_id"],
            },
            run_id=RUN_ID,
        )
        self.assertTrue(result.success)
        self.assertTrue(result.payload["promotion_authorized"])
        self.assertTrue(result.payload["promotion_performed"])
        self.assertRegex(result.payload["runtime_registry_sha256"], r"^[a-f0-9]{64}$")
        record = json.loads(self.fixture.registry.read_text(encoding="utf-8"))
        self.assertEqual(record["model"], "adapted")
        self.assertEqual(record["checkpoint"], str(self.fixture.candidate))
        self.assertEqual(record["checkpoint_sha256"], self.fixture.candidate_sha256)
        self.assertEqual(record["site_id"], profile["site_id"])
        self.assertEqual(record["tool_run_id"], RUN_ID)
        self.assertEqual(record["policy_sha256"], _sha256(self.fixture.policy))
        self.assertEqual(record["scope"], "isolated_candidate_runtime")
        self.assertEqual(
            result.payload["audit_evidence"]["candidate_checkpoint_sha256"],
            self.fixture.candidate_sha256,
        )
        self.assertEqual(result.payload["canary_evidence"]["candidate_weight"], 0.0)

    def test_audit_allows_postfit_query_but_exposes_only_support_dev(self):
        profile = self.fixture.profile()
        native = json.loads(self.fixture.native_complete.read_text())
        native["development_query_read"] = True
        native["evaluation"]["development_query"] = {
            "ols_mid_map_30_70": 0.99,
            "query_only_marker": 1.0,
        }
        self.fixture.native_complete.write_text(
            json.dumps(native, sort_keys=True), encoding="utf-8"
        )
        profile["artifacts"]["native_complete"] = self.fixture.spec(
            self.fixture.native_complete
        )
        result = PostTrainingTools(profile).execute_registered(
            "audit_candidate",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertTrue(result.success)
        evidence = result.payload["selection_evidence"]
        self.assertEqual(evidence["selection_role"], "support_dev")
        self.assertFalse(evidence["postfit_query_metrics_exposed"])
        self.assertNotIn("development_query", evidence)
        self.assertNotIn("query_only_marker", evidence)

    def test_missing_parent_metric_rejects_without_registry(self):
        profile = self.fixture.profile()
        receipt = json.loads(self.fixture.parent_support_metrics.read_text())
        del receipt["metrics"]["hit_at_1p5m"]
        self.fixture.parent_support_metrics.write_text(
            json.dumps(receipt, sort_keys=True), encoding="utf-8"
        )
        profile["artifacts"]["parent_support_metrics"] = self.fixture.spec(
            self.fixture.parent_support_metrics
        )
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertFalse(result.payload["promotion_authorized"])
        self.assertFalse(self.fixture.registry.exists())
        self.assertEqual(result.payload["reason"], "parent_support_metrics_incomplete")

    def test_parent_metric_source_identity_mismatch_rejects(self):
        profile = self.fixture.profile()
        receipt = json.loads(self.fixture.parent_support_metrics.read_text())
        receipt["source_checkpoint_sha256"] = "f" * 64
        self.fixture.parent_support_metrics.write_text(
            json.dumps(receipt, sort_keys=True), encoding="utf-8"
        )
        profile["artifacts"]["parent_support_metrics"] = self.fixture.spec(
            self.fixture.parent_support_metrics
        )
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertEqual(result.payload["reason"], "parent_support_metrics_source_mismatch")
        self.assertFalse(self.fixture.registry.exists())

    def _profile_with_legacy_canary_receipt(self):
        profile = self.fixture.profile()
        receipt = json.loads(self.fixture.shadow_receipt.read_text())
        del receipt["parent_checkpoint_sha256"]
        del receipt["candidate_checkpoint_sha256"]
        self.fixture.shadow_receipt.write_text(
            json.dumps(receipt, sort_keys=True), encoding="utf-8"
        )
        profile["artifacts"]["shadow_receipt"] = self.fixture.spec(self.fixture.shadow_receipt)
        return profile

    def test_zero_weight_canary_keeps_legacy_saved_prediction_path(self):
        profile = self._profile_with_legacy_canary_receipt()
        result = PostTrainingTools(profile).execute_registered(
            "zero_weight_canary",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertTrue(result.success)
        self.assertTrue(result.payload["source_output_exact"])
        self.assertEqual(result.payload["candidate_weight"], 0.0)

    def test_promotion_rejects_legacy_canary_without_checkpoint_identity(self):
        profile = self._profile_with_legacy_canary_receipt()
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertFalse(result.payload["promotion_authorized"])
        self.assertFalse(result.payload["promotion_performed"])
        self.assertFalse(self.fixture.registry.exists())
        self.assertIn("Canary checkpoint identity", result.payload["reason"])

    def test_canary_file_hash_is_still_required(self):
        profile = self.fixture.profile()
        prediction = self.fixture.prediction_candidate
        prediction.write_bytes(prediction.read_bytes() + b"changed")
        with self.assertRaises(ValueError) as context:
            PostTrainingTools(profile).execute_registered(
                "zero_weight_canary",
                {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
                run_id=RUN_ID,
            )
        self.assertIn("Canary predictions changed", str(context.exception))

    def test_policy_hash_mismatch_rejects_without_registry(self):
        profile = self.fixture.profile()
        profile["artifacts"]["promotion_policy"]["sha256"] = "0" * 64
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertFalse(result.payload["promotion_authorized"])
        self.assertFalse(self.fixture.registry.exists())
        self.assertEqual(result.payload["reason"], "Changed registered artifact: promotion_policy")

    def test_failed_numeric_policy_does_not_write_registry(self):
        profile = self.fixture.profile()
        policy = json.loads(self.fixture.policy.read_text())
        policy["thresholds"]["min_mid_gain"] = 0.11
        self.fixture.policy.write_text(
            json.dumps(policy, sort_keys=True, separators=(",", ":")), encoding="utf-8"
        )
        profile["artifacts"]["promotion_policy"] = self.fixture.spec(self.fixture.policy)
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertFalse(result.payload["promotion_authorized"])
        self.assertFalse(result.payload["promotion_performed"])
        self.assertFalse(self.fixture.registry.exists())
        self.assertEqual(result.payload["reason"], "numeric_gate_failed")

    def test_policy_pass_without_exclusive_registry_write_is_not_promotion(self):
        profile = self.fixture.profile()
        self.fixture.registry.write_text("existing", encoding="utf-8")
        result = PostTrainingTools(profile).execute_registered(
            "promote_or_reject",
            {"task": "uav", "site_id": profile["site_id"], "episode_id": profile["episode_id"]},
            run_id=RUN_ID,
        )
        self.assertFalse(result.success)
        self.assertFalse(result.payload["promotion_authorized"])
        self.assertFalse(result.payload["promotion_performed"])
        self.assertTrue(result.payload["promotion_decision"]["allowed"])
        self.assertEqual(result.payload["reason"].split(":", 1)[0], "runtime_registry_write_failed")
        self.assertEqual(self.fixture.registry.read_text(encoding="utf-8"), "existing")
