import unittest
from preparation_tools import PreparationTools


class Memory:
    def __init__(self): self.sites={}; self.episodes=[]
    def commission_site(self,key,value): self.sites[key]=value
    def site(self,key): return self.sites.get(key)
    def episode_records(self): return self.episodes
    def append_episode(self,value): self.episodes.append(value)


class PreparationTests(unittest.TestCase):
    def make(self):
        rows=[{'sequence':'seq','physical_site':'site','agent_role':'support_train','outer_split':'train'}]
        return PreparationTools(rows=rows,memory=Memory(),observation={'task':'uav'},artifacts={})

    def test_wrong_task_rejected(self):
        with self.assertRaises(ValueError):
            self.make().execute_registered('commission_background',
                {'task':'human','site_id':'site','episode_id':'seq'},run_id='a'*32)

    def test_test_role_rejected(self):
        tool=self.make()
        tool.rows[0]['agent_role']='source_test'
        with self.assertRaises(ValueError):
            tool.execute_registered('commission_background',
                {'task':'uav','site_id':'site','episode_id':'seq'},run_id='a'*32)

    def test_commission_is_manifest_registration_not_background_measurement(self):
        tool=self.make()
        result=tool.execute_registered('commission_background',
            {'task':'uav','site_id':'site','episode_id':'seq'},run_id='a'*32)
        self.assertFalse(result.success)
        self.assertEqual(tool.memory.site('site')['task'],'uav')
        self.assertFalse(result.payload['background_signal_processed'])

    def test_unknown_tool_rejected(self):
        with self.assertRaises(ValueError):
            self.make().execute_registered('shadow_train',
                {'task':'uav','site_id':'site','episode_id':'seq'},run_id='a'*32)

    def test_valid_observation_persisted_not_promotion(self):
        from uav_observation import bind_condition
        tool=self.make()
        tool.observation=bind_condition({
            'scene_layout':'open','illumination':'day','visual_condition':'normal',
            'weather_evidence':'unknown','observation_quality':'sufficient',
            'evidence_summary':'Open outdoor area.'},task='uav',site_id='site',
            episode_id='seq',observed_at=0,image_sha256='a'*64,observer_sha256='b'*64,mode='cached')
        result=tool.execute_registered('observe_episode',
            {'task':'uav','site_id':'site','episode_id':'seq'},run_id='a'*32)
        self.assertTrue(result.success)
        self.assertEqual(len(tool.memory.episodes),1)
        self.assertFalse(result.payload['authorizes_promotion'])

    def test_observation_from_other_episode_rejected(self):
        tool=self.make()
        result=tool.execute_registered('observe_episode',
            {'task':'uav','site_id':'site','episode_id':'seq'},run_id='a'*32)
        self.assertFalse(result.success)
        self.assertEqual(len(tool.memory.episodes),0)

    def test_diagnosis_needs_observed_episode(self):
        result=self.make().execute_registered('diagnose_condition',
            {'task':'uav','site_id':'site','episode_id':'seq'},run_id='a'*32)
        self.assertFalse(result.success)
