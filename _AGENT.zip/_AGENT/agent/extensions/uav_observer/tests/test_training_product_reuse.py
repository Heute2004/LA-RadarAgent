import unittest
from training_product_reuse import validate_product_metadata


class ReuseTests(unittest.TestCase):
    def records(self):
        hashes={'manifest_sha256':'a'*64,'u0_checkpoint_sha256':'b'*64,'pseudolabel_sha256':'c'*64}
        native={**hashes,'best_checkpoint_selection_role':'support_dev',
            'best_checkpoint_selection_metric':'ols_mid_map_30_70',
            **{key:False for key in ('locked_test_read','target_ground_truth_used_for_training',
                'target_truth_read_for_pseudolabels','support_dev_read_for_training_loss',
                'development_query_read_for_checkpoint_selection')}}
        execution={'task':'uav','mode':'real','success':True,'subprocess_exit_code':0,
            'simulation':False,'training_performed':True,'profile_sha256':'d'*64}
        return execution,native,hashes

    def test_identical_lineage_can_be_reused(self):
        execution,native,hashes=self.records()
        result=validate_product_metadata(execution,native,hashes,'d'*64)
        self.assertFalse(result['new_training_performed'])
        self.assertFalse(result['promotion_authorized'])

    def test_label_change_rejected(self):
        execution,native,hashes=self.records()
        native['pseudolabel_sha256']='f'*64
        with self.assertRaises(ValueError): validate_product_metadata(execution,native,hashes,'d'*64)

    def test_simulated_training_rejected(self):
        execution,native,hashes=self.records()
        execution['simulation']=True
        with self.assertRaises(ValueError): validate_product_metadata(execution,native,hashes,'d'*64)

    def test_different_budget_profile_rejected(self):
        execution,native,hashes=self.records()
        with self.assertRaises(ValueError): validate_product_metadata(execution,native,hashes,'e'*64)
