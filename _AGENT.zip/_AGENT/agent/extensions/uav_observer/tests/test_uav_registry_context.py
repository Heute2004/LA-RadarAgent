import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from uav_registry_context import load_routing_context


class RegistryContextTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for name in ['source.pt', 'adapted.pt']:
            (self.root / name).write_bytes(name.encode())
        sha = lambda name: hashlib.sha256((self.root / name).read_bytes()).hexdigest()
        self.config = {'routing_scope': {'source_or_unknown_route': 'base', 'registered_target_route': 'adapt'},
                       'models': {'base': {'relative_checkpoint': 'source.pt', 'sha256': sha('source.pt')},
                                  'adapt': {'relative_checkpoint': 'adapted.pt', 'sha256': sha('adapted.pt')}},
                       'postfit_development_query_report': {'secret_metric': 123.456}}
        self.config_path = self.root / 'route.json'
        self.config_path.write_text(json.dumps(self.config))
        self.config_sha = sha('route.json')
        receipt = {'decision': 'PROMOTED_AS_REGISTERED_TARGET_COARSE_ROUTE',
                   'decision_scope': 'registered_target_site_or_condition_only',
                   'route_contract_sha256': self.config_sha,
                   'parent': {'checkpoint_sha256': sha('source.pt')},
                   'candidate': {'checkpoint_sha256': sha('adapted.pt')},
                   'integrity': {'locked_test_read': False, 'development_query_used_for_selection': False,
                                 'target_rtk_used_for_training': False, 'target_rtk_used_for_pseudolabels': False,
                                 'source_route_replacement': False}}
        self.receipt_path = self.root / 'receipt.json'
        self.receipt_path.write_text(json.dumps(receipt))
        self.receipt_sha = sha('receipt.json')

    def load(self, category='target', role='support_train'):
        return load_routing_context(self.root, self.config_path, self.config_sha,
               self.receipt_path, self.receipt_sha,
               task='uav', site_id='yard', row={'physical_site': 'yard', 'scene_category': category,
                                               'agent_role': role, 'outer_split': 'train'})

    def test_target_eligibility_excludes_postfit_metrics(self):
        result = self.load()
        self.assertEqual(result['deployment']['eligible_models'], ['source', 'adapted'])
        self.assertNotIn('123.456', json.dumps(result))
        self.assertNotIn('postfit', json.dumps(result))

    def test_source_keeps_exact_source_only(self):
        self.assertEqual(self.load('source', 'source_supervised_train')['deployment']['eligible_models'], ['source'])

    def test_bad_adapted_weights_fall_back_without_false_authorization(self):
        (self.root / 'adapted.pt').write_bytes(b'changed')
        result = self.load()
        self.assertEqual(result['deployment']['eligible_models'], ['source'])
        self.assertEqual(result['adapted_status'], 'checkpoint_unavailable_or_mismatched')

    def test_test_role_and_bad_authority_are_rejected(self):
        with self.assertRaises(ValueError):
            self.load(role='source_test')
        self.config_path.write_text('{}')
        with self.assertRaises(ValueError):
            self.load()

    def test_development_manifest_spelling_is_supported(self):
        result = load_routing_context(self.root, self.config_path, self.config_sha,
                 self.receipt_path, self.receipt_sha, task='uav', site_id='yard',
                 row={'physical_site': 'yard', 'scene_category': 'target',
                      'agent_role': 'development_query', 'outer_split': 'development'})
        self.assertIn('adapted', result['deployment']['eligible_models'])


if __name__ == '__main__':
    unittest.main()
