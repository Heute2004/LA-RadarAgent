import unittest
from audit_uav_candidate import selection_view


class CandidateSelectionTests(unittest.TestCase):
    def fixture(self):
        return {'best_checkpoint_selection_role':'support_dev',
                'best_checkpoint_selection_metric':'ols_mid_map_30_70',
                'locked_test_read':False,'development_query_read_for_checkpoint_selection':False,
                'evaluation':{'support_dev':{'ols_mid_map_30_70':.6,'ols_coarse_map_20_50':.8,'hit_at_1p5m':.7},
                              'development_query':{'secret_metric':.99}},
                'best_checkpoint_selection_score':.6,'best_epoch_by_selection':3}

    def test_query_not_exposed(self):
        result=selection_view(self.fixture(),[{'epoch':0,'support_dev_ols_mid_map_30_70':.4}])
        self.assertNotIn('secret_metric',str(result))
        self.assertFalse(result['promotion_authorized'])
        self.assertAlmostEqual(result['mid_ols_gain'],.2)

    def test_query_selection_forbidden(self):
        receipt=self.fixture()
        receipt['best_checkpoint_selection_role']='development_query'
        with self.assertRaises(ValueError):
            selection_view(receipt,[])
