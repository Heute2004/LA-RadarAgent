import unittest
from lifecycle_runner import run_lifecycle


class RunnerTests(unittest.TestCase):
    def test_missing_workflow_binding_rejected_before_decision(self):
        class Backend:
            supported_tools=set()
        with self.assertRaises(ValueError):
            run_lifecycle(workflow={'task':'uav','initial_state':'preflight','states':{
                'preflight':{'allowed_tools':['verify_preflight']}}},backend=Backend(),
                scorer=None,choices=[],memory=None,context_provider=None,lifecycle_id='test')

    def test_unbounded_execution_rejected(self):
        with self.assertRaises(ValueError):
            run_lifecycle(workflow={},backend=None,scorer=None,choices=[],memory=None,
                context_provider=None,lifecycle_id='test',max_steps=0)
