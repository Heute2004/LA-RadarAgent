import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from background_binding import validate_background


class BackgroundTests(unittest.TestCase):
    def test_native_receipt_registration(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'receipt.json'
            data={'manifest_sha256':'a'*64,'temporal_background_mode':'full_episode_median_residual',
                'source_temporal_report_sha256':'b'*64,'target_roles':['support_train'],
                'target_sequence_ids':[43],**{key:False for key in (
                    'target_truth_read','support_truth_read','development_query_read','locked_test_read')}}
            path.write_text(json.dumps(data))
            spec={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                  'manifest_sha256':'a'*64,'source_temporal_report_sha256':'b'*64}
            rows=[{'sequence_id':'43','agent_role':'support_train','outer_split':'train'}]
            value=validate_background(spec,rows)
            self.assertFalse(value['new_background_measurement'])
            self.assertEqual(value['support_sequences'],[43])
            rows[0]['agent_role']='source_test'
            with self.assertRaises(ValueError): validate_background(spec,rows)
