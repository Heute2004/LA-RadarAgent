import unittest
from dataclasses import dataclass
from types import SimpleNamespace
from live_workflow_driver import run_step, recover_step


@dataclass
class FixtureResult:
    success: bool
    code: str
    payload: dict


class MemoryFixture:
    def __init__(self):
        self.entries=[]
    def ledger_records(self):
        return self.entries
    def append_ledger(self,entry):
        self.entries.append(entry)
    def append_qwen_decision(self,entry):
        pass


class DriverTests(unittest.TestCase):
    def fixture(self,simulation=False):
        workflow={'task':'uav','initial_state':'preflight','states':{
            'preflight':{'allowed_tools':['verify_preflight'],'success_transition':'observe','failure_transition':'rollback'},
            'observe':{},'rollback':{}}}
        context=dict(task='uav',site_id='site',episode_id='episode',observation=None,now=0,max_age_s=1,
                     radar_health={},memory_summary=[],last_tool_result=None,
                     deployment={'task':'uav','site_id':'site','registered':True,'retrieval_complete':False,'eligible_models':['source']})
        choice=SimpleNamespace(choice_id='verify_preflight',description_zh='Check assets')
        scorer=SimpleNamespace(choose=lambda prompt,choices:'verify_preflight')
        backend=SimpleNamespace(execute_registered=lambda tool,payload,run_id:FixtureResult(True,'fixture',
            {'task':'uav','tool_run_id':run_id,'simulation':simulation,'locked_test_read':False}))
        return dict(workflow=workflow,state='preflight',scorer=scorer,choices=[choice],context=context,
                    backend=backend,memory=MemoryFixture(),lifecycle_id='fixture-only')

    def test_completed_tool_advances(self):
        args=self.fixture()
        state,result=run_step(**args)
        self.assertEqual(state,'observe')
        self.assertEqual(args['memory'].entries[-1]['step_status'],'completed')

    def test_simulation_cannot_advance_or_restart(self):
        args=self.fixture(simulation=True)
        with self.assertRaises(ValueError):
            run_step(**args)
        with self.assertRaises(RuntimeError):
            run_step(**args)

    def test_recovery_uses_same_run_without_execution(self):
        args=self.fixture()
        args['memory'].append_ledger({'task':'uav','lifecycle_id':'fixture-only',
            'state':'preflight','tool':'verify_preflight','run_id':'existing','step_status':'started'})
        calls=[]
        def recover(tool, run_id):
            calls.append((tool,run_id))
            return FixtureResult(True,'completed',{'task':'uav','tool_run_id':run_id,
                'simulation':False,'locked_test_read':False})
        backend=SimpleNamespace(recover_registered=recover)
        state,result=recover_step(workflow=args['workflow'],backend=backend,
            memory=args['memory'],lifecycle_id='fixture-only')
        self.assertEqual(state,'observe')
        self.assertEqual(calls,[('verify_preflight','existing')])
        with self.assertRaises(ValueError):
            recover_step(workflow=args['workflow'],backend=backend,
                memory=args['memory'],lifecycle_id='fixture-only')

    def test_running_recovery_does_not_advance(self):
        args=self.fixture()
        args['memory'].append_ledger({'task':'uav','lifecycle_id':'fixture-only',
            'state':'preflight','tool':'verify_preflight','run_id':'existing','step_status':'started'})
        with self.assertRaises(RuntimeError):
            recover_step(workflow=args['workflow'],
                backend=SimpleNamespace(recover_registered=lambda tool,run_id:None),
                memory=args['memory'],lifecycle_id='fixture-only')
        self.assertEqual(len(args['memory'].entries),1)


if __name__=='__main__':
    unittest.main()
