import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest


sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from promotion_policy import evaluate_promotion


class PromotionPolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.policy_path = Path(self.temp.name) / "synthetic_policy.json"
        self.policy = {
            "schema": "numeric_promotion_policy",
            "task": "uav",
            "authorization": {
                "authorized": True,
                "task": "uav",
                "split_role": "support_dev",
            },
            "identity": {
                "parent_checkpoint_sha256": "a" * 64,
                "candidate_checkpoint_sha256": "b" * 64,
                "manifest_sha256": "c" * 64,
            },
            "thresholds": {
                "min_mid_gain": 0.01,
                "max_coarse_degradation": 0.02,
                "max_hit_degradation": 0.03,
            },
        }
        self.policy_path.write_text(
            json.dumps(self.policy, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        self.policy_sha256 = hashlib.sha256(self.policy_path.read_bytes()).hexdigest()
        self.authorization = {
            "authorized": True,
            "task": "uav",
            "split_role": "support_dev",
        }
        self.parent = {"checkpoint_sha256": "a" * 64}
        self.candidate = {"checkpoint_sha256": "b" * 64}
        self.manifest = {"manifest_sha256": "c" * 64}
        self.parent_metrics = {
            "split_role": "support_dev",
            "ols_mid_map_30_70": 0.50,
            "ols_coarse_map_20_50": 0.70,
            "hit_at_1p5m": 0.60,
        }
        self.candidate_metrics = {
            "split_role": "support_dev",
            "ols_mid_map_30_70": 0.52,
            "ols_coarse_map_20_50": 0.69,
            "hit_at_1p5m": 0.59,
        }

    def evaluate(self, **overrides):
        values = {
            "policy_path": self.policy_path,
            "policy_sha256": self.policy_sha256,
            "authorization": self.authorization,
            "parent": self.parent,
            "candidate": self.candidate,
            "manifest": self.manifest,
            "parent_metrics": self.parent_metrics,
            "candidate_metrics": self.candidate_metrics,
        }
        values.update(overrides)
        return evaluate_promotion(**values)

    def test_all_explicit_gates_pass(self):
        result = self.evaluate()
        self.assertTrue(result.allowed)
        self.assertEqual(result.reason, "all_numeric_gates_passed")
        self.assertAlmostEqual(result.gates["mid_gain"]["observed"], 0.02)
        self.assertTrue(all(gate["passed"] for gate in result.gates.values()))

    def test_missing_authorization_is_denied(self):
        result = self.evaluate(authorization=None)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "missing_authorization")

    def test_missing_metrics_are_denied(self):
        result = self.evaluate(candidate_metrics=None)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "missing_candidate_metrics")

    def test_wrong_policy_hash_is_denied(self):
        result = self.evaluate(policy_sha256="d" * 64)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "policy_hash_mismatch")

    def test_identity_mismatch_is_denied(self):
        result = self.evaluate(candidate={"checkpoint_sha256": "e" * 64})
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "candidate_checkpoint_sha256_mismatch")

    def test_missing_threshold_cannot_use_a_default(self):
        policy = dict(self.policy)
        policy["thresholds"] = {"min_mid_gain": 0.01, "max_coarse_degradation": 0.02}
        self.policy_path.write_text(
            json.dumps(policy, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        result = self.evaluate(
            policy_sha256=hashlib.sha256(self.policy_path.read_bytes()).hexdigest()
        )
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "policy_thresholds_incomplete_or_unexpected")

    def test_threshold_outside_explicit_range_is_denied(self):
        policy = dict(self.policy)
        policy["thresholds"] = {
            "min_mid_gain": 1.01,
            "max_coarse_degradation": 0.02,
            "max_hit_degradation": 0.03,
        }
        self.policy_path.write_text(
            json.dumps(policy, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        result = self.evaluate(
            policy_sha256=hashlib.sha256(self.policy_path.read_bytes()).hexdigest()
        )
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "policy_threshold_out_of_range")

    def test_negative_degradation_threshold_can_require_improvement(self):
        policy = dict(self.policy)
        policy["thresholds"] = {
            "min_mid_gain": 0.01,
            "max_coarse_degradation": -0.01,
            "max_hit_degradation": -0.005,
        }
        self.policy_path.write_text(
            json.dumps(policy, sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        result = self.evaluate(
            policy_sha256=hashlib.sha256(self.policy_path.read_bytes()).hexdigest(),
            candidate_metrics={
                "split_role": "support_dev",
                "ols_mid_map_30_70": 0.52,
                "ols_coarse_map_20_50": 0.72,
                "hit_at_1p5m": 0.61,
            },
        )
        self.assertTrue(result.allowed)
        self.assertEqual(result.gates["coarse_degradation"]["threshold"], -0.01)

    def test_duplicate_policy_key_is_denied(self):
        raw = (
            '{"schema":"numeric_promotion_policy",'
            '"task":"uav","task":"uav",'
            '"authorization":{"authorized":true,"task":"uav",'
            '"split_role":"support_dev"},'
            '"identity":{"parent_checkpoint_sha256":"' + "a" * 64 + '",'
            '"candidate_checkpoint_sha256":"' + "b" * 64 + '",'
            '"manifest_sha256":"' + "c" * 64 + '"},'
            '"thresholds":{"min_mid_gain":0.01,'
            '"max_coarse_degradation":0.02,"max_hit_degradation":0.03}}'
        )
        self.policy_path.write_text(raw, encoding="utf-8")
        result = self.evaluate(
            policy_sha256=hashlib.sha256(self.policy_path.read_bytes()).hexdigest()
        )
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "policy_json_duplicate_key")

    def test_policy_pass_is_judgment_only(self):
        result = self.evaluate()
        self.assertEqual(result.status, "policy_passed")
        self.assertFalse(result.registry_written)
        self.assertFalse(result.promotion_performed)

    def test_query_or_test_metric_is_denied(self):
        metrics = dict(self.candidate_metrics)
        metrics["query_hit"] = 1.0
        result = self.evaluate(candidate_metrics=metrics)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "query_or_test_metric_forbidden")

    def test_non_finite_metric_is_denied(self):
        metrics = dict(self.candidate_metrics)
        metrics["hit_at_1p5m"] = float("nan")
        result = self.evaluate(candidate_metrics=metrics)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "candidate_hit_at_1p5m_non_finite")

    def test_failed_numeric_gate_is_denied_without_rewriting_thresholds(self):
        metrics = dict(self.candidate_metrics)
        metrics["ols_coarse_map_20_50"] = 0.60
        result = self.evaluate(candidate_metrics=metrics)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "numeric_gate_failed")
        self.assertFalse(result.gates["coarse_degradation"]["passed"])
        self.assertEqual(result.gates["coarse_degradation"]["threshold"], 0.02)

    def test_observer_recommendation_is_not_a_promotion_metric(self):
        metrics = dict(self.candidate_metrics)
        metrics["vlm_recommends_promotion"] = True
        result = self.evaluate(candidate_metrics=metrics)
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "candidate_metrics_incomplete_or_unexpected")
        self.assertFalse(result.registry_written)

    def test_observer_cannot_relax_hash_bound_policy(self):
        self.policy["thresholds"]["max_coarse_degradation"] = 1.0
        self.policy_path.write_text(json.dumps(self.policy), encoding="utf-8")
        # The executor retains its trusted binding, not a hash supplied by an observer.
        result = self.evaluate()
        self.assertFalse(result.allowed)
        self.assertEqual(result.reason, "policy_hash_mismatch")
        self.assertFalse(result.promotion_performed)


if __name__ == "__main__":
    unittest.main()
