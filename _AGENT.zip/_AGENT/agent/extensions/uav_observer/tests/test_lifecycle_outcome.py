import unittest
from lifecycle_outcome import execution_outcome


class OutcomeTests(unittest.TestCase):
    def row(self, tool, payload, success=True, lifecycle='run'):
        return dict(lifecycle_id=lifecycle, step_status='completed', tool=tool,
                    tool_result=dict(success=success, payload=payload))

    def test_reuse_is_not_fresh_training(self):
        result=execution_outcome([self.row('shadow_train',dict(
            training_performed=False,original_training_performed=True))],'run')
        self.assertFalse(result['fresh_training'])
        self.assertTrue(result['registered_training_reused'])

    def test_policy_pass_is_not_promotion(self):
        result=execution_outcome([self.row('promote_or_reject',dict(
            policy_passed=True,promotion_performed=False))],'run')
        self.assertFalse(result['promotion_performed'])

    def test_only_successful_matching_execution_counts(self):
        rows=[self.row('shadow_train',dict(training_performed=True),False),
              self.row('shadow_train',dict(training_performed=True),lifecycle='other')]
        self.assertFalse(execution_outcome(rows,'run')['fresh_training'])

    def test_actual_execution_is_not_hardcoded_false(self):
        rows=[self.row('shadow_train',dict(training_performed=True)),
              self.row('promote_or_reject',dict(promotion_performed=True,
                  runtime_registry_sha256='a'*64))]
        result=execution_outcome(rows,'run')
        self.assertTrue(result['fresh_training'])
        self.assertTrue(result['promotion_performed'])

    def test_promotion_requires_registry_receipt(self):
        with self.assertRaises(ValueError):
            execution_outcome([self.row('promote_or_reject',dict(
                promotion_performed=True))],'run')
