import unittest
from dataclasses import dataclass
from qwen_observer_bridge import choose_tool
from test_uav_observation import observation


@dataclass
class Choice:
    choice_id: str
    description_zh: str
    requests: tuple = ()


class CaptureScorer:
    def __init__(self, answer):
        self.answer, self.prompt = answer, None

    def choose(self, prompt, choices):
        self.prompt = prompt
        return self.answer


def run(scorer, raw=None, **kwargs):
    return choose_tool(scorer, choices=[Choice("retrieve_experience", "Read prior results")],
                       task="uav", state="diagnose", site_id="site_a", episode_id="episode_a",
                       observation=raw, now=105, max_age_s=10, radar_health={},
                       memory_summary=[], last_tool_result=None,
                       deployment={"task": "uav", "site_id": "site_a", "registered": False,
                                   "retrieval_complete": False, "eligible_models": ["source"]}, **kwargs)


class BridgeTests(unittest.TestCase):
    def test_observation_reaches_scorer(self):
        scorer = CaptureScorer("retrieve_experience")
        result = run(scorer, observation())
        self.assertIn('"illumination": "night"', scorer.prompt)
        self.assertEqual(result["requested_tool"], "retrieve_experience")
        self.assertFalse(result["executed"])

    def test_stale_observation_not_shown_as_condition(self):
        raw = observation()
        raw["observed_at"] = 10
        scorer = CaptureScorer("retrieve_experience")
        run(scorer, raw)
        self.assertNotIn('"illumination": "night"', scorer.prompt)
        self.assertIn('"status": "stale"', scorer.prompt)

    def test_nonregistered_choice_is_rejected(self):
        with self.assertRaises(ValueError):
            run(CaptureScorer("shadow_train"), observation())

    def test_tool_result_is_observable_not_authorization(self):
        scorer = CaptureScorer("retrieve_experience")
        result = run(scorer, observation())
        self.assertIn("Dispatcher", scorer.prompt)
        self.assertNotIn("promotion_passed", result)

    def test_deployment_context_is_transmitted(self):
        scorer = CaptureScorer("retrieve_experience")
        run(scorer, observation())
        self.assertIn('"retrieval_complete": false', scorer.prompt)
        self.assertIn('"eligible_models": ["source"]', scorer.prompt)


if __name__ == "__main__":
    unittest.main()
