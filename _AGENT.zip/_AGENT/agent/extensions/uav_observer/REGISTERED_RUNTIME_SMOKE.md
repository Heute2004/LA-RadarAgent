# Registered Runtime Smoke

This is a bounded runtime-availability check for an already registered model.
It does not train, score accuracy, evaluate a metric, promote a model, write a
registry, read ground truth, or read Locked Test/Test payloads. It reuses the
existing isolated runtime data/model path and the task-scoped model request and
architecture helpers.

## Relative Entry

Run from the candidate package root with:

`extensions/uav_observer/registered_runtime_smoke.py`

The three pure validation tests are:

`extensions/uav_observer/tests/test_registered_runtime_smoke.py`

They cover unknown-site rejection, Source asset retention, and acceptance of an
explicitly registered adapted model.

## External Resource Parameters

The package contains no checkpoint, radar data, Qwen model, or Test payload.
The smoke caller must provide these hash-bound external resources:

| Argument | External value |
| --- | --- |
| `--registry` | `/home/hyc/radar+ris/AGENT-JSAC/artifacts/observer_decision_workspace/numeric_policy_qwen_acceptance_canary_bound/runtime_route.json` (`8ad752bb97cf4c8fb7e711e18502b18fabd040c3e67efe3c06c9f2eafcca377b`) |
| `--manifest` | `/home/hyc/radar+ris/AGENT-JSAC/artifacts/UAV_EASY53_HIT15_PROTOCOL_V6_CONDITION_BALANCED_20260906/server_bundle/uav_agent_nonlockbox_manifest.csv` (`9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2`) |
| `--source-checkpoint` | `/home/hyc/radar+ris/AGENT-JSAC/artifacts/UAV_V6_CORA_GLOBAL_20260906T104649Z/u0_global_polar/best.pt` (`cda324817f9519dfc8eeecc2d9f45ec359f77213a86789a058b488ab86a36a98`) |
| `--package-root` | The candidate package root containing this relative entry and `src/` |
| `--sequence-id` | `43` |
| `--agent-role` | `support_train` |
| `--frames` / `--device` | `3` / `cpu` |

The registered route selects `model=adapted` and binds candidate checkpoint
SHA256 `5b7421d4fbe4d58682e51bee3169941acb08a874b86d6f176cf4ec3b2d8e1844`.
The source checkpoint is used only as the exact architecture parent authority.

## Verified Receipt

The corresponding external receipt is retained at:

`/home/hyc/radar+ris/AGENT-JSAC/artifacts/observer_decision_workspace/numeric_policy_registered_runtime_smoke_adapted_seq043/receipt.json`

Local mirror SHA256:
`eb8d56d2a335fe133618c9e1e1b36c285e9c0ee6d7461a8307b50e31f5b1a010`

It records `model=adapted`, `sequence_id=43`, `agent_role=support_train`,
`frames=3`, `device=server_cpu`, `strict_state_dict=true`, finite outputs, and
`performance_evaluation=false`, `truth_read=false`, `locked_test_read=false`,
`training_performed=false`, `promotion_performed=false`, and
`registry_written=false`. The measured 6.785864-second runtime is an execution
receipt only, not a performance result.

The original source-only `isolated_registry_runtime.py` and the old frozen-route
`probe_observer_radar_execution.py` retain their original meanings.
