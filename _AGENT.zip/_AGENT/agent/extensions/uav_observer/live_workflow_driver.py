"""One real tool step using the accepted workflow, Qwen and durable memory.

No simulation fallback exists. An unresolved started step must be recovered by
its registered tool; it is never automatically re-executed after restart.
"""
import uuid
from dataclasses import asdict
from qwen_observer_bridge import choose_tool, workflow_choices, next_workflow_state


def _complete(workflow, record, result, memory):
    record={key:record[key] for key in ('task','lifecycle_id','state','tool','run_id')}
    value=asdict(result)
    payload=value.get('payload',{})
    if (payload.get('task')!='uav' or payload.get('simulation') is not False
        or payload.get('tool_run_id')!=record['run_id'] or payload.get('locked_test_read') is not False):
        raise ValueError('Unbound, cross-task or simulated result cannot advance a live workflow')
    next_state=next_workflow_state(workflow,record['state'],record['tool'],value)
    memory.append_ledger({**record,'step_status':'completed','next_state':next_state,'tool_result':value})
    return next_state,value


def recover_step(*, workflow, backend, memory, lifecycle_id):
    previous=[entry for entry in memory.ledger_records()
              if entry.get('lifecycle_id')==lifecycle_id]
    if not previous or previous[-1].get('step_status')!='started':
        raise ValueError('No unresolved step to recover')
    record=previous[-1]
    if (record.get('task')!='uav' or workflow.get('task')!='uav'
        or record['tool'] not in workflow['states'][record['state']]['allowed_tools']):
        raise ValueError('Persisted tool is outside the workflow authority')
    result=backend.recover_registered(record['tool'],run_id=record['run_id'])
    if result is None:
        raise RuntimeError('Recorded tool has no terminal receipt; do not restart it')
    return _complete(workflow,record,result,memory)


def run_step(*, workflow, state, scorer, choices, context, backend, memory, lifecycle_id):
    previous=[entry for entry in memory.ledger_records()
              if entry.get('lifecycle_id')==lifecycle_id]
    if previous and previous[-1].get('step_status')=='started':
        raise RuntimeError('Unresolved real tool step: recover its recorded run ID before continuing')
    if previous and previous[-1].get('next_state')!=state:
        raise ValueError('Requested state differs from persisted workflow state')
    if not previous and state!=workflow['initial_state']:
        raise ValueError('A fresh lifecycle must begin at the accepted initial state')
    menu=workflow_choices(workflow,state,choices)
    request=choose_tool(scorer,choices=menu,state=state,**context)
    memory.append_qwen_decision({'lifecycle_id':lifecycle_id,'request':request})
    run_id=uuid.uuid4().hex
    record={'task':'uav','lifecycle_id':lifecycle_id,'state':state,
            'tool':request['requested_tool'],'run_id':run_id}
    memory.append_ledger({**record,'step_status':'started'})
    result=backend.execute_registered(request['requested_tool'],
        {'task':'uav','site_id':context['site_id'],'episode_id':context['episode_id']},run_id=run_id)
    return _complete(workflow,record,result,memory)
