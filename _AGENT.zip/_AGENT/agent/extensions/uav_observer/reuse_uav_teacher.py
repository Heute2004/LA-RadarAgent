"""Materialize an exact registered historical teacher artifact, without inference.

The source report and adaptation contract must be members of the hash-verified
accepted package. This is explicit artifact reuse, not newly generated labels.
"""
import argparse
import json
import os
from pathlib import Path
import shutil

from uav_registry_context import digest
from execute_uav_training import verify_training_label_roles


def main():
    parser=argparse.ArgumentParser()
    for key in ('package-root','manifest','parent','labels','output'):
        parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--accepted-manifest-sha256',required=True)
    args=parser.parse_args()
    for key in ('package_root','manifest','parent','labels','output'):
        setattr(args,key,getattr(args,key).resolve())
    nonce=os.environ.get('AGENT_JSAC_TOOL_RUN_ID','')
    if len(nonce)!=32 or any(c not in '0123456789abcdef' for c in nonce):
        raise PermissionError('Registered executor identity required')
    if args.output.exists():
        raise FileExistsError('Never overwrite a previous teacher handoff')
    authority=args.package_root/'provenance/accepted_release_manifest.json'
    if digest(authority)!=args.accepted_manifest_sha256:
        raise ValueError('Accepted package authority changed')
    archive_manifest=json.loads(authority.read_text(encoding='utf-8'))
    pinned=archive_manifest['files']
    paths={name:args.package_root/'artifacts/reproduction_inventory/evidence/uav'/name
           for name in ('teacher_receipt.json','adaptation_parameters.json')}
    for path in paths.values():
        relative=path.relative_to(args.package_root).as_posix()
        if relative not in pinned or digest(path)!=pinned[relative]:
            raise ValueError('Adopted evidence differs from accepted package')
    teacher=json.loads(paths['teacher_receipt.json'].read_text(encoding='utf-8'))
    parameters=json.loads(paths['adaptation_parameters.json'].read_text(encoding='utf-8'))
    manifest_sha,parent_sha,label_sha=digest(args.manifest),digest(args.parent),digest(args.labels)
    if (manifest_sha!=teacher['manifest_sha256'] or manifest_sha!=parameters['manifest_sha256']
        or parent_sha!=parameters['u0_checkpoint_sha256']
        or label_sha!=teacher['pseudolabel_sha256'] or label_sha!=parameters['pseudolabel_sha256']):
        raise ValueError('Historical teacher input/output lineage mismatch')
    for flag in ('target_truth_read','development_query_read','locked_test_read'):
        if teacher.get(flag) is not False:
            raise PermissionError('Historical teacher evidence violates current permissions')
    count=verify_training_label_roles(args.manifest,args.labels)
    if count!=parameters['target_label_count']:
        raise ValueError('Label count differs from adopted contract')
    args.output.mkdir(parents=True)
    output=args.output/'target_labels.csv'
    with args.labels.open('rb') as source, output.open('xb') as destination:
        shutil.copyfileobj(source,destination)
    if digest(output)!=label_sha:
        raise ValueError('Materialized label readback differs')
    result=dict(task='uav',mode='real',tool='construct_weak_evidence',run_id=nonce,tool_run_id=nonce,
        execution_kind='registered_artifact_reuse',success=True,subprocess_exit_code=None,
        simulation=False,new_teacher_inference=False,training_performed=False,
        source_authority={'path':str(paths['teacher_receipt.json']),'sha256':digest(paths['teacher_receipt.json'])},
        original_teacher_manifest_sha256=manifest_sha,parent_checkpoint_sha256=parent_sha,
        manifest_sha256=manifest_sha,output={'path':str(output),'sha256':label_sha},label_count=count,
        target_truth_read=False,development_query_read=False,locked_test_read=False,
        promotion_authorized=False)
    with (args.output/'receipt.json').open('x',encoding='utf-8') as handle:
        json.dump(result,handle,indent=2)
    print(json.dumps(result))


if __name__=='__main__':
    main()
