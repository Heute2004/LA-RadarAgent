# Observation, Routing and Promotion Boundary

## Actual data flow

`qwen_observer_bridge.choose_tool` validates a task-scoped observation and places
it in `STATE_JSON.visual_observation`, alongside radar health, memory, the last
tool result and trusted deployment context. The full prompt is passed to the
ChoiceScorer; a request outside the supplied legal menu is rejected.

This establishes observation consumption, not evidence that the observation
improves the selected action. The policy-integrated 13-step acceptance trace
contains singleton legal menus. Its correct execution cannot demonstrate
comparative reasoning or a VLM performance gain.

## Separate authorities

| Component | Authority | No authority |
| --- | --- | --- |
| InternVL observer | Describe image-supported conditions | Model approval, coordinate labels or promotion thresholds |
| Qwen | Request a legal tool using the available evidence | Write model parameters, alter the registry or authorize a policy |
| Runtime request validator | Check requested model against trusted task/site eligibility | Infer eligibility from image appearance |
| Promotion evaluator | Compare pinned Support-dev metrics using an externally authorized native policy | Use VLM output, Query metrics or synthetic test thresholds as approval |
| Dispatcher | Verify training lineage and shadow evidence, then perform an authorized registry write | Transfer approval from a different checkpoint |

`runtime_model_request.authorize_model_request` checks the explicit eligible
model list and verified asset binding. `PostTrainingTools._promote_or_reject`
uses pinned policy, parent/candidate identity, Support-dev metrics and canary
evidence. Visual observation fields are not promotion inputs.

## Current evidence and limits

- The independent policy-integrated invocation completed with 13 verified
  input bindings, registered training reuse and source fallback.
- It did not train or promote a new model. Its rejection must not be reported
  as a learned VLM judgment about model quality.
- The parent Support-dev metrics now have an exact prediction-backed receipt.
  That closes a measurement gap, not an authorization gap.
- Existing native UAV policy authority is under audit. Missing authority must
  not be replaced by invented thresholds; conversely, observation integration
  must not silently tighten an already applicable approved policy.
- Historical exact-model approval remains attached to that model. Historical
  results, fresh experimental training and this invocation remain separate.

## Training scope

The ordinary-confidence and equal-count training runs belong to the locked
experimental comparisons. They are not required merely because an observer was
added. Frozen sensing models and results remain unchanged. No Test payload is
needed to establish this interface boundary.

This document records a code and invocation audit. It is not a new training,
promotion or performance receipt, and does not amend the frozen experiment
contract or any accepted package manifest.

## Observer isolation regression

The workspace policy tests explicitly reject an observer recommendation added
to candidate metrics, and reject a relaxed policy file whose bytes no longer
match the executor's trusted hash. The focused suite passed 15 tests. These
use synthetic policy fixtures only; they authorize no real model and do not
replace a production permission or a complete end-to-end behavior test.
