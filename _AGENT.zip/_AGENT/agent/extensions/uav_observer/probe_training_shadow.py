"""Audit the completed training's three recorded Support-dev prediction pairs."""
import hashlib
import json
from pathlib import Path
import numpy as np
from zero_weight_canary import read_predictions, compare_predictions


def main():
    root = Path(__file__).resolve().parent
    training = root / 'live_adaptation'
    destination = root / 'training_shadow_acceptance'
    destination.mkdir(exist_ok=False)
    receipt = {'task': 'uav', 'scope': 'offline_saved_prediction_shadow',
               'simulation': False, 'locked_test_read': False,
               'promotion_authorized': False, 'sequences': []}
    # These are the completed run's Support-dev episodes, not an arbitrary split scan.
    for sequence in (44, 70, 79):
        name = f'uav_seq_{sequence:03d}.npz'
        source = training / 'selection_probes/epoch_000_initialization/support_dev' / name
        candidate = training / 'frozen_postfit_predictions/support_dev' / name
        output, result = compare_predictions(read_predictions(source), read_predictions(candidate))
        result['sequence_id'] = sequence
        for label, path in [('source', source), ('candidate', candidate)]:
            result[label + '_path'] = str(path)
            result[label + '_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        np.savez_compressed(destination / name, **output)
        receipt['sequences'].append(result)
    receipt['frames'] = sum(item['frames'] for item in receipt['sequences'])
    (destination / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps({'frames': receipt['frames'], 'promotion_authorized': False,
                      'receipt': str(destination / 'receipt.json')}))


if __name__ == '__main__':
    main()
