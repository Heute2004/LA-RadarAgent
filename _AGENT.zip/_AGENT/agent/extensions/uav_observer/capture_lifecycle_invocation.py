"""Capture OS completion and exact command for the non-training lifecycle entry."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid


def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--config-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if digest(args.config)!=args.config_sha256 or args.output.exists():
        raise ValueError('Changed config or existing invocation directory')
    args.output.mkdir(parents=True)
    entry=Path(__file__).with_name('run_observer_agent.py')
    command=[sys.executable,str(entry),'--config',str(args.config),
             '--config-sha256',args.config_sha256,'--output',str(args.output/'lifecycle')]
    report=dict(invocation_id=uuid.uuid4().hex,command=command,
        entry_sha256=digest(entry),config_sha256=args.config_sha256,
        started_at=datetime.now(timezone.utc).isoformat())
    (args.output/'invocation_started.json').write_text(json.dumps(report,indent=2))
    started=time.perf_counter()
    with (args.output/'stdout.log').open('xb') as stdout, (args.output/'stderr.log').open('xb') as stderr:
        result=subprocess.run(command,stdout=stdout,stderr=stderr,check=False)
    report.update(exit_code=result.returncode,elapsed_seconds=time.perf_counter()-started,
        ended_at=datetime.now(timezone.utc).isoformat(),
        stdout_sha256=digest(args.output/'stdout.log'),stderr_sha256=digest(args.output/'stderr.log'))
    closure=args.output/'lifecycle/closure_receipt.json'
    report['closure_sha256']=digest(closure) if closure.exists() else None
    (args.output/'invocation_finished.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))
    sys.exit(result.returncode)


if __name__=='__main__': main()
