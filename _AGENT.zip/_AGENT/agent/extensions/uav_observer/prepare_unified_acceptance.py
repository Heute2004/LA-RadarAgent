"""Bind the previously verified assets to the generic single-invocation entry."""
import hashlib
import json
from pathlib import Path


def main():
    workspace=Path(__file__).resolve().parent
    root=workspace.parents[1]
    previous=workspace/'preparation_lifecycle_single_registration'
    post=json.loads((previous/'fallback_profile.json').read_text())
    registry=(previous/'teacher_tool_registry.json').read_text().replace(
        previous.relative_to(root).as_posix(),'{run_root}')
    manifest=root/'artifacts/UAV_EASY53_HIT15_PROTOCOL_V6_CONDITION_BALANCED_20260906/server_bundle/uav_agent_nonlockbox_manifest.csv'
    responses=workspace/'temporal_review_validation/responses.jsonl'
    background=root/'artifacts/UAV_HONLY_TARGET_TEMPORAL_PSEUDOLABELS_V1G_BACKGROUND_GLOBAL_20260907/PSEUDOLABEL_RECEIPT.json'
    config={'task':'uav','artifact_root':str(root),'package_root':str(workspace/'Observation-Decision-Agent'),
        'qwen':str(root.parent/'JSAC-AGENT-V4/models/Qwen2.5-0.5B-Instruct'),'qwen_device':'cpu',
        'episode_id':'uav_seq_043','post_training_profile':post,'teacher_registry':json.loads(registry),
        'manifest':{'path':str(manifest),'sha256':'9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2'},
        'responses':{'path':str(responses),'sha256':'22b9696dac512ea8b010d08901e975d7f3f811bd84b75811d430727a1232f2a6'},
        'background':{'path':str(background),'sha256':'c02fff83bf9051156bea09b7873337a1bae1ca6726f230adf71177b99064f94c',
            'manifest_sha256':post['manifest_sha256'],
            'source_temporal_report_sha256':'1244000dca875d7bd462eef916672d20d884d39796ab3717df399a2c09e0529c'}}
    path=workspace/'unified_acceptance_profile.json'
    with path.open('x') as handle: json.dump(config,handle,indent=2)
    print(json.dumps({'config':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))


if __name__=='__main__': main()
