"""Lineage gate for explicit reuse of a completed real training product.

Metadata validation requires externally pinned receipts and checkpoint bytes;
it is not itself proof that a supplied JSON was produced by training.
"""


def validate_product_metadata(execution, native, lineage, profile_sha256):
    if (execution.get('task')!='uav' or execution.get('mode')!='real'
        or execution.get('success') is not True or execution.get('simulation') is not False
        or execution.get('training_performed') is not True
        or type(execution.get('subprocess_exit_code')) is not int
        or execution['subprocess_exit_code']!=0
        or execution.get('profile_sha256')!=profile_sha256):
        raise ValueError('Training execution or budget profile is not eligible')
    if set(lineage)!={'manifest_sha256','u0_checkpoint_sha256','pseudolabel_sha256'}:
        raise ValueError('Incomplete requested training lineage')
    if any(native.get(key)!=value for key,value in lineage.items()):
        raise ValueError('Training parent, data or supervision differs')
    if (native.get('best_checkpoint_selection_role')!='support_dev'
        or native.get('best_checkpoint_selection_metric')!='ols_mid_map_30_70'
        or any(native.get(key) is not False for key in (
            'locked_test_read','target_ground_truth_used_for_training',
            'target_truth_read_for_pseudolabels','support_dev_read_for_training_loss',
            'development_query_read_for_checkpoint_selection'))):
        raise ValueError('Training permissions or selection role differ')
    return {'task':'uav','execution_kind':'registered_training_product_reuse',
            'new_training_performed':False,'promotion_authorized':False,
            'lineage':dict(lineage),'profile_sha256':profile_sha256}
