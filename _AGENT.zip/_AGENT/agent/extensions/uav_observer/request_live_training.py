"""Real Qwen request followed by the bounded live training entry point."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid
from qwen_observer_bridge import choose_tool, workflow_choices
from uav_observation import bind_condition
from uav_registry_context import digest


def main():
    p=argparse.ArgumentParser()
    for name in ('package-root','qwen','profile','teacher-receipt','responses','output'):
        p.add_argument('--'+name,type=Path,required=True)
    for name in ('profile-sha256','teacher-receipt-sha256','responses-sha256'):
        p.add_argument('--'+name,required=True)
    args=p.parse_args()
    if args.output.exists():
        raise FileExistsError('Fresh acceptance output required')
    for path,expected in [(args.profile,args.profile_sha256),(args.teacher_receipt,args.teacher_receipt_sha256),
                          (args.responses,args.responses_sha256)]:
        if digest(path)!=expected:
            raise ValueError('Accepted input changed')
    sys.path.insert(0,str(args.package_root/'src'))
    from agent_jsac.qwen_policy import RankedChoice,TransformersQwenChoiceScorer
    from agent_jsac.memory import TypedMemory
    response=next(json.loads(line) for line in args.responses.read_text().splitlines()
                  if json.loads(line)['sequence']=='uav_seq_043')
    if response['schema_error'] is not None:
        raise ValueError('Observer output is invalid')
    # This integration fixture uses an explicitly known audited Train episode.
    import csv
    profile=json.loads(args.profile.read_text())
    with Path(profile['bindings']['manifest']).open(encoding='utf-8-sig',newline='') as handle:
        row=next(row for row in csv.DictReader(handle) if int(row['sequence_id'])==43)
    site=row['physical_site']
    if row['agent_role']!='support_train' or row['outer_split']!='train':
        raise PermissionError('Integration episode permission changed')
    teacher=json.loads(args.teacher_receipt.read_text())
    from live_training_authority import validate_live_handoff
    validate_live_handoff(teacher,parent_sha256=profile['expected_hashes']['u0_checkpoint'],
        manifest_sha256=profile['expected_hashes']['manifest'],labels_path=profile['bindings']['target_pseudolabel_csv'])
    observation=bind_condition(response['prediction'],task='uav',site_id=site,episode_id=row['sequence'],
        observed_at=0,mode='cached',image_sha256=response['image_sha256'],
        observer_sha256=response['model_weights_sha256'])
    workflow=json.loads((args.package_root/'tasks/uav/workflow.json').read_text())
    menu=workflow_choices(workflow,'shadow_train',[RankedChoice('shadow_train',
        'Request the registered native adaptation tool with fixed parameters and verified teacher labels',())])
    scorer=TransformersQwenChoiceScorer(args.qwen,device='cuda:0')
    request=choose_tool(scorer,choices=menu,task='uav',state='shadow_train',site_id=site,
        episode_id=row['sequence'],observation=observation,now=0,max_age_s=10,
        radar_health={'status':'not_measured'},memory_summary=[],
        last_tool_result={'success':teacher['success'],'teacher_receipt_sha256':args.teacher_receipt_sha256,
                          'evidence_mode':teacher['execution_kind']},
        deployment={'task':'uav','site_id':site,'registered':True,'retrieval_complete':True,
                    'eligible_models':['source']})
    del scorer
    import gc,torch
    gc.collect()
    torch.cuda.empty_cache()
    args.output.mkdir(parents=True)
    memory=TypedMemory(args.output/'memory')
    memory.append_qwen_decision(request)
    run_id=uuid.uuid4().hex
    result=args.output/'training_result.json'
    environment=os.environ.copy()
    environment['AGENT_JSAC_TOOL_RUN_ID']=run_id
    command=[sys.executable,str(Path(__file__).with_name('execute_uav_training.py')),
        '--package-root',str(args.package_root),'--profile',str(args.profile),
        '--profile-sha256',args.profile_sha256,'--teacher-receipt',str(args.teacher_receipt),
        '--teacher-receipt-sha256',args.teacher_receipt_sha256,'--result',str(result)]
    memory.append_ledger({'task':'uav','state':'shadow_train','run_id':run_id,
                          'requested_tool':request['requested_tool'],'status':'launching'})
    process=subprocess.run(command,env=environment,check=False)
    receipt=json.loads(result.read_text()) if result.is_file() else {'success':False,'missing_result':True}
    memory.append_ledger({'task':'uav','run_id':run_id,'process_exit_code':process.returncode,'tool_result':receipt})
    with (args.output/'acceptance.json').open('x',encoding='utf-8') as handle:
        json.dump({'task':'uav','request':request,'tool_result':receipt,
                   'qwen_request_was_real':True,'single_legal_tool':True,
                   'full_lifecycle_verified':False,'promotion_performed':False,
                   'scope':'training-stage integration from registered teacher reuse, not a fresh autonomous discovery run'},handle,indent=2)
    raise SystemExit(process.returncode)


if __name__=='__main__':
    main()
