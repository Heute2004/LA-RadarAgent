"""Retain actual ranker input and conditional scores, not fabricated responses."""
import hashlib
import json
import math
from pathlib import Path
import time


class AuditedChoiceScorer:
    def __init__(self, delegate, directory, identity):
        self.delegate=delegate
        self.directory=Path(directory)
        self.directory.mkdir(parents=True,exist_ok=False)
        self.identity=dict(identity)
        self.calls=0

    def choose(self, prompt, choices):
        choices=list(choices)
        started=time.perf_counter()
        selected=self.delegate.choose(prompt,choices)
        elapsed=time.perf_counter()-started
        scores=dict(self.delegate.last_scores)
        ids=[choice.choice_id for choice in choices]
        if (set(scores)!=set(ids) or selected not in ids
                or any(not math.isfinite(float(x)) for x in scores.values())
                or selected!=max(scores,key=scores.__getitem__)):
            raise ValueError('Scorer result is not bound to the actual legal menu')
        self.calls+=1
        record=dict(model_identity=self.identity,prompt=prompt,
            prompt_sha256=hashlib.sha256(prompt.encode('utf-8')).hexdigest(),
            choices=[dict(id=c.choice_id,description=c.description_zh) for c in choices],
            scores=scores,selected_tool=selected,elapsed_seconds=elapsed,
            decision_method='rotated_option_mean_conditional_log_probability',
            free_text_generation=False,adapter_active=bool(getattr(self.delegate,'last_adapter_active',False)))
        with (self.directory/f'decision_{self.calls:04d}.json').open('x',encoding='utf-8') as handle:
            json.dump(record,handle,ensure_ascii=False,indent=2,allow_nan=False)
        return selected
