"""Persist native tool results for read-only recovery without subprocess replay."""
import hashlib
import json
import re
from dataclasses import asdict
from pathlib import Path
from agent_jsac.contracts import ToolResult


class RecoverableTools:
    def __init__(self, backend):
        self.backend=backend
        if any(item.get('require_run_id') is not True for item in backend.tools.values()):
            raise ValueError('Every live registration must enforce run identity')

    def _path(self, tool, run_id):
        if not re.fullmatch('[a-f0-9]{32}',run_id):
            raise ValueError('Invalid run ID')
        root=Path(self.backend.project_root).resolve()
        path=(root/self.backend.tools[tool]['result_json']).resolve()
        if not path.is_relative_to(root):
            raise ValueError('Receipt path escapes package root')
        return path

    def execute_registered(self, tool, payload, *, run_id):
        path=self._path(tool,run_id)
        result=self.backend.execute_registered(tool,payload,run_id=run_id)
        data={'tool':tool,'run_id':run_id,'result_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
              'result':asdict(result)}
        with path.with_suffix('.recovery.json').open('x',encoding='utf-8') as handle:
            json.dump(data,handle,allow_nan=False)
        return result

    def recover_registered(self, tool, *, run_id):
        path=self._path(tool,run_id)
        if not path.is_file():
            return None
        raw=path.read_bytes()
        if json.loads(raw).get('tool_run_id')!=run_id:
            raise ValueError('Receipt belongs to a different run')
        sidecar=path.with_suffix('.recovery.json')
        if not sidecar.is_file():
            return None
        data=json.loads(sidecar.read_text(encoding='utf-8'))
        if (data.get('tool')!=tool or data.get('run_id')!=run_id
            or data.get('result_sha256')!=hashlib.sha256(raw).hexdigest()
            or data['result']['payload'].get('tool_run_id')!=run_id):
            raise ValueError('Recorded native result changed or is unbound')
        return ToolResult(**data['result'])
