"""Real episode-condition/Qwen/radar execution, not a training lifecycle test.

Only audited Train episodes are allowed. No truth reader is instantiated. RGB
conditions are episode-level; synchronized per-frame observation is not claimed.
"""
import argparse
import csv
from dataclasses import asdict
import json
from pathlib import Path
import sys
import time

from uav_registry_context import digest, load_routing_context
from runtime_model_request import authorize_model_request, resolve_architecture
from uav_observation import bind_condition
from qwen_observer_bridge import choose_tool


def main():
    parser = argparse.ArgumentParser()
    for key in ('package-root', 'asset-root', 'manifest', 'responses', 'qwen', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--responses-sha256', required=True)
    parser.add_argument('--sequence-ids', type=int, nargs='+', required=True)
    parser.add_argument('--frames', type=int, default=3)
    parser.add_argument('--device', default='cpu', choices=('cpu', 'cuda:0'))
    args = parser.parse_args()
    if args.output.exists() or not 1 <= args.frames <= 300:
        raise ValueError('Fresh output and bounded frame count required')
    manifest_sha = '9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2'
    if digest(args.manifest) != manifest_sha or digest(args.responses) != args.responses_sha256:
        raise ValueError('Manifest or observer cache changed')
    with args.manifest.open(encoding='utf-8-sig', newline='') as handle:
        allowed = {int(row['sequence_id']): row for row in csv.DictReader(handle)
                   if row['outer_split'] == 'train'
                   and row['agent_role'] in {'source_supervised_train', 'support_train'}}
    if len(set(args.sequence_ids)) != len(args.sequence_ids) or not set(args.sequence_ids) <= set(allowed):
        raise PermissionError('Only explicit unique audited Train episodes are allowed')
    responses = [json.loads(line) for line in args.responses.read_text(encoding='utf-8').splitlines() if line.strip()]
    selected = {}
    for sequence_id in args.sequence_ids:
        row = allowed[sequence_id]
        candidates = [item for item in responses if item['sequence'] == row['sequence']
                      and item['schema_error'] is None]
        if not candidates:
            raise ValueError('No valid real observer response for episode')
        selected[sequence_id] = candidates[0]
    sys.path.insert(0, str(args.package_root / 'src'))
    import numpy as np
    import torch
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice, TransformersQwenChoiceScorer
    from agent_jsac.cora_u_radar_only import (CoraURadarOnlyGlobalPolar,
        FrozenUavGlobalPolarInferenceDataset, predict_cora_u_global_model)
    from observation_memory_tools import ObservationMemoryTools
    args.output.mkdir(parents=True)
    memory = TypedMemory(args.output / 'memory')
    from audited_scorer import AuditedChoiceScorer
    identity = {name: digest(args.qwen / name)
                for name in ('model.safetensors', 'config.json', 'tokenizer.json')}
    identity['scorer_source_sha256'] = digest(args.package_root / 'src/agent_jsac/qwen_policy.py')
    scorer = AuditedChoiceScorer(TransformersQwenChoiceScorer(args.qwen, device=args.device),
                                args.output / 'qwen_traces', identity)
    device = torch.device(args.device)
    if device.type == 'cpu':
        torch.set_num_threads(4)
    reports = []
    for sequence_id in args.sequence_ids:
        row, response = allowed[sequence_id], selected[sequence_id]
        site, episode = row['physical_site'], row['sequence']
        context = load_routing_context(args.asset_root,
            args.asset_root / 'configs/UAV_CORA_TARGET_COARSE_ROUTE_V3_20260907.json',
            '980663b2786840146e6d4e3bf189d57499220e42b7b4e637137ba6fbf983f588',
            args.asset_root / 'artifacts/UAV_TARGET_COARSE_SET_STRICT_V3_20260907/PROMOTION_RECEIPT.json',
            'c20e220b3f9fdccd5a488e09ba74c53ed93de2ff98ce9a259243912f8c57949b',
            task='uav', site_id=site, row=row)
        memory.commission_site(site, {'task': 'uav', 'manifest_sha256': manifest_sha})
        observation = bind_condition(response['prediction'], task='uav', site_id=site,
            episode_id=episode, observed_at=0, mode='cached',
            image_sha256=response['image_sha256'], observer_sha256=response['model_weights_sha256'])
        common = dict(task='uav', site_id=site, episode_id=episode, observation=observation,
                      now=0, max_age_s=10, radar_health={'status': 'not_measured'})
        retrieval = choose_tool(scorer, choices=[RankedChoice('retrieve_experience',
            'Retrieve the registered site memory before inference', ())], state='retrieve_memory',
            memory_summary=[], last_tool_result=None, deployment=context['deployment'], **common)
        memory.append_qwen_decision(retrieval)
        result = ObservationMemoryTools(memory).execute(retrieval['requested_tool'], {'task': 'uav', 'site_id': site})
        if not result.success:
            raise RuntimeError('Memory retrieval failed; inference not authorized')
        memory.append_ledger({'task': 'uav', 'site_id': site, 'tool_result': asdict(result)})
        deployment = dict(context['deployment'], retrieval_complete=True)
        descriptions = {'source': 'Infer with the registered source model; safe universal fallback.',
                        'adapted': 'Infer with the registered target-adapted model eligible at this site.'}
        choices = [RankedChoice('infer_' + alias, descriptions[alias], ()) for alias in deployment['eligible_models']]
        started = time.perf_counter()
        request = choose_tool(scorer, choices=choices, state='runtime_parent_selection',
            memory_summary=result.payload.get('episodes', []), last_tool_result=asdict(result),
            deployment=deployment, **common)
        decision_seconds = time.perf_counter() - started
        memory.append_qwen_decision(request)
        alias, asset = authorize_model_request(request['requested_tool'], context)
        if digest(asset['path']) != asset['sha256']:
            raise ValueError('Checkpoint changed before execution')
        payload = torch.load(asset['path'], map_location='cpu', weights_only=False)
        config = payload['config']
        norm = config['source_normalization']
        source_asset = context['assets']['source']
        if digest(source_asset['path']) != source_asset['sha256']:
            raise ValueError('Source architecture authority changed')
        source_config = torch.load(source_asset['path'], map_location='cpu', weights_only=False)['config']
        architecture = resolve_architecture(config, source_config, source_asset['sha256'])
        model = CoraURadarOnlyGlobalPolar(**architecture, causal=True).to(device).eval()
        model.load_state_dict(payload['state_dict'])
        dataset = FrozenUavGlobalPolarInferenceDataset(manifest_path=args.manifest,
            window_size=16, temporal_mode='causal', channel_mean=tuple(norm['mean']),
            channel_std=tuple(norm['std']), allowed_roles={row['agent_role']},
            allowed_sequence_ids={sequence_id})
        total = len(dataset.records)
        indices = np.unique(np.linspace(0, total - 1, min(args.frames, total), dtype=int))
        dataset.records = [dataset.records[index] for index in indices]
        if device.type == 'cuda':
            torch.cuda.synchronize()
        started = time.perf_counter()
        predictions = predict_cora_u_global_model(model, dataset, device=device, batch_size=1)
        if device.type == 'cuda':
            torch.cuda.synchronize()
        inference_seconds = time.perf_counter() - started
        values = predictions[sequence_id]
        if any(not np.isfinite(array).all() for array in values.values()):
            raise ValueError('Non-finite radar output')
        path = args.output / (episode + '_predictions.npz')
        with path.open('xb') as handle:
            np.savez_compressed(handle, **values)
        report = {'task': 'uav', 'episode': episode, 'model': alias,
            'checkpoint_sha256': asset['sha256'], 'request': request,
            'prediction_sha256': digest(path), 'frames': len(dataset),
            'qwen_decision_seconds': decision_seconds, 'radar_execution_seconds': inference_seconds,
            'success': True, 'truth_read': False, 'test_payload_read': False}
        memory.append_ledger(report)
        reports.append(report)
        del model, dataset, predictions, payload
        if device.type == 'cuda':
            torch.cuda.empty_cache()
    reopened = TypedMemory(args.output / 'memory')
    result = {'component': 'observer_memory_qwen_radar_execution', 'episodes': reports,
        'manifest_sha256': manifest_sha, 'responses_sha256': args.responses_sha256,
        'real_radar_inference': True, 'episode_level_cached_observation': True,
        'complete_training_lifecycle_verified': False, 'training_performed': False,
        'performance_evaluation': False, 'test_payload_read': False,
        'persistent_ledger_entries': len(reopened.ledger_records())}
    with (args.output / 'receipt.json').open('x', encoding='utf-8') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
