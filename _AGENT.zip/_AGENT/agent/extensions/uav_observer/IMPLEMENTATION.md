# UAV Observation and Decision Integration

## Approved Design

Add a task-scoped UAV observer while preserving the accepted Human interface and frozen package. Use an independent UAV VLM adapter. Qwen consumes observable conditions, trusted deployment identity, radar health and memory; the existing registered tools execute requests. VLM observations cannot grant model eligibility or supply UAV coordinate supervision.

## Verified Reuse Points

- src/agent_jsac/vlm_observer.py: existing HTTP transport and Human condition validation. Its externally restored route fields are not UAV scene predictions.
- src/agent_jsac/qwen_tool_cycle.py: lifecycle-aware dispatch and decision receipts; currently has a vlm_context field.
- src/agent_jsac/memory.py: persistent typed site, episode and decision memory.
- src/agent_jsac/qwen_adapter.py: existing adapter integrity and choice-set restrictions. Do not silently apply a Human branch-choice adapter to UAV.
- src/agent_jsac/task_workflow_runtime.py: explicitly simulation-only. Never present this entry as a live training backend.
- configs/UAV_CORA_TARGET_COARSE_ROUTE_V3_20260907.json: adopted model eligibility and exact fallback authority; preserve its hashes and original result identity.

## Execution Checklist

- [x] Read the adopted UAV handoff and routing authority.
- [x] Inspect observer, decision, memory and simulation interfaces.
- [x] Delegate non-external experiments to the six existing workers.
- [ ] Audit UAV image availability and episode/site binding; existing inspected manifest rows have empty visual_frame_dir.
- [ ] Create an isolated candidate package from the hash-verified accepted release; record provenance and never replace the original.
- [x] Implement task-scoped observation validation and freshness checks with failing tests first. Seven unittest cases pass; this is component validation, not live VLM or Qwen acceptance.
- [ ] Add Qwen context and system-prompt rules without bypassing existing eligibility checks.
- [ ] Add observation/result persistence and resume tests through existing memory facilities.
- [ ] Bind UAV image training records to the approved non-test roles; exclude coordinate truths and best-route labels.
- [ ] Train the UAV observer adapter on the server after data audit passes.
- [ ] Run real Qwen requests against registered tool interfaces; classify invalid, stale, cross-task and unregistered-site cases.
- [ ] Train a Qwen adapter only if actual failure cases require it, using disjoint evaluation episodes.
- [ ] Evaluate real observation-to-route-to-feedback execution and separately measure performance with unchanged radar models.
- [ ] Package code, workflows, skills, contracts, tests and external model/data manifests, with no version-number display names.

## Required Behavioral Tests

Unknown or missing observations cannot enable an unregistered target model. Stale observations must not be reused as fresh conditions. Human fields must not pass UAV validation. A night image must not by itself enable an adapted model. Qwen cannot write checkpoints or alter promotion thresholds. Tool failures are recorded and cannot produce success receipts. Restart must preserve pending tool identity without duplicating training. Simulation records cannot authorize live promotion. Old UAV results remain marked as radar-only control results.

## Completion Evidence

Report interface tests, real VLM field evaluation, actual Qwen requests, dispatcher results, memory restoration, runtime costs and prediction metrics separately. Missing image assets or absent live model evaluations remain explicit incomplete items, not simulated successes.

## Current Inspection

The local UAV task entry declares training_enabled=false and server_runtime_verified=false. This metadata must be reconciled against the hash-verified server release before production integration; it is not evidence that live training is supported by this local entry. Server directory inspection confirms the existing UAV data root contains radar and truth directories; it has not yet established a usable RGB binding. No truth files or Locked Test payloads were opened for this inspection.

Training-image audit subsequently located 20 allowed source/support-train episodes and 6000 JPGs under radarUAV-24K. See uav_training_image_audit.json; frame synchronization remains unproven.

Observation and scorer-bridge component tests: 13 passed. These use a capture scorer and do not prove Qwen decision accuracy.

Real server Qwen probe: qwen_request_probe.json. The unadapted 0.5B model selected select_parent_branch rather than expected retrieve_experience with missing observations and empty memory. No tool executed. The synthetic state did not explicitly encode registration or retrieval preconditions; refine that state contract before attributing the failure solely to model capability. Retain this negative result. This is not a sensing experiment or a complete loop acceptance.

After adding trusted deployment fields and an explicit retrieval prerequisite, qwen_deployment_context_probe.json records a correct real Qwen request (retrieve_experience). The same unadapted model was used. This is a corrected development probe, not an independent success-rate evaluation; it has no actual tool execution. Fourteen component tests pass. Both pre-change and post-change probes remain preserved.

## Verified Progress and Open Acceptance Failures

- Training-only image availability is verified: 20 allowed source/support episodes contain 6000 images. Sixty individual images were visually reviewed; scene-wide propagation of quality labels is prohibited because auto-exposure changes within episodes. Radar/RGB temporal synchronization remains unverified.
- A separate UAV observer pilot trained on 48 reviewed images, with 12 images from four other complete training-partition episodes reserved for validation. Three epochs completed on server GPU2. Structured validity was 12/12; scene layout agreement was 10/12; illumination, visual condition and observation-quality agreement were 12/12. These are assistant-reviewed, small, same-site validation labels, not independent ground truth or a final generalization result. All weather labels were unknown, so no weather-classification capability is established.
- ObservationMemoryTools implements actual task-scoped TypedMemory retrieval. Unknown sites, cross-task memory and unsupported actions fail instead of receiving a success/no-state-change receipt. Seventeen component tests pass. The original frozen Dispatcher/package is unchanged.
- observation_memory_acceptance_receipt.json records real Qwen inference on a cached real pilot VLM prediction. The first request retrieved real commissioned site memory and the receipt survived TypedMemory restart exactly. No sensing model was executed, trained, selected or promoted.
- The follow-up request repeated retrieval despite successful feedback. This is an OPEN decision/workflow acceptance failure, not a completed lifecycle. Preserve this receipt as a negative result; next implement explicit post-retrieval state transitions and test multiple allowed episodes before considering decision-model finetuning.
- No Locked Test payload was read. The complete new Agent package and final observer training/evaluation remain incomplete.

### Retrieval Probe Correction

The earlier open-menu probe was not bound to the adopted UAV workflow: it remained in diagnose and offered parent selection immediately after retrieval. The actual workflow requires retrieve_memory -> buffer_support -> weak_evidence -> branch_selection. Therefore repeated retrieval in that probe is not sufficient evidence of a Qwen model defect.

The corrected probe reads tasks/uav/workflow.json from the verified server release (SHA256 5db9d3d0383d7749475e2224e0882f78a0cdf3e6ef76cdfd52e138ce0c28a916). workflow_bound_memory_acceptance_receipt.json confirms actual memory retrieval, restart-equivalent feedback and a subsequent buffer_support request. Twenty component tests pass. Each tested state has only one legal tool: this verifies interface/state-machine execution, NOT comparative reasoning quality. Buffer construction and subsequent training were not executed by this probe; their production bindings remain to be integrated. Both probe receipts are preserved and no frozen file was overwritten.

### Expanded Observer Fit

The additional reviewed temporal images were included in a separate fit using the same predefined three epochs, learning rate and adapter rank. Training finished in 123.07 seconds (36 steps, 96 images); the earlier pilot checkpoint remains untouched. The server-reloaded model has SHA256 66e8589a29ce6401ed74abead986f9154fd3401b4a510ef02ed00e0c84e0a7af.

Strict JSON evaluation on 24 images from four held-out training-partition episodes passed 24/24 structure checks and matched every reviewed categorical field. Weather was unknown in all 24 cases, so this is not evidence of weather recognition. This small same-site, assistant-reviewed evaluation does not establish unseen-site generalization. No radar truth or Test data was used. The trained observer candidate is available for integration; complete Agent lifecycle acceptance is still pending.

Parser and bridge tests now total 23 passing cases. Strict parsing rejects duplicate keys, trailing prose and nonfinite literals; old receipts retain their original identities rather than being silently rescored into a new training result.

### Native Routing Assets

uav_registry_context.py projects the historical route authority into source/adapted eligibility, with hash verification for the route file, promotion receipt and checkpoints. It never passes the historical postfit performance tables to Qwen. A missing or altered adapted checkpoint removes adapted eligibility; the exact source fallback must be available. Source/Test role names follow the actual UAV manifest rather than Human sequence-number rules.

The real server audit runtime_asset_eligibility.json verified 31 permitted non-Test rows: 16 source-only and 15 registered target rows with adapted eligibility. No radar data, coordinate truth or Test payload was loaded. This is eligibility verification, not model routing performance or training authorization. Twenty-eight component tests now pass. Integration of these verified assets with complete production lifecycle tools remains pending.
# Verified Runtime Tool Execution

## Real Training Handoff Boundary

The accepted `uav_teacher_handoff.py` explicitly requires a simulated intercepted
teacher fixture. It is retained unchanged for its original acceptance purpose.
It must not be relabeled as a real producer receipt. The independent
`live_training_authority.py` rejects simulation, nonzero subprocess exit status,
forbidden evidence access, changed output files, and mismatched parent/manifest.
Its input must originate in the trusted executor, never in Qwen text. This
validator alone neither attests operating-system file access nor proves label
quality. Registered execution and access auditing are still required before
the live training stage can be enabled. No real teacher receipt was fabricated.

The independent `probe_observer_radar_execution.py` uses the actual reviewed
observer cache, actual Qwen scoring, persisted TypedMemory, a task-scoped model
request guard, and the native truth-free UAV radar inference dataset.

The first run executed the source episode but stopped on the adapted checkpoint:
the native adaptation script saves normalization and an exact source hash, but
does not repeat the source network dimensions. The independent loader now resolves
those dimensions only through the verified source checkpoint binding. It does not
guess defaults or modify either checkpoint. The failed run remains preserved.

The corrected receipt is `observer_radar_bound_execution/receipt.json`:
- `uav_seq_005`: Qwen requested source; three causal radar frames executed.
- `uav_seq_043`: Qwen requested adapted; three causal radar frames executed.
- Four actual tool-result ledger entries persist across memory reopening.
- No radar truth, Test payload, training or promotion was used.
- Conditions are cached episode observations, not synchronized frame observations.

This verifies an inference component path, not the full training lifecycle and
not a detection-performance or VLM-contribution experiment. Historical route
eligibility is reused explicitly; it is not reported as a new Agent promotion.
The accepted frozen package and its results remain unchanged. At the time of
that component run, its independent candidate ZIP had not been refreshed.

## Current Acceptance Scope

The independent `candidates/Observation-Audited-Agent` directory now contains
the runtime modules, decision-trace auditor and observer evidence exporter.
Local and server verification passed 77 tests and verified 2245 payload hashes;
all 2185 accepted original payloads remain unchanged. This is a directory
candidate, not a replacement for the frozen ZIP.

| Requirement | Evidence and remaining boundary |
| --- | --- |
| UAV semantic observer | A trained observer and 24-image field evaluation exist; known-site, assistant-reviewed references and cached episode observations only. |
| Qwen tool execution | Actual score traces, requests and tool receipts bind; the historical target runtime offered two legal models and executed the selected adapted checkpoint. |
| Persistent lifecycle | One invocation completed observation, teacher/product reuse, candidate audit, shadow canary and source fallback, with persistent memory. |
| Fresh adaptation training | A separate actual training execution and checkpoint exist; do not present registered product reuse as a new training execution. |
| New candidate promotion | The handler now supports a hash-bound external policy plus product and checkpoint-bound shadow checks. Synthetic registry-write tests pass. No real numeric authorization was created and no new candidate was promoted. |
| Agent benefit | Not established by singleton menus, two-frame runtime checks or tests; controlled experiments remain separate. |
| Full experiment completion | Not established: native training, matched-label controls and remaining control groups are still tracked in the experiment execution directory. |

Earlier counts and pending statements describe their original run snapshots.
Use this scope table and `Completion-Review.md` for the current completion
boundary, without rewriting historical receipts or reassigning their results.

The working overlay passed 105 local tests after policy integration. A new real
server Qwen invocation (`policy_integrated_rejection_invocation`) completed 13
steps in 26.9895 seconds with exit code zero. Full prompt/score/request binding
passed for all 13 decisions. All menus in this invocation were singleton, so
this is execution integration rather than comparative reasoning evidence.
The closure correctly reports registered training reuse, no fresh training and
no promotion. The existing packaged directory retains its own earlier hashes;
these later working-overlay changes do not silently update that package.
