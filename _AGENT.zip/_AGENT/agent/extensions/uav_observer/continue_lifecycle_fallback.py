"""Complete the current reuse lifecycle with real canary checking and fallback."""
import csv
import hashlib
import json
import os
from pathlib import Path
import sys


def main():
    workspace=Path(__file__).resolve().parent
    root=workspace.parents[1]
    os.chdir(root)
    package=workspace/'Observation-Decision-Agent'
    sys.path.insert(0,str(package/'src'))
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice,TransformersQwenChoiceScorer
    from live_workflow_driver import run_step
    from post_training_tools import PostTrainingTools
    output=workspace/'preparation_lifecycle_single_registration'
    memory=TypedMemory(output/'memory')
    last=memory.ledger_records()[-1]
    if last.get('next_state')!='zero_weight_canary':
        raise ValueError('Expected completed candidate audit')
    profile=json.loads((output/'post_training_profile.json').read_text())
    shadow=workspace/'training_shadow_acceptance/receipt.json'
    profile['artifacts']['shadow_receipt']={'path':str(shadow),
        'sha256':hashlib.sha256(shadow.read_bytes()).hexdigest()}
    manifest=root/'artifacts/UAV_EASY53_HIT15_PROTOCOL_V6_CONDITION_BALANCED_20260906/server_bundle/uav_agent_nonlockbox_manifest.csv'
    if hashlib.sha256(manifest.read_bytes()).hexdigest()!=profile['manifest_sha256']:
        raise ValueError('Manifest changed before canary')
    with manifest.open(encoding='utf-8-sig',newline='') as handle:
        profile['canary_support_sequences']=[int(row['sequence_id']) for row in csv.DictReader(handle)
            if row['agent_role']=='support_dev' and row['outer_split']=='train']
    with (output/'fallback_profile.json').open('x') as handle: json.dump(profile,handle,indent=2)
    backend=PostTrainingTools(profile,artifact_root=root)
    workflow=json.loads((package/'tasks/uav/workflow.json').read_text())
    scorer=TransformersQwenChoiceScorer(root.parent/'JSAC-AGENT-V4/models/Qwen2.5-0.5B-Instruct',device='cpu')
    choices=[RankedChoice(name,name.replace('_',' '),())
        for name in ('zero_weight_canary','promote_or_reject','rollback_identity')]
    context=dict(task='uav',site_id=profile['site_id'],episode_id=profile['episode_id'],
        observation=None,now=0,max_age_s=10,radar_health={'status':'not_measured'},
        memory_summary=memory.episode_records(),last_tool_result=last['tool_result'],
        deployment={'task':'uav','site_id':profile['site_id'],'registered':True,
            'retrieval_complete':True,'eligible_models':['source']})
    state='zero_weight_canary'
    for _ in range(3):
        state,result=run_step(workflow=workflow,state=state,scorer=scorer,choices=choices,
            context=context,backend=backend,memory=memory,lifecycle_id=last['lifecycle_id'])
        context['last_tool_result']=result
        print(json.dumps({'state':state,'result':result}),flush=True)
    restored=TypedMemory(output/'memory')
    runtime=json.loads(Path(profile['runtime_registry']).read_text())
    receipt={'task':'uav','scope':'real_reuse_lifecycle_with_policy_rejection',
        'final_state':state,'runtime_model':runtime['model'],'promotion_performed':False,
        'fallback_registry_written':True,'restored_memory_equal':restored.ledger_records()==memory.ledger_records(),
        'new_training_in_this_lifecycle':False,'training_product_reused':True,
        'fresh_source_to_deployment_training_verified':False,'locked_test_read':False,
        'completed_tool_steps':sum(entry.get('step_status')=='completed' for entry in memory.ledger_records())}
    if state!='observe' or runtime['model']!='source' or not receipt['restored_memory_equal']:
        raise RuntimeError('Fallback lifecycle did not close correctly')
    (output/'closure_receipt.json').write_text(json.dumps(receipt,indent=2))


if __name__=='__main__': main()
