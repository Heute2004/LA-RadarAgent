"""Continue the recorded preparation lifecycle through registered teacher reuse."""
import json
from pathlib import Path
import sys


def main():
    workspace=Path(__file__).resolve().parent
    root=workspace.parents[1]
    package=workspace/'Observation-Decision-Agent'
    sys.path.insert(0,str(package/'src'))
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice,TransformersQwenChoiceScorer
    from agent_jsac.tools.evolution import EvolutionToolBackend
    from registered_recovery import RecoverableTools
    from live_workflow_driver import run_step
    output=workspace/'preparation_lifecycle_single_registration'
    memory=TypedMemory(output/'memory')
    ledger=memory.ledger_records()
    if not ledger or ledger[-1].get('next_state')!='weak_evidence':
        raise ValueError('Prior preparation lifecycle is not at weak evidence')
    requests=memory.qwen_decision_records()
    episode=memory.episode_records()[-1]
    workflow=json.loads((package/'tasks/uav/workflow.json').read_text())
    rel=lambda path:str(path.relative_to(root))
    artifacts=root/'artifacts'
    fixed=['--package-root',rel(package),
        '--manifest',rel(artifacts/'UAV_EASY53_HIT15_PROTOCOL_V6_CONDITION_BALANCED_20260906/server_bundle/uav_agent_nonlockbox_manifest.csv'),
        '--parent',rel(artifacts/'UAV_V6_CORA_GLOBAL_20260906T104649Z/u0_global_polar/best.pt'),
        '--labels',rel(artifacts/'UAV_HONLY_TARGET_TEMPORAL_PSEUDOLABELS_V1G_BACKGROUND_GLOBAL_20260907/TARGET_PSEUDOLABELS.csv'),
        '--output',rel(output/'teacher'),
        '--accepted-manifest-sha256','a00088d3574f1beccb354f51d3070c2d00fc2b332faa97d8e6485760b4e2bd73']
    registry={'schema_version':'agent_jsac_registered_tools_v1','evolution_tools':{
        'construct_weak_evidence':{'script':rel(workspace/'reuse_uav_teacher.py'),
            'fixed_args':fixed,'result_json':rel(output/'teacher/receipt.json'),
            'allowed_output_root':rel(output/'teacher'),'require_run_id':True,
            'allowed_payload_fields':['task','site_id','episode_id'],'timeout_seconds':120}}}
    registry_path=output/'teacher_tool_registry.json'
    with registry_path.open('x') as handle: json.dump(registry,handle,indent=2)
    backend=RecoverableTools(EvolutionToolBackend(root,registry_path))
    scorer=TransformersQwenChoiceScorer(root.parent/'JSAC-AGENT-V4/models/Qwen2.5-0.5B-Instruct',device='cpu')
    context=dict(task='uav',site_id=episode['site_id'],episode_id=episode['episode_id'],
        observation=None,now=0,max_age_s=10,radar_health={'status':'not_measured'},
        memory_summary=memory.episode_records(),last_tool_result=ledger[-1]['tool_result'],
        deployment={'task':'uav','site_id':episode['site_id'],'registered':True,
                    'retrieval_complete':True,'eligible_models':['source']})
    state,result=run_step(workflow=workflow,state='weak_evidence',scorer=scorer,
        choices=[RankedChoice('construct_weak_evidence','Validate and materialize the registered native teacher labels',())],
        context=context,backend=backend,memory=memory,lifecycle_id=ledger[-1]['lifecycle_id'])
    receipt={'task':'uav','state':state,'label_count':result['payload']['label_count'],
        'execution_kind':result['payload']['execution_kind'],'new_teacher_inference':False,
        'real_qwen_inference':True,'locked_test_read':False,'full_lifecycle_verified':False,
        'previous_decision_count':len(requests),'decision_count':len(memory.qwen_decision_records())}
    (output/'teacher_continuation_receipt.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt))


if __name__=='__main__': main()
