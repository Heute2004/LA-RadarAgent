"""Trusted live adapter around the accepted native UAV training compiler.

Invoke only through the registered Dispatcher with an executor-produced teacher
receipt. Qwen never supplies command arguments or receipt content. This adapter
does not grant model promotion.
"""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from live_training_authority import validate_live_handoff
from uav_registry_context import digest


def verify_training_label_roles(manifest, labels):
    with Path(manifest).open(encoding='utf-8-sig', newline='') as handle:
        allowed = {int(row['sequence_id']) for row in csv.DictReader(handle)
                   if row['agent_role'] == 'support_train' and row['outer_split'] == 'train'}
    keys = set()
    with Path(labels).open(encoding='utf-8-sig', newline='') as handle:
        for row in csv.DictReader(handle):
            key = (int(row['sequence_id']), int(row['frame_id']))
            if key[0] not in allowed or key[1] < 0 or key in keys:
                raise PermissionError('Duplicate, invalid or unauthorized training label')
            keys.add(key)
    if not keys:
        raise ValueError('No authorized target labels')
    return len(keys)


def main():
    parser = argparse.ArgumentParser()
    for key in ('package-root','profile','teacher-receipt','result'):
        parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--profile-sha256',required=True)
    parser.add_argument('--teacher-receipt-sha256',required=True)
    args = parser.parse_args()
    if args.result.exists():
        raise FileExistsError('Never replace a previous tool result')
    nonce = os.environ.get('AGENT_JSAC_TOOL_RUN_ID','')
    if len(nonce) != 32 or any(c not in '0123456789abcdef' for c in nonce):
        raise PermissionError('Registered executor run identity required')
    if digest(args.profile) != args.profile_sha256 or digest(args.teacher_receipt) != args.teacher_receipt_sha256:
        raise ValueError('Runtime profile or teacher receipt changed')
    sys.path.insert(0,str(args.package_root/'src'))
    from agent_jsac.uav_training_preflight import compile_request
    # Reuse the native compiler as preparation only, then apply live authority.
    plan = compile_request(args.package_root,args.profile)
    files = plan['verified_files']
    receipt = json.loads(args.teacher_receipt.read_text(encoding='utf-8-sig'))
    validate_live_handoff(receipt,parent_sha256=files['u0_checkpoint']['sha256'],
        manifest_sha256=files['manifest']['sha256'],labels_path=files['target_pseudolabel_csv']['path'])
    count = verify_training_label_roles(files['manifest']['path'],files['target_pseudolabel_csv']['path'])
    command = plan['command']
    postfit = command.index('--postfit-roles')
    if command[postfit+1:] != ['source_development','support_dev','development_query']:
        raise PermissionError('Test or unrecognized postfit evaluation role')
    output = Path(command[command.index('--output-dir')+1])
    if args.result.resolve().is_relative_to(output.resolve()):
        raise ValueError('Tool result must be outside native training output')
    args.result.parent.mkdir(parents=True,exist_ok=True)
    stdout = args.result.with_suffix('.stdout.log')
    stderr = args.result.with_suffix('.stderr.log')
    started = time.time()
    with stdout.open('x',encoding='utf-8') as out, stderr.open('x',encoding='utf-8') as err:
        completed = subprocess.run(command,cwd=args.package_root,shell=False,
                                   stdout=out,stderr=err,check=False)
    checkpoint = output/'best.pt'
    native_receipt_path=output/'RUN_COMPLETE.json'
    native_receipt=json.loads(native_receipt_path.read_text()) if native_receipt_path.is_file() else {}
    success = (completed.returncode == 0 and checkpoint.is_file()
               and native_receipt.get('checkpoint_sha256') == digest(checkpoint)
               and native_receipt.get('best_checkpoint_selection_role') == 'support_dev'
               and native_receipt.get('locked_test_read') is False)
    result = dict(task='uav',mode='real',tool_run_id=nonce,tool='shadow_train',
        success=success,subprocess_exit_code=completed.returncode,simulation=False,
        training_process_started=True,training_performed=True if success else None,
        promotion_authorized=False,started_at=started,ended_at=time.time(),
        command=command,profile_sha256=args.profile_sha256,
        teacher_receipt_sha256=args.teacher_receipt_sha256,verified_files=files,
        label_count=count,checkpoint_sha256=digest(checkpoint) if success else None,
        checkpoint_path=str(checkpoint) if success else None,
        native_completion_receipt_sha256=digest(native_receipt_path) if native_receipt_path.is_file() else None,
        postfit_roles=command[postfit+1:],locked_test_read=False,
        permission_evidence='pinned native script and explicit role constraints; not an OS syscall trace')
    with args.result.open('x',encoding='utf-8') as handle:
        json.dump(result,handle,indent=2)
    if not success:
        raise SystemExit('Native training did not produce a successful checkpoint')


if __name__ == '__main__':
    main()
