"""Verify real non-Test deployment assets without evaluating model predictions."""
import argparse
import csv
import json
from pathlib import Path
from uav_registry_context import load_routing_context, digest, ALLOWED_ROLES


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest_sha = '9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2'
    if digest(args.manifest) != manifest_sha:
        raise ValueError('Manifest authority changed')
    config = args.root / 'configs/UAV_CORA_TARGET_COARSE_ROUTE_V3_20260907.json'
    receipt = args.root / 'artifacts/UAV_TARGET_COARSE_SET_STRICT_V3_20260907/PROMOTION_RECEIPT.json'
    config_sha = '980663b2786840146e6d4e3bf189d57499220e42b7b4e637137ba6fbf983f588'
    receipt_sha = 'c20e220b3f9fdccd5a488e09ba74c53ed93de2ff98ce9a259243912f8c57949b'
    with args.manifest.open(encoding='utf-8-sig', newline='') as handle:
        allowed = [row for row in csv.DictReader(handle) if row['agent_role'] in ALLOWED_ROLES]
    rows = []
    for row in allowed:
        context = load_routing_context(args.root, config, config_sha, receipt, receipt_sha,
                                       task='uav', site_id=row['physical_site'], row=row)
        rows.append({'sequence': row['sequence'], 'role': row['agent_role'], **context})
    result = {'task': 'uav', 'operation': 'runtime_asset_eligibility_audit',
              'rows': rows, 'manifest_sha256': manifest_sha,
              'model_predictions_evaluated': False, 'vlm_or_qwen_routing_evaluated': False,
              'radar_truth_read': False, 'test_payload_read': False,
              'source_only': sum(r['deployment']['eligible_models'] == ['source'] for r in rows),
              'adapted_eligible': sum('adapted' in r['deployment']['eligible_models'] for r in rows)}
    with args.output.open('x', encoding='utf-8') as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps({key: value for key, value in result.items() if key != 'rows'}))


if __name__ == '__main__':
    main()
