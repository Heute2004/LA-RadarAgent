"""Validate reuse of the native UAV offline background strategy."""
import hashlib
import json
from pathlib import Path


def validate_background(spec, rows):
    raw=Path(spec['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=spec['sha256']:
        raise ValueError('Background receipt hash mismatch')
    value=json.loads(raw)
    if (value.get('manifest_sha256')!=spec['manifest_sha256']
        or value.get('source_temporal_report_sha256')!=spec['source_temporal_report_sha256']
        or value.get('temporal_background_mode')!='full_episode_median_residual'
        or value.get('target_roles')!=['support_train']
        or any(value.get(key) is not False for key in (
            'target_truth_read','support_truth_read','development_query_read','locked_test_read'))):
        raise ValueError('Native background authority or permissions differ')
    allowed={int(row['sequence_id']) for row in rows
             if row['agent_role']=='support_train' and row['outer_split']=='train'}
    sequences=value.get('target_sequence_ids',[])
    if (not sequences or any(type(item) is not int for item in sequences)
        or len(set(sequences))!=len(sequences) or not set(sequences)<=allowed):
        raise ValueError('Background receipt includes unapproved episodes')
    return {'mode':'full_episode_median_residual','offline_teacher_only':True,
            'new_background_measurement':False,'execution_kind':'registered_strategy_reuse',
            'receipt_sha256':spec['sha256'],'support_sequences':sequences}
