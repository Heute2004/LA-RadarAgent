"""Offline shadow check. Only prediction arrays are loaded from saved outputs."""
import numpy as np

KEYS = ('frame_id', 'prediction_range_m', 'prediction_angle_deg', 'prediction_score')


def read_predictions(path):
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key].copy() for key in KEYS}


def compare_predictions(source, candidate):
    for predictions in (source, candidate):
        arrays = [np.asarray(predictions[key]) for key in KEYS]
        if (not arrays[0].size or any(array.ndim != 1 for array in arrays)
                or any(array.shape != arrays[0].shape for array in arrays)
                or any(not np.isfinite(array).all() for array in arrays)):
            raise ValueError('Invalid or nonfinite prediction stream')
        frames = arrays[0]
        if (np.any(frames < 0) or np.any(frames != np.floor(frames))
                or len(np.unique(frames)) != len(frames)):
            raise ValueError('Invalid or duplicate frame identity')
        if np.any(arrays[1] < 0) or np.any((arrays[3] < 0) | (arrays[3] > 1)):
            raise ValueError('Invalid range or confidence')
    if not np.array_equal(source['frame_id'], candidate['frame_id']):
        raise ValueError('Source and candidate frame identities differ')
    # Copy instead of arithmetic: the shadow candidate never changes the output.
    output = {key: np.asarray(source[key]).copy() for key in KEYS}
    return output, {'task': 'uav', 'scope': 'offline_saved_prediction_shadow',
                    'frames': len(output['frame_id']), 'candidate_weight': 0.0,
                    'source_output_exact': all(np.array_equal(output[k], source[k]) for k in KEYS),
                    'truth_arrays_loaded': False, 'promotion_authorized': False,
                    'runtime_registry_modified': False}
