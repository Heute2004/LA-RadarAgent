# Authorized Candidate Promotion

The numeric policy is an external operator-authorized input, not a policy that
Qwen may create or relax. No real numeric authorization is included in this
candidate package. Absence of authorization means rejection and source fallback.

## Required Evidence

1. An immutable policy file and its SHA256 supplied by the trusted configuration.
2. Exact UAV parent checkpoint, candidate checkpoint and manifest SHA256 bindings.
3. Actual parent and candidate Support-dev metrics under the same evaluator and
   frame scope: `ols_mid_map_30_70`, `ols_coarse_map_20_50`, `hit_at_1p5m`.
4. Verified training provenance and saved-prediction shadow evidence for those
   exact models. A policy passing alone is not permission to skip these checks.

The current training history stores only the parent's middle-threshold OLS.
Do not fill the other two parent metrics from another historical model, Query
results or an assumed constant. They require bound Support-dev evidence.

## External Fields

The policy has exactly `schema`, `task`, `authorization`, `identity` and
`thresholds`. `schema` is `numeric_promotion_policy`; `task` is `uav`.
Authorization explicitly records `authorized`, `task` and `split_role`.
The only accepted role here is `support_dev`.

Identity binds `parent_checkpoint_sha256`, `candidate_checkpoint_sha256` and
`manifest_sha256`. Thresholds contain all three fields below, with no defaults:

| Field | Comparison |
| --- | --- |
| `min_mid_gain` | candidate middle OLS minus parent middle OLS must be at least this value |
| `max_coarse_degradation` | parent coarse OLS minus candidate coarse OLS must not exceed this value |
| `max_hit_degradation` | parent Hit minus candidate Hit must not exceed this value |

Values use fractional metric units, not percentage-point integers. Negative
degradation limits require improvement. Finite values in [-1, 1] are required.
Duplicate JSON keys, missing fields, identity mismatch and Query/Test metrics
are rejected. Hash binding records identity; it does not independently prove
that an operator authorized the file. The trusted entry configuration supplies
that authority, never model-generated tool arguments.

## Result Meaning

`policy_passed` means only that all three numeric comparisons passed. The pure
evaluator never writes a registry, trains a model or performs promotion. The
Dispatcher must separately verify provenance and shadow evidence before an
exclusive registry write. Runtime routing must then consume that exact registry.

Synthetic unit-test policies are tests only. They are not production approvals,
performance results or permission to promote the current trained candidate.
The historical approved adapted checkpoint retains its separate authorization.

UAV has no expert-library stage. Human policy, metrics and expert lifecycle are
not inferred from this UAV contract.
