# UAV Background Commissioning

## Verified Native Method

The registered UAV teacher uses `full_episode_median_residual`, not a separate
empty-site recording. The receiver forms RA and RA-MTI residuals by applying
`temporal_median_residual` to all 300 maps in a permitted support-training
episode. This is offline, noncausal teacher preprocessing. It does not alter
the causal input contract of the deployed radar model.

Verified server implementation:

`/home/hyc/radar+ris/AGENT-JSAC/scripts/apply_uav_honly_source_candidate_association.py`

Function `_frame_views`, lines 100-108, calls the native residual function on
stacked RA/RA-MTI frames. Its temporal caller loads the background mode from the
frozen source temporal report, validates it, and uses it for target support.

## Native Evidence

The existing teacher receipt is:

`/home/hyc/radar+ris/AGENT-JSAC/artifacts/UAV_HONLY_TARGET_TEMPORAL_PSEUDOLABELS_V1G_BACKGROUND_GLOBAL_20260907/PSEUDOLABEL_RECEIPT.json`

It records `temporal_background_mode=full_episode_median_residual`, the bound
manifest SHA256
`9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2`,
and source temporal report SHA256
`1244000dca875d7bd462eef916672d20d884d39796ab3717df399a2c09e0529c`.
Its support sequences are 40, 43, 45, 64, 65, 68, 69 and 75. It records no
target truth, support truth, Development-query or Locked Test reading.
These are receipt/code claims, not an operating-system file-access trace.

## Required Adapter Semantics

Commissioning must validate and register the hash-bound native background
strategy and its applicable support scope. Reusing this artifact is not a new
background inference job and not a new empty-scene measurement. Native residual
computation belongs to teacher construction when a fresh teacher is requested.

`background_binding.validate_background` now verifies this registered receipt,
its manifest/source-temporal identity and permitted support scope. The preparation
adapter can register that strategy in real site memory; it continues to refuse
manifest-only commissioning. Server integration of this adapter remains pending.
No Human background expert or empty-site data may be silently substituted.

Verified native script SHA256:
`10ed64a9923371345badbc770ac0882b93fc19947da74493439bb727d419a098`.
Verified receipt SHA256:
`c02fff83bf9051156bea09b7873337a1bae1ca6726f230adf71177b99064f94c`.
