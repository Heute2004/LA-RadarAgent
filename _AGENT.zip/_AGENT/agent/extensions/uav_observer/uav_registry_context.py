"""Project verified UAV assets into metric-free decision context.

Deployment identity and permissions come from the caller's audited manifest,
not from observer text. The full historical registry is never sent to Qwen.
"""
import hashlib
import json
from pathlib import Path


ALLOWED_ROLES = {'source_supervised_train', 'source_development', 'support_train',
                 'support_dev', 'development_query'}
ROLE_SPLITS = {role: ('development' if role in {'source_development', 'development_query'} else 'train')
               for role in ALLOWED_ROLES}


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def _read_pinned(path, expected):
    if digest(path) != expected:
        raise ValueError('Routing authority hash mismatch')
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def load_routing_context(root, config_path, config_sha256, receipt_path, receipt_sha256,
                         *, task, site_id, row):
    if task != 'uav' or row.get('physical_site') != site_id:
        raise ValueError('Wrong task or deployment identity')
    if row.get('agent_role') not in ALLOWED_ROLES or row.get('outer_split') != ROLE_SPLITS[row['agent_role']]:
        raise ValueError('Unapproved or Test role')
    root = Path(root).resolve()
    config = _read_pinned(config_path, config_sha256)
    scope = config['routing_scope']
    names = {'source': scope['source_or_unknown_route'], 'adapted': scope['registered_target_route']}

    def verified_checkpoint(alias):
        model = config['models'][names[alias]]
        path = (root / model['relative_checkpoint']).resolve()
        if not path.is_relative_to(root):
            raise ValueError('Checkpoint escapes asset root')
        if not path.is_file() or digest(path) != model['sha256']:
            return None
        return {'path': str(path), 'sha256': model['sha256']}

    source = verified_checkpoint('source')
    if source is None:
        raise ValueError('Exact source fallback is unavailable')
    eligible, assets, status = ['source'], {'source': source}, 'not_target_site'
    if row.get('scene_category') == 'target':
        receipt = _read_pinned(receipt_path, receipt_sha256)
        false_fields = {'locked_test_read', 'development_query_used_for_selection',
                        'target_rtk_used_for_training', 'target_rtk_used_for_pseudolabels',
                        'source_route_replacement'}
        valid = (receipt.get('decision') == 'PROMOTED_AS_REGISTERED_TARGET_COARSE_ROUTE'
                 and receipt.get('decision_scope') == 'registered_target_site_or_condition_only'
                 and receipt.get('route_contract_sha256') == config_sha256
                 and receipt.get('parent', {}).get('checkpoint_sha256') == source['sha256']
                 and receipt.get('candidate', {}).get('checkpoint_sha256') == config['models'][names['adapted']]['sha256']
                 and all(receipt.get('integrity', {}).get(field) is False for field in false_fields))
        if not valid:
            status = 'promotion_receipt_not_eligible'
        else:
            adapted = verified_checkpoint('adapted')
            status = 'checkpoint_unavailable_or_mismatched' if adapted is None else 'registered_target_eligible'
            if adapted is not None:
                eligible.append('adapted')
                assets['adapted'] = adapted
    return {'deployment': {'task': task, 'site_id': site_id, 'registered': True,
                            'retrieval_complete': False, 'eligible_models': eligible},
            'assets': assets, 'adapted_status': status,
            'authority_sha256': config_sha256, 'promotion_receipt_sha256': receipt_sha256}
