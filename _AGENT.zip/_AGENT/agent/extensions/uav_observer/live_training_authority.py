"""Validate real teacher output identity; not a promotion or quality decision.

The executor must supply its own completed tool receipt, never Qwen-authored
JSON. Historical simulation fixtures remain invalid for this live handoff.
"""
from pathlib import Path
from uav_registry_context import digest


def validate_live_handoff(receipt, *, parent_sha256, manifest_sha256, labels_path):
    expected = {'task':'uav', 'mode':'real', 'tool':'construct_weak_evidence',
                'parent_checkpoint_sha256':parent_sha256, 'manifest_sha256':manifest_sha256}
    if not isinstance(receipt, dict) or any(receipt.get(key) != value for key,value in expected.items()):
        raise ValueError('Real teacher lineage mismatch')
    if receipt.get('success') is not True:
        raise ValueError('Teacher tool has not completed successfully')
    kind = receipt.get('execution_kind','subprocess')
    if kind == 'subprocess':
        if type(receipt.get('subprocess_exit_code')) is not int or receipt['subprocess_exit_code'] != 0:
            raise ValueError('Teacher process has not completed successfully')
    elif kind == 'registered_artifact_reuse':
        if receipt.get('subprocess_exit_code') is not None or receipt.get('new_teacher_inference') is not False:
            raise ValueError('Reused artifacts must not claim new teacher execution')
        authority = receipt.get('source_authority',{})
        if set(authority) != {'path','sha256'} or digest(authority['path']) != authority['sha256']:
            raise ValueError('Reused teacher authority is missing or changed')
    else:
        raise ValueError('Unknown teacher execution kind')
    for flag in ('simulation','target_truth_read','locked_test_read','development_query_read'):
        if receipt.get(flag) is not False:
            raise ValueError('Teacher evidence permission violation: ' + flag)
    if not isinstance(receipt.get('run_id'),str) or not receipt['run_id'].strip():
        raise ValueError('Missing producer identity')
    output = receipt.get('output')
    if not isinstance(output,dict) or set(output) != {'path','sha256'}:
        raise ValueError('Missing exact output binding')
    path = Path(output['path'])
    if not path.is_absolute() or path.resolve() != Path(labels_path).resolve():
        raise ValueError('Teacher output is not the requested training labels')
    if digest(path) != output['sha256']:
        raise ValueError('Teacher output changed after execution')
    return dict(output)
