"""Bind external native assets for one fresh UAV execution acceptance run."""
import argparse
import json
from pathlib import Path
import sys
from uav_registry_context import digest


def main():
    p=argparse.ArgumentParser()
    for name in ('package-root','asset-root','manifest','labels','parent','python','output','profile'):
        p.add_argument('--'+name,type=Path,required=True)
    args=p.parse_args()
    if args.profile.exists() or args.output.exists():
        raise FileExistsError('Profile and native output must be fresh')
    contract=json.loads((args.package_root/'tasks/uav/training.json').read_text(encoding='utf-8'))
    paths={'script':args.package_root/contract['implementation'],
           'parameters':args.package_root/contract['adaptation_parameters'],
           'manifest':args.manifest,'u0_checkpoint':args.parent,'target_pseudolabel_csv':args.labels}
    parameters=json.loads(paths['parameters'].read_text(encoding='utf-8'))
    if digest(args.parent)!=parameters['u0_checkpoint_sha256'] or digest(args.manifest)!=parameters['manifest_sha256']:
        raise ValueError('This acceptance run must reproduce the adopted parent and protocol')
    if digest(args.labels)!=parameters['pseudolabel_sha256']:
        raise ValueError('This is not the ordinary-confidence experiment')
    profile={'task':'uav','mode':'intercept',
        'bindings':{'manifest':str(args.manifest),'truth_root':str(args.asset_root/parameters['truth_root']),
                    'u0_checkpoint':str(args.parent),'target_pseudolabel_csv':str(args.labels),
                    'output_dir':str(args.output),'device':'cuda:0'},
        'expected_hashes':{key:digest(path) for key,path in paths.items()},
        'python_executable':str(args.python)}
    with args.profile.open('x',encoding='utf-8') as handle:
        json.dump(profile,handle,indent=2)
    sys.path.insert(0,str(args.package_root/'src'))
    from agent_jsac.uav_training_preflight import compile_request
    plan=compile_request(args.package_root,args.profile)
    print(json.dumps({'profile':str(args.profile),'profile_sha256':digest(args.profile),
                      'command':plan['command'],'training_started':False,
                      'live_teacher_validation_still_required':True}))


if __name__=='__main__':
    main()
