"""Verify actual source fallback execution from a pinned isolated registry.

This acceptance tool does not authorize adapted deployment or evaluate accuracy.
Only explicit Train episodes are read; no truth reader is instantiated.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import time


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_registry(record, row):
    if (record.get('task') != 'uav' or record.get('model') != 'source'
            or record.get('scope') != 'isolated_candidate_runtime'
            or row.get('outer_split') != 'train'
            or row.get('agent_role') not in {'support_train', 'source_supervised_train'}
            or row.get('physical_site') != record.get('site_id')
            or not re.fullmatch('[a-f0-9]{64}', record.get('checkpoint_sha256', ''))
            or not re.fullmatch('[a-f0-9]{32}', record.get('tool_run_id', ''))):
        raise ValueError('Unapproved runtime registry, task, site or episode role')
    return dict(record)


def main():
    parser = argparse.ArgumentParser()
    for name in ('registry', 'manifest', 'package-root', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--registry-sha256', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--sequence-id', type=int, required=True)
    parser.add_argument('--frames', type=int, default=3)
    args = parser.parse_args()
    if (args.output.exists() or not 1 <= args.frames <= 3
            or digest(args.registry) != args.registry_sha256
            or digest(args.manifest) != args.manifest_sha256):
        raise ValueError('Changed input or invalid output/frame scope')
    with args.manifest.open(encoding='utf-8-sig', newline='') as handle:
        rows = [row for row in csv.DictReader(handle)
                if int(row['sequence_id']) == args.sequence_id]
    if len(rows) != 1:
        raise ValueError('Episode not unique in manifest')
    record = validate_registry(json.loads(args.registry.read_text()), rows[0])
    if digest(record['checkpoint']) != record['checkpoint_sha256']:
        raise ValueError('Registered checkpoint changed')
    sys.path.insert(0, str(args.package_root / 'src'))
    import numpy as np
    import torch
    from agent_jsac.cora_u_radar_only import (CoraURadarOnlyGlobalPolar,
        FrozenUavGlobalPolarInferenceDataset, predict_cora_u_global_model)
    torch.set_num_threads(4)
    payload = torch.load(record['checkpoint'], map_location='cpu', weights_only=False)
    config = payload['config']
    model = CoraURadarOnlyGlobalPolar(**{key:int(config[key]) for key in
        ('base_channels','state_channels','attention_heads')}, causal=True).eval()
    model.load_state_dict(payload['state_dict'], strict=True)
    norm = config['source_normalization']
    dataset = FrozenUavGlobalPolarInferenceDataset(manifest_path=args.manifest,
        window_size=16, temporal_mode='causal', channel_mean=tuple(norm['mean']),
        channel_std=tuple(norm['std']), allowed_roles={rows[0]['agent_role']},
        allowed_sequence_ids={args.sequence_id})
    count = len(dataset.records)
    if not count:
        raise ValueError('Empty episode')
    indices = np.unique(np.linspace(0, count-1, min(args.frames, count), dtype=int))
    dataset.records = [dataset.records[index] for index in indices]
    started = time.perf_counter()
    with torch.inference_mode():
        predictions = predict_cora_u_global_model(model, dataset,
            device=torch.device('cpu'), batch_size=1)
    elapsed = time.perf_counter() - started
    values = predictions[args.sequence_id]
    if any(not np.isfinite(array).all() for array in values.values()):
        raise ValueError('Non-finite runtime prediction')
    args.output.mkdir(parents=True)
    path = args.output / 'predictions.npz'
    with path.open('xb') as handle:
        np.savez_compressed(handle, **values)
    receipt = dict(task='uav', scope='isolated_registry_source_runtime',
        model=record['model'], checkpoint_sha256=record['checkpoint_sha256'],
        registry_sha256=args.registry_sha256, route_tool_run_id=record['tool_run_id'],
        manifest_sha256=args.manifest_sha256, sequence_id=args.sequence_id,
        frames=len(dataset), prediction_sha256=digest(path), execution_seconds=elapsed,
        device='server_cpu', real_radar_inference=True, training_performed=False,
        truth_read=False, locked_test_read=False, performance_evaluation=False)
    (args.output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
