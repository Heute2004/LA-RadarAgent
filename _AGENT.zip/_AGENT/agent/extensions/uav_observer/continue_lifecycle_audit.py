"""Resume the same real lifecycle with explicit completed-product reuse."""
import hashlib
import json
from pathlib import Path
import sys
import os


def main():
    workspace=Path(__file__).resolve().parent
    root=workspace.parents[1]
    os.chdir(root)
    package=workspace/'Observation-Decision-Agent'
    sys.path.insert(0,str(package/'src'))
    from agent_jsac.memory import TypedMemory
    from agent_jsac.qwen_policy import RankedChoice,TransformersQwenChoiceScorer
    from post_training_tools import PostTrainingTools
    from live_workflow_driver import run_step,recover_step
    output=workspace/'preparation_lifecycle_single_registration'
    memory=TypedMemory(output/'memory')
    ledger=memory.ledger_records()
    resuming=ledger[-1].get('step_status')=='started' and ledger[-1].get('state')=='shadow_train'
    if ledger[-1].get('next_state')!='branch_selection' and not resuming:
        raise ValueError('Expected completed teacher step')
    episode=memory.episode_records()[-1]
    paths={'source':root/'artifacts/UAV_V6_CORA_GLOBAL_20260906T104649Z/u0_global_polar/best.pt',
        'teacher':output/'teacher/receipt.json',
        'candidate':workspace/'live_adaptation/best.pt',
        'native_complete':workspace/'live_adaptation/RUN_COMPLETE.json',
        'history':workspace/'live_adaptation/train_history.json',
        'training_execution':workspace/'qwen_live_training_acceptance/training_result.json'}
    artifacts={key:{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        for key,path in paths.items()}
    if (artifacts['source']['sha256']!='cda324817f9519dfc8eeecc2d9f45ec359f77213a86789a058b488ab86a36a98'
        or artifacts['candidate']['sha256']!='5b7421d4fbe4d58682e51bee3169941acb08a874b86d6f176cf4ec3b2d8e1844'):
        raise ValueError('Registered source or completed candidate differs')
    profile={'site_id':episode['site_id'],'episode_id':episode['episode_id'],'artifacts':artifacts,
        'manifest_sha256':'9192a839200366d1f0346f0a5065cacd353c6dcbaf702037bbaae4e732f747e2',
        'training_profile_sha256':'04158e8a82b1df5a35ddd9e7717d62bec8051a94bafc850e66c6ba3c4ad2cb62',
        'runtime_registry':str(output/'runtime_route.json')}
    profile_path=output/'post_training_profile.json'
    if resuming:
        if json.loads(profile_path.read_text())!=profile: raise ValueError('Recovery profile changed')
    else:
        with profile_path.open('x') as handle: json.dump(profile,handle,indent=2)
    backend=PostTrainingTools(profile,artifact_root=root)
    scorer=TransformersQwenChoiceScorer(root.parent/'JSAC-AGENT-V4/models/Qwen2.5-0.5B-Instruct',device='cpu')
    workflow=json.loads((package/'tasks/uav/workflow.json').read_text())
    choices=[RankedChoice(name,name.replace('_',' '),())
        for name in ('select_parent_branch','shadow_train','audit_candidate')]
    context=dict(task='uav',site_id=episode['site_id'],episode_id=episode['episode_id'],
        observation=None,now=0,max_age_s=10,radar_health={'status':'not_measured'},
        memory_summary=memory.episode_records(),last_tool_result=ledger[-1].get('tool_result'),
        deployment={'task':'uav','site_id':episode['site_id'],'registered':True,
            'retrieval_complete':True,'eligible_models':['source']})
    state='branch_selection'
    if resuming:
        state,result=recover_step(workflow=workflow,backend=backend,memory=memory,
            lifecycle_id=ledger[-1]['lifecycle_id'])
        context['last_tool_result']=result
    for _ in range(1 if resuming else 3):
        state,result=run_step(workflow=workflow,state=state,scorer=scorer,choices=choices,
            context=context,backend=backend,memory=memory,lifecycle_id=ledger[-1]['lifecycle_id'])
        context['last_tool_result']=result
        print(json.dumps({'next_state':state,'result':result}),flush=True)
    if state!='zero_weight_canary': raise RuntimeError('Unexpected post-training state')


if __name__=='__main__': main()
