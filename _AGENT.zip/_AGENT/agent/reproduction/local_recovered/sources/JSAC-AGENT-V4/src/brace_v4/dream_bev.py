"""DREAM-BEV Foundation: a causal CPM-2D-Lite-inspired RA/RA-MIT backbone."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn
from torch.nn import functional as functional


@dataclass(frozen=True)
class BEVGeometry:
    x_min_m: float = -10.0
    x_max_m: float = 10.0
    y_min_m: float = 0.0
    y_max_m: float = 23.4
    resolution_m: float = 0.1
    range_bins: int = 128
    azimuth_bins: int = 128
    sample_rate_hz: float = 6.25e6
    slope_hz_per_s: float = 9.994e12
    range_fft_size: int = 512

    @property
    def x_bins(self) -> int:
        return int(round((self.x_max_m - self.x_min_m) / self.resolution_m))

    @property
    def y_bins(self) -> int:
        return int(round((self.y_max_m - self.y_min_m) / self.resolution_m))

    @property
    def range_resolution_m(self) -> float:
        return 299_792_458.0 * self.sample_rate_hz / (2.0 * self.slope_hz_per_s * self.range_fft_size)

    def coordinate_grid(self, device: torch.device | None = None, dtype: torch.dtype = torch.float32) -> Tensor:
        x = self.x_min_m + torch.arange(self.x_bins, device=device, dtype=dtype) * self.resolution_m
        y = self.y_min_m + torch.arange(self.y_bins, device=device, dtype=dtype) * self.resolution_m
        grid_x, grid_y = torch.meshgrid(x, y, indexing="ij")
        return torch.stack((grid_x, grid_y), dim=-1)

    def metric_to_index(self, xy_m: Tensor) -> Tensor:
        x = torch.round((xy_m[..., 0] - self.x_min_m) / self.resolution_m).long().clamp(0, self.x_bins - 1)
        y = torch.round((xy_m[..., 1] - self.y_min_m) / self.resolution_m).long().clamp(0, self.y_bins - 1)
        return torch.stack((x, y), dim=-1)

    def index_to_metric(self, index: Tensor) -> Tensor:
        index = index.to(dtype=torch.float32)
        return torch.stack((self.x_min_m + index[..., 0] * self.resolution_m, self.y_min_m + index[..., 1] * self.resolution_m), dim=-1)


class PolarToBEV(nn.Module):
    def __init__(self, geometry: BEVGeometry) -> None:
        super().__init__()
        metric = geometry.coordinate_grid()
        x, y = metric.unbind(dim=-1)
        radius = torch.sqrt(x.square() + y.square())
        range_index = radius / geometry.range_resolution_m
        azimuth_index = ((torch.where(radius > 1e-6, x / radius, torch.zeros_like(radius))) + 1.0) * (geometry.azimuth_bins / 2.0)
        sampling_grid = torch.stack(
            (2.0 * azimuth_index / (geometry.azimuth_bins - 1) - 1.0, 2.0 * range_index / (geometry.range_bins - 1) - 1.0),
            dim=-1,
        ).unsqueeze(0)
        self.register_buffer("sampling_grid", sampling_grid, persistent=False)

    def forward(self, polar: Tensor) -> Tensor:
        grid = self.sampling_grid.to(device=polar.device, dtype=polar.dtype)
        return functional.grid_sample(polar, grid.expand(polar.shape[0], -1, -1, -1), mode="bilinear", padding_mode="zeros", align_corners=True)


def _groups(channels: int) -> int:
    return 8 if channels % 8 == 0 else 1


class ConvNormAct(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
        super().__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.GroupNorm(_groups(out_channels), out_channels),
            nn.SiLU(inplace=True),
        )


class ResidualBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(ConvNormAct(channels, channels), ConvNormAct(channels, channels))

    def forward(self, values: Tensor) -> Tensor:
        return values + self.layers(values)


class CausalMambaMixer(nn.Module):
    """True Mamba temporal mixer; V4 training must run in the verified WSL environment."""

    def __init__(self, channels: int = 64) -> None:
        super().__init__()
        try:
            from mamba_ssm import Mamba
        except ImportError as error:  # pragma: no cover - environment contract
            raise ImportError(
                "DREAM-BEV Foundation requires mamba_ssm. Use the verified WSL mamba environment from F:\\codex\\CODEx_STATE.md."
            ) from error
        self.mixer = Mamba(d_model=channels, d_state=16, d_conv=4, expand=2)
        self.norm = nn.LayerNorm(channels)

    def forward(self, tokens: Tensor) -> Tensor:
        if tokens.ndim != 3:
            raise ValueError("temporal tokens must be [batch,time,channels]")
        return self.norm(tokens + self.mixer(tokens))


class DREAMBEVFoundation(nn.Module):
    """Causal CPM-2D-Lite-inspired foundation with a stable BEV feature interface."""

    architecture_id = "DREAM-BEV-Foundation-CPM2D-CausalMamba-Presence-V2"

    def __init__(self, geometry: BEVGeometry | None = None) -> None:
        super().__init__()
        self.geometry = geometry or BEVGeometry()
        # Match the compact CPM-2D-Lite contract: temporal Mamba operates on
        # 64x64 polar tokens, then the latest state is restored to 128x128.
        self.stem = nn.Sequential(ConvNormAct(2, 64, stride=2), ConvNormAct(64, 64))
        self.temporal = CausalMambaMixer(64)
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.polar_to_bev = PolarToBEV(self.geometry)
        self.bev_stem = nn.Sequential(ConvNormAct(48, 64), ResidualBlock(64))
        self.bev_down1 = nn.Sequential(ConvNormAct(64, 96, stride=2), ResidualBlock(96))
        self.bev_down2 = nn.Sequential(ConvNormAct(96, 128, stride=2), ResidualBlock(128))
        self.decode = nn.Sequential(ConvNormAct(128, 96), ResidualBlock(96), ConvNormAct(96, 64))
        self.logit_head = nn.Conv2d(64, 1, kernel_size=1)
        self.presence_head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, 64), nn.SiLU(), nn.Linear(64, 1))
        nn.init.constant_(self.logit_head.bias, -2.19)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        if radar.ndim != 5 or radar.shape[2:] != (2, 128, 128):
            raise ValueError("radar must be [batch,time,2,128,128]")
        batch, time_steps = radar.shape[:2]
        spatial = self.stem(radar.reshape(batch * time_steps, 2, 128, 128))
        _, channels, height, width = spatial.shape
        tokens = spatial.reshape(batch, time_steps, channels, height, width).permute(0, 3, 4, 1, 2).reshape(batch * height * width, time_steps, channels)
        latest = self.temporal(tokens)[:, -1].reshape(batch, height, width, channels).permute(0, 3, 1, 2)
        polar_feature = self.reduce(functional.interpolate(latest, size=(128, 128), mode="bilinear", align_corners=False))
        bev = self.polar_to_bev(polar_feature)
        shared = self.bev_down2(self.bev_down1(self.bev_stem(bev)))
        decoded = functional.interpolate(self.decode(shared), size=(self.geometry.x_bins, self.geometry.y_bins), mode="bilinear", align_corners=False)
        return {
            "logits": self.logit_head(decoded),
            "presence_logit": self.presence_head(shared),
            "shared_feature": shared,
            "polar_feature": polar_feature,
        }


class GaussianFocalCoordinateLoss(nn.Module):
    def __init__(self, geometry: BEVGeometry | None = None, sigma_m: float = 0.35, coordinate_weight: float = 0.05) -> None:
        super().__init__()
        self.geometry = geometry or BEVGeometry()
        self.sigma_m = float(sigma_m)
        self.coordinate_weight = float(coordinate_weight)
        self.register_buffer("grid", self.geometry.coordinate_grid(), persistent=False)

    def target(self, xy_m: Tensor) -> Tensor:
        grid = self.grid.to(device=xy_m.device, dtype=xy_m.dtype)
        delta = grid.unsqueeze(0) - xy_m[:, None, None, :]
        target = torch.exp(-0.5 * delta.square().sum(dim=-1) / (self.sigma_m * self.sigma_m))
        indices = self.geometry.metric_to_index(xy_m)
        target[torch.arange(xy_m.shape[0], device=xy_m.device), indices[:, 0], indices[:, 1]] = 1.0
        return target.unsqueeze(1)

    def decode_softargmax(self, logits: Tensor) -> Tensor:
        flat = torch.softmax(logits[:, 0].float().flatten(1) / 0.25, dim=-1)
        return flat @ self.grid.to(device=logits.device, dtype=torch.float32).reshape(-1, 2)

    def per_sample(self, logits: Tensor, xy_m: Tensor) -> tuple[Tensor, dict[str, Tensor]]:
        """Return one coordinate loss per frame for confidence-weighted teachers."""
        target = self.target(xy_m.float())
        stable_logits = logits.float()
        probability = stable_logits.sigmoid()
        positive = target.eq(1.0)
        pos = -(1.0 - probability).pow(2.0) * (-functional.softplus(-stable_logits))
        neg = -((1.0 - target).pow(4.0)) * probability.pow(2.0) * (-functional.softplus(stable_logits))
        heatmap = torch.where(positive, pos, neg).flatten(1).sum(1)
        coordinate = functional.smooth_l1_loss(
            self.decode_softargmax(stable_logits), xy_m.float(), reduction="none"
        ).mean(dim=1)
        return heatmap + self.coordinate_weight * coordinate, {
            "heatmap": heatmap.detach(),
            "coordinate": coordinate.detach(),
        }

    def forward(self, logits: Tensor, xy_m: Tensor) -> tuple[Tensor, dict[str, Tensor]]:
        target = self.target(xy_m.float())
        stable_logits = logits.float()
        probability = stable_logits.sigmoid()
        positive = target.eq(1.0)
        pos = -(1.0 - probability).pow(2.0) * (-functional.softplus(-stable_logits))
        neg = -((1.0 - target).pow(4.0)) * probability.pow(2.0) * (-functional.softplus(stable_logits))
        heatmap = torch.where(positive, pos, neg).flatten(1).sum(1).mean()
        coordinate = functional.smooth_l1_loss(self.decode_softargmax(stable_logits), xy_m.float())
        total = heatmap + self.coordinate_weight * coordinate
        return total, {"heatmap": heatmap.detach(), "coordinate": coordinate.detach()}


class RadarPresenceLocalizationLoss(GaussianFocalCoordinateLoss):
    """Joint presence and BEV localization loss with exact empty-frame masking."""

    def __init__(self, geometry: BEVGeometry | None = None, sigma_m: float = 0.35, coordinate_weight: float = 0.05, presence_weight: float = 1.0) -> None:
        super().__init__(geometry=geometry, sigma_m=sigma_m, coordinate_weight=coordinate_weight)
        self.presence_weight = float(presence_weight)

    def target_with_empty(self, xy_m: Tensor, has_person: Tensor) -> Tensor:
        target = xy_m.new_zeros((xy_m.shape[0], 1, self.geometry.x_bins, self.geometry.y_bins))
        positive = has_person.to(dtype=torch.bool)
        if bool(positive.any()):
            target[positive] = self.target(xy_m[positive].float())
        return target

    def forward(self, logits: Tensor, presence_logits: Tensor, xy_m: Tensor, has_person: Tensor) -> tuple[Tensor, dict[str, Tensor]]:
        target = self.target_with_empty(xy_m.float(), has_person)
        stable_logits = logits.float()
        probability = stable_logits.sigmoid()
        positive = target.eq(1.0)
        pos = -(1.0 - probability).pow(2.0) * (-functional.softplus(-stable_logits))
        neg = -((1.0 - target).pow(4.0)) * probability.pow(2.0) * (-functional.softplus(stable_logits))
        heatmap = torch.where(positive, pos, neg).flatten(1).sum(1).mean()
        has_person_float = has_person.to(dtype=stable_logits.dtype)
        presence = functional.binary_cross_entropy_with_logits(presence_logits.squeeze(1).float(), has_person_float)
        person_mask = has_person.to(dtype=torch.bool)
        if bool(person_mask.any()):
            coordinate = functional.smooth_l1_loss(self.decode_softargmax(stable_logits[person_mask]), xy_m[person_mask].float())
        else:
            coordinate = stable_logits.sum() * 0.0
        total = heatmap + self.coordinate_weight * coordinate + self.presence_weight * presence
        return total, {
            "heatmap": heatmap.detach(),
            "coordinate": coordinate.detach(),
            "presence": presence.detach(),
            "positive_frames": person_mask.sum().detach(),
            "empty_frames": (~person_mask).sum().detach(),
        }


@torch.inference_mode()
def decode_peak(logits: Tensor, geometry: BEVGeometry | None = None) -> tuple[Tensor, Tensor]:
    geometry = geometry or BEVGeometry()
    score, flat = logits[:, 0].sigmoid().flatten(1).max(dim=1)
    x = torch.div(flat, geometry.y_bins, rounding_mode="floor")
    y = flat.remainder(geometry.y_bins)
    return geometry.index_to_metric(torch.stack((x, y), dim=-1)).to(logits.device), score
