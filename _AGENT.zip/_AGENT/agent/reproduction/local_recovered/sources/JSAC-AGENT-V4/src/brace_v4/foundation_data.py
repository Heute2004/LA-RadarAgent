"""Data contracts for the V4 simple-scene foundation models.

This module intentionally only exposes left RGB, Radar-H RA, Radar-H RA-MIT,
and offline source-stage BEV supervision.  It never accepts depth, right RGB,
manual route labels, future frames, or target-site human labels.
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset


SIMPLE_FOUNDATION_SEQUENCES = frozenset(
    {
        *(f"seq_{value:03d}" for value in range(38, 44)),
        *(f"seq_{value:03d}" for value in range(61, 105) if value not in {64, 84}),
    }
)

# These are deployment-commissioned backgrounds.  They supervise only the
# no-person/presence objective; no target-site human location is exposed.
COMMISSIONING_EMPTY_SITES = {
    "site_00_l_corridor": "l_corridor_background",
    "site_01_open_indoor": "open_indoor_background",
    "site_02_cluttered_indoor": "cluttered_indoor_background",
    "site_03_open_outdoor": "open_outdoor_background",
    "site_04_complex_outdoor_rain_night": "complex_outdoor_rain_night_background",
    "site_05_complex_outdoor_dry_day": "complex_outdoor_dry_day_background",
    "site_06_complex_outdoor_rain_day": "complex_outdoor_rain_day_background",
}


def as_bool(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def validate_foundation_split(payload: dict[str, Any]) -> None:
    train = {str(value).strip().lower() for value in payload.get("train", ())}
    development = {str(value).strip().lower() for value in payload.get("development", ())}
    if not train or not development:
        raise ValueError("foundation split must contain non-empty train and development sequence lists")
    if train & development:
        raise ValueError(f"foundation train/development sequences must be disjoint: {sorted(train & development)}")
    invalid = (train | development) - SIMPLE_FOUNDATION_SEQUENCES
    if invalid:
        raise ValueError(f"foundation split contains non-simple or explicitly excluded sequences: {sorted(invalid)}")


def load_foundation_split(path: str | Path) -> dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_foundation_split(payload)
    return payload


@dataclass(frozen=True)
class FoundationFrameRecord:
    sample_source: str
    sequence: str
    frame_id: int
    split: str
    ra_path: Path
    ra_mti_path: Path
    rgb_path: Path
    person_label_path: Path
    target_xy_m: tuple[float, float]
    has_person: bool
    input_valid: bool
    label_valid: bool


class FoundationRadarDataset(Dataset[dict[str, Tensor | str]]):
    """Past-only RA/RA-MIT clips for source-stage radar foundation training."""

    def __init__(
        self,
        data_root: str | Path,
        manifest_path: str | Path,
        split: str,
        *,
        empty_root: str | Path | None = None,
        clip_length: int = 16,
        db_center: float = 80.0,
        db_scale: float = 30.0,
        cache_in_memory: bool = False,
    ) -> None:
        if clip_length < 1:
            raise ValueError("clip_length must be positive")
        roots = {"human_data": Path(data_root)}
        if empty_root is not None:
            roots["empty_data"] = Path(empty_root)
        self.clip_length = int(clip_length)
        self.db_center = float(db_center)
        self.db_scale = float(db_scale)
        self.cache_in_memory = bool(cache_in_memory)
        self._cache: dict[Path, Tensor] = {}
        self._sequence_cache: dict[str, Tensor] = {}
        grouped: dict[str, list[FoundationFrameRecord]] = defaultdict(list)
        with Path(manifest_path).open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                if row["split"].strip().lower() != split.strip().lower():
                    continue
                sample_source = row.get("sample_source", "source_human").strip()
                root_name = row.get("radar_root", "human_data").strip()
                if root_name not in roots:
                    raise ValueError(f"unknown radar source root: {root_name}")
                sequence = row["sequence"].strip().lower()
                is_empty = sample_source == "source_empty_negative"
                if not is_empty and sequence not in SIMPLE_FOUNDATION_SEQUENCES:
                    raise ValueError(f"foundation manifest contains prohibited human sequence: {sequence}")
                if is_empty and sequence not in COMMISSIONING_EMPTY_SITES:
                    raise ValueError(f"foundation manifest contains prohibited empty site: {sequence}")
                grouped[sequence].append(
                    FoundationFrameRecord(
                        sample_source=sample_source,
                        sequence=sequence,
                        frame_id=int(row["frame_id"]),
                        split=row["split"],
                        ra_path=roots[root_name] / row["ra_relpath"],
                        ra_mti_path=roots[root_name] / row["ra_mti_relpath"],
                        rgb_path=roots[root_name] / row.get("rgb_relpath", ""),
                        person_label_path=roots[root_name] / row.get("person_label_relpath", ""),
                        target_xy_m=(float(row["target_x_m"]), float(row["target_y_m"])),
                        has_person=as_bool(row.get("has_person", row.get("label_valid", "True"))),
                        input_valid=as_bool(row["input_valid"]),
                        label_valid=as_bool(row["label_valid"]),
                    )
                )
        self.sequences = {
            sequence: tuple(sorted(records, key=lambda item: item.frame_id))
            for sequence, records in sorted(grouped.items())
        }
        self.samples: list[tuple[str, int]] = []
        for sequence, records in self.sequences.items():
            for position, record in enumerate(records):
                history = self._history_positions(position)
                label_is_consistent = (not record.has_person) or record.label_valid
                if label_is_consistent and record.input_valid and all(records[index].input_valid for index in history):
                    self.samples.append((sequence, position))
        if not self.samples:
            raise ValueError(f"no eligible foundation samples for split={split!r}")
        if self.cache_in_memory:
            self._preload_sequence_clips()

    def _history_positions(self, end_position: int) -> list[int]:
        return [max(0, end_position - self.clip_length + 1 + offset) for offset in range(self.clip_length)]

    def _read_map(self, path: Path) -> Tensor:
        cached = self._cache.get(path)
        if cached is not None:
            return cached
        if not path.is_file():
            raise FileNotFoundError(f"missing radar input: {path}")
        values = np.load(path, allow_pickle=False).astype(np.float32, copy=False)
        if values.shape != (128, 128):
            raise ValueError(f"radar map must be 128x128, got {values.shape}: {path}")
        values = np.nan_to_num(values, nan=self.db_center, posinf=self.db_center + self.db_scale, neginf=self.db_center - self.db_scale)
        tensor = torch.from_numpy(np.clip((values - self.db_center) / self.db_scale, -3.0, 3.0))
        if self.cache_in_memory:
            self._cache[path] = tensor
        return tensor

    def _preload_sequence_clips(self) -> None:
        """Materialize each source sequence once for inexpensive causal indexing."""

        for sequence, records in self.sequences.items():
            frames = [
                torch.stack(
                    (self._read_map(record.ra_path), self._read_map(record.ra_mti_path)),
                    dim=0,
                )
                for record in records
            ]
            self._sequence_cache[sequence] = torch.stack(frames, dim=0).contiguous()
        # The contiguous sequence tensors are now the cache; retaining every
        # per-view tensor would double the resident RAM footprint.
        self._cache.clear()

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        sequence, position = self.samples[index]
        records = self.sequences[sequence]
        history_positions = self._history_positions(position)
        target = records[position]
        cached_sequence = self._sequence_cache.get(sequence)
        if cached_sequence is not None:
            radar = cached_sequence.index_select(
                0, torch.tensor(history_positions, dtype=torch.long)
            )
        else:
            history = [records[item] for item in history_positions]
            radar = torch.stack(
                [
                    torch.stack(
                        (self._read_map(record.ra_path), self._read_map(record.ra_mti_path)),
                        dim=0,
                    )
                    for record in history
                ],
                dim=0,
            )
        return {
            "radar": radar,
            "target_xy_m": torch.tensor(target.target_xy_m, dtype=torch.float32),
            "has_person": torch.tensor(target.has_person, dtype=torch.bool),
            "frame_id": torch.tensor(target.frame_id, dtype=torch.int64),
            "sequence": sequence,
            "sample_index": torch.tensor(index, dtype=torch.long),
        }
