"""Empty-scene-only dataset for the commissioned radar background expert."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset


_FRAME_PATTERN = re.compile(r"frame_(\d+)\.npy$")


@dataclass(frozen=True)
class _SitePackage:
    name: str
    frames: tuple[int, ...]
    ra_directory: Path
    ra_mti_directory: Path
    mean: Tensor
    std: Tensor


def _frame_ids(directory: Path) -> tuple[int, ...]:
    found = []
    for path in directory.glob("frame_*.npy"):
        match = _FRAME_PATTERN.fullmatch(path.name)
        if match is not None:
            found.append(int(match.group(1)))
    return tuple(sorted(found))


class CommissionedEmptyRadarDataset(Dataset[dict[str, Tensor | str]]):
    """All sites participate; each site uses its final frames as development data."""

    def __init__(self, root: str | Path, *, partition: str, development_tail_frames: int = 100) -> None:
        super().__init__()
        if partition not in {"train", "development"}:
            raise ValueError("partition must be 'train' or 'development'")
        if development_tail_frames < 1:
            raise ValueError("development_tail_frames must be positive")
        root = Path(root)
        if not root.is_dir():
            raise FileNotFoundError(f"missing empty-scene root: {root}")
        packages: list[_SitePackage] = []
        for site in sorted(path for path in root.iterdir() if path.is_dir() and path.name.startswith("site_")):
            ra = site / "Radar" / "RA"
            ra_mti = site / "Radar" / "RA-MIT"
            stats_path = site / "BackgroundStats" / "background_stats.npz"
            ra_frames, mti_frames = _frame_ids(ra), _frame_ids(ra_mti)
            if not ra_frames or ra_frames != mti_frames:
                raise ValueError(f"RA/RA-MIT frame mismatch at {site}")
            if len(ra_frames) <= development_tail_frames:
                raise ValueError(f"{site} has too few frames for an independent temporal tail")
            archive = np.load(stats_path, allow_pickle=False)
            mean = torch.from_numpy(np.stack((archive["RA_mean_db"], archive["RA-MIT_mean_db"])).astype(np.float32, copy=True))
            std = torch.from_numpy(np.stack((archive["RA_std_db"], archive["RA-MIT_std_db"])).astype(np.float32, copy=True)).clamp_min_(1e-3)
            packages.append(_SitePackage(site.name, ra_frames, ra, ra_mti, mean, std))
        if not packages:
            raise ValueError(f"no commissioned site packages found at {root}")
        self.packages = tuple(packages)
        self.site_names = tuple(package.name for package in self.packages)
        self.samples: list[tuple[int, int]] = []
        for site_index, package in enumerate(self.packages):
            frames = package.frames[:-development_tail_frames] if partition == "train" else package.frames[-development_tail_frames:]
            self.samples.extend((site_index, frame) for frame in frames)

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        site_index, frame = self.samples[index]
        package = self.packages[site_index]
        radar = torch.from_numpy(
            np.stack(
                (
                    np.load(package.ra_directory / f"frame_{frame:04d}.npy", allow_pickle=False),
                    np.load(package.ra_mti_directory / f"frame_{frame:04d}.npy", allow_pickle=False),
                )
            ).astype(np.float32, copy=False)
        )
        return {
            "radar": radar,
            "background_mean": package.mean,
            "background_std": package.std,
            "site_index": torch.tensor(site_index, dtype=torch.long),
            "site_name": package.name,
            "frame": torch.tensor(frame, dtype=torch.long),
        }
