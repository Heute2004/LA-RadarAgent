"""CORA-BEV: causal observation-recurrent radar BEV foundation.

The model preserves the V4 expert feature contract while deliberately using a
separate RA/RA-MTI observation encoder and a causal recurrent BEV aggregator.
It has no Mamba dependency and never consumes future radar frames.
"""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from .dream_bev import BEVGeometry, ConvNormAct, PolarToBEV, ResidualBlock


class _ObservationConvLSTMCell(nn.Module):
    """ConvLSTM state update gated by the current RA/RA-MTI agreement map."""

    def __init__(self, channels: int = 128) -> None:
        super().__init__()
        self.reliability_projection = nn.Sequential(
            nn.Conv2d(1, channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(8, channels),
            nn.Sigmoid(),
        )
        self.gates = nn.Conv2d(channels * 2, channels * 4, kernel_size=3, padding=1)

    def forward(self, current: Tensor, reliability: Tensor, state: tuple[Tensor, Tensor] | None) -> tuple[Tensor, Tensor]:
        if state is None:
            hidden = torch.zeros_like(current)
            cell = torch.zeros_like(current)
        else:
            hidden, cell = state
        observation_gate = 0.5 + self.reliability_projection(reliability)
        gated_current = current * observation_gate
        input_gate, forget_gate, output_gate, proposal = self.gates(torch.cat((gated_current, hidden), dim=1)).chunk(4, dim=1)
        cell = torch.sigmoid(forget_gate) * cell + torch.sigmoid(input_gate) * torch.tanh(proposal)
        hidden = torch.sigmoid(output_gate) * torch.tanh(cell)
        return hidden, cell


class CORABEVFoundation(nn.Module):
    """Causal Observation Recurrent Aggregator for Radar BEV sensing.

    RA and RA-MTI are independently encoded to prevent a single observation
    path from silently dominating.  Their current agreement predicts a bounded
    reliability field that conditions each causal ConvLSTM update in BEV.
    """

    architecture_id = "CORA-BEV-RA-RAMTI-ObservationConvLSTM-Presence-V1"

    def __init__(self, geometry: BEVGeometry | None = None) -> None:
        super().__init__()
        self.geometry = geometry or BEVGeometry()
        self.ra_encoder = nn.Sequential(ConvNormAct(1, 24, stride=2), ConvNormAct(24, 24))
        self.mti_encoder = nn.Sequential(ConvNormAct(1, 24, stride=2), ConvNormAct(24, 24))
        self.reliability_head = nn.Sequential(
            nn.Conv2d(2, 16, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(8, 16),
            nn.SiLU(inplace=True),
            nn.Conv2d(16, 1, kernel_size=1),
        )
        self.polar_fuse = nn.Sequential(ConvNormAct(48, 48), ResidualBlock(48))
        self.polar_to_bev = PolarToBEV(self.geometry)
        self.bev_stem = nn.Sequential(ConvNormAct(48, 64), ResidualBlock(64))
        self.bev_down1 = nn.Sequential(ConvNormAct(64, 96, stride=2), ResidualBlock(96))
        self.bev_down2 = nn.Sequential(ConvNormAct(96, 128, stride=2), ResidualBlock(128))
        self.temporal = _ObservationConvLSTMCell(128)
        self.state_fuse = nn.Sequential(ConvNormAct(128, 128), ResidualBlock(128))
        self.decode = nn.Sequential(ConvNormAct(128, 96), ResidualBlock(96), ConvNormAct(96, 64))
        self.logit_head = nn.Conv2d(64, 1, kernel_size=1)
        self.presence_head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, 64), nn.SiLU(), nn.Linear(64, 1))
        nn.init.constant_(self.logit_head.bias, -2.19)

    def _validate(self, radar: Tensor) -> None:
        if radar.ndim != 5 or radar.shape[2:] != (2, 128, 128):
            raise ValueError("radar must be [batch,time,2,128,128]")

    def _encode_observations(self, radar_frames: Tensor) -> tuple[Tensor, Tensor]:
        raw = radar_frames[:, 0:1]
        mti = radar_frames[:, 1:2]
        reliability = torch.sigmoid(self.reliability_head(radar_frames))
        raw_feature = functional.interpolate(self.ra_encoder(raw), size=(128, 128), mode="bilinear", align_corners=False)
        mti_feature = functional.interpolate(self.mti_encoder(mti), size=(128, 128), mode="bilinear", align_corners=False)
        polar_feature = self.polar_fuse(torch.cat((reliability * raw_feature, (1.0 - reliability) * mti_feature), dim=1))
        return polar_feature, reliability

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate(radar)
        batch, time_steps = radar.shape[:2]
        flattened = radar.reshape(batch * time_steps, 2, 128, 128)
        polar_flat, reliability_flat = self._encode_observations(flattened)
        polar_sequence = polar_flat.reshape(batch, time_steps, 48, 128, 128)
        reliability_sequence = reliability_flat.reshape(batch, time_steps, 1, 128, 128)

        bev_flat = self.polar_to_bev(polar_flat)
        shared_sequence = self.bev_down2(self.bev_down1(self.bev_stem(bev_flat))).reshape(batch, time_steps, 128, 50, 59)
        reliability_bev = functional.interpolate(
            self.polar_to_bev(reliability_flat), size=(50, 59), mode="bilinear", align_corners=False
        ).reshape(batch, time_steps, 1, 50, 59)

        state: tuple[Tensor, Tensor] | None = None
        for index in range(time_steps):
            state = self.temporal(shared_sequence[:, index], reliability_bev[:, index], state)
        shared_feature = self.state_fuse(state[0])
        decoded = functional.interpolate(self.decode(shared_feature), size=(self.geometry.x_bins, self.geometry.y_bins), mode="bilinear", align_corners=False)
        return {
            "logits": self.logit_head(decoded),
            "presence_logit": self.presence_head(shared_feature),
            "polar_feature": polar_sequence[:, -1],
            "shared_feature": shared_feature,
            "observation_reliability": reliability_sequence[:, -1],
        }
