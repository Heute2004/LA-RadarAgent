"""Immutable split and image-input rules for the JSAC Agent V4 protocol."""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping


_SEQUENCE_PATTERN = re.compile(r"^seq_(\d{3})$")
_IMAGE_PATTERN = re.compile(r"^Data_train/(seq_(\d{3}))/RGB/frame_(\d{4})\.jpg$")


def sequence_number(sequence: str) -> int:
    """Return a validated numeric sequence identifier."""
    matched = _SEQUENCE_PATTERN.fullmatch(sequence)
    if matched is None:
        raise ValueError(f"Invalid sequence identifier: {sequence!r}")
    return int(matched.group(1))


def site_for_sequence(sequence: str) -> str:
    """Map a human-data sequence to its commissioned empty-background site."""
    number = sequence_number(sequence)
    if 1 <= number <= 21:
        return "site_00_l_corridor"
    if 22 <= number <= 37:
        return "site_02_cluttered_indoor"
    if 38 <= number <= 60:
        return "site_01_open_indoor"
    if 61 <= number <= 104:
        return "site_03_open_outdoor"
    if 105 <= number <= 106:
        return "site_06_complex_outdoor_rain_day"
    if 107 <= number <= 122:
        return "site_05_complex_outdoor_dry_day"
    if 123 <= number <= 140:
        return "site_04_complex_outdoor_rain_night"
    if 141 <= number <= 155:
        return "site_06_complex_outdoor_rain_day"
    raise ValueError(f"No empty-background site is defined for {sequence}")


def is_foundation_source(sequence: str) -> bool:
    """Return whether a sequence belongs to either clean foundation domain."""
    number = sequence_number(sequence)
    return 38 <= number <= 43 or 61 <= number <= 104


def _ordered_without(sequences: Iterable[str], excluded: set[str]) -> list[str]:
    return [sequence for sequence in sequences if sequence not in excluded]


def _assert_disjoint(groups: Mapping[str, Iterable[str]]) -> None:
    names = list(groups)
    sets = {name: set(groups[name]) for name in names}
    for index, left in enumerate(names):
        for right in names[index + 1 :]:
            overlap = sets[left].intersection(sets[right])
            if overlap:
                raise ValueError(f"V3 split groups must be disjoint: {left}/{right} share {sorted(overlap)}")


def build_protocol(v3_split: Mapping[str, Iterable[str]], *, extra_excluded: Iterable[str] = ()) -> dict:
    """Derive the strict V4 foundation and target roles from the frozen V3 split."""
    required = ("train", "development_val", "locked_test", "excluded")
    missing = [key for key in required if key not in v3_split]
    if missing:
        raise ValueError(f"V3 split lacks required key(s): {missing}")

    v3 = {key: list(v3_split[key]) for key in required}
    for sequences in v3.values():
        for sequence in sequences:
            sequence_number(sequence)
    _assert_disjoint(v3)

    global_excluded = sorted(set(v3["excluded"]).union(extra_excluded), key=sequence_number)
    excluded_set = set(global_excluded)
    active = {
        "train": _ordered_without(v3["train"], excluded_set),
        "development": _ordered_without(v3["development_val"], excluded_set),
        "locked_test": _ordered_without(v3["locked_test"], excluded_set),
    }
    foundation = {
        split: [sequence for sequence in sequences if is_foundation_source(sequence)]
        for split, sequences in active.items()
    }
    agent_target = {
        split: [sequence for sequence in sequences if not is_foundation_source(sequence)]
        for split, sequences in active.items()
    }
    _assert_disjoint({
        "foundation_train": foundation["train"],
        "foundation_development": foundation["development"],
        "foundation_locked_test": foundation["locked_test"],
        "target_train": agent_target["train"],
        "target_development": agent_target["development"],
        "target_locked_test": agent_target["locked_test"],
    })
    all_active = set().union(*(set(values) for family in (foundation, agent_target) for values in family.values()))
    leaked = all_active.intersection(excluded_set)
    if leaked:
        raise ValueError(f"Global exclusions leaked into V4 protocol: {sorted(leaked)}")

    return {
        "schema_version": "jsac_agent_v4_strict_v3_protocol_v2",
        "source_protocol": "LOCKBOX_V3_SEQUENCE_LISTS.json",
        "global_excluded": global_excluded,
        "foundation": foundation,
        "agent_target": agent_target,
    }


def map_vlm_image(image: str, visual_condition: str) -> dict[str, str]:
    """Map condition-training inputs to background images without label conflicts.

    Low-light indoor records retain their original image because no matching
    commissioned low-light empty site exists. All other real V3 images use the
    corresponding commissioned empty background at the same frame index.
    """
    matched = _IMAGE_PATTERN.fullmatch(image)
    if matched is None:
        raise ValueError(f"Expected a V3 original RGB path, got: {image!r}")
    sequence, _, frame = matched.groups()
    site = site_for_sequence(sequence)
    normalized_condition = visual_condition.strip().lower()
    is_unmatched_indoor_low_light = site == "site_01_open_indoor" and "low_light" in normalized_condition
    if is_unmatched_indoor_low_light:
        return {
            "image": image,
            "source_image": image,
            "empty_site": site,
            "input_mode": "original_real_low_light",
        }
    return {
        "image": f"empty_train/{site}/RGB/frame_{frame}.jpg",
        "source_image": image,
        "empty_site": site,
        "input_mode": "matched_empty_background",
    }
