"""Causal commissioned-scene foreground and background evidence for V4.

CSS-V2 is deliberately a sidecar.  It estimates foreground evidence relative
to a commissioned empty reference, but never returns a coordinate or changes a
radar-detector logit.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from brace_v4.dream_bev import BEVGeometry


def _groups(channels: int) -> int:
    for groups in (8, 4, 2, 1):
        if channels % groups == 0:
            return groups
    return 1


class _ConvNormAct(nn.Sequential):
    def __init__(self, input_channels: int, output_channels: int) -> None:
        super().__init__(
            nn.Conv2d(input_channels, output_channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(_groups(output_channels), output_channels),
            nn.SiLU(inplace=True),
        )


class _Residual(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(_ConvNormAct(channels, channels), _ConvNormAct(channels, channels))

    def forward(self, values: Tensor) -> Tensor:
        return values + self.layers(values)


def _as_background_batch(value: Tensor, reference: Tensor, *, name: str) -> Tensor:
    if value.ndim != 5 or value.shape[2] != 2:
        raise ValueError("radar history must be [batch,time,2,height,width]")
    if reference.ndim == 3:
        reference = reference.unsqueeze(0)
    if reference.ndim != 4 or reference.shape[1:] != value.shape[2:]:
        raise ValueError(f"{name} must be [batch-or-one,2,height,width]")
    if reference.shape[0] not in (1, value.shape[0]):
        raise ValueError(f"{name} batch must be one or match radar batch")
    return reference.to(device=value.device, dtype=value.dtype)


def metric_to_polar_grid(
    xy_m: Tensor,
    *,
    height: int,
    width: int,
    geometry: BEVGeometry | None = None,
) -> Tensor:
    """Map metric `[x,y]` candidates to a `grid_sample` polar grid."""
    if xy_m.ndim != 2 or xy_m.shape[1] != 2:
        raise ValueError("candidate coordinates must be [batch,2]")
    if height < 2 or width < 2:
        raise ValueError("polar evidence map must be at least 2x2")
    geometry = geometry or BEVGeometry()
    x, y = xy_m.float().unbind(dim=1)
    radius = torch.sqrt(x.square() + y.square()).clamp_min(1e-6)
    range_index = radius / geometry.range_resolution_m
    azimuth_index = ((x / radius) + 1.0) * (geometry.azimuth_bins / 2.0)
    grid_x = (2.0 * azimuth_index / (width - 1) - 1.0).clamp(-1.0, 1.0)
    grid_y = (2.0 * range_index / (height - 1) - 1.0).clamp(-1.0, 1.0)
    return torch.stack((grid_x, grid_y), dim=-1).view(xy_m.shape[0], 1, 1, 2)


def binary_auroc(scores: Tensor, labels: Tensor) -> float | None:
    """AUROC with averaged ranks; returns None for a one-class target."""
    if scores.ndim != 1 or labels.ndim != 1 or scores.shape != labels.shape:
        raise ValueError("scores and labels must be matching one-dimensional tensors")
    labels = labels.bool()
    positives = int(labels.sum())
    negatives = int((~labels).sum())
    if not positives or not negatives:
        return None
    values, order = torch.sort(scores.detach().double().cpu())
    sorted_labels = labels.detach().cpu()[order]
    ranks = torch.empty_like(values)
    start = 0
    while start < values.numel():
        end = start + 1
        while end < values.numel() and values[end] == values[start]:
            end += 1
        ranks[start:end] = 0.5 * ((start + 1) + end)
        start = end
    rank_sum = ranks[sorted_labels].sum()
    return float((rank_sum - positives * (positives + 1) / 2.0) / (positives * negatives))


def fpr_at_tpr(scores: Tensor, labels: Tensor, *, target_tpr: float = 0.95) -> float:
    """Lowest FPR at the first descending threshold reaching a target TPR."""
    if not 0.0 < target_tpr <= 1.0:
        raise ValueError("target_tpr must be in (0,1]")
    if scores.ndim != 1 or labels.ndim != 1 or scores.shape != labels.shape:
        raise ValueError("scores and labels must be matching one-dimensional tensors")
    labels = labels.bool()
    positives = int(labels.sum())
    negatives = int((~labels).sum())
    if not positives or not negatives:
        raise ValueError("FPR@TPR requires both positive and negative labels")
    ordered = torch.argsort(scores.detach(), descending=True)
    sorted_labels = labels[ordered]
    true_positive = torch.cumsum(sorted_labels, dim=0)
    false_positive = torch.cumsum(~sorted_labels, dim=0)
    reached = torch.nonzero(true_positive >= math.ceil(target_tpr * positives), as_tuple=False)
    if not reached.numel():
        return 1.0
    return float(false_positive[int(reached[0, 0])] / negatives)


class CommissionedSceneSentinel(nn.Module):
    """Foreground MIL sidecar referenced to a commissioned background map."""

    architecture_id = "Commissioned-Scene-Sentinel-PolarMIL-V2"

    def __init__(
        self,
        *,
        hidden_channels: int = 32,
        feature_channels: int = 16,
        topk_ratio: float = 0.01,
        evidence_pool_kernel: int = 5,
        nominal_change: float = 1.5,
        z_clip: float = 12.0,
        use_temporal_delta: bool = True,
    ) -> None:
        super().__init__()
        if hidden_channels < 4 or feature_channels < 2:
            raise ValueError("hidden_channels must be >=4 and feature_channels must be >=2")
        if not 0.0 < topk_ratio <= 1.0:
            raise ValueError("topk_ratio must be in (0,1]")
        if evidence_pool_kernel < 1 or evidence_pool_kernel % 2 == 0:
            raise ValueError("evidence_pool_kernel must be positive and odd")
        if nominal_change <= 0.0 or z_clip <= 0.0:
            raise ValueError("nominal_change and z_clip must be positive")
        self.topk_ratio = float(topk_ratio)
        self.evidence_pool_kernel = int(evidence_pool_kernel)
        self.nominal_change = float(nominal_change)
        self.z_clip = float(z_clip)
        self.use_temporal_delta = bool(use_temporal_delta)
        self.encoder = nn.Sequential(
            _ConvNormAct(7, hidden_channels),
            _Residual(hidden_channels),
            _ConvNormAct(hidden_channels, hidden_channels),
            _Residual(hidden_channels),
        )
        self.feature_head = nn.Conv2d(hidden_channels, feature_channels, kernel_size=1)
        self.evidence_head = nn.Conv2d(hidden_channels, 1, kernel_size=1)
        nn.init.constant_(self.evidence_head.bias, -2.0)

    def standardize(self, radar_history_db: Tensor, background_mean_db: Tensor, background_std_db: Tensor) -> Tensor:
        if radar_history_db.ndim != 5 or radar_history_db.shape[1] < 1 or radar_history_db.shape[2] != 2:
            raise ValueError("radar history must be [batch,time,2,height,width] with at least one causal frame")
        mean = _as_background_batch(radar_history_db, background_mean_db, name="background_mean_db")
        std = _as_background_batch(radar_history_db, background_std_db, name="background_std_db").clamp_min(1e-3)
        return ((radar_history_db - mean[:, None]) / std[:, None]).clamp(-self.z_clip, self.z_clip)

    def _input_features(self, z_history: Tensor) -> tuple[Tensor, Tensor]:
        latest = z_history[:, -1]
        previous = z_history[:, max(0, z_history.shape[1] - 4) : -1]
        temporal_delta = latest - previous.median(dim=1).values if self.use_temporal_delta and previous.shape[1] else torch.zeros_like(latest)
        channel_difference = latest[:, :1] - latest[:, 1:2]
        features = torch.cat((latest, latest.abs(), temporal_delta, channel_difference), dim=1)
        return features, latest.abs().mean(dim=1, keepdim=True)

    def forward(
        self,
        radar_history_db: Tensor,
        background_mean_db: Tensor,
        background_std_db: Tensor,
        *,
        candidate_xy_m: Tensor | None = None,
    ) -> dict[str, Tensor]:
        z_history = self.standardize(radar_history_db, background_mean_db, background_std_db)
        inputs, raw_residual = self._input_features(z_history)
        encoded = self.encoder(inputs)
        evidence_logits = self.evidence_head(encoded)
        evidence_probability = evidence_logits.sigmoid()
        flat_logits = evidence_logits.flatten(1)
        topk = max(1, int(math.ceil(self.topk_ratio * flat_logits.shape[1])))
        presence_logit = flat_logits.topk(topk, dim=1).values.mean(dim=1, keepdim=True)
        low_foreground_weight = (1.0 - evidence_probability).detach()
        change = (raw_residual * low_foreground_weight).sum(dim=(-2, -1)) / low_foreground_weight.sum(dim=(-2, -1)).clamp_min(1.0)
        consistency = torch.exp(-change / self.nominal_change)
        output = {
            "foreground_evidence_logits": evidence_logits,
            "foreground_evidence_probability": evidence_probability,
            "foreground_presence_logit": presence_logit,
            "foreground_presence_probability": presence_logit.sigmoid(),
            "background_consistency_score": consistency,
            "background_change_score": change,
            "background_feature": self.feature_head(encoded),
        }
        if candidate_xy_m is None:
            output["candidate_local_support"] = torch.zeros_like(presence_logit)
        else:
            if candidate_xy_m.shape != (radar_history_db.shape[0], 2):
                raise ValueError("candidate_xy_m must be [batch,2]")
            pooled = functional.avg_pool2d(evidence_probability, self.evidence_pool_kernel, stride=1, padding=self.evidence_pool_kernel // 2)
            grid = metric_to_polar_grid(candidate_xy_m, height=pooled.shape[-2], width=pooled.shape[-1])
            output["candidate_local_support"] = functional.grid_sample(pooled, grid.to(device=pooled.device, dtype=pooled.dtype), align_corners=True).flatten(1)
        return output


class SceneSentinelLoss(nn.Module):
    """Presence MIL plus an explicit all-cells-empty penalty."""

    def __init__(self, *, empty_map_weight: float = 0.2) -> None:
        super().__init__()
        if empty_map_weight < 0.0:
            raise ValueError("empty_map_weight must be non-negative")
        self.empty_map_weight = float(empty_map_weight)

    def forward(self, output: dict[str, Tensor], has_person: Tensor) -> tuple[Tensor, dict[str, Tensor]]:
        labels = has_person.to(dtype=output["foreground_presence_logit"].dtype).reshape(-1)
        presence = functional.binary_cross_entropy_with_logits(output["foreground_presence_logit"].reshape(-1), labels)
        empty = ~has_person.bool().reshape(-1)
        if bool(empty.any()):
            empty_map = functional.softplus(output["foreground_evidence_logits"][empty]).mean()
        else:
            empty_map = presence.new_zeros(())
        total = presence + self.empty_map_weight * empty_map
        return total, {"presence": presence.detach(), "empty_map": empty_map.detach()}
