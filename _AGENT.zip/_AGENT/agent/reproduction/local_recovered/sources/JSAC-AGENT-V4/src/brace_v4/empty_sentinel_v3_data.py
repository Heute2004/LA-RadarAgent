"""Causal empty-scene histories for Empty-Sentinel V3."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset

from brace_v4.background_expert_data import _frame_ids


@dataclass(frozen=True)
class _Site:
    name: str
    frames: tuple[int, ...]
    frame_to_position: dict[int, int]
    ra_dir: Path
    ra_mti_dir: Path
    mean: Tensor
    std: Tensor


class EmptySentinelV3Dataset(Dataset[dict[str, Tensor | str]]):
    """Temporal train/tail-development split of every commissioned empty site."""

    def __init__(
        self,
        root: str | Path,
        *,
        partition: str,
        clip_length: int = 16,
        development_tail_frames: int = 100,
        cache_in_memory: bool = False,
    ) -> None:
        if partition not in {"train", "development"}:
            raise ValueError("partition must be train or development")
        if clip_length < 1 or development_tail_frames < 1:
            raise ValueError("clip_length and development_tail_frames must be positive")
        self.root = Path(root)
        self.clip_length = int(clip_length)
        self.cache_in_memory = bool(cache_in_memory)
        self._cache: dict[Path, Tensor] = {}
        self.sites: list[_Site] = []
        for site in sorted(path for path in self.root.iterdir() if path.is_dir() and path.name.startswith("site_")):
            ra_dir, ra_mti_dir = site / "Radar" / "RA", site / "Radar" / "RA-MIT"
            frames = _frame_ids(ra_dir)
            if not frames or frames != _frame_ids(ra_mti_dir):
                raise ValueError(f"RA/RA-MIT mismatch for {site}")
            if len(frames) <= development_tail_frames:
                raise ValueError(f"insufficient frames at {site}")
            archive = np.load(site / "BackgroundStats" / "background_stats.npz", allow_pickle=False)
            mean = torch.from_numpy(np.stack((archive["RA_mean_db"], archive["RA-MIT_mean_db"])).astype(np.float32, copy=True))
            std = torch.from_numpy(np.stack((archive["RA_std_db"], archive["RA-MIT_std_db"])).astype(np.float32, copy=True)).clamp_min_(1e-3)
            self.sites.append(
                _Site(
                    site.name,
                    frames,
                    {frame: position for position, frame in enumerate(frames)},
                    ra_dir,
                    ra_mti_dir,
                    mean,
                    std,
                )
            )
        if not self.sites:
            raise ValueError(f"no empty sites under {self.root}")
        self.site_names = tuple(site.name for site in self.sites)
        self.samples: list[tuple[int, int]] = []
        for site_index, site in enumerate(self.sites):
            selected = site.frames[:-development_tail_frames] if partition == "train" else site.frames[-development_tail_frames:]
            self.samples.extend((site_index, frame) for frame in selected)
        if self.cache_in_memory:
            for site in self.sites:
                for frame in site.frames:
                    self._read(site.ra_dir / f"frame_{frame:04d}.npy")
                    self._read(site.ra_mti_dir / f"frame_{frame:04d}.npy")

    def _read(self, path: Path) -> Tensor:
        value = self._cache.get(path)
        if value is not None:
            return value
        array = np.load(path, allow_pickle=False).astype(np.float32, copy=False)
        if array.shape != (128, 128):
            raise ValueError(f"expected 128x128 map: {path}")
        tensor = torch.from_numpy(np.nan_to_num(array, nan=80.0, posinf=110.0, neginf=50.0).copy())
        if self.cache_in_memory:
            self._cache[path] = tensor
        return tensor

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        site_index, frame = self.samples[index]
        site = self.sites[site_index]
        position = site.frame_to_position[frame]
        positions = [max(0, position - self.clip_length + 1 + offset) for offset in range(self.clip_length)]
        history = torch.stack(
            [
                torch.stack(
                    (
                        self._read(site.ra_dir / f"frame_{site.frames[item]:04d}.npy"),
                        self._read(site.ra_mti_dir / f"frame_{site.frames[item]:04d}.npy"),
                    ),
                    dim=0,
                )
                for item in positions
            ],
            dim=0,
        )
        return {
            "history_db": history,
            "cora_radar": ((history - 80.0) / 30.0).clamp(-3.0, 3.0),
            "background_mean": site.mean,
            "background_std": site.std,
            "site_index": torch.tensor(site_index, dtype=torch.long),
            "site_name": site.name,
            "frame_id": torch.tensor(frame, dtype=torch.long),
        }
