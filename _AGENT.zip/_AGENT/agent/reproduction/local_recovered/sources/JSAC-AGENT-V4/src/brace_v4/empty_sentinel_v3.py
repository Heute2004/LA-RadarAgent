"""Commissioned empty-scene static-peak rejection for frozen radar bases.

The model is intentionally polar-only.  It can score a frozen detector
candidate, but cannot generate a coordinate, a BEV map, or a detector logit.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from brace_v4.dream_bev import BEVGeometry


def _groups(channels: int) -> int:
    for value in (8, 4, 2, 1):
        if channels % value == 0:
            return value
    return 1


class _ConvNormAct(nn.Sequential):
    def __init__(self, inputs: int, outputs: int, *, groups: int = 1) -> None:
        super().__init__(
            nn.Conv2d(inputs, outputs, kernel_size=3, padding=1, groups=groups, bias=False),
            nn.GroupNorm(_groups(outputs), outputs),
            nn.SiLU(inplace=True),
        )


class _Residual(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(_ConvNormAct(channels, channels), _ConvNormAct(channels, channels))

    def forward(self, values: Tensor) -> Tensor:
        return values + self.layers(values)


def _background_batch(history: Tensor, reference: Tensor, *, name: str) -> Tensor:
    if history.ndim != 5 or history.shape[2] != 2:
        raise ValueError("history must be [batch,time,2,height,width]")
    if reference.ndim == 3:
        reference = reference.unsqueeze(0)
    if reference.ndim != 4 or reference.shape[1:] != history.shape[2:]:
        raise ValueError(f"{name} must be [batch-or-one,2,height,width]")
    if reference.shape[0] not in (1, history.shape[0]):
        raise ValueError(f"{name} batch must be one or match the history batch")
    return reference.to(device=history.device, dtype=history.dtype)


def candidate_xy_to_polar_index(xy_m: Tensor, *, geometry: BEVGeometry | None = None, height: int = 128, width: int = 128) -> Tensor:
    """Return nearest `[range,azimuth]` polar indices for metric candidates."""
    if xy_m.ndim != 3 or xy_m.shape[-1] != 2:
        raise ValueError("xy_m must be [batch,candidates,2]")
    geometry = geometry or BEVGeometry()
    x, y = xy_m.float().unbind(dim=-1)
    radius = torch.sqrt(x.square() + y.square()).clamp_min(1e-6)
    ranges = torch.round(radius / geometry.range_resolution_m).long().clamp(0, height - 1)
    azimuth = torch.round(((x / radius) + 1.0) * (geometry.azimuth_bins / 2.0)).long().clamp(0, width - 1)
    return torch.stack((ranges, azimuth), dim=-1)


def render_candidate_targets(
    xy_m: Tensor,
    *,
    geometry: BEVGeometry | None = None,
    height: int = 128,
    width: int = 128,
    sigma_bins: float = 2.0,
) -> Tensor:
    """Render soft static-risk supervision around frozen detector candidates."""
    if sigma_bins <= 0.0:
        raise ValueError("sigma_bins must be positive")
    indices = candidate_xy_to_polar_index(xy_m, geometry=geometry, height=height, width=width)
    rows = torch.arange(height, device=xy_m.device, dtype=xy_m.dtype).view(1, 1, height, 1)
    cols = torch.arange(width, device=xy_m.device, dtype=xy_m.dtype).view(1, 1, 1, width)
    row_center = indices[..., 0].to(dtype=xy_m.dtype).unsqueeze(-1).unsqueeze(-1)
    col_center = indices[..., 1].to(dtype=xy_m.dtype).unsqueeze(-1).unsqueeze(-1)
    squared = (rows - row_center).square() + (cols - col_center).square()
    return torch.exp(-0.5 * squared / (sigma_bins * sigma_bins)).amax(dim=1, keepdim=True)


def sample_candidate_risk(risk_map: Tensor, xy_m: Tensor, *, geometry: BEVGeometry | None = None) -> Tensor:
    """Read the risk map at frozen candidates without altering their geometry."""
    if risk_map.ndim != 4 or risk_map.shape[1] != 1:
        raise ValueError("risk_map must be [batch,1,height,width]")
    if xy_m.ndim == 2:
        xy_m = xy_m.unsqueeze(1)
    if xy_m.ndim != 3 or xy_m.shape[:1] != risk_map.shape[:1] or xy_m.shape[-1] != 2:
        raise ValueError("xy_m must be [batch,candidates,2]")
    indices = candidate_xy_to_polar_index(xy_m, geometry=geometry, height=risk_map.shape[-2], width=risk_map.shape[-1])
    flat = risk_map[:, 0].flatten(1)
    locations = indices[..., 0] * risk_map.shape[-1] + indices[..., 1]
    return flat.gather(1, locations)


def static_peak_focal_loss(logits: Tensor, target: Tensor, *, positive_weight: float = 12.0, gamma: float = 2.0) -> Tensor:
    """Candidate-focused focal BCE for known false peaks in empty frames."""
    if logits.shape != target.shape or logits.ndim != 4 or logits.shape[1] != 1:
        raise ValueError("logits and target must be matching [batch,1,height,width]")
    if positive_weight <= 0.0 or gamma < 0.0:
        raise ValueError("positive_weight must be positive and gamma non-negative")
    target = target.to(dtype=logits.dtype).clamp(0.0, 1.0)
    probability = logits.sigmoid()
    positive = -target * (1.0 - probability).pow(gamma) * functional.logsigmoid(logits)
    negative = -(1.0 - target) * probability.pow(gamma) * functional.logsigmoid(-logits)
    weights = 1.0 + positive_weight * target
    return ((positive + negative) * weights).sum() / weights.sum().clamp_min(1.0)


class EmptySentinelV3(nn.Module):
    """Scene-commissioned static false-peak risk map with a change alarm."""

    architecture_id = "Empty-Sentinel-V3-StaticPeakRisk"

    def __init__(self, *, hidden_channels: int = 32, z_clip: float = 12.0) -> None:
        super().__init__()
        if hidden_channels < 8 or z_clip <= 0.0:
            raise ValueError("hidden_channels must be >=8 and z_clip must be positive")
        self.z_clip = float(z_clip)
        self.encoder = nn.Sequential(
            _ConvNormAct(9, hidden_channels),
            _Residual(hidden_channels),
            _ConvNormAct(hidden_channels, hidden_channels, groups=hidden_channels),
            _ConvNormAct(hidden_channels, hidden_channels),
            _Residual(hidden_channels),
        )
        self.risk_head = nn.Conv2d(hidden_channels, 1, kernel_size=1)
        self.change_head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(hidden_channels, 1))
        nn.init.constant_(self.risk_head.bias, -3.0)

    def standardize(self, history_db: Tensor, background_mean_db: Tensor, background_std_db: Tensor) -> Tensor:
        mean = _background_batch(history_db, background_mean_db, name="background_mean_db")
        std = _background_batch(history_db, background_std_db, name="background_std_db").clamp_min(1e-3)
        return ((history_db - mean[:, None]) / std[:, None]).clamp(-self.z_clip, self.z_clip)

    def _inputs(self, history_db: Tensor, background_mean_db: Tensor, background_std_db: Tensor) -> Tensor:
        z = self.standardize(history_db, background_mean_db, background_std_db)
        latest = z[:, -1]
        prior = z[:, :-1].median(dim=1).values if z.shape[1] > 1 else latest
        temporal_delta = latest - prior
        mean = _background_batch(history_db, background_mean_db, name="background_mean_db")
        mean_normalized = ((mean - 80.0) / 30.0).clamp(-3.0, 3.0)
        channel_difference = latest[:, :1] - latest[:, 1:2]
        return torch.cat((latest, latest.abs(), temporal_delta, channel_difference, mean_normalized), dim=1)

    def forward(self, history_db: Tensor, background_mean_db: Tensor, background_std_db: Tensor) -> dict[str, Tensor]:
        features = self.encoder(self._inputs(history_db, background_mean_db, background_std_db))
        risk_logits = self.risk_head(features)
        change_logit = self.change_head(features)
        return {
            "static_peak_risk_logits": risk_logits,
            "static_peak_risk": risk_logits.sigmoid(),
            "background_change_logit": change_logit,
            "background_change_probability": change_logit.sigmoid(),
        }
