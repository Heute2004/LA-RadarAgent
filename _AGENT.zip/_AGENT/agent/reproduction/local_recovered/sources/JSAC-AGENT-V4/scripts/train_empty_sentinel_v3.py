#!/usr/bin/env python3
"""Train Empty-Sentinel V3 from commissioned empty radar scenes only."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

import numpy as np
import torch
from torch import Tensor
from torch.nn import functional as functional
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

from brace_v4.cora_bev import CORABEVFoundation
from brace_v4.dream_bev import BEVGeometry
from brace_v4.empty_sentinel_v3 import EmptySentinelV3, render_candidate_targets, sample_candidate_risk, static_peak_focal_loss
from brace_v4.empty_sentinel_v3_data import EmptySentinelV3Dataset
from brace_v4.scene_sentinel import binary_auroc


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True
    torch.set_float32_matmul_precision("high")


def to_device(batch: dict[str, Tensor | str], device: torch.device) -> dict[str, Tensor | str]:
    return {key: value.to(device, non_blocking=True) if isinstance(value, Tensor) else value for key, value in batch.items()}


def load_cora(path: Path, device: torch.device) -> CORABEVFoundation:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    model = CORABEVFoundation()
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.to(device).eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model


def topk_candidates(logits: Tensor, *, top_k: int, geometry: BEVGeometry | None = None) -> tuple[Tensor, Tensor]:
    if logits.ndim != 4 or logits.shape[1] != 1 or top_k < 1:
        raise ValueError("expected [batch,1,x,y] logits and positive top_k")
    geometry = geometry or BEVGeometry()
    probability = logits[:, 0].float().sigmoid().flatten(1)
    scores, flat = probability.topk(min(top_k, probability.shape[1]), dim=1)
    x = torch.div(flat, geometry.y_bins, rounding_mode="floor")
    y = flat.remainder(geometry.y_bins)
    xy = geometry.index_to_metric(torch.stack((x, y), dim=-1)).to(device=logits.device)
    return xy, scores


def site_stats(dataset: EmptySentinelV3Dataset, device: torch.device) -> tuple[Tensor, Tensor]:
    return (
        torch.stack([site.mean for site in dataset.sites]).to(device),
        torch.stack([site.std for site in dataset.sites]).to(device),
    )


def mixed_background(batch: dict[str, Tensor | str], mean_bank: Tensor, std_bank: Tensor) -> tuple[Tensor, Tensor, Tensor]:
    site_index = batch["site_index"]
    if not isinstance(site_index, Tensor):
        raise TypeError("site_index missing")
    count = mean_bank.shape[0]
    offsets = torch.randint(1, count, site_index.shape, device=site_index.device)
    wrong_index = (site_index + offsets) % count
    mismatch = torch.rand(site_index.shape, device=site_index.device) < 0.5
    chosen = torch.where(mismatch, wrong_index, site_index)
    return mean_bank[chosen], std_bank[chosen], mismatch.to(dtype=torch.float32)


def _batch_keys(batch: dict[str, Tensor | str]) -> list[tuple[str, int]]:
    names = batch["site_name"]
    frame_ids = batch["frame_id"]
    if not isinstance(names, (list, tuple)) or not isinstance(frame_ids, Tensor):
        raise TypeError("batch must contain collated site_name and frame_id")
    return [(str(site), int(frame)) for site, frame in zip(names, frame_ids.tolist(), strict=True)]


@torch.inference_mode()
def precompute_candidates(
    dataset: EmptySentinelV3Dataset,
    cora: CORABEVFoundation,
    *,
    device: torch.device,
    top_k: int,
    batch_size: int,
) -> dict[tuple[str, int], Tensor]:
    """Cache frozen CORA candidates once; V3 never backpropagates through CORA."""
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
    result: dict[tuple[str, int], Tensor] = {}
    cora.eval()
    for raw_batch in loader:
        batch = to_device(raw_batch, device)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            output = cora(batch["cora_radar"])
        candidates, _ = topk_candidates(output["logits"], top_k=top_k)
        for key, value in zip(_batch_keys(raw_batch), candidates.float().cpu(), strict=True):
            result[key] = value.contiguous()
    if len(result) != len(dataset):
        raise RuntimeError(f"candidate cache is incomplete: {len(result)} / {len(dataset)}")
    return result


def frozen_candidates(
    batch: dict[str, Tensor | str],
    cora: CORABEVFoundation | None,
    cache: Mapping[tuple[str, int], Tensor] | None,
    *,
    top_k: int,
    device: torch.device,
) -> Tensor:
    if cache is not None:
        try:
            return torch.stack([cache[key] for key in _batch_keys(batch)]).to(device, non_blocking=True)
        except KeyError as error:
            raise KeyError(f"missing frozen CORA candidate for {error.args[0]}") from error
    if cora is None:
        raise RuntimeError("either frozen CORA or a complete candidate cache is required")
    cora_radar = batch["cora_radar"]
    if not isinstance(cora_radar, Tensor):
        raise TypeError("cora_radar missing")
    with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        cora_output = cora(cora_radar)
    candidates, _ = topk_candidates(cora_output["logits"], top_k=top_k)
    return candidates


def empty_batch_loss(
    sentinel: EmptySentinelV3,
    cora: CORABEVFoundation | None,
    batch: dict[str, Tensor | str],
    mean_bank: Tensor,
    std_bank: Tensor,
    candidate_cache: Mapping[tuple[str, int], Tensor] | None,
    *,
    top_k: int,
    change_weight: float,
    risk_positive_weight: float,
) -> tuple[Tensor, dict[str, Tensor]]:
    history = batch["history_db"]
    cora_radar = batch["cora_radar"]
    mean = batch["background_mean"]
    std = batch["background_std"]
    if not all(isinstance(value, Tensor) for value in (history, cora_radar, mean, std)):
        raise TypeError("malformed empty batch")
    candidates = frozen_candidates(batch, cora, candidate_cache, top_k=top_k, device=history.device)
    target = render_candidate_targets(candidates, height=history.shape[-2], width=history.shape[-1])
    output = sentinel(history, mean, std)
    risk_loss = static_peak_focal_loss(output["static_peak_risk_logits"], target, positive_weight=risk_positive_weight)
    mixed_mean, mixed_std, mismatch = mixed_background(batch, mean_bank, std_bank)
    mixed_output = sentinel(history, mixed_mean, mixed_std)
    change_loss = functional.binary_cross_entropy_with_logits(mixed_output["background_change_logit"].squeeze(1), mismatch)
    loss = risk_loss + change_weight * change_loss
    candidate_risk = sample_candidate_risk(output["static_peak_risk"], candidates).mean(dim=1)
    return loss, {
        "risk_loss": risk_loss.detach(),
        "change_loss": change_loss.detach(),
        "candidate_risk": candidate_risk.detach(),
        "change_score": mixed_output["background_change_probability"].squeeze(1).detach(),
        "change_target": mismatch.detach(),
    }


@torch.inference_mode()
def evaluate(
    sentinel: EmptySentinelV3,
    cora: CORABEVFoundation | None,
    loader: DataLoader,
    mean_bank: Tensor,
    std_bank: Tensor,
    candidate_cache: Mapping[tuple[str, int], Tensor] | None,
    *,
    device: torch.device,
    top_k: int,
    change_weight: float,
    risk_positive_weight: float,
) -> dict[str, float | None]:
    sentinel.eval()
    losses: list[Tensor] = []
    risks: list[Tensor] = []
    change_scores: list[Tensor] = []
    change_targets: list[Tensor] = []
    for raw_batch in loader:
        batch = to_device(raw_batch, device)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            loss, parts = empty_batch_loss(
                sentinel,
                cora,
                batch,
                mean_bank,
                std_bank,
                candidate_cache,
                top_k=top_k,
                change_weight=change_weight,
                risk_positive_weight=risk_positive_weight,
            )
        losses.append(loss.float().cpu())
        risks.append(parts["candidate_risk"].float().cpu())
        change_scores.append(parts["change_score"].float().cpu())
        change_targets.append(parts["change_target"].bool().cpu())
    risk = torch.cat(risks)
    scores, targets = torch.cat(change_scores), torch.cat(change_targets)
    return {
        "frames": float(risk.numel()),
        "loss": float(torch.stack(losses).mean()),
        "mean_empty_candidate_risk": float(risk.mean()),
        "p90_empty_candidate_risk": float(torch.quantile(risk, 0.9)),
        "background_change_auroc": binary_auroc(scores, targets),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--empty-root", type=Path, required=True)
    parser.add_argument("--cora-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=25)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--hidden-channels", type=int, default=32)
    parser.add_argument("--clip-length", type=int, default=16)
    parser.add_argument("--top-k", type=int, default=4)
    parser.add_argument("--development-tail-frames", type=int, default=100)
    parser.add_argument("--change-weight", type=float, default=0.25)
    parser.add_argument("--risk-positive-weight", type=float, default=12.0)
    parser.add_argument("--early-stop-patience", type=int, default=5)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--ram-cache", action="store_true")
    parser.add_argument("--precompute-candidates", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("Empty-Sentinel V3 training requires CUDA")
    if args.epochs < 1 or args.batch_size < 1 or args.top_k < 1:
        raise ValueError("epochs, batch-size and top-k must be positive")
    seed_everything(args.seed)
    device = torch.device("cuda")
    train_set = EmptySentinelV3Dataset(
        args.empty_root,
        partition="train",
        clip_length=args.clip_length,
        development_tail_frames=args.development_tail_frames,
        cache_in_memory=args.ram_cache,
    )
    development_set = EmptySentinelV3Dataset(
        args.empty_root,
        partition="development",
        clip_length=args.clip_length,
        development_tail_frames=args.development_tail_frames,
        cache_in_memory=args.ram_cache,
    )
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=True)
    development_loader = DataLoader(development_set, batch_size=args.batch_size, shuffle=False, num_workers=0, pin_memory=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    cora = load_cora(args.cora_checkpoint, device)
    candidate_cache: dict[tuple[str, int], Tensor] | None = None
    if args.precompute_candidates:
        print("Precomputing frozen CORA Top-K candidates for Empty-Sentinel V3...", flush=True)
        candidate_cache = {}
        for name, dataset in (("train", train_set), ("development", development_set)):
            values = precompute_candidates(dataset, cora, device=device, top_k=args.top_k, batch_size=args.batch_size)
            overlap = set(candidate_cache).intersection(values)
            if overlap:
                raise RuntimeError(f"candidate cache keys overlap between partitions: {next(iter(overlap))}")
            candidate_cache.update(values)
            print(f"  {name}: {len(values)} frames", flush=True)
        torch.save(
            {
                "schema_version": "empty_sentinel_v3_frozen_cora_candidate_cache_v1",
                "cora_checkpoint_sha256": sha256(args.cora_checkpoint),
                "top_k": args.top_k,
                "candidates": candidate_cache,
            },
            args.output_dir / "frozen_cora_topk_candidates.pt",
        )
        del cora
        cora = None
        torch.cuda.empty_cache()
    sentinel = EmptySentinelV3(hidden_channels=args.hidden_channels).to(device)
    optimizer = torch.optim.AdamW(sentinel.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    mean_bank, std_bank = site_stats(train_set, device)
    config = {
        "schema_version": "empty_sentinel_v3_training_v1",
        "architecture": sentinel.architecture_id,
        "frozen_cora_checkpoint": str(args.cora_checkpoint),
        "frozen_cora_sha256": sha256(args.cora_checkpoint),
        "empty_root": str(args.empty_root),
        "sites": list(train_set.site_names),
        "train_empty_frames": len(train_set),
        "development_empty_frames": len(development_set),
        "parameters": sum(parameter.numel() for parameter in sentinel.parameters()),
        "training_inputs": ["commissioned empty RA", "commissioned empty RA-MIT", "matching empty mean/std", "frozen CORA Top-K"],
        "forbidden_inputs": ["Final-BEV", "human coordinate", "RGB", "depth", "future frames", "Locked Test"],
        "runtime_outputs": ["static_peak_risk", "background_change_probability"],
        "coordinate_modification": False,
        "detector_logit_modification": False,
        "candidate_cache_precomputed": candidate_cache is not None,
        "arguments": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (args.output_dir / "run_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    history: list[dict[str, object]] = []
    best: dict[str, object] | None = None
    stale = 0
    for epoch in range(1, args.epochs + 1):
        sentinel.train()
        train_losses: list[float] = []
        for raw_batch in train_loader:
            batch = to_device(raw_batch, device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                loss, _ = empty_batch_loss(
                    sentinel,
                    cora,
                    batch,
                    mean_bank,
                    std_bank,
                    candidate_cache,
                    top_k=args.top_k,
                    change_weight=args.change_weight,
                    risk_positive_weight=args.risk_positive_weight,
                )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(sentinel.parameters(), 5.0)
            optimizer.step()
            train_losses.append(float(loss.detach()))
        scheduler.step()
        development = evaluate(
            sentinel,
            cora,
            development_loader,
            mean_bank,
            std_bank,
            candidate_cache,
            device=device,
            top_k=args.top_k,
            change_weight=args.change_weight,
            risk_positive_weight=args.risk_positive_weight,
        )
        record = {"epoch": epoch, "lr": optimizer.param_groups[0]["lr"], "train_loss": float(np.mean(train_losses)), "development": development}
        history.append(record)
        print(json.dumps(record, ensure_ascii=True), flush=True)
        metric = float(development["loss"])
        if best is None or metric < float(best["development"]["loss"]):
            best = {"epoch": epoch, "development": development}
            stale = 0
            torch.save(
                {
                    "schema_version": "empty_sentinel_v3_checkpoint_v1",
                    "architecture": sentinel.architecture_id,
                    "model_kwargs": {"hidden_channels": args.hidden_channels},
                    "model_state": sentinel.state_dict(),
                    "epoch": epoch,
                    "development": development,
                    "config_sha256": sha256(args.output_dir / "run_config.json"),
                },
                args.output_dir / "best.pt",
            )
        else:
            stale += 1
        (args.output_dir / "history.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (args.output_dir / "best_metrics.json").write_text(json.dumps(best, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if stale >= args.early_stop_patience:
            break
    completion = {
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "completed_epochs": len(history),
        "best": best,
        "early_stopped": len(history) < args.epochs,
    }
    (args.output_dir / "training_complete.json").write_text(json.dumps(completion, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
