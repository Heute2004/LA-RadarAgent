#!/usr/bin/env python3
"""Development-only audit for Empty-Sentinel V3 static false-peak rejection.

The audit deliberately uses only source human *presence* to calibrate a
conservative risk threshold.  It never reads Final-BEV, target human labels,
or Locked Test, and it cannot modify a detector coordinate or detector logit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

from brace_v4.cora_bev import CORABEVFoundation
from brace_v4.dream_bev import BEVGeometry, decode_peak
from brace_v4.empty_sentinel_v3 import EmptySentinelV3, sample_candidate_risk
from brace_v4.empty_sentinel_v3_data import EmptySentinelV3Dataset
from brace_v4.foundation_data import FoundationRadarDataset
from brace_v4.scene_sentinel import binary_auroc, fpr_at_tpr
from brace_v4.v4_protocol import site_for_sequence


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def to_device(batch: dict[str, Tensor | str], device: torch.device) -> dict[str, Tensor | str]:
    return {key: value.to(device, non_blocking=True) if isinstance(value, Tensor) else value for key, value in batch.items()}


def load_cora(path: Path, device: torch.device) -> CORABEVFoundation:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    model = CORABEVFoundation()
    model.load_state_dict(checkpoint["model_state"], strict=True)
    return model.to(device).eval()


def load_sentinel(path: Path, device: torch.device) -> EmptySentinelV3:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    model = EmptySentinelV3(**checkpoint["model_kwargs"])
    model.load_state_dict(checkpoint["model_state"], strict=True)
    return model.to(device).eval()


class BackgroundBank:
    """Immutable commissioned background statistics keyed by site name."""

    def __init__(self, empty_root: Path) -> None:
        self._stats: dict[str, tuple[Tensor, Tensor]] = {}
        for site in sorted(path for path in empty_root.iterdir() if path.is_dir() and path.name.startswith("site_")):
            archive = np.load(site / "BackgroundStats" / "background_stats.npz", allow_pickle=False)
            mean = torch.from_numpy(np.stack((archive["RA_mean_db"], archive["RA-MIT_mean_db"])).astype(np.float32, copy=True))
            std = torch.from_numpy(np.stack((archive["RA_std_db"], archive["RA-MIT_std_db"])).astype(np.float32, copy=True)).clamp_min_(1e-3)
            self._stats[site.name] = (mean, std)
        if not self._stats:
            raise ValueError("no commissioned site statistics found")

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._stats))

    def fetch(self, sites: list[str], device: torch.device) -> tuple[Tensor, Tensor]:
        values = [self._stats[site] for site in sites]
        return torch.stack([value[0] for value in values]).to(device), torch.stack([value[1] for value in values]).to(device)


def detector_candidates(cora: CORABEVFoundation, radar: Tensor, *, top_k: int) -> tuple[Tensor, Tensor]:
    output = cora(radar)
    logits = output["logits"].float()
    probability = logits[:, 0].sigmoid().flatten(1)
    scores, flat = probability.topk(min(top_k, probability.shape[1]), dim=1)
    geometry = BEVGeometry()
    indices = torch.stack((torch.div(flat, geometry.y_bins, rounding_mode="floor"), flat.remainder(geometry.y_bins)), dim=-1)
    candidates = geometry.index_to_metric(indices).to(device=radar.device)
    presence = output["presence_logit"].float().sigmoid().squeeze(1)
    return candidates, scores[:, 0] * presence


def threshold_for_minimum_retention(values: Tensor, *, retain_at_least: float) -> Tensor:
    """Return an inclusive threshold retaining at least the requested fraction.

    `torch.quantile` interpolates between observations and can discard one
    additional frame at a boundary. This order-statistic rule is conservative
    by construction and is therefore appropriate for the safety contract.
    """
    if values.ndim != 1 or values.numel() == 0:
        raise ValueError("values must be a non-empty vector")
    if not 0.0 < retain_at_least <= 1.0:
        raise ValueError("retain_at_least must lie in (0, 1]")
    sorted_values = values.sort().values
    index = min(sorted_values.numel() - 1, max(0, math.ceil(retain_at_least * sorted_values.numel()) - 1))
    return sorted_values[index]


def binary_metrics(scores: Tensor, labels: Tensor) -> dict[str, float | None]:
    """Report frame-level foreground evidence without a coordinate label."""
    auroc = binary_auroc(scores.float().cpu(), labels.bool().cpu())
    return {
        "auroc": auroc,
        "fpr_at_99pct_human_tpr": fpr_at_tpr(scores.float().cpu(), labels.bool().cpu(), target_tpr=0.99) if auroc is not None else None,
        "human_mean": float(scores[labels].float().mean()),
        "empty_mean": float(scores[~labels].float().mean()),
    }


@torch.inference_mode()
def source_human_calibration(
    dataset: FoundationRadarDataset,
    cora: CORABEVFoundation,
    sentinel: EmptySentinelV3,
    bank: BackgroundBank,
    *,
    device: torch.device,
    batch_size: int,
) -> dict[str, Tensor | float | int]:
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
    risks: list[Tensor] = []
    scores: list[Tensor] = []
    frames = 0
    for raw_batch in loader:
        person_mask_cpu = raw_batch["has_person"].bool()
        if not bool(person_mask_cpu.any()):
            continue
        batch = to_device(raw_batch, device)
        person_mask = batch["has_person"].bool()
        radar = batch["radar"][person_mask]
        sites = [site_for_sequence(str(sequence)) for index, sequence in enumerate(raw_batch["sequence"]) if bool(person_mask_cpu[index])]
        mean, std = bank.fetch(sites, device)
        candidates, score = detector_candidates(cora, radar, top_k=1)
        history_db = radar * 30.0 + 80.0
        risk = sample_candidate_risk(sentinel(history_db, mean, std)["static_peak_risk"], candidates).squeeze(1)
        risks.append(risk.float().cpu())
        scores.append(score.float().cpu())
        frames += int(risk.numel())
    if not risks:
        raise ValueError("source Development contains no human frames")
    risk = torch.cat(risks)
    score = torch.cat(scores)
    candidate_score_threshold = torch.quantile(score, 0.01)
    active_risk = risk[score >= candidate_score_threshold]
    risk_threshold = threshold_for_minimum_retention(active_risk, retain_at_least=0.99)
    retention = float(((score >= candidate_score_threshold) & (risk <= risk_threshold)).sum() / (score >= candidate_score_threshold).sum().clamp_min(1))
    return {
        "frames": frames,
        "candidate_score_threshold": float(candidate_score_threshold),
        "risk_threshold": float(risk_threshold),
        "human_active_candidate_retention": retention,
        "_base_candidate_score": score,
        "_safe_foreground_evidence": score * (1.0 - risk),
    }


@torch.inference_mode()
def empty_rejection_audit(
    dataset: EmptySentinelV3Dataset,
    cora: CORABEVFoundation,
    sentinel: EmptySentinelV3,
    *,
    device: torch.device,
    batch_size: int,
    candidate_score_threshold: float,
    risk_threshold: float,
) -> dict[str, object]:
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
    site_counts: dict[str, list[int]] = {site: [0, 0] for site in dataset.site_names}
    all_base: list[Tensor] = []
    all_safe: list[Tensor] = []
    all_score: list[Tensor] = []
    all_evidence: list[Tensor] = []
    for raw_batch in loader:
        batch = to_device(raw_batch, device)
        candidates, score = detector_candidates(cora, batch["cora_radar"], top_k=1)
        output = sentinel(batch["history_db"], batch["background_mean"], batch["background_std"])
        risk = sample_candidate_risk(output["static_peak_risk"], candidates).squeeze(1)
        base_active = score >= candidate_score_threshold
        safe_active = base_active & (risk <= risk_threshold)
        all_base.append(base_active.cpu())
        all_safe.append(safe_active.cpu())
        all_score.append(score.float().cpu())
        all_evidence.append((score * (1.0 - risk)).float().cpu())
        for index, site in enumerate(raw_batch["site_name"]):
            site_counts[str(site)][0] += int(base_active[index])
            site_counts[str(site)][1] += int(safe_active[index])
    base = torch.cat(all_base)
    safe = torch.cat(all_safe)
    base_rate = float(base.float().mean())
    safe_rate = float(safe.float().mean())
    reduction = 0.0 if base_rate == 0.0 else 1.0 - safe_rate / base_rate
    by_site = {
        site: {
            "frames": int(len(dataset.samples) // len(dataset.site_names)),
            "base_false_candidate_rate": base_count / max(1, len(dataset.samples) // len(dataset.site_names)),
            "safe_false_candidate_rate": safe_count / max(1, len(dataset.samples) // len(dataset.site_names)),
            "relative_reduction": 0.0 if base_count == 0 else 1.0 - safe_count / base_count,
        }
        for site, (base_count, safe_count) in site_counts.items()
    }
    return {
        "frames": int(base.numel()),
        "base_false_candidate_rate": base_rate,
        "safe_false_candidate_rate": safe_rate,
        "relative_reduction": reduction,
        "sites_with_at_least_20pct_reduction": sum(item["relative_reduction"] >= 0.20 for item in by_site.values()),
        "by_site": by_site,
        "_base_candidate_score": torch.cat(all_score),
        "_safe_foreground_evidence": torch.cat(all_evidence),
    }


@torch.inference_mode()
def background_change_audit(
    dataset: EmptySentinelV3Dataset,
    sentinel: EmptySentinelV3,
    *,
    device: torch.device,
    batch_size: int,
) -> dict[str, object]:
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
    means = torch.stack([site.mean for site in dataset.sites]).to(device)
    stds = torch.stack([site.std for site in dataset.sites]).to(device)
    score: list[Tensor] = []
    label: list[Tensor] = []
    for raw_batch in loader:
        batch = to_device(raw_batch, device)
        correct = sentinel(batch["history_db"], batch["background_mean"], batch["background_std"])["background_change_probability"].squeeze(1)
        index = batch["site_index"]
        wrong = (index + 1) % means.shape[0]
        mismatched = sentinel(batch["history_db"], means[wrong], stds[wrong])["background_change_probability"].squeeze(1)
        score.extend((correct.cpu(), mismatched.cpu()))
        label.extend((torch.zeros_like(correct, dtype=torch.bool).cpu(), torch.ones_like(mismatched, dtype=torch.bool).cpu()))
    scores, labels = torch.cat(score), torch.cat(label)
    return {"frames": int(scores.numel()), "wrong_site_positive": int(labels.sum()), "auroc": binary_auroc(scores, labels)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--empty-root", type=Path, required=True)
    parser.add_argument("--presence-manifest", type=Path, required=True)
    parser.add_argument("--cora-checkpoint", type=Path, required=True)
    parser.add_argument("--sentinel-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--preload-ram", action="store_true")
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("Empty-Sentinel V3 audit requires CUDA")
    device = torch.device("cuda")
    cora = load_cora(args.cora_checkpoint, device)
    sentinel = load_sentinel(args.sentinel_checkpoint, device)
    bank = BackgroundBank(args.empty_root)
    source = FoundationRadarDataset(
        args.data_root,
        args.presence_manifest,
        "Development",
        empty_root=args.empty_root,
        clip_length=16,
        cache_in_memory=args.preload_ram,
    )
    empty = EmptySentinelV3Dataset(
        args.empty_root,
        partition="development",
        clip_length=16,
        cache_in_memory=args.preload_ram,
    )
    calibration = source_human_calibration(source, cora, sentinel, bank, device=device, batch_size=args.batch_size)
    rejection = empty_rejection_audit(
        empty,
        cora,
        sentinel,
        device=device,
        batch_size=args.batch_size,
        candidate_score_threshold=float(calibration["candidate_score_threshold"]),
        risk_threshold=float(calibration["risk_threshold"]),
    )
    change = background_change_audit(empty, sentinel, device=device, batch_size=args.batch_size)
    human_base = calibration.pop("_base_candidate_score")
    human_safe = calibration.pop("_safe_foreground_evidence")
    empty_base = rejection.pop("_base_candidate_score")
    empty_safe = rejection.pop("_safe_foreground_evidence")
    if not all(isinstance(value, Tensor) for value in (human_base, human_safe, empty_base, empty_safe)):
        raise TypeError("foreground evidence audit values must be tensors")
    presence_labels = torch.cat((torch.ones_like(human_base, dtype=torch.bool), torch.zeros_like(empty_base, dtype=torch.bool)))
    foreground_evidence = {
        "frames": int(presence_labels.numel()),
        "human_frames": int(presence_labels.sum()),
        "empty_frames": int((~presence_labels).sum()),
        "frozen_cora_candidate_score": binary_metrics(torch.cat((human_base, empty_base)), presence_labels),
        "v3_static_risk_safe_evidence": binary_metrics(torch.cat((human_safe, empty_safe)), presence_labels),
        "definition": "frozen CORA top-1 candidate score multiplied by (1 - V3 static-peak risk); no coordinate or Final-BEV input",
    }
    gates = {
        "source_human_active_retention_at_least_0p99": float(calibration["human_active_candidate_retention"]) >= 0.99,
        "held_out_empty_relative_reduction_at_least_0p20": float(rejection["relative_reduction"]) >= 0.20,
        "at_least_5_of_7_sites_reduce_by_20pct": int(rejection["sites_with_at_least_20pct_reduction"]) >= 5,
        "wrong_site_background_change_auroc_at_least_0p90": change["auroc"] is not None and float(change["auroc"]) >= 0.90,
        "foreground_presence_evidence_auroc_at_least_0p90": foreground_evidence["v3_static_risk_safe_evidence"]["auroc"] is not None and float(foreground_evidence["v3_static_risk_safe_evidence"]["auroc"]) >= 0.90,
        "coordinate_modification_exactly_zero": True,
        "detector_logit_modification_exactly_zero": True,
        "locked_test_read_exactly_zero": True,
    }
    report = {
        "schema_version": "empty_sentinel_v3_development_audit_v2",
        "scope": {
            "source_calibration": "Foundation Development human presence only",
            "empty_evaluation": "commissioned empty tail Development only",
            "locked_test_read": False,
            "final_bev_read": False,
            "target_human_label_read": False,
            "coordinate_modification": False,
            "detector_logit_modification": False,
        },
        "inputs": {
            "cora_checkpoint_sha256": sha256(args.cora_checkpoint),
            "sentinel_checkpoint_sha256": sha256(args.sentinel_checkpoint),
            "presence_manifest_sha256": sha256(args.presence_manifest),
        },
        "calibration": calibration,
        "empty_false_peak_rejection": rejection,
        "background_change": change,
        "foreground_presence_evidence": foreground_evidence,
        "acceptance_gates": gates,
        "accepted_for_safety_buffer": all(gates.values()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
