from __future__ import annotations

import hashlib
import math
from collections.abc import Iterator
from pathlib import Path
from typing import Literal

import torch
from torch import Tensor, nn

from ..expert_primitives import causal_previous_window, decode_peak_xy, gaussian_logit_delta, metric_bev_crop, metric_polar_crop
from ..geometry import BEVGeometry
from .backbones import MRODNetBEV
from .e3_experts import _low_threshold_polar_candidates
from .heterogeneous_experts import _ROIEncoder, _clamp_metric_xy, _positive_diagonal_covariance, _zero_linear


E4ExpertKind = Literal["aurf_lite", "sdp_tbd"]
E4_EXPERT_KINDS: tuple[E4ExpertKind, ...] = ("aurf_lite", "sdp_tbd")


def _local_rc_basis(center_xy_m: Tensor) -> tuple[Tensor, Tensor]:
    """Return radial and cross-range unit vectors for metric BEV coordinates."""
    radius = center_xy_m.norm(dim=-1, keepdim=True).clamp_min(0.25)
    radial = center_xy_m / radius
    cross = torch.stack((radial[:, 1], -radial[:, 0]), dim=1)
    return radial, cross


def _cartesian_to_rc(delta_xy_m: Tensor, center_xy_m: Tensor) -> Tensor:
    radial, cross = _local_rc_basis(center_xy_m)
    return torch.stack(((delta_xy_m * radial).sum(dim=-1), (delta_xy_m * cross).sum(dim=-1)), dim=-1)


def _rc_to_cartesian(delta_rc_m: Tensor, center_xy_m: Tensor) -> Tensor:
    radial, cross = _local_rc_basis(center_xy_m)
    return delta_rc_m[:, 0:1] * radial + delta_rc_m[:, 1:2] * cross


class _BaseE4Expert(nn.Module):
    def __init__(self, geometry: BEVGeometry, offset_bound_m: float, sigma_m: float) -> None:
        super().__init__()
        self.geometry = geometry
        self.offset_bound_m = offset_bound_m
        self.sigma_m = sigma_m

    def _render_delta(self, base_xy_m: Tensor, proposal_xy_m: Tensor, strength: Tensor) -> Tensor:
        return gaussian_logit_delta(base_xy_m, proposal_xy_m, strength, self.geometry, self.sigma_m)


class AURFLiteExpert(_BaseE4Expert):
    """Local polar-BEV anisotropic uncertainty residual field around the frozen peak."""

    def __init__(self, geometry: BEVGeometry, components: int = 2) -> None:
        super().__init__(geometry, offset_bound_m=0.55, sigma_m=0.28)
        if components != 2:
            raise ValueError("AURF-Lite is intentionally fixed to two local uncertainty modes")
        self.components = components
        self.polar_encoder = _ROIEncoder(48, 32)
        self.bev_encoder = _ROIEncoder(128, 32)
        self.state = nn.Sequential(nn.Linear(68, 96), nn.SiLU(inplace=True), nn.Linear(96, 96), nn.SiLU(inplace=True))
        self.mixture_head = nn.Linear(96, components * 5)
        self.scale_head = _zero_linear(nn.Linear(96, 1))
        self.acceptance_head = nn.Linear(96, 1)
        self.covariance_head = nn.Linear(96, 2)

    def forward(
        self,
        polar_feature: Tensor,
        shared_feature: Tensor,
        radar: Tensor,
        base_logits: Tensor,
        base_xy_m: Tensor,
        previous_xy_m: Tensor,
    ) -> dict[str, Tensor]:
        polar_crop = metric_polar_crop(polar_feature, base_xy_m, self.geometry, span_m=1.8, output_size=11)
        bev_crop = metric_bev_crop(shared_feature, base_xy_m, self.geometry, span_m=2.0, output_size=15)
        innovation = base_xy_m - previous_xy_m
        state = self.state(torch.cat((self.polar_encoder(polar_crop), self.bev_encoder(bev_crop), innovation, base_xy_m / 20.0), dim=1))
        raw = self.mixture_head(state).reshape(-1, self.components, 5)
        mixture_logits = raw[:, :, 0]
        mixture = torch.softmax(mixture_logits, dim=1)
        offsets_rc = self.offset_bound_m * torch.tanh(raw[:, :, 1:3])
        std_rc = (0.06 + 0.54 * torch.sigmoid(raw[:, :, 3:5])).clamp(0.06, 0.60)
        cartesian_offsets = torch.stack(
            [_rc_to_cartesian(offsets_rc[:, index], base_xy_m) for index in range(self.components)], dim=1
        )
        component_xy_m = _clamp_metric_xy(
            (base_xy_m[:, None] + cartesian_offsets).reshape(-1, 2), self.geometry
        ).reshape(-1, self.components, 2)
        proposal_xy_m = (mixture.unsqueeze(-1) * component_xy_m).sum(dim=1)
        delta = self._render_delta(base_xy_m, proposal_xy_m, torch.tanh(self.scale_head(state)))
        return {
            "delta_bev_logit": delta,
            "acceptance_logit": self.acceptance_head(state),
            "covariance": _positive_diagonal_covariance(self.covariance_head(state)),
            "causal_state": state,
            "proposal_xy_m": proposal_xy_m,
            "mixture_logits": mixture_logits,
            "mixture_weights": mixture,
            "mixture_offset_rc_m": offsets_rc,
            "mixture_std_rc_m": std_rc,
            "mixture_component_xy_m": component_xy_m,
        }


class SDPTBDExpert(_BaseE4Expert):
    """Causal soft-Viterbi track-before-detect over low-threshold polar candidates."""

    def __init__(self, geometry: BEVGeometry, candidate_count: int = 8) -> None:
        super().__init__(geometry, offset_bound_m=0.45, sigma_m=0.30)
        if candidate_count < 6:
            raise ValueError("SDP-TBD needs at least six candidates per causal frame")
        self.candidate_count = candidate_count
        self.local_encoder = _ROIEncoder(2, 24)
        self.token_project = nn.Sequential(nn.Linear(29, 64), nn.SiLU(inplace=True), nn.Linear(64, 64), nn.SiLU(inplace=True))
        self.emission_head = nn.Linear(64, 1)
        self.transition = nn.Sequential(nn.Linear(6, 32), nn.SiLU(inplace=True), nn.Linear(32, 1))
        self.offset_head = nn.Linear(64, 2)
        self.scale_head = _zero_linear(nn.Linear(64, 1))
        self.acceptance_head = nn.Linear(64, 1)
        self.covariance_head = nn.Linear(64, 2)

    def _candidate_features(self, radar: Tensor, candidates_xy_m: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        batch, frames, count, _ = candidates_xy_m.shape
        source = radar.reshape(batch * frames, 2, 128, 128).repeat_interleave(count, dim=0)
        crops = metric_polar_crop(source, candidates_xy_m.reshape(batch * frames * count, 2), self.geometry, span_m=1.2, output_size=7)
        embedding = self.local_encoder(crops).reshape(batch, frames, count, -1)
        local_score = crops.mean(dim=(1, 2, 3)).reshape(batch, frames, count)
        agreement = -(crops[:, 0] - crops[:, 1]).abs().mean(dim=(-2, -1)).reshape(batch, frames, count)
        return embedding, local_score, agreement

    def _soft_viterbi(self, emission: Tensor, positions: Tensor, score: Tensor, agreement: Tensor) -> Tensor:
        """Return normalized causal path log-posteriors, one candidate distribution per frame."""
        batch, frames, count = emission.shape
        alpha = emission[:, 0]
        history = [alpha]
        for time_index in range(1, frames):
            previous = positions[:, time_index - 1, :, None, :]
            current = positions[:, time_index, None, :, :]
            delta = current - previous
            distance = delta.norm(dim=-1)
            transition_input = torch.cat(
                (
                    delta,
                    distance.unsqueeze(-1),
                    score[:, time_index - 1, :, None, None].expand(-1, -1, count, -1),
                    score[:, time_index, None, :, None].expand(-1, count, -1, -1),
                    (agreement[:, time_index - 1, :, None] - agreement[:, time_index, None, :]).abs().unsqueeze(-1),
                ),
                dim=-1,
            )
            transition = self.transition(transition_input).squeeze(-1) - 2.0 * torch.relu(distance - 0.65)
            alpha = emission[:, time_index] + torch.logsumexp(alpha[:, :, None] + transition, dim=1)
            alpha = alpha - alpha.max(dim=1, keepdim=True).values
            history.append(alpha)
        return torch.stack(history, dim=1).reshape(batch, frames, count)

    def forward(
        self,
        polar_feature: Tensor,
        shared_feature: Tensor,
        radar: Tensor,
        base_logits: Tensor,
        base_xy_m: Tensor,
        previous_xy_m: Tensor,
    ) -> dict[str, Tensor]:
        batch, frames = radar.shape[:2]
        low_candidates, low_score = _low_threshold_polar_candidates(radar, self.candidate_count, self.geometry)
        # A causal base-velocity anchor keeps the trellis observable when a weak
        # historical frame has no local raw maximum at the true position. It is
        # generated solely from the current and previous frozen-base estimates.
        velocity = base_xy_m - previous_xy_m
        frame_offset = torch.arange(frames, device=radar.device, dtype=radar.dtype) - float(frames - 1)
        anchor = _clamp_metric_xy(
            (base_xy_m[:, None] + frame_offset.view(1, frames, 1) * velocity[:, None]).reshape(-1, 2), self.geometry
        ).reshape(batch, frames, 2)
        candidates_xy_m = torch.cat((anchor[:, :, None], low_candidates[:, :, : self.candidate_count - 1]), dim=2)
        prior_score = low_score.mean(dim=2, keepdim=True)
        detector_score = torch.cat((prior_score, low_score[:, :, : self.candidate_count - 1]), dim=2)
        current_low = low_candidates[:, -1, : self.candidate_count - 2]
        current = torch.cat((base_xy_m[:, None], previous_xy_m[:, None], current_low), dim=1)
        candidates_xy_m[:, -1] = current
        detector_score[:, -1] = torch.cat((prior_score[:, -1], prior_score[:, -1], low_score[:, -1, : self.candidate_count - 2]), dim=1)
        embedding, local_score, agreement = self._candidate_features(radar, candidates_xy_m)
        normalized_score = (detector_score - detector_score.mean(dim=2, keepdim=True)) / detector_score.std(dim=2, keepdim=True).clamp_min(1e-4)
        time_coordinate = torch.linspace(-1.0, 0.0, frames, device=radar.device, dtype=radar.dtype).view(1, frames, 1, 1)
        token_input = torch.cat(
            (
                embedding,
                normalized_score.unsqueeze(-1),
                agreement.unsqueeze(-1),
                candidates_xy_m / torch.tensor((10.0, 23.4), device=radar.device, dtype=radar.dtype),
                time_coordinate.expand(batch, frames, self.candidate_count, 1),
            ),
            dim=-1,
        )
        tokens = self.token_project(token_input)
        emission = self.emission_head(tokens).squeeze(-1) + 0.15 * normalized_score + 0.10 * agreement
        path_logits = self._soft_viterbi(emission, candidates_xy_m, normalized_score, agreement)
        mixture = torch.softmax(path_logits[:, -1], dim=1)
        current_tokens = tokens[:, -1]
        corrected_candidates = _clamp_metric_xy(
            (current + self.offset_bound_m * torch.tanh(self.offset_head(current_tokens))).reshape(-1, 2), self.geometry
        ).reshape(batch, self.candidate_count, 2)
        proposal_xy_m = (mixture.unsqueeze(-1) * corrected_candidates).sum(dim=1)
        state = (mixture.unsqueeze(-1) * current_tokens).sum(dim=1)
        delta = self._render_delta(base_xy_m, proposal_xy_m, torch.tanh(self.scale_head(state)))
        return {
            "delta_bev_logit": delta,
            "acceptance_logit": self.acceptance_head(state),
            "covariance": _positive_diagonal_covariance(self.covariance_head(state)),
            "causal_state": state,
            "proposal_xy_m": proposal_xy_m,
            "candidate_mixture": mixture,
            "candidate_xy_m": corrected_candidates,
            "candidate_history_xy_m": candidates_xy_m,
            "tbd_path_logits": path_logits,
            "tbd_emission_logits": emission,
        }


class DREAME4RouteExpertBEV(nn.Module):
    """Frozen DREAM-BEV plus a causal E4 local-probability or path expert."""

    def __init__(self, expert_kind: E4ExpertKind, logit_cap: float = 3.0, candidate_count: int = 8) -> None:
        super().__init__()
        if expert_kind not in E4_EXPERT_KINDS:
            raise ValueError(f"unsupported E4 expert_kind={expert_kind!r}; expected one of {E4_EXPERT_KINDS}")
        self.geometry = BEVGeometry()
        self.expert_kind = expert_kind
        self.logit_cap = logit_cap
        self.backbone = MRODNetBEV()
        self.expert: nn.Module = AURFLiteExpert(self.geometry) if expert_kind == "aurf_lite" else SDPTBDExpert(self.geometry, candidate_count)
        self._freeze_backbone()

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True) -> "DREAME4RouteExpertBEV":
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("model") not in {None, "m_rodnet_lite"}:
            raise ValueError("E4 experts require an m_rodnet_lite/DREAM-BEV checkpoint")
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from (parameter for parameter in self.expert.parameters() if parameter.requires_grad)

    def expert_state_dict(self) -> dict[str, object]:
        return {"expert_kind": self.expert_kind, "logit_cap": self.logit_cap, "expert": self.expert.state_dict()}

    def _base_observation(self, radar: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        with torch.no_grad():
            polar_feature = self.backbone.forward_polar_feature(radar)
            shared_feature = self.backbone.shared_from_polar_feature(polar_feature)
            base_logits = self.backbone.decoder.decode_shared(shared_feature)
            previous_polar = self.backbone.forward_polar_feature(causal_previous_window(radar))
            previous_logits = self.backbone.decoder.decode_shared(self.backbone.shared_from_polar_feature(previous_polar))
            base_xy_m, _ = decode_peak_xy(base_logits, self.geometry)
            previous_xy_m, _ = decode_peak_xy(previous_logits, self.geometry)
        return polar_feature, shared_feature, base_logits, torch.cat((base_xy_m, previous_xy_m), dim=1)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        polar_feature, shared_feature, base_logits, peaks = self._base_observation(radar)
        base_xy_m, previous_xy_m = peaks[:, :2], peaks[:, 2:]
        expert_output = self.expert(polar_feature, shared_feature, radar, base_logits, base_xy_m, previous_xy_m)
        delta = expert_output["delta_bev_logit"].clamp(-self.logit_cap, self.logit_cap)
        acceptance = torch.sigmoid(expert_output["acceptance_logit"])
        logits = base_logits + acceptance[:, :, None, None] * delta
        return {
            "logits": logits,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "acceptance_logit": expert_output["acceptance_logit"],
            "covariance": expert_output["covariance"],
            "causal_state": expert_output["causal_state"],
            "proposal_xy_m": expert_output["proposal_xy_m"],
            "base_peak_xy_m": base_xy_m,
            "previous_peak_xy_m": previous_xy_m,
            "shared_feature": shared_feature,
            **{key: value for key, value in expert_output.items() if key not in {"delta_bev_logit", "acceptance_logit", "covariance", "causal_state", "proposal_xy_m"}},
        }
