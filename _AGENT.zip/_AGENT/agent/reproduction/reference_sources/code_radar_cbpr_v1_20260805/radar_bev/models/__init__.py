from __future__ import annotations

from functools import partial

from torch import nn

from .backbones import (
    CDCBEV,
    CausalConvGRUBEV,
    CausalConvLSTMBEV,
    ERODNetCoreBEV,
    MRODNetBEV,
    MTRODNetBEV,
    RadarFormerLiteBEV,
    ResUNetBEV,
    RWKVBEV,
    TSMResUNetBEV,
    TRODNetWindowBEV,
    TemporalInceptionBEV,
    UIUNet3DBEV,
)
from .full_mamba import FullMRODNetBEV, FullMTRODNetBEV
from .e3_experts import DREAME3RouteExpertBEV
from .e4_experts import DREAME4RouteExpertBEV
from .e5_experts import DREAME5RouteExpertBEV
from .e6_experts import DREAME6RouteExpertBEV
from .e7_experts import DREAME7RouteExpertBEV
from .e9_pbm_hbr import (
    DREAME9PBMHBRStage1BEV,
    DREAME9PBMHBRStage2BEV,
    DREAME9PBMHBRStage2RDBEV,
    DREAME9PBMHBRQualityBEV,
    DREAME9PBMHBRQualityRDBEV,
)
from .heterogeneous_experts import DREAMHeterogeneousExpertBEV
from .harder_ris_expert import (
    HarderRISCompactExpertBEV,
    HarderRISFullMapExpertBEV,
    HarderRISSpatialHeatmapExpertBEV,
)
from .lcorridor_ris_expert import DREAMLCorridorRISExpertBEV
from .ragt import RAGTConvLSTMBEV
from .route_experts import DREAMRouteExpertBEV


def build_model(name: str, **kwargs: object) -> nn.Module:
    registry = {
        "resunet": ResUNetBEV,
        "tsm_resunet": TSMResUNetBEV,
        "convlstm": CausalConvLSTMBEV,
        "convgru": CausalConvGRUBEV,
        "cdc": CDCBEV,
        "temporal_inception": TemporalInceptionBEV,
        "uiunet3d": UIUNet3DBEV,
        "erodnet_core": ERODNetCoreBEV,
        "trodnet_window": TRODNetWindowBEV,
        "m_trodnet_lite": MTRODNetBEV,
        "m_rodnet_lite": MRODNetBEV,
        "ragt_cpm3d_rcdg": partial(MTRODNetBEV, lite_variant="rcdg"),
        "ragt_cpm3d_rcdg_ctim": partial(MTRODNetBEV, lite_variant="rcdg_ctim"),
        "ragt_cpm3d_lite": partial(MTRODNetBEV, lite_variant="full"),
        "ragt_cpm2d_lite": partial(MRODNetBEV, lite_variant="full"),
        "ragt_window_lite": partial(TRODNetWindowBEV, lite_variant="full"),
        "m_trodnet_full": FullMTRODNetBEV,
        "m_rodnet_full": FullMRODNetBEV,
        "radarformer_lite": RadarFormerLiteBEV,
        "rwkv_bev": RWKVBEV,
        "ragt_ds": partial(RAGTConvLSTMBEV, variant="ds"),
        "ragt_dsg": partial(RAGTConvLSTMBEV, variant="dsg"),
        "ragt_convlstm": partial(RAGTConvLSTMBEV, variant="full"),
        "dream_route_expert": DREAMRouteExpertBEV,
        "dream_heterogeneous_expert": DREAMHeterogeneousExpertBEV,
        "dream_e3_route_expert": DREAME3RouteExpertBEV,
        "dream_e4_route_expert": DREAME4RouteExpertBEV,
        "dream_e5_route_expert": DREAME5RouteExpertBEV,
        "dream_e6_route_expert": DREAME6RouteExpertBEV,
        "dream_e7_route_expert": DREAME7RouteExpertBEV,
        "dream_e9_pbm_hbr_stage1": DREAME9PBMHBRStage1BEV,
        "dream_e9_pbm_hbr_stage2": DREAME9PBMHBRStage2BEV,
        "dream_e9_pbm_hbr_stage2_rd": DREAME9PBMHBRStage2RDBEV,
        "dream_e9_pbm_hbr_quality": DREAME9PBMHBRQualityBEV,
        "dream_e9_pbm_hbr_quality_rd": DREAME9PBMHBRQualityRDBEV,
        "dream_lcorridor_ris_expert": DREAMLCorridorRISExpertBEV,
        "harder_ris_fullmap_expert": HarderRISFullMapExpertBEV,
        "harder_ris_compact_expert": HarderRISCompactExpertBEV,
        "harder_ris_spatial_expert": HarderRISSpatialHeatmapExpertBEV,
    }
    try:
        return registry[name.lower()](**kwargs)
    except KeyError as error:
        choices = ", ".join(sorted(registry))
        raise ValueError(f"Unknown radar model {name!r}; choose one of: {choices}") from error


__all__ = ["build_model"]
