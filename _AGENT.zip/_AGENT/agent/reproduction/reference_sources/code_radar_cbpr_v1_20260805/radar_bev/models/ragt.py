from __future__ import annotations

from typing import Literal

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from ..geometry import BEVGeometry
from .common import BEVDecoder, ConvLSTMCell, ConvNormAct, RadarBEVBase, ResidualBlock


class RAGTPolarEncoder(nn.Module):
    """Compact one-channel polar encoder used independently for RA and RA-MTI."""

    def __init__(self, output_channels: int = 24, stem_channels: int = 16) -> None:
        super().__init__()
        self.network = nn.Sequential(
            ConvNormAct(1, stem_channels),
            ResidualBlock(stem_channels),
            ConvNormAct(stem_channels, output_channels),
            ResidualBlock(output_channels),
        )

    def forward(self, value: Tensor) -> Tensor:
        if value.ndim != 4 or value.shape[1] != 1:
            raise ValueError("RAGT polar stream must be [batch,1,128,128]")
        return self.network(value)


class BEVGeometryEmbedding(nn.Module):
    """Fixed metric geometry made available at every requested BEV resolution."""

    def __init__(self, geometry: BEVGeometry) -> None:
        super().__init__()
        metric = geometry.coordinate_grid()
        x, y = metric.unbind(dim=-1)
        radial_distance = torch.sqrt(x.square() + y.square())
        max_distance = torch.sqrt(
            torch.tensor(geometry.x_max_m**2 + geometry.y_max_m**2, dtype=metric.dtype)
        )
        sin_azimuth = torch.where(
            radial_distance > 1e-6,
            x / radial_distance,
            torch.zeros_like(radial_distance),
        )
        normalized_x = x / max(abs(geometry.x_min_m), abs(geometry.x_max_m))
        normalized_y = 2.0 * (y - geometry.y_min_m) / (geometry.y_max_m - geometry.y_min_m) - 1.0
        self.register_buffer(
            "features",
            torch.stack((radial_distance / max_distance, sin_azimuth, normalized_x, normalized_y), dim=0).unsqueeze(0),
            persistent=False,
        )

    def forward(self, reference: Tensor) -> Tensor:
        if reference.ndim != 4:
            raise ValueError("geometry reference must be [batch,channels,height,width]")
        geometry = self.features.to(device=reference.device, dtype=reference.dtype)
        if geometry.shape[-2:] != reference.shape[-2:]:
            geometry = functional.interpolate(geometry, size=reference.shape[-2:], mode="bilinear", align_corners=True)
        return geometry.expand(reference.shape[0], -1, -1, -1)


class ReliabilityGate(nn.Module):
    """Framewise spatial allocation between raw RA and clutter-suppressed RA-MTI."""

    def __init__(self, channels: int, geometry_channels: int = 4) -> None:
        super().__init__()
        self.channels = channels
        self.geometry_channels = geometry_channels
        self.network = nn.Sequential(
            ConvNormAct(channels * 3 + geometry_channels, channels),
            nn.Conv2d(channels, 1, kernel_size=1),
        )

    def forward(self, ra: Tensor, mti: Tensor, geometry: Tensor) -> Tensor:
        if ra.shape != mti.shape:
            raise ValueError("RA and RA-MTI features must have matching shapes")
        if geometry.shape != (ra.shape[0], self.geometry_channels, *ra.shape[-2:]):
            raise ValueError("geometry must match feature batch and spatial shape")
        gate = torch.sigmoid(self.network(torch.cat((ra, mti, (ra - mti).abs(), geometry), dim=1)))
        return gate * ra + (1.0 - gate) * mti


class GeometryConvLSTMCell(nn.Module):
    """ConvLSTM whose gates receive a fixed BEV geometry embedding."""

    def __init__(self, input_channels: int, hidden_channels: int, geometry_channels: int = 4) -> None:
        super().__init__()
        self.input_channels = input_channels
        self.hidden_channels = hidden_channels
        self.geometry_channels = geometry_channels
        self.gates = nn.Conv2d(
            input_channels + hidden_channels,
            hidden_channels * 4,
            kernel_size=3,
            padding=1,
        )
        self.geometry_bias = nn.Conv2d(geometry_channels, hidden_channels * 4, kernel_size=1)

    def geometry_gate_bias(self, geometry: Tensor) -> Tensor:
        if geometry.ndim != 4 or geometry.shape[1] != self.geometry_channels:
            raise ValueError("geometry must match the configured geometry channels")
        return self.geometry_bias(geometry)

    def forward_with_geometry_bias(
        self,
        value: Tensor,
        state: tuple[Tensor, Tensor] | None,
        geometry_gate_bias: Tensor,
    ) -> tuple[Tensor, Tensor]:
        if value.ndim != 4 or value.shape[1] != self.input_channels:
            raise ValueError("value must match the configured ConvLSTM input channels")
        expected_bias_shape = (value.shape[0], self.hidden_channels * 4, *value.shape[-2:])
        if geometry_gate_bias.shape != expected_bias_shape:
            raise ValueError("geometry gate bias must match batch and spatial shape")
        if state is None:
            zeros = value.new_zeros(value.shape[0], self.hidden_channels, value.shape[2], value.shape[3])
            hidden, cell = zeros, zeros
        else:
            hidden, cell = state
            expected_state_shape = (value.shape[0], self.hidden_channels, *value.shape[-2:])
            if hidden.shape != expected_state_shape or cell.shape != expected_state_shape:
                raise ValueError("state must match the configured hidden channels, batch, and spatial shape")
        input_gate, forget_gate, output_gate, candidate = (
            self.gates(torch.cat((value, hidden), dim=1)) + geometry_gate_bias
        ).chunk(4, dim=1)
        cell = torch.sigmoid(forget_gate) * cell + torch.sigmoid(input_gate) * torch.tanh(candidate)
        hidden = torch.sigmoid(output_gate) * torch.tanh(cell)
        return hidden, cell

    def forward(
        self,
        value: Tensor,
        state: tuple[Tensor, Tensor] | None,
        geometry: Tensor,
    ) -> tuple[Tensor, Tensor]:
        expected_geometry_shape = (value.shape[0], self.geometry_channels, *value.shape[-2:])
        if geometry.shape != expected_geometry_shape:
            raise ValueError("geometry must match the configured channels, batch, and spatial shape")
        return self.forward_with_geometry_bias(value, state, self.geometry_gate_bias(geometry))


class BoundedStateTransport(nn.Module):
    """Local metric BEV alignment before a recurrent update."""

    def __init__(
        self,
        channels: int,
        geometry_channels: int = 4,
        resolution_m: float = 0.1,
        max_offset_m: float = 0.4,
    ) -> None:
        super().__init__()
        self.channels = channels
        self.geometry_channels = geometry_channels
        self.resolution_m = resolution_m
        self.max_offset_m = max_offset_m
        self.motion_summary_channels = geometry_channels + 2
        self.context = ConvNormAct(self.motion_summary_channels, 16)
        self.offset_head = nn.Conv2d(16, 2, kernel_size=3, padding=1)
        self.confidence_head = nn.Conv2d(16, 1, kernel_size=1)

    def _validate_inputs(self, value: Tensor, hidden: Tensor, geometry: Tensor) -> None:
        expected_feature_shape = (value.shape[0], self.channels, *value.shape[-2:])
        expected_geometry_shape = (value.shape[0], self.geometry_channels, *value.shape[-2:])
        if value.shape != expected_feature_shape or hidden.shape != expected_feature_shape:
            raise ValueError("value and hidden must match the configured channels, batch, and spatial shape")
        if geometry.shape != expected_geometry_shape:
            raise ValueError("geometry must match the configured channels, batch, and spatial shape")

    def _motion_context(self, value: Tensor, hidden: Tensor, geometry: Tensor) -> Tensor:
        self._validate_inputs(value, hidden, geometry)
        summary = torch.cat((value.mean(dim=1, keepdim=True), hidden.mean(dim=1, keepdim=True), geometry), dim=1)
        return self.context(summary)

    def predict_offset_m(self, value: Tensor, hidden: Tensor, geometry: Tensor) -> Tensor:
        return self.max_offset_m * torch.tanh(self.offset_head(self._motion_context(value, hidden, geometry)))

    @staticmethod
    def _sampling_grid(offset_m: Tensor, resolution_m: float) -> Tensor:
        batch, _, height, width = offset_m.shape
        x = torch.linspace(-1.0, 1.0, height, device=offset_m.device, dtype=offset_m.dtype)
        y = torch.linspace(-1.0, 1.0, width, device=offset_m.device, dtype=offset_m.dtype)
        x_grid, y_grid = torch.meshgrid(x, y, indexing="ij")
        grid = torch.stack((y_grid, x_grid), dim=-1).unsqueeze(0).expand(batch, -1, -1, -1).clone()
        offset_cells = offset_m / resolution_m
        # Tensor height maps to physical x, while grid_sample's first coordinate maps to width/physical y.
        grid[..., 0] += 2.0 * offset_cells[:, 1] / max(width - 1, 1)
        grid[..., 1] += 2.0 * offset_cells[:, 0] / max(height - 1, 1)
        return grid

    def forward(
        self,
        value: Tensor,
        state: tuple[Tensor, Tensor] | None,
        geometry: Tensor,
    ) -> tuple[Tensor, Tensor] | None:
        if state is None:
            return None
        hidden, cell = state
        context = self._motion_context(value, hidden, geometry)
        offset_m = self.max_offset_m * torch.tanh(self.offset_head(context))
        confidence = torch.sigmoid(self.confidence_head(context))
        grid = self._sampling_grid(offset_m, self.resolution_m)
        warped_state = functional.grid_sample(
            torch.cat((hidden, cell), dim=1),
            grid,
            mode="bilinear",
            padding_mode="border",
            align_corners=True,
        )
        warped_hidden, warped_cell = warped_state.split(self.channels, dim=1)
        return (
            confidence * warped_hidden + (1.0 - confidence) * hidden,
            confidence * warped_cell + (1.0 - confidence) * cell,
        )


RAGTVariant = Literal["ds", "dsg", "full"]


class RAGTConvLSTMBEV(RadarBEVBase):
    """Reliability-Aware Geometry-Transport ConvLSTM with fixed public ablations."""

    VALID_VARIANTS = ("ds", "dsg", "full")

    def __init__(self, variant: RAGTVariant = "full") -> None:
        if variant not in self.VALID_VARIANTS:
            choices = ", ".join(self.VALID_VARIANTS)
            raise ValueError(f"Unknown RAGT variant {variant!r}; choose one of: {choices}")
        super().__init__()
        self.variant = variant
        self.ra_encoder = RAGTPolarEncoder(24)
        self.mti_encoder = RAGTPolarEncoder(24)
        self.geometry_embedding = BEVGeometryEmbedding(self.geometry)
        self.reliability_gate = ReliabilityGate(24)
        self.fusion_projection = nn.Sequential(ConvNormAct(24, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)
        self.temporal: ConvLSTMCell | GeometryConvLSTMCell
        if variant == "ds":
            self.temporal = ConvLSTMCell(128, 128)
            self.transport = None
        else:
            self.temporal = GeometryConvLSTMCell(128, 128)
            self.transport = BoundedStateTransport(128, resolution_m=self.geometry.resolution_m) if variant == "full" else None
        self.fuse = nn.Sequential(ConvNormAct(128, 128), ResidualBlock(128))

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        batch, frames = radar.shape[:2]
        ra_polar = self.ra_encoder(radar[:, :, 0].reshape(batch * frames, 1, 128, 128))
        mti_polar = self.mti_encoder(radar[:, :, 1].reshape(batch * frames, 1, 128, 128))
        ra_bev = self.polar_to_bev(ra_polar)
        mti_bev = self.polar_to_bev(mti_polar)
        geometry_bev = self.geometry_embedding(ra_bev)
        fused_bev = self.fusion_projection(self.reliability_gate(ra_bev, mti_bev, geometry_bev))
        shared_sequence = self.decoder.encode_shared(fused_bev).reshape(batch, frames, 128, 50, 59)
        shared_geometry = self.geometry_embedding(shared_sequence[:, 0])
        geometry_gate_bias = (
            self.temporal.geometry_gate_bias(shared_geometry) if self.variant != "ds" else None
        )

        state: tuple[Tensor, Tensor] | None = None
        for time_index in range(frames):
            current = shared_sequence[:, time_index]
            if self.transport is not None:
                state = self.transport(current, state, shared_geometry)
            if self.variant == "ds":
                state = self.temporal(current, state)
            else:
                if geometry_gate_bias is None:
                    raise RuntimeError("geometry-conditioned RAGT requires a precomputed geometry gate bias")
                state = self.temporal.forward_with_geometry_bias(current, state, geometry_gate_bias)
        if state is None:
            raise RuntimeError("RAGT requires a non-empty temporal input window")
        shared_feature = self.fuse(state[0])
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}
