from __future__ import annotations

import importlib.util
import sys
import types
from contextlib import contextmanager
from importlib.machinery import ModuleSpec
from pathlib import Path
from typing import Iterator

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from .common import BEVDecoder, ConvNormAct, RadarBEVBase, ResidualBlock

try:
    from mamba_ssm import Mamba
except ImportError:
    Mamba = None


_REFERENCE_ROOT = Path(__file__).resolve().parents[2] / "third_party" / "trodnet_reference"


def _require_mamba() -> None:
    if Mamba is None:
        raise ImportError(
            "Full Mamba backbones require mamba_ssm. Run them in the local WSL "
            "'mamba' environment documented in docs/WSL_MAMBA_ENV.md."
        )


class _DropPath(nn.Module):
    """Small timm-compatible fallback required only by the frozen reference code."""

    def __init__(self, drop_prob: float = 0.0) -> None:
        super().__init__()
        self.drop_prob = drop_prob

    def forward(self, value: Tensor) -> Tensor:
        if self.drop_prob == 0.0 or not self.training:
            return value
        keep_probability = 1.0 - self.drop_prob
        shape = (value.shape[0],) + (1,) * (value.ndim - 1)
        mask = (keep_probability + torch.rand(shape, dtype=value.dtype, device=value.device)).floor()
        return value.div(keep_probability) * mask


def _module(name: str, package: bool = False) -> types.ModuleType:
    value = types.ModuleType(name)
    value.__spec__ = ModuleSpec(name, loader=None, is_package=package)
    if package:
        value.__path__ = []
    return value


@contextmanager
def _reference_import_context() -> Iterator[None]:
    """Supply only inert legacy imports while loading the frozen reference files."""

    previous: dict[str, types.ModuleType | None] = {}

    def install(name: str, value: types.ModuleType) -> None:
        previous.setdefault(name, sys.modules.get(name))
        sys.modules[name] = value

    thop = _module("thop")
    thop.profile = lambda *args, **kwargs: (0, 0)
    install("thop", thop)

    fvcore = _module("fvcore", package=True)
    fvcore_nn = _module("fvcore.nn")
    fvcore_nn.FlopCountAnalysis = object
    fvcore_nn.parameter_count_table = lambda *args, **kwargs: ""
    fvcore.nn = fvcore_nn
    install("fvcore", fvcore)
    install("fvcore.nn", fvcore_nn)

    timm = _module("timm", package=True)
    timm_models = _module("timm.models", package=True)
    timm_layers = _module("timm.models.layers")
    timm_layers.DropPath = _DropPath
    timm_layers.trunc_normal_ = torch.nn.init.trunc_normal_
    timm_layers.to_3tuple = lambda value: value if isinstance(value, tuple) else (value, value, value)
    timm_models.layers = timm_layers
    timm.models = timm_models
    install("timm", timm)
    install("timm.models", timm_models)
    install("timm.models.layers", timm_layers)

    config = _module("config", package=True)
    selector = _module("config.selector")
    selector.rudet_configs = {"viz_SSCS": False}
    selector.MDRSSM_configs = {"SSCS": False}
    config.selector = selector
    install("config", config)
    install("config.selector", selector)

    model = _module("model", package=True)
    backbone = _module("model.backbone", package=True)
    chirp = _module("model.backbone.ChirpFeatureExtractor")
    chirp.MNet = nn.Identity
    mdrssm = _module("model.MDRSSM")
    mdrssm.EightWayMambaLayer = nn.Identity
    model.backbone = backbone
    backbone.ChirpFeatureExtractor = chirp
    model.MDRSSM = mdrssm
    install("model", model)
    install("model.backbone", backbone)
    install("model.backbone.ChirpFeatureExtractor", chirp)
    install("model.MDRSSM", mdrssm)

    try:
        yield
    finally:
        for name, value in previous.items():
            if value is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value


def _load_reference_module(filename: str) -> types.ModuleType:
    _require_mamba()
    source = _REFERENCE_ROOT / filename
    if not source.is_file():
        raise FileNotFoundError(f"Frozen full-capacity reference source is missing: {source}")
    module_name = f"_radar_reference_{source.stem.lower()}"
    specification = importlib.util.spec_from_file_location(module_name, source)
    if specification is None or specification.loader is None:
        raise ImportError(f"Could not load frozen reference source: {source}")
    reference = importlib.util.module_from_spec(specification)
    with _reference_import_context():
        specification.loader.exec_module(reference)
    return reference


class _CausalWindowMamba3D(nn.Module):
    """Past-only Mamba along time for every spatial cell of a 3D Swin window."""

    def __init__(self, channels: int, window_size: tuple[int, int, int]) -> None:
        super().__init__()
        _require_mamba()
        self.channels = channels
        self.window_height = window_size[1]
        self.window_width = window_size[2]
        self.temporal = Mamba(d_model=channels, d_state=16, d_conv=4, expand=2)
        self.spatial = nn.Sequential(
            nn.Conv3d(channels, channels, kernel_size=(1, 3, 3), padding=(0, 1, 1), groups=channels, bias=False),
            nn.Conv3d(channels, channels, kernel_size=1, bias=False),
        )

    def forward(
        self,
        value: Tensor,
        mask: Tensor | None = None,
        prev_v: Tensor | None = None,
        prev_k: Tensor | None = None,
        prev_q: Tensor | None = None,
        is_decoder: bool = False,
    ) -> tuple[Tensor, None, None, None, None]:
        del mask, prev_v, prev_k, prev_q, is_decoder
        windows, tokens, channels = value.shape
        if channels != self.channels:
            raise ValueError(f"Expected {self.channels} channels, got {channels}")
        spatial_area = self.window_height * self.window_width
        if tokens % spatial_area:
            raise ValueError("3D window token count is incompatible with the frozen spatial window")
        frames = tokens // spatial_area
        volume = value.reshape(windows, frames, self.window_height, self.window_width, channels)
        sequence = volume.permute(0, 2, 3, 1, 4).reshape(windows * spatial_area, frames, channels)
        sequence = self.temporal(sequence)
        mixed = sequence.reshape(windows, self.window_height, self.window_width, frames, channels)
        mixed = mixed.permute(0, 4, 3, 1, 2).contiguous()
        mixed = mixed + self.spatial(mixed)
        mixed = mixed.permute(0, 2, 3, 4, 1).reshape(windows, tokens, channels)
        return mixed, None, None, None, None


def _make_full_trod_mamba_backbone() -> nn.Module:
    reference = _load_reference_module("T_RODNet.py")
    backbone = reference.T_RODNet(num_classes=1, embed_dim=64, win_size=4).swin_unet
    backbone.convlast = nn.Identity()
    for layer in [*backbone.layers, *backbone.layers_up]:
        if hasattr(layer, "shift_size"):
            layer.shift_size = (0, layer.shift_size[1], layer.shift_size[2])
        for block in getattr(layer, "blocks", []):
            block.shift_size = (0, block.shift_size[1], block.shift_size[2])
            block.attn = _CausalWindowMamba3D(block.dim, block.window_size)
    return backbone


class FullMTRODNetBEV(RadarBEVBase):
    """Full 3D Swin-U T-RODNet skeleton with every temporal attention window replaced by causal Mamba."""

    def __init__(self) -> None:
        super().__init__()
        self.backbone = _make_full_trod_mamba_backbone()
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        feature = self.backbone(radar.permute(0, 2, 1, 3, 4))
        if feature.ndim != 5 or feature.shape[1] != 64:
            raise RuntimeError(f"Unexpected full T-ROD feature shape: {tuple(feature.shape)}")
        polar_feature = self.reduce(feature[:, :, -1])
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


def _make_full_mrod_backbone() -> nn.Module:
    reference = _load_reference_module("MDRSSM.py")
    mrod = reference.MDRSSM(
        num_classes=1,
        embed_dim=64,
        win_size=4,
        use_moe_SSCS=False,
        use_posEmbed=False,
        use_BiMamba=False,
        use_EightWay=False,
        use_ADCBranch=False,
    )
    backbone = mrod.mamba_unet
    backbone.convlast = nn.Identity()
    return backbone


class FullMRODNetBEV(RadarBEVBase):
    """Full single-direction Mamba-U RODNet, with the native multi-scale RA decoder retained."""

    def __init__(self) -> None:
        super().__init__()
        self.backbone = _make_full_mrod_backbone()
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)
        self._checkpoint_blocks = [
            module for module in self.backbone.modules() if module.__class__.__name__ == "MambaBlock3D"
        ]
        self._set_checkpointing(True)

    def _set_checkpointing(self, enabled: bool) -> None:
        for module in self._checkpoint_blocks:
            module.use_checkpoint = enabled

    def train(self, mode: bool = True) -> "FullMRODNetBEV":
        super().train(mode)
        # The frozen reference block checkpoints unconditionally when enabled.
        # Keep its memory-saving path for training, but never checkpoint eval.
        self._set_checkpointing(mode)
        return self

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        feature = self.backbone(radar.permute(0, 2, 1, 3, 4), None)
        if feature.ndim != 5 or feature.shape[1] != 64:
            raise RuntimeError(f"Unexpected full M-ROD feature shape: {tuple(feature.shape)}")
        polar_feature = self.reduce(feature[:, :, -1])
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}
