from __future__ import annotations

import hashlib
import math
from collections.abc import Iterator
from pathlib import Path

import torch
from torch import Tensor, nn
from torch.nn import functional

from ..expert_primitives import decode_peak_xy
from ..geometry import BEVGeometry
from ..lcorridor_ris import extract_ris_peak_sequence
from .backbones import MRODNetBEV
from .common import ConvGRUCell, ConvNormAct, ResidualBlock


class HarderRISFullMapExpertBEV(nn.Module):
    """Frozen DREAM-BEV plus a causal low-resolution full-map RIS adapter."""

    uses_future_frames = False

    def __init__(self) -> None:
        super().__init__()
        self.backbone = MRODNetBEV()
        self.raw_encoder = nn.Sequential(
            ConvNormAct(2, 16),
            ResidualBlock(16),
        )
        self.temporal = ConvGRUCell(16, 32)
        self.fuse = nn.Sequential(
            ConvNormAct(160, 128),
            ResidualBlock(128),
        )
        self.decode = nn.Sequential(
            ConvNormAct(128, 96),
            ResidualBlock(96),
            ConvNormAct(96, 64),
        )
        self.logit_head = nn.Conv2d(64, 1, kernel_size=1)
        nn.init.zeros_(self.logit_head.weight)
        nn.init.zeros_(self.logit_head.bias)
        self._freeze_backbone()

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True) -> "HarderRISFullMapExpertBEV":
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("model") not in {None, "m_rodnet_lite"}:
            raise ValueError("Harder RIS expert requires the DREAM-BEV m_rodnet_lite checkpoint")
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from self.raw_encoder.parameters()
        yield from self.temporal.parameters()
        yield from self.fuse.parameters()
        yield from self.decode.parameters()
        yield from self.logit_head.parameters()

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        with torch.no_grad():
            base_output = self.backbone(radar)
            base_shared = base_output["shared_feature"]
            base_logits = base_output["logits"]
        batch, frames = radar.shape[:2]
        raw_bev = self.backbone.polar_to_bev(
            radar.reshape(batch * frames, 2, 128, 128)
        )
        raw_bev = functional.interpolate(
            raw_bev,
            size=(50, 59),
            mode="bilinear",
            align_corners=False,
        )
        raw_sequence = self.raw_encoder(raw_bev).reshape(
            batch,
            frames,
            16,
            50,
            59,
        )
        hidden = None
        for time_index in range(frames):
            hidden = self.temporal(raw_sequence[:, time_index], hidden)
        shared_feature = self.fuse(torch.cat((base_shared, hidden), dim=1))
        decoded = self.decode(shared_feature)
        decoded = functional.interpolate(
            decoded,
            size=(
                self.backbone.geometry.x_bins,
                self.backbone.geometry.y_bins,
            ),
            mode="bilinear",
            align_corners=False,
        )
        residual_logits = self.logit_head(decoded)
        logits = base_logits + residual_logits
        peak_sequence_xy_m, peak_quality = extract_ris_peak_sequence(
            radar,
            self.backbone.geometry,
        )
        return {
            "logits": logits,
            "base_logits": base_logits,
            "residual_logits": residual_logits,
            "shared_feature": shared_feature,
            "base_shared_feature": base_shared,
            "raw_peak_xy_m": peak_sequence_xy_m[:, -1],
            "peak_sequence_xy_m": peak_sequence_xy_m,
            "peak_quality": peak_quality,
        }


class HarderRISCompactExpertBEV(nn.Module):
    """Compact causal full-map coordinate expert for the L-corridor harder domain."""

    uses_future_frames = False

    def __init__(
        self,
        hidden_channels: int = 128,
        sigma_m: float = 0.20,
    ) -> None:
        super().__init__()
        if hidden_channels < 32:
            raise ValueError("hidden_channels must be at least 32")
        if sigma_m <= 0.0:
            raise ValueError("sigma_m must be positive")
        self.geometry = BEVGeometry()
        self.backbone = MRODNetBEV()
        self.frame_encoder = nn.Sequential(
            ConvNormAct(2, 16, stride=2),
            ConvNormAct(16, 24, stride=2),
            ConvNormAct(24, 32, stride=2),
            ResidualBlock(32),
        )
        self.frame_project = nn.Sequential(
            nn.Flatten(start_dim=1),
            nn.Linear(32 * 16 * 16, hidden_channels),
            nn.SiLU(inplace=True),
        )
        self.temporal = nn.GRU(hidden_channels, hidden_channels, batch_first=True)
        self.position_fuse = nn.Sequential(
            nn.Linear(hidden_channels + 5, hidden_channels),
            nn.SiLU(inplace=True),
        )
        self.position_head = nn.Linear(hidden_channels, 2)
        self.confidence_head = nn.Linear(hidden_channels, 1)
        self.covariance_head = nn.Linear(hidden_channels, 2)
        nn.init.zeros_(self.position_head.weight)
        initial_x_fraction = (1.0 - (-1.5)) / 7.0
        initial_y_fraction = (3.5 - 0.25) / 6.0
        nn.init.constant_(
            self.position_head.bias[0],
            float(torch.logit(torch.tensor(initial_x_fraction))),
        )
        nn.init.constant_(
            self.position_head.bias[1],
            float(torch.logit(torch.tensor(initial_y_fraction))),
        )
        self.sigma_m = float(sigma_m)
        self.register_buffer(
            "metric_grid",
            self.geometry.coordinate_grid(),
            persistent=False,
        )
        self._freeze_backbone()

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True) -> "HarderRISCompactExpertBEV":
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("model") not in {None, "m_rodnet_lite"}:
            raise ValueError("Compact harder RIS expert requires the DREAM-BEV checkpoint")
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from self.frame_encoder.parameters()
        yield from self.frame_project.parameters()
        yield from self.temporal.parameters()
        yield from self.position_fuse.parameters()
        yield from self.position_head.parameters()
        yield from self.confidence_head.parameters()
        yield from self.covariance_head.parameters()

    def expert_state_dict(self) -> dict[str, object]:
        return {
            "frame_encoder": self.frame_encoder.state_dict(),
            "frame_project": self.frame_project.state_dict(),
            "temporal": self.temporal.state_dict(),
            "position_fuse": self.position_fuse.state_dict(),
            "position_head": self.position_head.state_dict(),
            "confidence_head": self.confidence_head.state_dict(),
            "covariance_head": self.covariance_head.state_dict(),
            "hidden_channels": self.temporal.hidden_size,
            "sigma_m": self.sigma_m,
        }

    def load_expert_checkpoint(
        self,
        checkpoint_path: str | Path,
        *,
        expected_base_sha256: str | None = None,
    ) -> dict[str, object]:
        payload = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=False)
        if payload.get("model") != "HarderRISCompactExpertBEV":
            raise ValueError("Checkpoint is not a compact harder RIS expert")
        if (
            expected_base_sha256 is not None
            and payload.get("base_checkpoint_sha256") != expected_base_sha256
        ):
            raise ValueError("Expert checkpoint was trained on a different frozen DREAM-BEV base")
        state = payload["expert_state"]
        if int(state.get("hidden_channels", self.temporal.hidden_size)) != self.temporal.hidden_size:
            raise ValueError("Compact expert hidden size does not match the checkpoint")
        self.frame_encoder.load_state_dict(state["frame_encoder"], strict=True)
        self.frame_project.load_state_dict(state["frame_project"], strict=True)
        self.temporal.load_state_dict(state["temporal"], strict=True)
        self.position_fuse.load_state_dict(state["position_fuse"], strict=True)
        self.position_head.load_state_dict(state["position_head"], strict=True)
        self.confidence_head.load_state_dict(state["confidence_head"], strict=True)
        self.covariance_head.load_state_dict(state["covariance_head"], strict=True)
        return payload

    def _metric_positions(self, hidden: Tensor, raw_peak: Tensor, quality: Tensor) -> Tensor:
        scale = hidden.new_tensor((6.0, 6.0))
        evidence = torch.cat(
            (
                raw_peak / scale,
                quality / 3.0,
            ),
            dim=-1,
        )
        normalized = torch.sigmoid(
            self.position_head(self.position_fuse(torch.cat((hidden, evidence), dim=-1)))
        )
        x_m = -1.5 + 7.0 * normalized[..., 0]
        y_m = 0.25 + 6.0 * normalized[..., 1]
        return torch.stack((x_m, y_m), dim=-1)

    def _measurement_logits(self, xy_m: Tensor, confidence_logit: Tensor) -> Tensor:
        grid = self.metric_grid.to(device=xy_m.device, dtype=xy_m.dtype)
        distance_squared = (
            (grid[..., 0].unsqueeze(0) - xy_m[:, 0, None, None]).square()
            + (grid[..., 1].unsqueeze(0) - xy_m[:, 1, None, None]).square()
        )
        gaussian = torch.exp(-0.5 * distance_squared / (self.sigma_m * self.sigma_m))
        amplitude = 16.0 + 2.0 * torch.tanh(confidence_logit).view(-1, 1, 1)
        return (-8.0 + amplitude * gaussian).unsqueeze(1)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone._validate_input(radar)
        batch, frames = radar.shape[:2]
        frame_feature = self.frame_encoder(
            radar.reshape(batch * frames, 2, 128, 128)
        )
        tokens = self.frame_project(frame_feature).reshape(batch, frames, -1)
        hidden_sequence, _ = self.temporal(tokens)
        raw_peak_sequence, peak_quality = extract_ris_peak_sequence(
            radar,
            self.geometry,
        )
        predicted_sequence = self._metric_positions(
            hidden_sequence,
            raw_peak_sequence,
            peak_quality,
        )
        fused_state = self.position_fuse(
            torch.cat(
                (
                    hidden_sequence[:, -1],
                    raw_peak_sequence[:, -1] / radar.new_tensor((6.0, 6.0)),
                    peak_quality[:, -1] / 3.0,
                ),
                dim=-1,
            )
        )
        proposal = predicted_sequence[:, -1]
        confidence_logit = self.confidence_head(fused_state).squeeze(-1)
        sigma = functional.softplus(self.covariance_head(fused_state)) + 0.05
        with torch.no_grad():
            base_output = self.backbone(radar)
            base_xy_m, base_score = decode_peak_xy(
                base_output["logits"],
                self.geometry,
            )
        return {
            "logits": self._measurement_logits(proposal, confidence_logit),
            "shared_feature": base_output["shared_feature"],
            "base_logits": base_output["logits"],
            "base_xy_m": base_xy_m,
            "base_score": base_score.squeeze(1),
            "proposal_xy_m": proposal,
            "offset_xy_m": proposal - raw_peak_sequence[:, -1],
            "confidence_logit": confidence_logit,
            "covariance": torch.diag_embed(sigma.square()),
            "causal_state": hidden_sequence[:, -1],
            "raw_peak_xy_m": raw_peak_sequence[:, -1],
            "peak_sequence_xy_m": predicted_sequence,
            "raw_peak_sequence_xy_m": raw_peak_sequence,
            "peak_quality": peak_quality,
        }


class HarderRISSpatialHeatmapExpertBEV(nn.Module):
    """Causal full-map RIS expert that preserves native polar geometry."""

    uses_future_frames = False

    def __init__(
        self,
        hidden_channels: int = 32,
        sigma_m: float = 0.20,
        softmax_temperature: float = 0.20,
        use_aux_views: bool = False,
    ) -> None:
        super().__init__()
        if hidden_channels < 16:
            raise ValueError("hidden_channels must be at least 16")
        if sigma_m <= 0.0:
            raise ValueError("sigma_m must be positive")
        if softmax_temperature <= 0.0:
            raise ValueError("softmax_temperature must be positive")
        self.geometry = BEVGeometry()
        self.backbone = MRODNetBEV()
        self.frame_encoder = nn.Sequential(
            ConvNormAct(6, 16, stride=2),
            ResidualBlock(16),
            ConvNormAct(16, 24, stride=2),
            ResidualBlock(24),
        )
        self.temporal = ConvGRUCell(24, hidden_channels)
        self.use_aux_views = bool(use_aux_views)
        self.auxiliary_fuse = (
            nn.Sequential(
                ConvNormAct(hidden_channels + 2, hidden_channels),
                ResidualBlock(hidden_channels),
            )
            if self.use_aux_views
            else nn.Identity()
        )
        self.polar_decoder = nn.Sequential(
            ConvNormAct(hidden_channels, 32),
            ResidualBlock(32),
            nn.Upsample(scale_factor=2.0, mode="bilinear", align_corners=False),
            ConvNormAct(32, 24),
            nn.Upsample(scale_factor=2.0, mode="bilinear", align_corners=False),
            ConvNormAct(24, 16),
            nn.Conv2d(16, 1, kernel_size=1),
        )
        self.confidence_head = nn.Linear(hidden_channels, 1)
        self.quality_feature_head = nn.Sequential(
            nn.Linear(4, 16),
            nn.SiLU(),
            nn.Linear(16, 1),
        )
        nn.init.zeros_(self.quality_feature_head[-1].weight)
        nn.init.zeros_(self.quality_feature_head[-1].bias)
        self.covariance_head = nn.Linear(hidden_channels, 2)
        self.sigma_m = float(sigma_m)
        self.softmax_temperature = float(softmax_temperature)
        self.register_buffer(
            "metric_grid",
            self.geometry.coordinate_grid(),
            persistent=False,
        )
        self.register_buffer(
            "polar_metric_grid",
            self._build_polar_metric_grid(),
            persistent=False,
        )
        self.register_buffer(
            "polar_coordinate_channels",
            self._build_polar_coordinate_channels(),
            persistent=False,
        )
        self._freeze_backbone()

    def _build_polar_metric_grid(self) -> Tensor:
        range_m = self.geometry.range_axis_m[:, None]
        azimuth_index = torch.arange(self.geometry.azimuth_bins, dtype=torch.float32)
        sin_azimuth = azimuth_index / (self.geometry.azimuth_bins / 2.0) - 1.0
        x_m = range_m * sin_azimuth[None, :]
        y_m = torch.sqrt((range_m.square() - x_m.square()).clamp_min(0.0))
        return torch.stack((x_m, y_m), dim=-1)

    def _build_polar_coordinate_channels(self) -> Tensor:
        normalized_range = torch.linspace(0.0, 1.0, self.geometry.range_bins)
        sin_azimuth = torch.arange(self.geometry.azimuth_bins, dtype=torch.float32)
        sin_azimuth = sin_azimuth / (self.geometry.azimuth_bins / 2.0) - 1.0
        return torch.stack(
            (
                normalized_range[:, None].expand(-1, self.geometry.azimuth_bins),
                sin_azimuth[None, :].expand(self.geometry.range_bins, -1),
            ),
            dim=0,
        )

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True) -> "HarderRISSpatialHeatmapExpertBEV":
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("model") not in {None, "m_rodnet_lite"}:
            raise ValueError("Spatial harder RIS expert requires the DREAM-BEV checkpoint")
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from self.frame_encoder.parameters()
        yield from self.temporal.parameters()
        yield from self.auxiliary_fuse.parameters()
        yield from self.polar_decoder.parameters()
        yield from self.confidence_head.parameters()
        yield from self.quality_feature_head.parameters()
        yield from self.covariance_head.parameters()

    def expert_state_dict(self) -> dict[str, object]:
        return {
            "frame_encoder": self.frame_encoder.state_dict(),
            "temporal": self.temporal.state_dict(),
            "auxiliary_fuse": self.auxiliary_fuse.state_dict(),
            "polar_decoder": self.polar_decoder.state_dict(),
            "confidence_head": self.confidence_head.state_dict(),
            "quality_feature_head": self.quality_feature_head.state_dict(),
            "covariance_head": self.covariance_head.state_dict(),
            "hidden_channels": self.temporal.hidden_channels,
            "sigma_m": self.sigma_m,
            "softmax_temperature": self.softmax_temperature,
            "use_aux_views": self.use_aux_views,
        }

    def load_expert_checkpoint(
        self,
        checkpoint_path: str | Path,
        *,
        expected_base_sha256: str | None = None,
    ) -> dict[str, object]:
        payload = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=False)
        if payload.get("model") != "HarderRISSpatialHeatmapExpertBEV":
            raise ValueError("Checkpoint is not a spatial harder RIS expert")
        if (
            expected_base_sha256 is not None
            and payload.get("base_checkpoint_sha256") != expected_base_sha256
        ):
            raise ValueError("Expert checkpoint was trained on a different frozen DREAM-BEV base")
        state = payload["expert_state"]
        if int(state.get("hidden_channels", self.temporal.hidden_channels)) != self.temporal.hidden_channels:
            raise ValueError("Spatial expert hidden size does not match the checkpoint")
        if bool(state.get("use_aux_views", False)) != self.use_aux_views:
            raise ValueError("Spatial expert auxiliary-view contract does not match the checkpoint")
        self.frame_encoder.load_state_dict(state["frame_encoder"], strict=True)
        self.temporal.load_state_dict(state["temporal"], strict=True)
        self.auxiliary_fuse.load_state_dict(state.get("auxiliary_fuse", {}), strict=True)
        self.polar_decoder.load_state_dict(state["polar_decoder"], strict=True)
        self.confidence_head.load_state_dict(state["confidence_head"], strict=True)
        quality_state = state.get("quality_feature_head")
        if quality_state is not None:
            self.quality_feature_head.load_state_dict(quality_state, strict=True)
        self.covariance_head.load_state_dict(state["covariance_head"], strict=True)
        return payload

    def _soft_position(self, polar_logits: Tensor) -> Tensor:
        probabilities = functional.softmax(
            polar_logits.flatten(start_dim=1) / self.softmax_temperature,
            dim=-1,
        )
        metric = self.polar_metric_grid.to(
            device=polar_logits.device,
            dtype=polar_logits.dtype,
        ).reshape(-1, 2)
        return probabilities @ metric

    def _subbin_position(self, polar_logits: Tensor) -> Tensor:
        scores = polar_logits[:, 0].float()
        flat_index = scores.flatten(start_dim=1).argmax(dim=-1)
        row = torch.div(flat_index, self.geometry.azimuth_bins, rounding_mode="floor")
        col = flat_index.remainder(self.geometry.azimuth_bins)
        batch_index = torch.arange(scores.shape[0], device=scores.device)
        center = scores[batch_index, row, col]

        def quadratic_offset(negative: Tensor, positive: Tensor, interior: Tensor) -> Tensor:
            left = scores[batch_index, negative[0], negative[1]]
            right = scores[batch_index, positive[0], positive[1]]
            denominator = left - 2.0 * center + right
            offset = torch.where(
                denominator.abs() > 1e-6,
                0.5 * (left - right) / denominator,
                torch.zeros_like(center),
            ).clamp(-0.5, 0.5)
            return torch.where(interior, offset, torch.zeros_like(offset))

        range_offset = quadratic_offset(
            ((row - 1).clamp_min(0), col),
            ((row + 1).clamp_max(self.geometry.range_bins - 1), col),
            (row > 0) & (row < self.geometry.range_bins - 1),
        )
        azimuth_offset = quadratic_offset(
            (row, (col - 1).clamp_min(0)),
            (row, (col + 1).clamp_max(self.geometry.azimuth_bins - 1)),
            (col > 0) & (col < self.geometry.azimuth_bins - 1),
        )
        range_bin = row.float() + range_offset
        azimuth_bin = col.float() + azimuth_offset
        range_m = range_bin * self.geometry.range_resolution_m
        sin_azimuth = (
            azimuth_bin / (self.geometry.azimuth_bins / 2.0) - 1.0
        ).clamp(-1.0, 1.0)
        x_m = range_m * sin_azimuth
        y_m = torch.sqrt((range_m.square() - x_m.square()).clamp_min(0.0))
        return torch.stack((x_m, y_m), dim=-1)

    def _measurement_logits(self, xy_m: Tensor, confidence_logit: Tensor) -> Tensor:
        grid = self.metric_grid.to(device=xy_m.device, dtype=xy_m.dtype)
        distance_squared = (
            (grid[..., 0].unsqueeze(0) - xy_m[:, 0, None, None]).square()
            + (grid[..., 1].unsqueeze(0) - xy_m[:, 1, None, None]).square()
        )
        gaussian = torch.exp(-0.5 * distance_squared / (self.sigma_m * self.sigma_m))
        amplitude = 16.0 + 2.0 * torch.tanh(confidence_logit).view(-1, 1, 1)
        return (-8.0 + amplitude * gaussian).unsqueeze(1)

    @staticmethod
    def _normalize_profile(profile: Tensor) -> Tensor:
        mean = profile.mean(dim=-1, keepdim=True)
        std = profile.std(dim=-1, keepdim=True).clamp_min(0.05)
        return (profile - mean) / std

    def _fuse_auxiliary_views(
        self,
        hidden: Tensor,
        rd_mti: Tensor | None,
        ad: Tensor | None,
    ) -> Tensor:
        if not self.use_aux_views:
            return hidden
        if rd_mti is None or ad is None:
            raise ValueError("Spatial harder RIS expert requires RD-MTI and AD views")
        if (
            rd_mti.ndim != 4
            or ad.ndim != 4
            or rd_mti.shape[-2:] != (128, 256)
            or ad.shape[-2:] != (128, 256)
        ):
            raise ValueError("RD-MTI and AD must both be [batch,frames,128,256]")
        range_profile = self._normalize_profile(
            torch.logsumexp(rd_mti[:, -1].float(), dim=-1)
        ).unsqueeze(1).unsqueeze(-1)
        azimuth_profile = self._normalize_profile(
            torch.logsumexp(ad[:, -1].float(), dim=-1)
        ).unsqueeze(1).unsqueeze(-2)
        range_profile = functional.interpolate(
            range_profile,
            size=(hidden.shape[-2], 1),
            mode="bilinear",
            align_corners=False,
        ).expand(-1, -1, hidden.shape[-2], hidden.shape[-1])
        azimuth_profile = functional.interpolate(
            azimuth_profile,
            size=(1, hidden.shape[-1]),
            mode="bilinear",
            align_corners=False,
        ).expand(-1, -1, hidden.shape[-2], hidden.shape[-1])
        return self.auxiliary_fuse(
            torch.cat((hidden, range_profile, azimuth_profile), dim=1)
        )

    def forward(
        self,
        radar: Tensor,
        *,
        rd_mti: Tensor | None = None,
        ad: Tensor | None = None,
    ) -> dict[str, Tensor]:
        self.backbone._validate_input(radar)
        batch, frames = radar.shape[:2]
        mean = radar.float().mean(dim=(-2, -1), keepdim=True)
        std = radar.float().std(dim=(-2, -1), keepdim=True).clamp_min(0.05)
        normalized = (radar.float() - mean) / std
        temporal_difference = torch.zeros_like(normalized)
        if frames > 1:
            temporal_difference[:, 1:] = normalized[:, 1:] - normalized[:, :-1]
        coordinates = self.polar_coordinate_channels.to(
            device=radar.device,
            dtype=normalized.dtype,
        ).view(1, 1, 2, 128, 128).expand(batch, frames, -1, -1, -1)
        spatial_input = torch.cat(
            (normalized, temporal_difference, coordinates),
            dim=2,
        )
        frame_feature = self.frame_encoder(
            spatial_input.reshape(batch * frames, 6, 128, 128)
        ).reshape(batch, frames, 24, 32, 32)
        hidden = None
        for time_index in range(frames):
            hidden = self.temporal(frame_feature[:, time_index], hidden)
        hidden = self._fuse_auxiliary_views(hidden, rd_mti, ad)
        polar_logits = self.polar_decoder(hidden)
        confidence_xy_m = self._subbin_position(polar_logits.detach())
        proposal = (
            self._soft_position(polar_logits)
            if self.training
            else confidence_xy_m
        )
        pooled = functional.adaptive_avg_pool2d(hidden, output_size=1).flatten(start_dim=1)
        flat_polar = polar_logits.float().flatten(start_dim=1)
        top_two = flat_polar.topk(k=2, dim=-1).values
        peak_margin = (top_two[:, 0] - top_two[:, 1]).detach()
        log_normalizer = torch.logsumexp(flat_polar, dim=-1)
        probabilities = torch.softmax(flat_polar, dim=-1)
        normalized_entropy = -(
            probabilities * torch.log(probabilities.clamp_min(1e-12))
        ).sum(dim=-1) / math.log(flat_polar.shape[-1])
        quality_features = torch.stack(
            (
                peak_margin,
                top_two[:, 0] - log_normalizer,
                1.0 - normalized_entropy,
                top_two[:, 0] - flat_polar.mean(dim=-1),
            ),
            dim=-1,
        ).detach()
        confidence_logit = (
            self.confidence_head(pooled).squeeze(-1)
            + peak_margin
            + self.quality_feature_head(quality_features).squeeze(-1)
        )
        sigma = functional.softplus(self.covariance_head(pooled)) + 0.05
        raw_peak_sequence, peak_quality = extract_ris_peak_sequence(
            radar,
            self.geometry,
        )
        with torch.no_grad():
            base_output = self.backbone(radar)
            base_xy_m, base_score = decode_peak_xy(
                base_output["logits"],
                self.geometry,
            )
        return {
            "logits": self._measurement_logits(proposal, confidence_logit),
            "polar_logits": polar_logits,
            "shared_feature": base_output["shared_feature"],
            "base_logits": base_output["logits"],
            "base_xy_m": base_xy_m,
            "base_score": base_score.squeeze(1),
            "proposal_xy_m": proposal,
            "confidence_target_xy_m": confidence_xy_m,
            "offset_xy_m": proposal - raw_peak_sequence[:, -1],
            "confidence_logit": confidence_logit,
            "covariance": torch.diag_embed(sigma.square()),
            "causal_state": hidden,
            "raw_peak_xy_m": raw_peak_sequence[:, -1],
            "peak_sequence_xy_m": raw_peak_sequence,
            "raw_peak_sequence_xy_m": raw_peak_sequence,
            "peak_quality": peak_quality,
        }
