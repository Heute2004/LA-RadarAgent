from __future__ import annotations

import hashlib
from collections.abc import Iterator
from pathlib import Path
from typing import Literal

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from ..expert_primitives import causal_previous_window, decode_peak_xy, gaussian_logit_delta, metric_bev_crop, metric_polar_crop
from ..geometry import BEVGeometry
from .backbones import MRODNetBEV
from .heterogeneous_experts import _ROIEncoder, _clamp_metric_xy, _positive_diagonal_covariance, _zero_linear


E6ExpertKind = Literal["rhem"]
E6_EXPERT_KINDS: tuple[E6ExpertKind, ...] = ("rhem",)


def _metric_grid(centers_xy_m: Tensor, span_m: float, output_size: int) -> Tensor:
    offset = torch.linspace(-span_m / 2.0, span_m / 2.0, output_size, dtype=centers_xy_m.dtype, device=centers_xy_m.device)
    offset_x, offset_y = torch.meshgrid(offset, offset, indexing="ij")
    return centers_xy_m[:, None, None, :] + torch.stack((offset_x, offset_y), dim=-1).unsqueeze(0)


def _bounded_displacement(base_xy_m: Tensor, proposal_xy_m: Tensor, bound_m: float) -> Tensor:
    displacement = proposal_xy_m - base_xy_m
    norm = displacement.norm(dim=1, keepdim=True).clamp_min(1e-6)
    return base_xy_m + displacement * (bound_m * torch.tanh(norm / bound_m) / norm)


def _weighted_geometric_median(grid: Tensor, weight: Tensor, iterations: int = 5) -> Tensor:
    """A small unrolled Weiszfeld solver for a robust local echo centre."""
    location = (weight[..., None] * grid).sum(dim=(1, 2)) / weight.sum(dim=(1, 2)).clamp_min(1e-6)[:, None]
    for _ in range(iterations):
        distance = (grid - location[:, None, None]).norm(dim=-1).clamp_min(1e-4)
        inverse_distance = weight / distance
        location = (inverse_distance[..., None] * grid).sum(dim=(1, 2)) / inverse_distance.sum(dim=(1, 2)).clamp_min(1e-6)[:, None]
    return location


class _AnisotropicLocalEncoder(nn.Module):
    """Light local encoder with separate angular and range receptive fields."""

    def __init__(self, in_channels: int, channels: int = 48) -> None:
        super().__init__()
        self.input = nn.Sequential(nn.Conv2d(in_channels, channels, kernel_size=1), nn.GroupNorm(6, channels), nn.SiLU(inplace=True))
        self.depthwise = nn.Conv2d(channels, channels, kernel_size=3, padding=1, groups=channels)
        self.pointwise = nn.Conv2d(channels, channels, kernel_size=1)
        self.angular = nn.Conv2d(channels, channels, kernel_size=(1, 5), padding=(0, 2))
        self.range = nn.Conv2d(channels, channels, kernel_size=(5, 1), padding=(2, 0))
        self.norm = nn.GroupNorm(6, channels)

    def forward(self, values: Tensor) -> Tensor:
        state = self.input(values)
        residual = state
        state = self.pointwise(self.depthwise(state))
        state = functional.silu(self.angular(state) + self.range(state), inplace=True)
        return self.norm(state + residual)


class RHEMExpert(nn.Module):
    """Range-adaptive robust human-echo mixture expert for indoor clutter.

    The three maps are latent local support responsibilities, not semantic masks.
    Only the body-support-weighted robust geometric centre may form a bounded
    correction to the frozen DREAM-BEV peak.
    """

    def __init__(self, geometry: BEVGeometry) -> None:
        super().__init__()
        self.geometry = geometry
        self.span_m = 2.0
        self.crop_size = 25
        # 48 frozen polar channels + current/mean/std raw RA pair + local x/y.
        self.local_encoder = _AnisotropicLocalEncoder(56)
        self.responsibility_head = nn.Conv2d(48, 3, kernel_size=1)
        self.bev_encoder = _ROIEncoder(128, 32)
        self.state = nn.Sequential(nn.Linear(87, 80), nn.SiLU(inplace=True), nn.Linear(80, 64), nn.SiLU(inplace=True))
        self.scale_head = _zero_linear(nn.Linear(64, 1))
        self.acceptance_head = nn.Linear(64, 1)
        self.covariance_head = nn.Linear(64, 2)

    def _history_raw_crops(self, radar: Tensor, base_xy_m: Tensor, previous_xy_m: Tensor) -> tuple[Tensor, Tensor]:
        batch, frames = radar.shape[:2]
        history_frames = min(5, frames)
        velocity = base_xy_m - previous_xy_m
        offsets = torch.arange(history_frames, device=radar.device, dtype=radar.dtype) - float(history_frames - 1)
        centres = _clamp_metric_xy((base_xy_m[:, None] + offsets[None, :, None] * velocity[:, None]).reshape(-1, 2), self.geometry)
        source = radar[:, -history_frames:].reshape(batch * history_frames, 2, 128, 128)
        crops = metric_polar_crop(source, centres, self.geometry, span_m=self.span_m, output_size=self.crop_size)
        return crops.reshape(batch, history_frames, 2, self.crop_size, self.crop_size), velocity

    def forward(
        self,
        polar_feature: Tensor,
        shared_feature: Tensor,
        radar: Tensor,
        base_logits: Tensor,
        base_xy_m: Tensor,
        previous_xy_m: Tensor,
    ) -> dict[str, Tensor]:
        del base_logits
        raw_history, velocity = self._history_raw_crops(radar, base_xy_m, previous_xy_m)
        raw_current = raw_history[:, -1]
        raw_mean = raw_history.mean(dim=1)
        raw_std = raw_history.std(dim=1, unbiased=False)
        grid = _metric_grid(base_xy_m, self.span_m, self.crop_size)
        local_xy = (grid - base_xy_m[:, None, None]).permute(0, 3, 1, 2) / self.span_m
        polar_local = metric_polar_crop(polar_feature, base_xy_m, self.geometry, span_m=self.span_m, output_size=self.crop_size)
        local_input = torch.cat((polar_local, raw_current, raw_mean, raw_std, local_xy), dim=1)
        local_feature = self.local_encoder(local_input)
        responsibility = torch.softmax(self.responsibility_head(local_feature), dim=1)
        # This is a local excess score in normalized dB-feature space.  We cap
        # its top tail so a furniture peak cannot dominate the support centre.
        joint_energy = 0.65 * raw_current[:, 0] + 0.35 * raw_current[:, 1]
        local_median = joint_energy.flatten(start_dim=1).median(dim=1).values[:, None, None]
        excess = functional.softplus((joint_energy - local_median) / 0.16)
        cap = torch.quantile(excess.flatten(start_dim=1), 0.90, dim=1)[:, None, None].clamp_min(1e-4)
        support_weight = responsibility[:, 0] * excess.minimum(cap)
        raw_centre = _weighted_geometric_median(grid, support_weight)
        proposal_xy_m = _clamp_metric_xy(_bounded_displacement(base_xy_m, raw_centre, 0.45), self.geometry)

        support_sum = support_weight.sum(dim=(1, 2)).clamp_min(1e-6)
        support_embedding = (local_feature * (support_weight / support_sum[:, None, None]).unsqueeze(1)).sum(dim=(2, 3))
        support_compactness = (support_weight * (grid - raw_centre[:, None, None]).square().sum(dim=-1)).sum(dim=(1, 2)) / support_sum
        temporal_disagreement = (raw_current - raw_mean).abs().mean(dim=(1, 2, 3), keepdim=False)
        state_input = torch.cat(
            (
                support_embedding,
                self.bev_encoder(metric_bev_crop(shared_feature, base_xy_m, self.geometry, span_m=2.4, output_size=21)),
                velocity,
                base_xy_m / torch.tensor((10.0, 23.4), device=base_xy_m.device, dtype=base_xy_m.dtype),
                (support_sum / float(self.crop_size * self.crop_size)).unsqueeze(1),
                support_compactness.unsqueeze(1),
                temporal_disagreement.unsqueeze(1),
            ),
            dim=1,
        )
        state = self.state(state_input)
        strength = torch.tanh(self.scale_head(state))
        return {
            "delta_bev_logit": gaussian_logit_delta(base_xy_m, proposal_xy_m, strength, self.geometry, sigma_m=0.24),
            "acceptance_logit": self.acceptance_head(state),
            "covariance": _positive_diagonal_covariance(self.covariance_head(state)),
            "causal_state": state,
            "proposal_xy_m": proposal_xy_m,
            "rhem_raw_center_xy_m": raw_centre,
            "support_responsibility": responsibility,
            "support_compactness": support_compactness,
            "support_mass": support_sum / float(self.crop_size * self.crop_size),
            "temporal_disagreement": temporal_disagreement,
        }


class DREAME6RouteExpertBEV(nn.Module):
    """Frozen DREAM-BEV plus the R2 RHEM bounded residual expert."""

    def __init__(self, expert_kind: E6ExpertKind, logit_cap: float = 3.0, candidate_count: int = 8) -> None:
        super().__init__()
        del candidate_count
        if expert_kind not in E6_EXPERT_KINDS:
            raise ValueError(f"unsupported E6 expert_kind={expert_kind!r}")
        self.geometry = BEVGeometry()
        self.expert_kind = expert_kind
        self.logit_cap = logit_cap
        self.backbone = MRODNetBEV()
        self.expert = RHEMExpert(self.geometry)
        self._freeze_backbone()

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True) -> "DREAME6RouteExpertBEV":
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("model") not in {None, "m_rodnet_lite"}:
            raise ValueError("E6 experts require an m_rodnet_lite/DREAM-BEV checkpoint")
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from (parameter for parameter in self.expert.parameters() if parameter.requires_grad)

    def expert_state_dict(self) -> dict[str, object]:
        return {"expert_kind": self.expert_kind, "logit_cap": self.logit_cap, "expert": self.expert.state_dict()}

    def _base_observation(self, radar: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        with torch.no_grad():
            polar_feature = self.backbone.forward_polar_feature(radar)
            shared_feature = self.backbone.shared_from_polar_feature(polar_feature)
            base_logits = self.backbone.decoder.decode_shared(shared_feature)
            previous_polar = self.backbone.forward_polar_feature(causal_previous_window(radar))
            previous_logits = self.backbone.decoder.decode_shared(self.backbone.shared_from_polar_feature(previous_polar))
            base_xy_m, _ = decode_peak_xy(base_logits, self.geometry)
            previous_xy_m, _ = decode_peak_xy(previous_logits, self.geometry)
        return polar_feature, shared_feature, base_logits, torch.cat((base_xy_m, previous_xy_m), dim=1)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        polar_feature, shared_feature, base_logits, peaks = self._base_observation(radar)
        base_xy_m, previous_xy_m = peaks[:, :2], peaks[:, 2:]
        expert_output = self.expert(polar_feature, shared_feature, radar, base_logits, base_xy_m, previous_xy_m)
        delta = expert_output["delta_bev_logit"].clamp(-self.logit_cap, self.logit_cap)
        acceptance = torch.sigmoid(expert_output["acceptance_logit"])
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "acceptance_logit": expert_output["acceptance_logit"],
            "covariance": expert_output["covariance"],
            "causal_state": expert_output["causal_state"],
            "proposal_xy_m": expert_output["proposal_xy_m"],
            "base_peak_xy_m": base_xy_m,
            "previous_peak_xy_m": previous_xy_m,
            "shared_feature": shared_feature,
            **{key: value for key, value in expert_output.items() if key not in {"delta_bev_logit", "acceptance_logit", "covariance", "causal_state", "proposal_xy_m"}},
        }
