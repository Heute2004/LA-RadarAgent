from __future__ import annotations

import hashlib
from collections.abc import Iterator
from pathlib import Path

import torch
from torch import Tensor, nn
from torch.nn import functional

from ..expert_primitives import decode_peak_xy
from ..geometry import BEVGeometry
from ..lcorridor_ris import extract_ris_peak_sequence
from .backbones import MRODNetBEV


def _clamp_xy(xy_m: Tensor, geometry: BEVGeometry) -> Tensor:
    return torch.stack(
        (
            xy_m[:, 0].clamp(geometry.x_min_m, geometry.x_max_m - geometry.resolution_m),
            xy_m[:, 1].clamp(geometry.y_min_m, geometry.y_max_m - geometry.resolution_m),
        ),
        dim=-1,
    )


class CausalRISPeakRefiner(nn.Module):
    """Small causal correction head around a label-free RIS RA-MTI peak."""

    uses_future_frames = False

    def __init__(
        self,
        geometry: BEVGeometry | None = None,
        hidden_channels: int = 64,
        offset_bound_m: float = 0.18,
    ) -> None:
        super().__init__()
        if hidden_channels < 8:
            raise ValueError("hidden_channels must be at least 8")
        if offset_bound_m <= 0.0:
            raise ValueError("offset_bound_m must be positive")
        self.geometry = geometry or BEVGeometry()
        self.offset_bound_m = float(offset_bound_m)
        self.input_project = nn.Sequential(
            nn.Linear(7, hidden_channels),
            nn.SiLU(inplace=True),
        )
        self.temporal = nn.GRU(hidden_channels, hidden_channels, batch_first=True)
        self.base_project = nn.Sequential(
            nn.Linear(4, hidden_channels),
            nn.SiLU(inplace=True),
        )
        self.fuse = nn.Sequential(
            nn.Linear(hidden_channels * 2, hidden_channels),
            nn.SiLU(inplace=True),
        )
        self.offset_head = nn.Linear(hidden_channels, 2)
        self.confidence_head = nn.Linear(hidden_channels, 1)
        self.covariance_head = nn.Linear(hidden_channels, 2)
        nn.init.zeros_(self.offset_head.weight)
        nn.init.zeros_(self.offset_head.bias)

    def forward(
        self,
        peak_xy_m: Tensor,
        quality: Tensor,
        base_evidence: Tensor | None = None,
    ) -> dict[str, Tensor]:
        if peak_xy_m.ndim != 3 or peak_xy_m.shape[-1] != 2:
            raise ValueError("peak_xy_m must be [batch,frames,2]")
        if quality.shape != (*peak_xy_m.shape[:2], 3):
            raise ValueError("quality must be [batch,frames,3]")
        velocity = torch.cat(
            (torch.zeros_like(peak_xy_m[:, :1]), peak_xy_m[:, 1:] - peak_xy_m[:, :-1]),
            dim=1,
        )
        scale = peak_xy_m.new_tensor((10.0, self.geometry.y_max_m))
        temporal_input = torch.cat((peak_xy_m / scale, quality / 3.0, velocity), dim=-1)
        sequence, _ = self.temporal(self.input_project(temporal_input))
        state = sequence[:, -1]
        if base_evidence is None:
            base_evidence = torch.zeros(
                peak_xy_m.shape[0],
                4,
                device=peak_xy_m.device,
                dtype=peak_xy_m.dtype,
            )
        if base_evidence.shape != (peak_xy_m.shape[0], 4):
            raise ValueError("base_evidence must be [batch,4]")
        fused = self.fuse(torch.cat((state, self.base_project(base_evidence)), dim=-1))
        offset = self.offset_bound_m * torch.tanh(self.offset_head(fused))
        proposal = _clamp_xy(peak_xy_m[:, -1] + offset, self.geometry)
        sigma = functional.softplus(self.covariance_head(fused)) + 0.04
        return {
            "proposal_xy_m": proposal,
            "offset_xy_m": offset,
            "confidence_logit": self.confidence_head(fused).squeeze(-1),
            "covariance": torch.diag_embed(sigma.square()),
            "causal_state": state,
        }


class DREAMLCorridorRISExpertBEV(nn.Module):
    """Frozen DREAM-BEV plus a RIS-specialized causal peak measurement expert."""

    def __init__(
        self,
        hidden_channels: int = 64,
        offset_bound_m: float = 0.18,
        sigma_m: float = 0.16,
    ) -> None:
        super().__init__()
        if sigma_m <= 0.0:
            raise ValueError("sigma_m must be positive")
        self.geometry = BEVGeometry()
        self.backbone = MRODNetBEV()
        self.refiner = CausalRISPeakRefiner(
            geometry=self.geometry,
            hidden_channels=hidden_channels,
            offset_bound_m=offset_bound_m,
        )
        self.sigma_m = float(sigma_m)
        self.base_blend_logit = nn.Parameter(torch.tensor(-4.0))
        self.register_buffer(
            "metric_grid",
            self.geometry.coordinate_grid(),
            persistent=False,
        )
        self._freeze_backbone()

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True) -> "DREAMLCorridorRISExpertBEV":
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if payload.get("model") not in {None, "m_rodnet_lite"}:
            raise ValueError("L-corridor RIS expert requires the frozen DREAM-BEV checkpoint")
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from self.refiner.parameters()
        yield self.base_blend_logit

    def expert_state_dict(self) -> dict[str, object]:
        return {
            "refiner": self.refiner.state_dict(),
            "base_blend_logit": self.base_blend_logit.detach().cpu(),
        }

    def load_expert_checkpoint(
        self,
        checkpoint_path: str | Path,
        *,
        expected_base_sha256: str | None = None,
    ) -> dict[str, object]:
        payload = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=False)
        if payload.get("model") != "DREAMLCorridorRISExpertBEV":
            raise ValueError("Checkpoint is not a DREAM L-corridor RIS expert")
        if expected_base_sha256 is not None and payload.get("base_checkpoint_sha256") != expected_base_sha256:
            raise ValueError("Expert checkpoint was trained on a different frozen DREAM-BEV base")
        state = payload["expert_state"]
        self.refiner.load_state_dict(state["refiner"], strict=True)
        self.base_blend_logit.data.copy_(
            torch.as_tensor(state["base_blend_logit"], dtype=self.base_blend_logit.dtype)
        )
        return payload

    def _measurement_logits(self, xy_m: Tensor, confidence_logit: Tensor) -> Tensor:
        grid = self.metric_grid.to(device=xy_m.device, dtype=xy_m.dtype)
        distance_squared = (
            (grid[..., 0].unsqueeze(0) - xy_m[:, 0, None, None]).square()
            + (grid[..., 1].unsqueeze(0) - xy_m[:, 1, None, None]).square()
        )
        gaussian = torch.exp(-0.5 * distance_squared / (self.sigma_m * self.sigma_m))
        amplitude = 16.0 + 2.0 * torch.tanh(confidence_logit).view(-1, 1, 1)
        return (-8.0 + amplitude * gaussian).unsqueeze(1)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        with torch.no_grad():
            base_output = self.backbone(radar)
            base_logits = base_output["logits"]
            base_xy_m, base_score = decode_peak_xy(base_logits, self.geometry)
        peak_xy_m, peak_quality = extract_ris_peak_sequence(radar, self.geometry)
        current_peak = peak_xy_m[:, -1]
        base_evidence = torch.cat(
            (
                base_xy_m / current_peak.new_tensor((10.0, self.geometry.y_max_m)),
                base_score / 8.0,
                (base_xy_m - current_peak).norm(dim=-1, keepdim=True),
            ),
            dim=-1,
        )
        refined = self.refiner(peak_xy_m, peak_quality, base_evidence)
        measurement_logits = self._measurement_logits(
            refined["proposal_xy_m"],
            refined["confidence_logit"],
        )
        base_blend = torch.sigmoid(self.base_blend_logit)
        logits = measurement_logits + base_blend * base_logits.clamp(-8.0, 8.0)
        return {
            "logits": logits,
            "base_logits": base_logits,
            "measurement_logits": measurement_logits,
            "raw_peak_xy_m": current_peak,
            "peak_sequence_xy_m": peak_xy_m,
            "peak_quality": peak_quality,
            "base_xy_m": base_xy_m,
            "base_score": base_score.squeeze(1),
            "base_blend": base_blend,
            **refined,
        }
