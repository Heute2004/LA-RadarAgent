from __future__ import annotations

from typing import Literal

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from .common import BEVDecoder, ConvGRUCell, ConvLSTMCell, ConvNormAct, PolarFrameEncoder, RadarBEVBase, ResidualBlock
from .ragt_lite import RAGTLiteAdapters, RAGTLiteVariant

try:
    from mamba_ssm import Mamba
except ImportError:
    Mamba = None


class ResUNetBEV(RadarBEVBase):
    """C0: current-frame spatial baseline."""

    def __init__(self) -> None:
        super().__init__()
        self.encoder = PolarFrameEncoder(48)
        self.decoder = BEVDecoder(48, self.geometry)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        polar_feature = self.encoder(radar[:, -1])
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class CausalConvLSTMBEV(RadarBEVBase):
    """C1: causal recurrent state over BEV features."""

    def __init__(self) -> None:
        super().__init__()
        self.encoder = PolarFrameEncoder(48)
        self.decoder = BEVDecoder(48, self.geometry)
        self.temporal = ConvLSTMCell(128, 128)
        self.fuse = nn.Sequential(ConvNormAct(128, 128), ResidualBlock(128))

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        batch, frames = radar.shape[:2]
        polar = self.encoder(radar.reshape(batch * frames, 2, 128, 128))
        bev = self.polar_to_bev(polar)
        shared_sequence = self.decoder.encode_shared(bev).reshape(batch, frames, 128, 50, 59)
        state = None
        for time_index in range(frames):
            state = self.temporal(shared_sequence[:, time_index], state)
        shared_feature = self.fuse(state[0])
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class _SequenceBEVBase(RadarBEVBase):
    """Shared per-frame polar encoder and BEV encoder for causal sequence models."""

    def __init__(self, polar_channels: int = 48) -> None:
        super().__init__()
        self.encoder = PolarFrameEncoder(polar_channels)
        self.decoder = BEVDecoder(polar_channels, self.geometry)

    def _shared_sequence(self, radar: Tensor) -> Tensor:
        self._validate_input(radar)
        batch, frames = radar.shape[:2]
        polar = self.encoder(radar.reshape(batch * frames, 2, 128, 128))
        bev = self.polar_to_bev(polar)
        return self.decoder.encode_shared(bev).reshape(batch, frames, 128, 50, 59)


class TSMResUNetBEV(_SequenceBEVBase):
    """B1: lightweight past-window temporal shift before a spatial BEV decoder."""

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        sequence = self._shared_sequence(radar)
        shifted = sequence.clone()
        fold = sequence.shape[2] // 8
        if sequence.shape[1] > 1:
            shifted[:, 1:, :fold] = sequence[:, :-1, :fold]
            shifted[:, :-1, fold : 2 * fold] = sequence[:, 1:, fold : 2 * fold]
        shared_feature = shifted[:, -1]
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class CausalConvGRUBEV(_SequenceBEVBase):
    """B2: recurrent baseline with a less parameter-heavy causal ConvGRU state."""

    def __init__(self) -> None:
        super().__init__()
        self.temporal = ConvGRUCell(128, 128)
        self.fuse = nn.Sequential(ConvNormAct(128, 128), ResidualBlock(128))

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        sequence = self._shared_sequence(radar)
        hidden = None
        for time_index in range(sequence.shape[1]):
            hidden = self.temporal(sequence[:, time_index], hidden)
        shared_feature = self.fuse(hidden)
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class CDCBEV(RadarBEVBase):
    """C5: compact RODNet-style temporal 3D convolution over the past window."""

    def __init__(self) -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(2, 32, dimensions=3), ConvNormAct(32, 48, dimensions=3))
        self.temporal = nn.Sequential(
            nn.Conv3d(48, 64, kernel_size=(3, 3, 3), padding=(1, 1, 1), bias=False),
            nn.GroupNorm(8, 64),
            nn.SiLU(inplace=True),
            nn.Conv3d(64, 48, kernel_size=(3, 3, 3), padding=(1, 1, 1), bias=False),
            nn.GroupNorm(8, 48),
            nn.SiLU(inplace=True),
        )
        self.decoder = BEVDecoder(48, self.geometry)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        polar = radar.permute(0, 2, 1, 3, 4)
        polar_feature = self.temporal(self.stem(polar))[:, :, -1]
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class TemporalInceptionBEV(RadarBEVBase):
    """B6: multiple past-window temporal receptive fields on native RA features."""

    def __init__(self) -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(2, 48, dimensions=3), ConvNormAct(48, 48, dimensions=3))
        self.branches = nn.ModuleList(
            [
                nn.Conv3d(48, 24, kernel_size=(kernel, 3, 3), padding=(kernel // 2, 1, 1), bias=False)
                for kernel in (3, 5, 7)
            ]
        )
        self.fuse = nn.Sequential(ConvNormAct(72, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        feature = self.stem(radar.permute(0, 2, 1, 3, 4))
        branch = torch.cat([functional.silu(layer(feature)) for layer in self.branches], dim=1)[:, :, -1]
        polar_feature = self.fuse(branch)
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class UIUNet3DBEV(RadarBEVBase):
    """B7: U-shaped 3D convolutional encoder-decoder adapted to two RA channels."""

    def __init__(self) -> None:
        super().__init__()
        self.encoder1 = nn.Sequential(ConvNormAct(2, 32, dimensions=3), ConvNormAct(32, 32, dimensions=3))
        self.encoder2 = nn.Sequential(ConvNormAct(32, 64, stride=(1, 2, 2), dimensions=3), ConvNormAct(64, 64, dimensions=3))
        self.bottleneck = nn.Sequential(ConvNormAct(64, 64, dimensions=3), ConvNormAct(64, 64, dimensions=3))
        self.out_polar = nn.Sequential(ConvNormAct(96, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        polar = radar.permute(0, 2, 1, 3, 4)
        encoded1 = self.encoder1(polar)
        skip = encoded1[:, :, -1]
        encoded = self.bottleneck(self.encoder2(encoded1))[:, :, -1]
        encoded = functional.interpolate(encoded, size=(128, 128), mode="bilinear", align_corners=False)
        polar_feature = self.out_polar(torch.cat((skip, encoded), dim=1))
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class ERODNetCoreBEV(RadarBEVBase):
    """B8: E-RODNet core adaptation: chirp SFF removed, MetaFormer/GFF idea retained."""

    def __init__(self) -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(2, 64, dimensions=3), ConvNormAct(64, 64, dimensions=3))
        self.blocks = nn.ModuleList([_MetaFormer3DBlock(64) for _ in range(3)])
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        feature = self.stem(radar.permute(0, 2, 1, 3, 4))
        for block in self.blocks:
            feature = block(feature)
        polar_feature = self.reduce(feature[:, :, -1])
        shared_feature = self.decoder.encode_shared(self.polar_to_bev(polar_feature))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class _MetaFormer3DBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.token_mixer = nn.Conv3d(channels, channels, kernel_size=(3, 5, 5), padding=(1, 2, 2), groups=channels)
        self.norm1 = nn.GroupNorm(8, channels)
        self.mlp = nn.Sequential(nn.Conv3d(channels, channels * 2, kernel_size=1), nn.GELU(), nn.Conv3d(channels * 2, channels, kernel_size=1))
        self.norm2 = nn.GroupNorm(8, channels)

    def forward(self, value: Tensor) -> Tensor:
        value = value + self.token_mixer(self.norm1(value))
        return value + self.mlp(self.norm2(value))


class _CausalMambaTokenMixer(nn.Module):
    """Selective state-space mixing over a past-only temporal token sequence."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        if Mamba is None:
            raise ImportError(
                "Mamba candidates require mamba_ssm. Use the local WSL 'mamba' "
                "environment documented in docs/WSL_MAMBA_ENV.md."
            )
        self.mixer = Mamba(d_model=channels, d_state=16, d_conv=4, expand=2)
        self.norm = nn.LayerNorm(channels)

    def forward(self, tokens: Tensor) -> Tensor:
        if tokens.ndim != 3:
            raise ValueError("tokens must be [batch,time,channels]")
        return self.norm(tokens + self.mixer(tokens))


class TRODNetWindowBEV(RadarBEVBase):
    """B9: T-RODNet-inspired temporal window attention, adapted for RA/RA-MTI only."""

    def __init__(self, lite_variant: RAGTLiteVariant = "base") -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(2, 64, stride=(1, 2, 2), dimensions=3), ConvNormAct(64, 64, dimensions=3))
        self.attention = nn.MultiheadAttention(64, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(64)
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)
        self.ragt_lite = RAGTLiteAdapters(64, lite_variant)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        conditioned_radar, evidence = self.ragt_lite.condition_radar(radar)
        feature = self.stem(conditioned_radar.permute(0, 2, 1, 3, 4))
        batch, channels, frames, height, width = feature.shape
        sequence = feature.permute(0, 2, 1, 3, 4)
        sequence = self.ragt_lite.condition_temporal(sequence, evidence)
        tokens = sequence.permute(0, 3, 4, 1, 2).reshape(batch * height * width, frames, channels)
        attended, _ = self.attention(tokens, tokens, tokens, need_weights=False)
        latest = self.norm(tokens[:, -1] + attended[:, -1]).reshape(batch, height, width, channels).permute(0, 3, 1, 2)
        latest = functional.interpolate(latest, size=(128, 128), mode="bilinear", align_corners=False)
        polar_feature = self.reduce(latest)
        bev_feature = self.ragt_lite.condition_bev(self.polar_to_bev(polar_feature))
        shared_feature = self.decoder.encode_shared(bev_feature)
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class MTRODNetBEV(RadarBEVBase):
    """M3.5: T-RODNet local 3D stem with its temporal attention replaced by causal Mamba."""

    def __init__(self, lite_variant: RAGTLiteVariant = "base") -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(2, 64, stride=(1, 2, 2), dimensions=3), ConvNormAct(64, 64, dimensions=3))
        self.temporal = _CausalMambaTokenMixer(64)
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)
        self.ragt_lite = RAGTLiteAdapters(64, lite_variant)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self._validate_input(radar)
        conditioned_radar, evidence = self.ragt_lite.condition_radar(radar)
        feature = self.stem(conditioned_radar.permute(0, 2, 1, 3, 4))
        batch, channels, frames, height, width = feature.shape
        sequence = feature.permute(0, 2, 1, 3, 4)
        sequence = self.ragt_lite.condition_temporal(sequence, evidence)
        tokens = sequence.permute(0, 3, 4, 1, 2).reshape(batch * height * width, frames, channels)
        latest = self.temporal(tokens)[:, -1].reshape(batch, height, width, channels).permute(0, 3, 1, 2)
        latest = functional.interpolate(latest, size=(128, 128), mode="bilinear", align_corners=False)
        polar_feature = self.reduce(latest)
        bev_feature = self.ragt_lite.condition_bev(self.polar_to_bev(polar_feature))
        shared_feature = self.decoder.encode_shared(bev_feature)
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class MRODNetBEV(RadarBEVBase):
    """M3.5: framewise ROD-style spatial stem followed by causal Mamba temporal mixing."""

    def __init__(self, lite_variant: RAGTLiteVariant = "base") -> None:
        super().__init__()
        self.stem = nn.Sequential(ConvNormAct(2, 64, stride=2), ConvNormAct(64, 64))
        self.temporal = _CausalMambaTokenMixer(64)
        self.reduce = nn.Sequential(ConvNormAct(64, 48), ResidualBlock(48))
        self.decoder = BEVDecoder(48, self.geometry)
        self.ragt_lite = RAGTLiteAdapters(64, lite_variant)

    def forward_polar_feature(self, radar: Tensor) -> Tensor:
        """Return the final native-polar feature before polar-to-BEV projection."""
        self._validate_input(radar)
        conditioned_radar, evidence = self.ragt_lite.condition_radar(radar)
        batch, frames = conditioned_radar.shape[:2]
        feature = self.stem(conditioned_radar.reshape(batch * frames, 2, 128, 128))
        _, channels, height, width = feature.shape
        sequence = feature.reshape(batch, frames, channels, height, width)
        sequence = self.ragt_lite.condition_temporal(sequence, evidence)
        tokens = sequence.permute(0, 3, 4, 1, 2).reshape(batch * height * width, frames, channels)
        latest = self.temporal(tokens)[:, -1].reshape(batch, height, width, channels).permute(0, 3, 1, 2)
        latest = functional.interpolate(latest, size=(128, 128), mode="bilinear", align_corners=False)
        return self.reduce(latest)

    def shared_from_polar_feature(self, polar_feature: Tensor) -> Tensor:
        """Project a 48-channel polar feature through the frozen BEV interface."""
        if polar_feature.ndim != 4 or polar_feature.shape[1:] != (48, 128, 128):
            raise ValueError("polar_feature must be [batch,48,128,128]")
        bev_feature = self.ragt_lite.condition_bev(self.polar_to_bev(polar_feature))
        return self.decoder.encode_shared(bev_feature)

    def forward_shared(self, radar: Tensor) -> Tensor:
        """Return the stable BEV interface used by later residual experts."""
        return self.shared_from_polar_feature(self.forward_polar_feature(radar))

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        shared_feature = self.forward_shared(radar)
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class RadarFormerLiteBEV(_SequenceBEVBase):
    """B10: compact temporal self-attention on BEV tokens, not a chirp-merging reproduction."""

    def __init__(self) -> None:
        super().__init__()
        self.attention = nn.MultiheadAttention(128, num_heads=4, batch_first=True)
        self.norm = nn.LayerNorm(128)
        self.fuse = nn.Sequential(ConvNormAct(128, 128), ResidualBlock(128))

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        sequence = self._shared_sequence(radar)
        batch, frames, channels, height, width = sequence.shape
        tokens = sequence.permute(0, 3, 4, 1, 2).reshape(batch * height * width, frames, channels)
        attended, _ = self.attention(tokens, tokens, tokens, need_weights=False)
        latest = self.norm(tokens[:, -1] + attended[:, -1])
        shared_feature = self.fuse(latest.reshape(batch, height, width, channels).permute(0, 3, 1, 2))
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}


class RWKVBEV(_SequenceBEVBase):
    """B11: causal weighted-key-value recurrence at the shared BEV resolution."""

    def __init__(self) -> None:
        super().__init__()
        self.key = nn.Conv2d(128, 128, kernel_size=1)
        self.value = nn.Conv2d(128, 128, kernel_size=1)
        self.receptance = nn.Conv2d(128, 128, kernel_size=1)
        self.decay_logit = nn.Parameter(torch.full((1, 128, 1, 1), -1.0))
        self.fuse = nn.Sequential(ConvNormAct(128, 128), ResidualBlock(128))

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        sequence = self._shared_sequence(radar)
        numerator = denominator = None
        decay = torch.sigmoid(self.decay_logit)
        output = None
        for time_index in range(sequence.shape[1]):
            value = sequence[:, time_index]
            key = self.key(value)
            weighted_value = torch.exp(key.clamp(-6.0, 6.0)) * self.value(value)
            weighted_key = torch.exp(key.clamp(-6.0, 6.0))
            if numerator is None:
                numerator, denominator = weighted_value, weighted_key
            else:
                numerator = decay * numerator + weighted_value
                denominator = decay * denominator + weighted_key
            output = torch.sigmoid(self.receptance(value)) * numerator / denominator.clamp_min(1e-4)
        shared_feature = self.fuse(output)
        return {"logits": self.decoder.decode_shared(shared_feature), "shared_feature": shared_feature}
