from __future__ import annotations

"""Five final route experts on a frozen CPB-ConvLSTM feature interface.

The expert heads are imported directly.  In particular, no DREAM/Mamba
backbone is constructed at any point: this avoids accidental feature or weight
reuse and makes the transfer experiment runnable in the standard rvmg env.
"""

import hashlib
from collections.abc import Iterator
from pathlib import Path
from typing import Literal

import torch
from torch import Tensor, nn
from torch.nn import functional

from ..expert_primitives import (
    causal_previous_window,
    decode_peak_xy,
    gaussian_logit_delta,
    local_maximum_candidates,
    metric_bev_crop,
    metric_polar_crop,
)
from ..geometry import BEVGeometry
from .backbones import CausalConvLSTMBEV
from .e3_experts import GGSRREExpert, LTGEExpert, _low_threshold_polar_candidates
from .e7_experts import TECSEchoCandidateSelector
from .e9_pbm_hbr import (
    PBMHBRStage1CandidateReranker,
    PBMHBRStage2CandidateReranker,
    PBMHBRStage2RDCandidateReranker,
    fixed_backbone_window,
)
from .heterogeneous_experts import CLOREXpert, _ROIEncoder, _positive_diagonal_covariance, _zero_linear


class _FrozenConvLSTMExpert(nn.Module):
    """Common frozen CPB-ConvLSTM observation contract."""

    def __init__(self, *, logit_cap: float) -> None:
        super().__init__()
        if logit_cap <= 0.0:
            raise ValueError("logit_cap must be positive")
        self.geometry = BEVGeometry()
        self.logit_cap = float(logit_cap)
        self.backbone = CausalConvLSTMBEV()
        self._freeze_backbone()

    def _freeze_backbone(self) -> None:
        self.backbone.requires_grad_(False)
        self.backbone.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        self.backbone.eval()
        return self

    def load_base_checkpoint(self, checkpoint_path: str | Path) -> str:
        path = Path(checkpoint_path)
        payload = torch.load(path, map_location="cpu", weights_only=False)
        model_name = payload.get("model")
        if model_name not in {None, "convlstm"}:
            raise ValueError(
                "ConvLSTM-transfer experts require a canonical 'convlstm' checkpoint, "
                f"not {model_name!r}."
            )
        self.backbone.load_state_dict(payload.get("model_state", payload), strict=True)
        self._freeze_backbone()
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        yield from (parameter for parameter in self.expert.parameters() if parameter.requires_grad)

    def _base_observation(self, radar: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Current polar feature plus genuine temporal ConvLSTM BEV state."""
        with torch.no_grad():
            base_output = self.backbone(radar)
            base_logits = base_output["logits"]
            shared_feature = base_output["shared_feature"]
            polar_feature = self.backbone.encoder(radar[:, -1])
            previous_logits = self.backbone(causal_previous_window(radar))["logits"]
            base_xy_m, _ = decode_peak_xy(base_logits, self.geometry)
            previous_xy_m, _ = decode_peak_xy(previous_logits, self.geometry)
        return polar_feature, shared_feature, base_logits, previous_logits, torch.cat((base_xy_m, previous_xy_m), dim=1)


class ConvLSTMHeterogeneousExpertBEV(_FrozenConvLSTMExpert):
    """CLOR, transferred without changing its local temporal-refinement head."""

    def __init__(self, expert_kind: Literal["clor"] = "clor", logit_cap: float = 3.0, candidate_count: int = 4) -> None:
        if expert_kind != "clor":
            raise ValueError("ConvLSTM transfer currently supports CLOR only in the heterogeneous family")
        super().__init__(logit_cap=logit_cap)
        self.expert_kind = expert_kind
        self.candidate_count = int(candidate_count)
        self.expert = CLOREXpert(self.geometry)

    def expert_state_dict(self) -> dict[str, object]:
        return {"expert_kind": self.expert_kind, "logit_cap": self.logit_cap, "expert": self.expert.state_dict()}

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        polar, shared, base_logits, _, peaks = self._base_observation(radar)
        base_xy_m, previous_xy_m = peaks[:, :2], peaks[:, 2:]
        output = self.expert(polar, shared, radar, base_logits, base_xy_m, previous_xy_m)
        delta = output["delta_bev_logit"].clamp(-self.logit_cap, self.logit_cap)
        acceptance = torch.sigmoid(output["acceptance_logit"])
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "acceptance_logit": output["acceptance_logit"],
            "covariance": output["covariance"],
            "causal_state": output["causal_state"],
            "proposal_xy_m": output["proposal_xy_m"],
            "base_peak_xy_m": base_xy_m,
            "previous_peak_xy_m": previous_xy_m,
            "shared_feature": shared,
            **{key: value for key, value in output.items() if key not in {"delta_bev_logit", "acceptance_logit", "covariance", "causal_state", "proposal_xy_m"}},
        }


class ConvLSTME3RouteExpertBEV(_FrozenConvLSTMExpert):
    """LTGE and GG-SRRE heads on frozen CPB-ConvLSTM features."""

    def __init__(self, expert_kind: Literal["ltge", "gg_srre"], logit_cap: float = 3.0, candidate_count: int = 6) -> None:
        if expert_kind not in {"ltge", "gg_srre"}:
            raise ValueError("ConvLSTM E3 transfer supports only LTGE or GG-SRRE")
        super().__init__(logit_cap=logit_cap)
        self.expert_kind = expert_kind
        self.expert: nn.Module = LTGEExpert(self.geometry, candidate_count=candidate_count) if expert_kind == "ltge" else GGSRREExpert(self.geometry)

    def set_training_phase(self, phase: str) -> None:
        if self.expert_kind != "gg_srre":
            if phase != "joint":
                raise ValueError("LTGE supports joint training only")
            return
        assert isinstance(self.expert, GGSRREExpert)
        self.expert.set_training_phase(phase)

    def expert_state_dict(self) -> dict[str, object]:
        phase = self.expert.training_phase if isinstance(self.expert, GGSRREExpert) else "joint"
        return {"expert_kind": self.expert_kind, "logit_cap": self.logit_cap, "training_phase": phase, "expert": self.expert.state_dict()}

    def load_expert_checkpoint(self, checkpoint_path: str | Path) -> None:
        state = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=False).get("expert_state")
        if not isinstance(state, dict) or state.get("expert_kind") != self.expert_kind:
            raise ValueError("expert checkpoint kind does not match")
        self.expert.load_state_dict(state["expert"], strict=True)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        polar, shared, base_logits, _, peaks = self._base_observation(radar)
        base_xy_m, previous_xy_m = peaks[:, :2], peaks[:, 2:]
        output = self.expert(polar, shared, radar, base_logits, base_xy_m, previous_xy_m)
        delta = output["delta_bev_logit"].clamp(-self.logit_cap, self.logit_cap)
        acceptance = output.get("acceptance_override")
        if acceptance is None:
            acceptance = torch.sigmoid(output["acceptance_logit"])
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "acceptance_logit": output["acceptance_logit"],
            "covariance": output["covariance"],
            "causal_state": output["causal_state"],
            "proposal_xy_m": output["proposal_xy_m"],
            "base_peak_xy_m": base_xy_m,
            "previous_peak_xy_m": previous_xy_m,
            "shared_feature": shared,
            **{key: value for key, value in output.items() if key not in {"delta_bev_logit", "acceptance_logit", "acceptance_override", "covariance", "causal_state", "proposal_xy_m"}},
        }


class ConvLSTMTECSEchoExpertBEV(_FrozenConvLSTMExpert):
    """The audited TECS candidate set, fed by the ConvLSTM interface."""

    def __init__(self, expert_kind: str = "tecs", logit_cap: float = 3.5, candidate_count: int = 10, force_acceptance: bool = False, acceptance_temperature: float = 1.0, acceptance_bias: float = 0.0, residual_scale: float = 1.0) -> None:
        if expert_kind != "tecs" or candidate_count != TECSEchoCandidateSelector.candidate_count:
            raise ValueError("TECS requires its fixed 10-candidate contract")
        super().__init__(logit_cap=logit_cap)
        self.expert_kind = expert_kind
        self.force_acceptance = bool(force_acceptance)
        self.acceptance_temperature = float(acceptance_temperature)
        self.acceptance_bias = float(acceptance_bias)
        self.residual_scale = float(residual_scale)
        self.expert = TECSEchoCandidateSelector(self.geometry)

    def expert_state_dict(self) -> dict[str, object]:
        return {"expert_kind": self.expert_kind, "logit_cap": self.logit_cap, "force_acceptance": self.force_acceptance, "acceptance_temperature": self.acceptance_temperature, "acceptance_bias": self.acceptance_bias, "residual_scale": self.residual_scale, "expert": self.expert.state_dict()}

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        self.backbone.eval()
        polar, shared, base_logits, _, peaks = self._base_observation(radar)
        base_xy_m, previous_xy_m = peaks[:, :2], peaks[:, 2:]
        output = self.expert(polar, shared, radar, base_logits, base_xy_m, previous_xy_m)
        delta = (self.residual_scale * output["delta_bev_logit"]).clamp(-self.logit_cap, self.logit_cap)
        acceptance_logit = output["acceptance_logit"].float()
        acceptance = torch.ones_like(acceptance_logit) if self.force_acceptance else torch.sigmoid(self.acceptance_temperature * acceptance_logit + self.acceptance_bias)
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "acceptance_logit": output["acceptance_logit"],
            "covariance": output["covariance"],
            "causal_state": output["causal_state"],
            "proposal_xy_m": output["proposal_xy_m"],
            "base_peak_xy_m": base_xy_m,
            "previous_peak_xy_m": previous_xy_m,
            "shared_feature": shared,
            **{key: value for key, value in output.items() if key not in {"delta_bev_logit", "acceptance_logit", "covariance", "causal_state", "proposal_xy_m"}},
        }


class ConvLSTMPBMHBRStage1BEV(_FrozenConvLSTMExpert):
    """PB-MHBR Stage-1 re-ranker on frozen ConvLSTM features."""

    def __init__(self, logit_cap: float = 3.0, residual_scale: float = 1.0) -> None:
        super().__init__(logit_cap=logit_cap)
        if residual_scale <= 0.0:
            raise ValueError("residual_scale must be positive")
        self.residual_scale = float(residual_scale)
        self.expert = PBMHBRStage1CandidateReranker(self.geometry)

    def expert_state_dict(self) -> dict[str, object]:
        return {"stage": "pb_mhbr_stage1", "logit_cap": self.logit_cap, "residual_scale": self.residual_scale, "expert": self.expert.state_dict()}

    def forward(self, radar: Tensor, *, rd: Tensor | None = None, rd_mti: Tensor | None = None) -> dict[str, Tensor]:
        self.backbone.eval()
        backbone_radar = fixed_backbone_window(radar)
        with torch.no_grad():
            base_output = self.backbone(backbone_radar)
            polar = self.backbone.encoder(backbone_radar[:, -1])
            shared = base_output["shared_feature"]
            base_logits = base_output["logits"]
            previous_logits = self.backbone(causal_previous_window(backbone_radar))["logits"]
        output = self.expert(polar, shared, radar, base_logits, previous_logits, rd=rd, rd_mti=rd_mti)
        delta = (self.residual_scale * output["delta_bev_logit"]).clamp(-self.logit_cap, self.logit_cap)
        acceptance = output["stage1_acceptance"].float()
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "learned_acceptance": torch.sigmoid(output["acceptance_logit"].float()),
            "shared_feature": shared,
            **output,
        }


class ConvLSTMDPBRBEV(_FrozenConvLSTMExpert):
    """DPBR on frozen CPB-ConvLSTM features.

    DPBR keeps the original PB-MHBR contract deliberately narrow: it resolves
    only causal RA candidates.  The optional RD/RD-MTI branch adds a
    candidate-range Doppler-consistency token; it never regresses a coordinate
    directly from RD, which has no azimuth measurement.
    """

    def __init__(self, *, use_rd: bool, logit_cap: float = 3.0, residual_scale: float = 1.0) -> None:
        super().__init__(logit_cap=logit_cap)
        if residual_scale <= 0.0:
            raise ValueError("residual_scale must be positive")
        self.use_rd = bool(use_rd)
        self.residual_scale = float(residual_scale)
        self.expert: nn.Module = (
            PBMHBRStage2RDCandidateReranker(self.geometry)
            if self.use_rd
            else PBMHBRStage2CandidateReranker(self.geometry)
        )

    def expert_state_dict(self) -> dict[str, object]:
        return {
            "expert_kind": "dpbr_rd" if self.use_rd else "dpbr_no_rd",
            "use_rd": self.use_rd,
            "logit_cap": self.logit_cap,
            "residual_scale": self.residual_scale,
            "expert": self.expert.state_dict(),
        }

    def load_expert_checkpoint(self, checkpoint_path: str | Path) -> None:
        state = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=False).get("expert_state")
        expected = "dpbr_rd" if self.use_rd else "dpbr_no_rd"
        if not isinstance(state, dict) or state.get("expert_kind") != expected:
            raise ValueError("DPBR checkpoint kind does not match")
        self.expert.load_state_dict(state["expert"], strict=True)

    def forward(self, radar: Tensor, *, rd: Tensor | None = None, rd_mti: Tensor | None = None) -> dict[str, Tensor]:
        self.backbone.eval()
        backbone_radar = fixed_backbone_window(radar)
        with torch.no_grad():
            base_output = self.backbone(backbone_radar)
            polar = self.backbone.encoder(backbone_radar[:, -1])
            shared = base_output["shared_feature"]
            base_logits = base_output["logits"]
            previous_logits = self.backbone(causal_previous_window(backbone_radar))["logits"]
        if self.use_rd and (rd is None or rd_mti is None):
            raise ValueError("DPBR-RD requires aligned RD and RD-MIT tensors")
        output = self.expert(
            polar,
            shared,
            radar,
            base_logits,
            previous_logits,
            rd=rd,
            rd_mti=rd_mti,
        )
        delta = (self.residual_scale * output["delta_bev_logit"]).clamp(-self.logit_cap, self.logit_cap)
        acceptance = output["stage1_acceptance"].float()
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta,
            "base_logits": base_logits,
            "delta_bev_logit": delta,
            "acceptance": acceptance,
            "learned_acceptance": torch.sigmoid(output["acceptance_logit"].float()),
            "shared_feature": shared,
            **output,
        }


class ConvLSTMCBGARBEV(_FrozenConvLSTMExpert):
    """Causal Branch-Graph Association Refiner on frozen CPB-ConvLSTM.

    The refiner uses RA/RA-MTI only.  It creates candidates in each of the
    last eight causal frames, scores links between physically reachable
    candidates, and decodes the highest-scoring path.  It is intentionally a
    candidate selector rather than a free coordinate regressor.
    """

    causal_steps = 8
    backbone_clip_length = 16
    bev_candidate_count = 6
    polar_candidate_count = 6
    candidate_count = bev_candidate_count + polar_candidate_count
    edge_radius_m = 0.75
    # Frozen historical windows are evaluation-only.  This micro-batch only
    # bounds inference memory; it cannot alter candidate values or gradients.
    frozen_backbone_micro_batch = 4

    def __init__(self, logit_cap: float = 3.0, residual_scale: float = 1.0) -> None:
        super().__init__(logit_cap=logit_cap)
        if residual_scale <= 0.0:
            raise ValueError("residual_scale must be positive")
        self.residual_scale = float(residual_scale)
        self.polar_encoder = _ROIEncoder(48, 24)
        self.raw_encoder = _ROIEncoder(2, 20)
        self.bev_encoder = _ROIEncoder(128, 24)
        self.type_embedding = nn.Embedding(2, 6)
        self.node_project = nn.Sequential(
            nn.Linear(24 + 20 + 24 + 6 + 3, 64),
            nn.SiLU(inplace=True),
            nn.Linear(64, 64),
            nn.SiLU(inplace=True),
        )
        self.unary_head = _zero_linear(nn.Linear(64, 1))
        self.edge_head = nn.Sequential(
            nn.Linear(64 + 64 + 2 + 1 + 1, 64),
            nn.SiLU(inplace=True),
            _zero_linear(nn.Linear(64, 1)),
        )
        self.state_head = nn.Sequential(
            nn.Linear(64 + 4, 64),
            nn.SiLU(inplace=True),
            nn.Linear(64, 48),
            nn.SiLU(inplace=True),
        )
        self.scale_head = _zero_linear(nn.Linear(48, 1))
        self.acceptance_head = _zero_linear(nn.Linear(48, 1))
        self.covariance_head = nn.Linear(48, 2)

    def expert_parameters(self) -> Iterator[nn.Parameter]:
        """Expose only CBGAR parameters; the CPB-ConvLSTM stays frozen."""
        yield from (
            parameter
            for name, parameter in self.named_parameters()
            if not name.startswith("backbone.") and parameter.requires_grad
        )

    def expert_state_dict(self) -> dict[str, object]:
        return {
            "expert_kind": "cbgar_ra_ra_mti",
            "causal_steps": self.causal_steps,
            "backbone_clip_length": self.backbone_clip_length,
            "bev_candidate_count": self.bev_candidate_count,
            "polar_candidate_count": self.polar_candidate_count,
            "edge_radius_m": self.edge_radius_m,
            "frozen_backbone_micro_batch": self.frozen_backbone_micro_batch,
            "logit_cap": self.logit_cap,
            "residual_scale": self.residual_scale,
            "expert": {
                "polar_encoder": self.polar_encoder.state_dict(),
                "raw_encoder": self.raw_encoder.state_dict(),
                "bev_encoder": self.bev_encoder.state_dict(),
                "type_embedding": self.type_embedding.state_dict(),
                "node_project": self.node_project.state_dict(),
                "unary_head": self.unary_head.state_dict(),
                "edge_head": self.edge_head.state_dict(),
                "state_head": self.state_head.state_dict(),
                "scale_head": self.scale_head.state_dict(),
                "acceptance_head": self.acceptance_head.state_dict(),
                "covariance_head": self.covariance_head.state_dict(),
            },
        }

    def load_expert_checkpoint(self, checkpoint_path: str | Path) -> None:
        state = torch.load(Path(checkpoint_path), map_location="cpu", weights_only=False).get("expert_state")
        if not isinstance(state, dict) or state.get("expert_kind") != "cbgar_ra_ra_mti":
            raise ValueError("CBGAR checkpoint kind does not match")
        expert_state = state["expert"]
        for name in (
            "polar_encoder", "raw_encoder", "bev_encoder", "type_embedding", "node_project",
            "unary_head", "edge_head", "state_head", "scale_head", "acceptance_head", "covariance_head",
        ):
            getattr(self, name).load_state_dict(expert_state[name], strict=True)

    def _candidate_crops(self, feature: Tensor, candidates_xy_m: Tensor, cropper, span_m: float, output_size: int) -> Tensor:
        batch, count, _ = candidates_xy_m.shape
        repeated = feature.repeat_interleave(count, dim=0)
        crop = cropper(repeated, candidates_xy_m.reshape(batch * count, 2), self.geometry, span_m, output_size)
        return crop.reshape(batch, count, *crop.shape[1:])

    def _frame_candidates(self, radar_window: Tensor) -> tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Return candidates and frozen feature maps for one causal terminal frame."""
        with torch.no_grad():
            base_output = self.backbone(radar_window)
            base_logits = base_output["logits"]
            shared = base_output["shared_feature"]
            polar = self.backbone.encoder(radar_window[:, -1])
        bev_xy, bev_score = local_maximum_candidates(base_logits, self.bev_candidate_count, self.geometry)
        polar_xy, polar_score = _low_threshold_polar_candidates(radar_window, self.polar_candidate_count, self.geometry)
        polar_xy, polar_score = polar_xy[:, -1], polar_score[:, -1]
        candidates = torch.cat((bev_xy, polar_xy), dim=1)
        source_scores = torch.cat((bev_score, polar_score), dim=1)
        type_ids = torch.cat(
            (
                torch.zeros(self.bev_candidate_count, dtype=torch.long, device=radar_window.device),
                torch.ones(self.polar_candidate_count, dtype=torch.long, device=radar_window.device),
            )
        ).expand(radar_window.shape[0], -1)
        return candidates, source_scores, type_ids, polar, shared, base_logits

    def _node_tokens(
        self,
        radar_window: Tensor,
        candidates: Tensor,
        source_scores: Tensor,
        type_ids: Tensor,
        polar_feature: Tensor,
        shared_feature: Tensor,
    ) -> Tensor:
        batch, count, _ = candidates.shape
        polar_crop = self._candidate_crops(polar_feature, candidates, metric_polar_crop, 0.90, 9)
        raw_crop = self._candidate_crops(radar_window[:, -1], candidates, metric_polar_crop, 0.90, 9)
        bev_crop = self._candidate_crops(shared_feature, candidates, metric_bev_crop, 1.50, 9)
        polar_embedding = self.polar_encoder(polar_crop.reshape(batch * count, *polar_crop.shape[2:])).reshape(batch, count, -1)
        raw_embedding = self.raw_encoder(raw_crop.reshape(batch * count, *raw_crop.shape[2:])).reshape(batch, count, -1)
        bev_embedding = self.bev_encoder(bev_crop.reshape(batch * count, *bev_crop.shape[2:])).reshape(batch, count, -1)
        geometry = torch.cat(
            (
                candidates / torch.tensor((10.0, 23.4), device=candidates.device, dtype=candidates.dtype),
                source_scores[:, :, None] / 4.0,
            ),
            dim=-1,
        )
        return self.node_project(
            torch.cat(
                (polar_embedding, raw_embedding, bev_embedding, self.type_embedding(type_ids), geometry),
                dim=-1,
            )
        )

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        if radar.ndim != 5:
            raise ValueError("radar must be [batch,time,channels,height,width]")
        required = self.backbone_clip_length + self.causal_steps - 1
        if radar.shape[1] < required:
            raise ValueError(f"CBGAR requires {required} causal frames, got {radar.shape[1]}")
        self.backbone.eval()
        history = radar[:, -required:]
        windows = torch.stack(
            [
                history[:, terminal - self.backbone_clip_length + 1 : terminal + 1]
                for terminal in range(self.backbone_clip_length - 1, required)
            ],
            dim=1,
        )
        batch = windows.shape[0]
        flat_windows = windows.reshape(batch * self.causal_steps, *windows.shape[2:]).contiguous()
        # The frozen backbone sees exactly the same eight causal windows as the
        # loop version.  Flattening only eliminates Python-level launch gaps.
        # Large flattened causal batches exceed the shared-GPU memory budget.
        # Chunking frozen inference is mathematically identical because every
        # historical terminal window is evaluated independently with no gradient.
        frozen_chunks = [
            self._frame_candidates(chunk)
            for chunk in flat_windows.split(self.frozen_backbone_micro_batch, dim=0)
        ]
        flat_candidates = torch.cat([item[0] for item in frozen_chunks], dim=0)
        flat_source_scores = torch.cat([item[1] for item in frozen_chunks], dim=0)
        flat_type_ids = torch.cat([item[2] for item in frozen_chunks], dim=0)
        flat_polar = torch.cat([item[3] for item in frozen_chunks], dim=0)
        flat_shared = torch.cat([item[4] for item in frozen_chunks], dim=0)
        flat_base_logits = torch.cat([item[5] for item in frozen_chunks], dim=0)
        flat_nodes = self._node_tokens(
            flat_windows,
            flat_candidates,
            flat_source_scores,
            flat_type_ids,
            flat_polar,
            flat_shared,
        )
        nodes = flat_nodes.reshape(batch, self.causal_steps, self.candidate_count, -1)
        candidate_xy = flat_candidates.reshape(batch, self.causal_steps, self.candidate_count, 2)
        source_scores = flat_source_scores.reshape(batch, self.causal_steps, self.candidate_count)
        base_logits = flat_base_logits.reshape(
            batch,
            self.causal_steps,
            *flat_base_logits.shape[1:],
        )[:, -1]
        unary = self.unary_head(nodes).squeeze(-1)
        path_score = unary[:, 0]
        parent_history: list[Tensor] = []
        for step in range(1, self.causal_steps):
            previous_nodes = nodes[:, step - 1]
            current_nodes = nodes[:, step]
            previous_xy = candidate_xy[:, step - 1]
            current_xy = candidate_xy[:, step]
            displacement = current_xy[:, None] - previous_xy[:, :, None]
            distance = displacement.norm(dim=-1, keepdim=True)
            source_delta = source_scores[:, step, None] - source_scores[:, step - 1, :, None]
            pair = torch.cat(
                (
                    previous_nodes[:, :, None].expand(-1, -1, self.candidate_count, -1),
                    current_nodes[:, None].expand(-1, self.candidate_count, -1, -1),
                    displacement / self.edge_radius_m,
                    distance / self.edge_radius_m,
                    source_delta[:, :, :, None] / 4.0,
                ),
                dim=-1,
            )
            edge = self.edge_head(pair).squeeze(-1)
            edge = edge.masked_fill(distance.squeeze(-1) > self.edge_radius_m, -12.0)
            predecessor_score, predecessor = (path_score[:, :, None] + edge).max(dim=1)
            path_score = unary[:, step] + predecessor_score
            parent_history.append(predecessor)
        selector_logits = path_score
        mixture = torch.softmax(selector_logits, dim=1)
        selected_index = mixture.argmax(dim=1)
        hard = functional.one_hot(selected_index, num_classes=self.candidate_count).to(dtype=mixture.dtype)
        straight_through = hard + mixture - mixture.detach()
        current_candidates = candidate_xy[:, -1]
        proposal_xy_m = (straight_through[:, :, None] * current_candidates).sum(dim=1)
        base_xy_m = current_candidates[:, 0]
        previous_base_xy_m = candidate_xy[:, -2, 0]
        selected_node = (mixture[:, :, None] * nodes[:, -1]).sum(dim=1)
        top_two = selector_logits.topk(k=2, dim=1).values
        global_health = torch.stack(
            (
                history[:, -1].mean(dim=(1, 2, 3)),
                history[:, -1].std(dim=(1, 2, 3), unbiased=False),
                top_two[:, 0] - top_two[:, 1],
                (base_xy_m - previous_base_xy_m).norm(dim=1),
            ),
            dim=1,
        )
        state = self.state_head(torch.cat((selected_node, global_health), dim=1))
        strength = 3.0 * torch.tanh(self.scale_head(state))
        nonbase_soft = mixture[:, 1:].sum(dim=1, keepdim=True)
        nonbase_hard = (selected_index > 0).to(mixture.dtype)[:, None]
        acceptance = nonbase_hard + nonbase_soft - nonbase_soft.detach()
        return {
            "logits": base_logits + acceptance[:, :, None, None] * gaussian_logit_delta(base_xy_m, proposal_xy_m, strength, self.geometry, sigma_m=0.22).clamp(-self.logit_cap, self.logit_cap),
            "base_logits": base_logits,
            "delta_bev_logit": gaussian_logit_delta(base_xy_m, proposal_xy_m, strength, self.geometry, sigma_m=0.22).clamp(-self.logit_cap, self.logit_cap),
            "acceptance": acceptance,
            "acceptance_logit": self.acceptance_head(state),
            "covariance": _positive_diagonal_covariance(self.covariance_head(state)),
            "causal_state": state,
            "proposal_xy_m": proposal_xy_m,
            "candidate_xy_m": current_candidates,
            "candidate_selector_logits": selector_logits,
            "candidate_mixture": mixture,
            "selected_candidate_index": selected_index,
            "base_peak_xy_m": base_xy_m,
            "previous_peak_xy_m": previous_base_xy_m,
            "candidate_source_scores": source_scores[:, -1],
            "candidate_path_parent": torch.stack(parent_history, dim=1),
        }
