from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor
from torch.nn import functional as functional

from .losses import QualityAwareBEVLoss


@dataclass(frozen=True)
class E8LossOutput:
    total: Tensor
    localization: Tensor
    selector: Tensor
    gate: Tensor
    correction_rate: Tensor
    safe_target_accuracy: Tensor
    correction_selector_recall: Tensor
    correction_gate_mean: Tensor


def e8_loss_terms(
    output: dict[str, Tensor],
    target_xy_m: Tensor,
    sample_weight: Tensor,
    identity_mask: Tensor,
    criterion: QualityAwareBEVLoss,
    correction_radius_m: float = 0.30,
    selector_weight: float = 1.0,
    gate_weight: float = 0.55,
    proposal_weight: float = 0.30,
    positive_weight: float = 12.0,
) -> E8LossOutput:
    """Supervise only safe, observable base-failure corrections.

    A positive is present only when the frozen peak is outside 0.30 m and at
    least one local measured candidate is within 0.30 m.  All other frames,
    including an already-correct base, explicitly target the base candidate and
    a closed correction gate.  GT therefore teaches a training label, never a
    runtime input or candidate coordinate.
    """
    identity_mask = identity_mask.bool()
    target_mask = ~identity_mask
    zero = output["logits"].new_zeros(())
    if not bool(target_mask.any()):
        # A shuffled negative-only mini-batch is common with a concatenated
        # route/identity dataset.  It must still teach a closed gate and the
        # frozen base candidate, rather than returning a detached zero loss.
        selector = functional.cross_entropy(
            output["candidate_selector_logits"].float(),
            torch.zeros(output["candidate_selector_logits"].shape[0], dtype=torch.long, device=output["logits"].device),
        )
        gate = functional.binary_cross_entropy_with_logits(
            output["acceptance_logit"][:, 0].float(),
            torch.zeros(output["acceptance_logit"].shape[0], dtype=torch.float32, device=output["logits"].device),
        )
        return E8LossOutput(total=0.25 * (selector + gate), localization=zero, selector=selector.detach(), gate=gate.detach(), correction_rate=zero, safe_target_accuracy=zero, correction_selector_recall=zero, correction_gate_mean=zero)
    candidates = output["candidate_xy_m"][target_mask]
    target = target_xy_m[target_mask]
    candidate_error = (candidates - target[:, None]).norm(dim=-1)
    base_error = candidate_error[:, 0]
    nonbase_error, best_nonbase_relative = candidate_error[:, 1:].min(dim=1)
    correction_target = (base_error > correction_radius_m) & (nonbase_error <= correction_radius_m)
    selector_target = torch.where(correction_target, best_nonbase_relative + 1, torch.zeros_like(best_nonbase_relative))
    weights = torch.where(correction_target, torch.full_like(base_error, positive_weight), torch.ones_like(base_error))
    selector_per_item = functional.cross_entropy(output["candidate_selector_logits"][target_mask].float(), selector_target, reduction="none")
    selector = (selector_per_item * weights).sum() / weights.sum().clamp_min(1e-6)
    gate = functional.binary_cross_entropy_with_logits(
        output["acceptance_logit"][target_mask, 0].float(), correction_target.float(), pos_weight=torch.tensor(positive_weight, device=target.device)
    )
    if bool(identity_mask.any()):
        identity_selector = functional.cross_entropy(
            output["candidate_selector_logits"][identity_mask].float(),
            torch.zeros(int(identity_mask.sum().item()), dtype=torch.long, device=target.device),
        )
        identity_gate = functional.binary_cross_entropy_with_logits(
            output["acceptance_logit"][identity_mask, 0].float(),
            torch.zeros(int(identity_mask.sum().item()), dtype=torch.float32, device=target.device),
        )
        # Misrouted samples explicitly learn the base candidate and a closed
        # gate, rather than merely being absent from the specialist loss.
        selector = selector + 0.25 * identity_selector
        gate = gate + 0.25 * identity_gate
    proposal = functional.smooth_l1_loss(output["proposal_xy_m"][target_mask], candidates[torch.arange(candidates.shape[0], device=target.device), selector_target])
    localization = criterion(output["logits"][target_mask], target, sample_weight[target_mask]).total
    selected = output["selected_candidate_index"][target_mask]
    safe_target_accuracy = (selected == selector_target).float().mean()
    correction_rate = correction_target.float().mean()
    if bool(correction_target.any()):
        correction_selector_recall = (selected[correction_target] == selector_target[correction_target]).float().mean()
        correction_gate_mean = torch.sigmoid(output["acceptance_logit"][target_mask, 0][correction_target]).mean()
    else:
        correction_selector_recall = zero
        correction_gate_mean = zero
    return E8LossOutput(
        total=localization + selector_weight * selector + gate_weight * gate + proposal_weight * proposal,
        localization=localization.detach(), selector=selector.detach(), gate=gate.detach(), correction_rate=correction_rate.detach(), safe_target_accuracy=safe_target_accuracy.detach(), correction_selector_recall=correction_selector_recall.detach(), correction_gate_mean=correction_gate_mean.detach(),
    )
