from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset

from .geometry import BEVGeometry


LCORRIDOR_TRAIN_SEQUENCES = (
    "seq_001",
    "seq_002",
    "seq_004",
    "seq_007",
    "seq_008",
    "seq_010",
    "seq_013",
    "seq_014",
    "seq_016",
    "seq_017",
    "seq_019",
)
LCORRIDOR_EVAL_SEQUENCES = (
    "seq_003",
    "seq_006",
    "seq_009",
    "seq_012",
    "seq_015",
    "seq_018",
    "seq_021",
)
LCORRIDOR_LOCKED_TEST_SEQUENCES = (
    "seq_005",
    "seq_011",
    "seq_020",
)
FINAL_RIS_CONDITION = "directeq_lcorridor9_v6_blend085_{sequence}"
FINAL_RIS_FEATURE_DIRECTORY = "ReceivedADCStandardFeaturesV1"
HARD_RIS_CONDITION = "hard_ris_final_{sequence}"
HARD_RIS_FEATURE_DIRECTORY = "StandardFeaturesV1"
HARDER_RIS_CONDITION = "harder_ris_final_{sequence}"
HARDER_RIS_FEATURE_DIRECTORY = "StandardFeaturesV1"
HARDER_RIS_V2_CONDITION = "harder_ris_v2_final_{sequence}"
HARDER_RIS_V2_FEATURE_DIRECTORY = "StandardFeaturesV1"
EMPTYCAL_RIS_CONDITION = "emptycal_ris_v1_{sequence}"
EMPTYCAL_RIS_V2_CONDITION = "emptycal_ris_v2_{sequence}"
EMPTYCAL_RIS_V2_MODERATE_CONDITION = "emptycal_ris_v2_moderate_{sequence}"
EMPTYCAL_RIS_V3_REBUILT_CONDITION = "emptycal_ris_v3_rebuilt_{sequence}"
EMPTYCAL_RIS_V3_THREE_TIER_CONDITION = "emptycal_ris_v3_three_tier_{sequence}"
STAGEB_REALISTIC_V8_CONDITION = "stageb_realistic_scatter_v8_{sequence}"
EMPTYCAL_RIS_FEATURE_DIRECTORY = "StandardFeaturesV1"
LCORRIDOR_RIS_INPUT_DOMAINS = (
    "final_v6",
    "hard_v3",
    "harder_v1",
    "harder_v2",
    "emptycal_v1",
    "emptycal_v2",
    "emptycal_v2_moderate",
    "emptycal_v3_rebuilt",
    "emptycal_v3_three_tier",
    "stageb_realistic_v8",
)
RIS_VIEWS = {
    "RA": (128, 128),
    "RA-MIT": (128, 128),
    "RD": (128, 256),
    "RD-MIT": (128, 256),
    "AD": (128, 256),
}


def lcorridor_ris_feature_root(
    data_root: Path,
    sequence: str,
    *,
    input_domain: str = "final_v6",
) -> Path:
    if input_domain == "final_v6":
        return (
            Path(data_root)
            / sequence
            / "RadarRIS"
            / FINAL_RIS_CONDITION.format(sequence=sequence)
            / FINAL_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "hard_v3":
        return (
            Path(data_root)
            / sequence
            / HARD_RIS_CONDITION.format(sequence=sequence)
            / HARD_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "harder_v1":
        return (
            Path(data_root)
            / sequence
            / HARDER_RIS_CONDITION.format(sequence=sequence)
            / HARDER_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "harder_v2":
        return (
            Path(data_root)
            / sequence
            / HARDER_RIS_V2_CONDITION.format(sequence=sequence)
            / HARDER_RIS_V2_FEATURE_DIRECTORY
        )
    if input_domain == "emptycal_v1":
        return (
            Path(data_root)
            / sequence
            / EMPTYCAL_RIS_CONDITION.format(sequence=sequence)
            / EMPTYCAL_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "emptycal_v2":
        return (
            Path(data_root)
            / sequence
            / EMPTYCAL_RIS_V2_CONDITION.format(sequence=sequence)
            / EMPTYCAL_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "emptycal_v2_moderate":
        return (
            Path(data_root)
            / sequence
            / EMPTYCAL_RIS_V2_MODERATE_CONDITION.format(sequence=sequence)
            / EMPTYCAL_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "emptycal_v3_rebuilt":
        return (
            Path(data_root)
            / sequence
            / EMPTYCAL_RIS_V3_REBUILT_CONDITION.format(sequence=sequence)
            / EMPTYCAL_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "emptycal_v3_three_tier":
        return (
            Path(data_root)
            / sequence
            / EMPTYCAL_RIS_V3_THREE_TIER_CONDITION.format(sequence=sequence)
            / EMPTYCAL_RIS_FEATURE_DIRECTORY
        )
    if input_domain == "stageb_realistic_v8":
        return (
            Path(data_root)
            / sequence
            / STAGEB_REALISTIC_V8_CONDITION.format(sequence=sequence)
            / EMPTYCAL_RIS_FEATURE_DIRECTORY
        )
    raise ValueError(
        f"Unsupported L-corridor RIS input domain {input_domain!r}; "
        f"expected one of {LCORRIDOR_RIS_INPUT_DOMAINS}"
    )


def _as_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes"}


def _quadratic_offset(left: Tensor, center: Tensor, right: Tensor) -> Tensor:
    denominator = left - 2.0 * center + right
    valid = denominator.abs() > torch.finfo(denominator.dtype).eps
    offset = torch.where(valid, 0.5 * (left - right) / denominator, torch.zeros_like(center))
    return offset.clamp(-0.5, 0.5)


def _gather_2d(values: Tensor, row: Tensor, col: Tensor) -> Tensor:
    batch, frames, height, width = values.shape
    flat = values.reshape(batch, frames, height * width)
    index = (row * width + col).unsqueeze(-1)
    return flat.gather(2, index).squeeze(-1)


def extract_ris_peak_sequence(
    radar: Tensor,
    geometry: BEVGeometry | None = None,
) -> tuple[Tensor, Tensor]:
    """Extract causal, label-free sub-bin RA-MTI peaks for every input frame.

    Returns metric peak coordinates ``[B,T,2]`` and three quality values per
    frame: peak strength, top-1/top-2 margin, and peak-to-map-mean contrast.
    """

    geometry = geometry or BEVGeometry()
    if radar.ndim != 5 or radar.shape[2:] != (
        2,
        geometry.range_bins,
        geometry.azimuth_bins,
    ):
        raise ValueError("radar must be [batch,frames,2,128,128]")
    ra_mti = radar[:, :, 1].float()
    batch, frames, height, width = ra_mti.shape
    flattened = ra_mti.reshape(batch, frames, height * width)
    top_values, top_indices = flattened.topk(2, dim=-1)
    peak_index = top_indices[..., 0]
    row = torch.div(peak_index, width, rounding_mode="floor")
    col = peak_index.remainder(width)

    row_low = (row - 1).clamp(0, height - 1)
    row_high = (row + 1).clamp(0, height - 1)
    col_low = (col - 1).clamp(0, width - 1)
    col_high = (col + 1).clamp(0, width - 1)
    center = _gather_2d(ra_mti, row, col)
    row_offset = _quadratic_offset(
        _gather_2d(ra_mti, row_low, col),
        center,
        _gather_2d(ra_mti, row_high, col),
    )
    col_offset = _quadratic_offset(
        _gather_2d(ra_mti, row, col_low),
        center,
        _gather_2d(ra_mti, row, col_high),
    )
    row_offset = torch.where((row > 0) & (row < height - 1), row_offset, torch.zeros_like(row_offset))
    col_offset = torch.where((col > 0) & (col < width - 1), col_offset, torch.zeros_like(col_offset))

    range_index = row.float() + row_offset
    azimuth_index = col.float() + col_offset
    range_m = range_index * geometry.range_resolution_m
    sin_azimuth = (azimuth_index / (geometry.azimuth_bins / 2.0) - 1.0).clamp(-1.0, 1.0)
    x_m = range_m * sin_azimuth
    y_m = torch.sqrt((range_m.square() - x_m.square()).clamp_min(0.0))
    xy_m = torch.stack((x_m, y_m), dim=-1).to(dtype=radar.dtype)
    quality = torch.stack(
        (
            top_values[..., 0],
            top_values[..., 0] - top_values[..., 1],
            top_values[..., 0] - flattened.mean(dim=-1),
        ),
        dim=-1,
    ).to(dtype=radar.dtype)
    return xy_m, quality


@dataclass(frozen=True)
class LCorridorRISFrame:
    sequence: str
    frame_id: int
    feature_root: Path
    target_xy_m: tuple[float, float]


class LCorridorRISWindowDataset(Dataset[dict[str, Tensor | str]]):
    """Final V6 L-corridor RIS features under the V3 11/7/3 lockbox split.

    This loader intentionally ignores original-radar anomaly flags and never
    reads RGB or depth. The RIS reconstruction has its own validated input
    contract, while supervision comes only from the frozen final BEV track.
    """

    def __init__(
        self,
        data_root: Path,
        manifest_path: Path,
        sequences: Iterable[str],
        *,
        clip_length: int = 16,
        db_center: float = 80.0,
        db_scale: float = 30.0,
        cache_in_memory: bool = False,
        include_aux_views: bool = False,
        expected_frame_count: int = 300,
        input_domain: str = "final_v6",
        condition_prefix: str | None = None,
    ) -> None:
        if clip_length < 1:
            raise ValueError("clip_length must be positive")
        if expected_frame_count < 1:
            raise ValueError("expected_frame_count must be positive")
        self.data_root = Path(data_root)
        self.clip_length = int(clip_length)
        self.db_center = float(db_center)
        self.db_scale = float(db_scale)
        self.cache_in_memory = bool(cache_in_memory)
        self.include_aux_views = bool(include_aux_views)
        self.expected_frame_count = int(expected_frame_count)
        if input_domain not in LCORRIDOR_RIS_INPUT_DOMAINS:
            raise ValueError(
                f"Unsupported L-corridor RIS input domain {input_domain!r}; "
                f"expected one of {LCORRIDOR_RIS_INPUT_DOMAINS}"
            )
        self.input_domain = input_domain
        if condition_prefix is not None and input_domain != "harder_v2":
            raise ValueError("condition_prefix override is only supported for harder_v2")
        self.condition_prefix = condition_prefix
        self._cache: dict[Path, Tensor] = {}
        wanted = {str(sequence) for sequence in sequences}
        if not wanted:
            raise ValueError("at least one L-corridor sequence is required")

        sequence_rows: dict[str, list[LCorridorRISFrame]] = defaultdict(list)
        with Path(manifest_path).open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                sequence = row["sequence"]
                if sequence not in wanted:
                    continue
                if not _as_bool(row["final_bev_label_valid"]):
                    raise ValueError(f"{sequence} frame={row['frame_id']}: final BEV label must be valid")
                sequence_rows[sequence].append(
                    LCorridorRISFrame(
                        sequence=sequence,
                        frame_id=int(row["frame_id"]),
                        feature_root=(
                            self.data_root
                            / sequence
                            / f"{self.condition_prefix}_{sequence}"
                            / HARDER_RIS_V2_FEATURE_DIRECTORY
                            if self.condition_prefix is not None
                            else lcorridor_ris_feature_root(
                                self.data_root,
                                sequence,
                                input_domain=self.input_domain,
                            )
                        ),
                        target_xy_m=(float(row["final_bev_x_m"]), float(row["final_bev_y_m"])),
                    )
                )
        missing = wanted - set(sequence_rows)
        if missing:
            raise ValueError(f"manifest is missing requested L-corridor sequences: {sorted(missing)}")
        self.sequences = {
            sequence: tuple(sorted(rows, key=lambda item: item.frame_id))
            for sequence, rows in sequence_rows.items()
        }
        for sequence, rows in self.sequences.items():
            self._validate_sequence(sequence, rows)
        self.samples = [
            (sequence, position)
            for sequence, rows in sorted(self.sequences.items())
            for position in range(len(rows))
        ]
        if self.cache_in_memory:
            for rows in self.sequences.values():
                for row in rows:
                    self._read(row.feature_root / "RA" / self._frame_name(row.frame_id), RIS_VIEWS["RA"])
                    self._read(row.feature_root / "RA-MIT" / self._frame_name(row.frame_id), RIS_VIEWS["RA-MIT"])
                    if self.include_aux_views:
                        for view in ("RD", "RD-MIT", "AD"):
                            self._read(row.feature_root / view / self._frame_name(row.frame_id), RIS_VIEWS[view])

    @staticmethod
    def _frame_name(frame_id: int) -> str:
        return f"frame_{frame_id:04d}.npy"

    def _validate_sequence(self, sequence: str, rows: tuple[LCorridorRISFrame, ...]) -> None:
        expected_ids = list(range(self.expected_frame_count))
        if len(rows) != self.expected_frame_count or [row.frame_id for row in rows] != expected_ids:
            raise ValueError(f"{sequence}: expected contiguous frames 0..{self.expected_frame_count - 1}")
        root = rows[0].feature_root
        metadata_path = root / "metadata.json"
        if not metadata_path.is_file():
            raise FileNotFoundError(f"{sequence}: missing final RIS metadata: {metadata_path}")
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if self.input_domain == "final_v6":
            valid_processing = (
                metadata.get("processing_version") == "received_ris_adc_standard_features_v1"
            )
        elif self.input_domain == "hard_v3":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "hard_ris_real_background_adc_v3"
                and source_metadata.get("sequence") == sequence
            )
        elif self.input_domain == "harder_v1":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "harder_ris_real_background_adc_v1"
                and source_metadata.get("sequence") == sequence
            )
        elif self.input_domain == "harder_v2":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "harder_ris_real_background_adc_v2"
                and source_metadata.get("sequence") == sequence
            )
        elif self.input_domain == "emptycal_v1":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "emptycal_ris_background_subtracted_adc_v1"
                and source_metadata.get("sequence") == sequence
            )
        elif self.input_domain == "emptycal_v2":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "emptycal_ris_background_subtracted_adc_v2"
                and source_metadata.get("sequence") == sequence
            )
        elif self.input_domain == "emptycal_v2_moderate":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "emptycal_ris_v2_moderate_adc_v1"
                and source_metadata.get("sequence") == sequence
                and source_metadata.get("receiver_label_access") == "none"
                and source_metadata.get("difficulty_profile", {}).get("difficulty_fraction")
                == 0.5
            )
        elif self.input_domain == "emptycal_v3_rebuilt":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "emptycal_ris_background_subtracted_adc_v2"
                and source_metadata.get("sequence") == sequence
            )
        elif self.input_domain == "emptycal_v3_three_tier":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "emptycal_ris_v3_three_tier_adc_v1"
                and source_metadata.get("sequence") == sequence
                and source_metadata.get("receiver_label_access") == "none"
                and source_metadata.get("difficulty_profile", {}).get("tier_counts")
                == {"baseline": 150, "hard": 50, "harder": 50, "extreme": 50}
            )
        elif self.input_domain == "stageb_realistic_v8":
            source_metadata = metadata.get("source_hard_ris_metadata", {})
            realism_calibration = source_metadata.get("realism_calibration", {})
            forbidden_inputs = set(source_metadata.get("model_runtime_forbidden_inputs", ()))
            valid_processing = (
                metadata.get("processing_version") == "radar_feature_folders_v1"
                and source_metadata.get("processing_version")
                == "stage_b_realistic_human_scatter_adc_v8"
                and source_metadata.get("sequence") == sequence
                and realism_calibration.get("parameter_selection_split")
                == "seq022+ train only"
                and realism_calibration.get("retains_or_copies_real_target_patches") is False
                and "generator_audit_not_model_input" in forbidden_inputs
                and "human x/y labels" in forbidden_inputs
                and "future frames" in forbidden_inputs
            )
        else:
            raise AssertionError(f"Unhandled L-corridor RIS input domain: {self.input_domain}")
        if not valid_processing:
            raise ValueError(
                f"{sequence}: unsupported {self.input_domain} RIS processing version"
            )
        if metadata.get("sequence") != sequence or metadata.get("receiver_label_access") != "none":
            raise ValueError(f"{sequence}: final RIS feature contract is not sequence-bound and label-free")
        required_views = ("RA", "RA-MIT", "RD", "RD-MIT", "AD") if self.include_aux_views else ("RA", "RA-MIT")
        for view in required_views:
            if metadata.get("views", {}).get(view, {}).get("shape") != list(RIS_VIEWS[view]):
                raise ValueError(f"{sequence}: {view} metadata shape is invalid")
            paths = sorted((root / view).glob("frame_*.npy"))
            expected_names = [self._frame_name(frame_id) for frame_id in expected_ids]
            if len(paths) != self.expected_frame_count or [path.name for path in paths] != expected_names:
                raise ValueError(f"{sequence}: {view} frames are incomplete or non-contiguous")

    def _history_positions(self, end_position: int) -> list[int]:
        return [
            max(0, end_position - self.clip_length + 1 + offset)
            for offset in range(self.clip_length)
        ]

    def _read(self, path: Path, shape: tuple[int, int]) -> Tensor:
        cached = self._cache.get(path)
        if cached is not None:
            return cached
        values = np.load(path, allow_pickle=False).astype(np.float32, copy=False)
        if values.shape != shape:
            raise ValueError(f"Expected {shape}, got {values.shape} at {path}")
        values = np.nan_to_num(
            values,
            nan=self.db_center,
            posinf=self.db_center + self.db_scale,
            neginf=self.db_center - self.db_scale,
        )
        tensor = torch.from_numpy(np.clip((values - self.db_center) / self.db_scale, -3.0, 3.0))
        if self.cache_in_memory:
            self._cache[path] = tensor
        return tensor

    @property
    def cached_map_count(self) -> int:
        return len(self._cache)

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        sequence, end_position = self.samples[index]
        rows = self.sequences[sequence]
        history = [rows[position] for position in self._history_positions(end_position)]
        target = rows[end_position]
        radar = torch.stack(
            [
                torch.stack(
                    (
                        self._read(row.feature_root / "RA" / self._frame_name(row.frame_id), RIS_VIEWS["RA"]),
                        self._read(
                            row.feature_root / "RA-MIT" / self._frame_name(row.frame_id),
                            RIS_VIEWS["RA-MIT"],
                        ),
                    )
                )
                for row in history
            ]
        )
        item: dict[str, Tensor | str] = {
            "radar": radar,
            "target_xy_m": torch.tensor(target.target_xy_m, dtype=torch.float32),
            "history_target_xy_m": torch.tensor([row.target_xy_m for row in history], dtype=torch.float32),
            "sample_weight": torch.tensor(1.0, dtype=torch.float32),
            "history_frame_ids": torch.tensor([row.frame_id for row in history], dtype=torch.int64),
            "frame_id": torch.tensor(target.frame_id, dtype=torch.int64),
            "sequence": sequence,
        }
        if self.include_aux_views:
            item["rd"] = torch.stack(
                [self._read(row.feature_root / "RD" / self._frame_name(row.frame_id), RIS_VIEWS["RD"]) for row in history]
            )
            item["rd_mti"] = torch.stack(
                [
                    self._read(
                        row.feature_root / "RD-MIT" / self._frame_name(row.frame_id),
                        RIS_VIEWS["RD-MIT"],
                    )
                    for row in history
                ]
            )
            item["ad"] = torch.stack(
                [self._read(row.feature_root / "AD" / self._frame_name(row.frame_id), RIS_VIEWS["AD"]) for row in history]
            )
        return item
