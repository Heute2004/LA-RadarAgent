from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


TRAIN_SPLIT = "Train"
DEV_SPLIT = "Development Val"
TEST_SPLIT = "Locked Test"
EXCLUDED_SPLIT = "Excluded"
ALLOWED_PROPOSAL_SPLITS = {TRAIN_SPLIT, DEV_SPLIT, TEST_SPLIT, EXCLUDED_SPLIT}


def sequence_number(sequence: str) -> int:
    prefix, value = sequence.strip().split("_", maxsplit=1)
    if prefix != "seq" or not value.isdigit():
        raise ValueError(f"invalid sequence name: {sequence!r}")
    return int(value)


def is_lcorridor_sequence(sequence: str) -> bool:
    return 1 <= sequence_number(sequence) <= 21


def _load_proposal(path: Path) -> dict[str, dict[str, str]]:
    records: dict[str, dict[str, str]] = {}
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            sequence = row["序列"].strip()
            split = row["提案split"].strip()
            if split not in ALLOWED_PROPOSAL_SPLITS:
                raise ValueError(f"{sequence}: unsupported proposal split {split!r}")
            if sequence in records:
                raise ValueError(f"duplicate proposal row: {sequence}")
            records[sequence] = row
    if not records:
        raise ValueError("proposal is empty")
    return records


def _route_for_proposal(row: dict[str, str]) -> str:
    category = row.get("当前大类", "")
    route = row.get("当前雷达路由", "").strip()
    if "日间干燥" in category:
        return "outdoor_dry_complex"
    if any(marker in category for marker in ("夜雨", "小雨", "雨后湿地")):
        return "outdoor_wet_return"
    return route


def _read_frame_manifest(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError("frame manifest has no header")
        rows = list(reader)
        return list(reader.fieldnames), rows


def _read_routing_manifest(path: Path) -> list[dict[str, object]]:
    records = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                records.append(json.loads(line))
    return records


def _write_frame_manifest(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_routing_manifest(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_training_manifest(path: Path, scope: str = "base") -> dict[str, int]:
    if scope not in {"base", "lcorridor"}:
        raise ValueError("scope must be 'base' or 'lcorridor'")
    sequence_splits: dict[str, set[str]] = defaultdict(set)
    row_count = 0
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            row_count += 1
            sequence = row["sequence"].strip()
            split = row["split"].strip()
            if split == TEST_SPLIT:
                raise ValueError(f"Locked Test is forbidden in a training manifest: {sequence}")
            if split == EXCLUDED_SPLIT:
                raise ValueError(f"Excluded sequence is forbidden in a training manifest: {sequence}")
            if split not in {TRAIN_SPLIT, DEV_SPLIT}:
                raise ValueError(f"unsupported training split {split!r}: {sequence}")
            if scope == "base" and is_lcorridor_sequence(sequence):
                raise ValueError(f"base protocol forbids L-corridor sequence {sequence}")
            if scope == "lcorridor" and not is_lcorridor_sequence(sequence):
                raise ValueError(f"L-corridor protocol received non-corridor sequence {sequence}")
            sequence_splits[sequence].add(split)
    if row_count == 0:
        raise ValueError("training manifest is empty")
    conflicting = {sequence: splits for sequence, splits in sequence_splits.items() if len(splits) != 1}
    if conflicting:
        raise ValueError(f"sequences span multiple splits: {conflicting}")
    split_counts = Counter(next(iter(splits)) for splits in sequence_splits.values())
    return {split: split_counts.get(split, 0) for split in (TRAIN_SPLIT, DEV_SPLIT)}


def validate_locked_test_manifest(
    path: Path,
    scope: str = "base",
) -> dict[str, int]:
    if scope not in {"base", "lcorridor"}:
        raise ValueError("scope must be 'base' or 'lcorridor'")
    sequences: set[str] = set()
    row_count = 0
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            row_count += 1
            sequence = row["sequence"].strip()
            split = row["split"].strip()
            if split != TEST_SPLIT:
                raise ValueError(
                    "locked-test manifest may contain only Locked Test "
                    f"rows: {sequence} has {split!r}"
                )
            if scope == "base" and is_lcorridor_sequence(sequence):
                raise ValueError(
                    f"base Locked Test forbids L-corridor sequence {sequence}"
                )
            if scope == "lcorridor" and not is_lcorridor_sequence(sequence):
                raise ValueError(
                    "L-corridor Locked Test received non-corridor sequence "
                    f"{sequence}"
                )
            sequences.add(sequence)
    if row_count == 0:
        raise ValueError("locked-test manifest is empty")
    return {TEST_SPLIT: len(sequences)}


def validate_training_routing_manifest(path: Path, scope: str = "base") -> dict[str, int]:
    if scope not in {"base", "lcorridor"}:
        raise ValueError("scope must be 'base' or 'lcorridor'")
    records = _read_routing_manifest(Path(path))
    if not records:
        raise ValueError("training routing manifest is empty")
    sequence_splits: dict[str, set[str]] = defaultdict(set)
    for row in records:
        sequence = str(row["sequence_name"])
        split = str(row["split"])
        if split == TEST_SPLIT:
            raise ValueError(f"Locked Test is forbidden in a training routing manifest: {sequence}")
        if split == EXCLUDED_SPLIT:
            raise ValueError(f"Excluded sequence is forbidden in a training routing manifest: {sequence}")
        if split not in {TRAIN_SPLIT, DEV_SPLIT}:
            raise ValueError(f"unsupported training route split {split!r}: {sequence}")
        if scope == "base" and is_lcorridor_sequence(sequence):
            raise ValueError(f"base routing protocol forbids L-corridor sequence {sequence}")
        if scope == "lcorridor" and not is_lcorridor_sequence(sequence):
            raise ValueError(f"L-corridor routing protocol received non-corridor sequence {sequence}")
        sequence_splits[sequence].add(split)
    conflicting = {sequence: splits for sequence, splits in sequence_splits.items() if len(splits) != 1}
    if conflicting:
        raise ValueError(f"routing sequences span multiple splits: {conflicting}")
    split_counts = Counter(next(iter(splits)) for splits in sequence_splits.values())
    return {split: split_counts.get(split, 0) for split in (TRAIN_SPLIT, DEV_SPLIT)}


def build_lockbox_v3_manifests(
    source_frame_manifest: Path,
    source_routing_manifest: Path,
    proposal_csv: Path,
    output_dir: Path,
) -> dict[str, Path]:
    source_frame_manifest = Path(source_frame_manifest)
    source_routing_manifest = Path(source_routing_manifest)
    proposal_csv = Path(proposal_csv)
    output_dir = Path(output_dir)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"refusing to overwrite non-empty output directory: {output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)

    proposal = _load_proposal(proposal_csv)
    fieldnames, source_frames = _read_frame_manifest(source_frame_manifest)
    source_routes = _read_routing_manifest(source_routing_manifest)
    source_frame_sequences = {row["sequence"] for row in source_frames}
    source_route_sequences = {str(row["sequence_name"]) for row in source_routes}
    missing_frames = set(proposal) - source_frame_sequences
    missing_routes = set(proposal) - source_route_sequences
    if missing_frames:
        raise ValueError(f"proposal sequences missing from frame manifest: {sorted(missing_frames)}")
    if missing_routes:
        raise ValueError(f"proposal sequences missing from routing manifest: {sorted(missing_routes)}")

    frame_groups: dict[str, list[dict[str, str]]] = {
        "base_train_dev": [],
        "base_locked_test": [],
        "lcorridor_train_dev": [],
        "lcorridor_locked_test": [],
    }
    for source_row in source_frames:
        sequence = source_row["sequence"]
        record = proposal.get(sequence)
        if record is None:
            continue
        split = record["提案split"].strip()
        if split == EXCLUDED_SPLIT:
            continue
        row = dict(source_row)
        row["split"] = split
        corridor = is_lcorridor_sequence(sequence)
        if corridor and split in {TRAIN_SPLIT, DEV_SPLIT}:
            frame_groups["lcorridor_train_dev"].append(row)
        elif corridor and split == TEST_SPLIT:
            frame_groups["lcorridor_locked_test"].append(row)
        elif not corridor and split in {TRAIN_SPLIT, DEV_SPLIT}:
            frame_groups["base_train_dev"].append(row)
        elif not corridor and split == TEST_SPLIT:
            frame_groups["base_locked_test"].append(row)

    routing_groups: dict[str, list[dict[str, object]]] = {
        "base_train_dev": [],
        "base_locked_test": [],
        "lcorridor_train_dev": [],
        "lcorridor_locked_test": [],
    }
    for source_row in source_routes:
        sequence = str(source_row["sequence_name"])
        record = proposal.get(sequence)
        if record is None:
            continue
        split = record["提案split"].strip()
        if split == EXCLUDED_SPLIT:
            continue
        row = dict(source_row)
        row["split"] = split
        row["adapter_route"] = _route_for_proposal(record)
        row["m1_routing_version"] = "m1_vlm_routing_lockbox_v3_20260801"
        corridor = is_lcorridor_sequence(sequence)
        if corridor and split in {TRAIN_SPLIT, DEV_SPLIT}:
            routing_groups["lcorridor_train_dev"].append(row)
        elif corridor and split == TEST_SPLIT:
            routing_groups["lcorridor_locked_test"].append(row)
        elif not corridor and split in {TRAIN_SPLIT, DEV_SPLIT}:
            routing_groups["base_train_dev"].append(row)
        elif not corridor and split == TEST_SPLIT:
            routing_groups["base_locked_test"].append(row)

    outputs = {
        "base_train_dev_frame_manifest": output_dir / "m0_base_train_dev_frame_manifest_v3.csv",
        "base_locked_test_frame_manifest": output_dir / "m0_base_locked_test_frame_manifest_v3.csv",
        "base_train_dev_routing_manifest": output_dir / "m1_base_train_dev_routing_manifest_v3.jsonl",
        "base_locked_test_routing_manifest": output_dir / "m1_base_locked_test_routing_manifest_v3.jsonl",
        "lcorridor_train_dev_frame_manifest": output_dir / "m0_lcorridor_train_dev_frame_manifest_v3.csv",
        "lcorridor_locked_test_frame_manifest": output_dir / "m0_lcorridor_locked_test_frame_manifest_v3.csv",
        "lcorridor_train_dev_routing_manifest": output_dir / "m1_lcorridor_train_dev_routing_manifest_v3.jsonl",
        "lcorridor_locked_test_routing_manifest": output_dir / "m1_lcorridor_locked_test_routing_manifest_v3.jsonl",
    }
    for key in ("base_train_dev", "base_locked_test", "lcorridor_train_dev", "lcorridor_locked_test"):
        _write_frame_manifest(outputs[f"{key}_frame_manifest"], fieldnames, frame_groups[key])
        _write_routing_manifest(outputs[f"{key}_routing_manifest"], routing_groups[key])

    validate_training_manifest(outputs["base_train_dev_frame_manifest"], scope="base")
    validate_training_manifest(outputs["lcorridor_train_dev_frame_manifest"], scope="lcorridor")
    validate_training_routing_manifest(outputs["base_train_dev_routing_manifest"], scope="base")
    validate_training_routing_manifest(outputs["lcorridor_train_dev_routing_manifest"], scope="lcorridor")
    summary = {
        "protocol": "lockbox_v3_20260801",
        "base_excludes_sequences_001_to_021": True,
        "excluded_sequences": sorted(
            sequence for sequence, row in proposal.items() if row["提案split"].strip() == EXCLUDED_SPLIT
        ),
        "artifacts": {},
    }
    for key, path in outputs.items():
        if path.suffix == ".csv":
            rows = _read_frame_manifest(path)[1]
            sequence_counts = Counter(row["split"] for row in {row["sequence"]: row for row in rows}.values())
            row_count = len(rows)
        else:
            rows = _read_routing_manifest(path)
            sequence_counts = Counter(str(row["split"]) for row in rows)
            row_count = len(rows)
        summary["artifacts"][key] = {
            "path": path.name,
            "rows": row_count,
            "sequences_by_split": dict(sorted(sequence_counts.items())),
            "sha256": _sha256(path),
        }
    protocol_path = output_dir / "lockbox_v3_protocol.json"
    protocol_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    outputs["protocol"] = protocol_path
    checksums = output_dir / "SHA256SUMS.txt"
    with checksums.open("w", encoding="ascii", newline="\n") as handle:
        handle.write(
            "".join(f"{_sha256(path)}  {path.name}\n" for path in sorted(outputs.values(), key=lambda item: item.name))
        )
    outputs["checksums"] = checksums
    return outputs
