import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.e9_pbm_hbr import (
    PBMHBRQualityCandidateReranker,
    PBMHBRStage1CandidateReranker,
    PBMHBRStage2CandidateReranker,
    PBMHBRStage2RDCandidateReranker,
    calibrate_peak_confidence,
    fixed_backbone_window,
    range_doppler_candidate_statistics,
)
from scripts.train_m4_e9_pbm_hbr_stage1 import (
    resolve_sequence_override,
    select_best_metrics,
)


def test_pbm_hbr_stage1_is_exact_identity_before_training_and_keeps_fixed_candidates():
    expert = PBMHBRStage1CandidateReranker(BEVGeometry()).eval()
    output = expert(
        torch.randn(2, 48, 128, 128),
        torch.randn(2, 128, 50, 59),
        torch.randn(2, 5, 2, 128, 128),
        torch.randn(2, 1, 200, 234),
        torch.randn(2, 1, 200, 234),
    )

    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["candidate_xy_m"].shape == (2, 8, 2)
    assert output["candidate_selector_logits"].shape == (2, 8)
    assert torch.allclose(output["candidate_mixture"].sum(dim=1), torch.ones(2), atol=1e-6)
    assert torch.equal(output["selected_candidate_index"], torch.zeros(2, dtype=torch.long))
    assert torch.equal(output["candidate_xy_m"][:, 0], output["base_peak_xy_m"])
    assert torch.equal(output["candidate_xy_m"][:, -1], output["base_peak_xy_m"])
    assert torch.equal(output["stage1_acceptance"], torch.zeros(2, 1))


def test_stage1_best_metrics_remain_comparable_after_first_epoch():
    best = {"dev_ap_0p3m": -1.0}
    development = {"ap_0p3m": 0.65, "loss": 1.2}

    best, improved = select_best_metrics(
        best,
        {"epoch": 1, "dev_ap_0p3m": 0.65},
        development,
    )
    assert improved
    assert best["dev_ap_0p3m"] == 0.65

    unchanged, improved = select_best_metrics(
        best,
        {"epoch": 2, "dev_ap_0p3m": 0.64},
        {"ap_0p3m": 0.64},
    )
    assert not improved
    assert unchanged == best


def test_pbm_hbr_stage2_adds_causal_temporal_and_three_branch_evidence():
    expert = PBMHBRStage2CandidateReranker(BEVGeometry()).eval()
    output = expert(
        torch.randn(2, 48, 128, 128),
        torch.randn(2, 128, 50, 59),
        torch.randn(2, 5, 2, 128, 128),
        torch.randn(2, 1, 200, 234),
        torch.randn(2, 1, 200, 234),
    )

    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["candidate_xy_m"].shape == (2, 8, 2)
    assert output["temporal_candidate_embedding"].shape == (2, 8, 32)
    assert output["candidate_branch_posterior"].shape == (2, 8, 3)
    assert output["branch_posterior"].shape == (2, 3)
    assert torch.allclose(output["candidate_branch_posterior"].sum(dim=-1), torch.ones(2, 8), atol=1e-6)
    assert torch.allclose(output["branch_posterior"].sum(dim=-1), torch.ones(2), atol=1e-6)
    assert torch.equal(output["selected_candidate_index"], torch.zeros(2, dtype=torch.long))
    assert torch.equal(output["stage1_acceptance"], torch.zeros(2, 1))


def test_sequence_override_is_explicit_and_deduplicated():
    assert resolve_sequence_override(("seq_001",), "") == ("seq_001",)
    assert resolve_sequence_override(
        ("seq_001",),
        "seq_119, seq_120,seq_119,seq_122",
    ) == ("seq_119", "seq_120", "seq_122")


def test_long_expert_history_keeps_frozen_backbone_on_last_16_frames():
    radar = torch.arange(64).reshape(1, 64, 1, 1, 1)

    window = fixed_backbone_window(radar, clip_length=16)

    assert window.shape == (1, 16, 1, 1, 1)
    assert torch.equal(window[:, 0], radar[:, 48])
    assert torch.equal(window[:, -1], radar[:, -1])


def test_range_doppler_candidate_statistics_are_finite_and_candidate_aligned():
    rd = torch.zeros(1, 3, 4, 8)
    rd_mti = torch.ones_like(rd)
    candidates = torch.tensor([[[0.0, 0.0], [0.0, 23.3]]])

    features = range_doppler_candidate_statistics(
        rd,
        rd_mti,
        candidates,
        BEVGeometry(),
    )

    assert features.shape == (1, 2, 10)
    assert torch.isfinite(features).all()
    assert torch.all(features[..., 1] > features[..., 0])


def test_pbm_hbr_stage2_rd_keeps_identity_and_emits_rd_features():
    expert = PBMHBRStage2RDCandidateReranker(BEVGeometry()).eval()
    output = expert(
        torch.randn(1, 48, 128, 128),
        torch.randn(1, 128, 50, 59),
        torch.randn(1, 5, 2, 128, 128),
        torch.randn(1, 1, 200, 234),
        torch.randn(1, 1, 200, 234),
        rd=torch.randn(1, 5, 128, 256),
        rd_mti=torch.randn(1, 5, 128, 256),
    )

    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["rd_candidate_statistics"].shape == (1, 8, 10)
    assert output["rd_candidate_embedding"].shape == (1, 8, 16)


def test_peak_confidence_calibration_preserves_argmax_and_sets_peak_logit():
    logits = torch.tensor(
        [[[[1.0, -2.0], [0.5, 3.0]]], [[[4.0, 1.0], [-1.0, 0.0]]]]
    )
    quality_logit = torch.tensor([[-0.75], [1.25]])

    calibrated = calibrate_peak_confidence(logits, quality_logit)

    assert torch.equal(
        calibrated.flatten(start_dim=1).argmax(dim=1),
        logits.flatten(start_dim=1).argmax(dim=1),
    )
    assert torch.allclose(
        calibrated.flatten(start_dim=1).amax(dim=1),
        quality_logit[:, 0],
    )


def test_quality_reranker_is_identity_initialized_and_emits_correctness_logit():
    expert = PBMHBRQualityCandidateReranker(BEVGeometry()).eval()
    base_logits = torch.randn(2, 1, 200, 234)
    output = expert(
        torch.randn(2, 48, 128, 128),
        torch.randn(2, 128, 50, 59),
        torch.randn(2, 5, 2, 128, 128),
        base_logits,
        torch.randn(2, 1, 200, 234),
    )

    base_peak_logit = base_logits.flatten(start_dim=1).amax(dim=1, keepdim=True)
    assert output["correctness_logit"].shape == (2, 1)
    assert torch.equal(output["correctness_logit"], base_peak_logit)
