import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.e6_experts import RHEMExpert


def test_rhem_starts_as_exact_identity_and_exposes_three_support_maps():
    geometry = BEVGeometry()
    expert = RHEMExpert(geometry).eval()
    output = expert(
        torch.randn(1, 48, 128, 128),
        torch.randn(1, 128, 50, 59),
        torch.randn(1, 5, 2, 128, 128),
        torch.randn(1, 1, 200, 234),
        torch.tensor([[0.0, 5.0]]),
        torch.tensor([[-0.1, 4.9]]),
    )
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["support_responsibility"].shape == (1, 3, 25, 25)
    assert torch.allclose(output["support_responsibility"].sum(dim=1), torch.ones(1, 25, 25), atol=1e-6)
    assert (output["proposal_xy_m"] - torch.tensor([[0.0, 5.0]])).norm(dim=1).item() <= 0.451
