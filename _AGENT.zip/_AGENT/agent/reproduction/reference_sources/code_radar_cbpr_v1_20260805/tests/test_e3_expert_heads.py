import pytest
import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.e3_experts import CUCREExpert, GGSRREExpert, LTGEExpert, _low_threshold_polar_candidates


@pytest.mark.parametrize("expert_class", (CUCREExpert, LTGEExpert, GGSRREExpert))
def test_e3_heads_start_with_zero_bev_residual(expert_class):
    torch.manual_seed(17)
    geometry = BEVGeometry()
    expert = expert_class(geometry).eval()
    output = expert(
        torch.randn(1, 48, 128, 128),
        torch.randn(1, 128, 50, 59),
        torch.randn(1, 4, 2, 128, 128),
        torch.randn(1, 1, 200, 234),
        torch.tensor([[0.0, 8.0]]),
        torch.tensor([[-0.1, 7.9]]),
    )

    if expert_class is CUCREExpert:
        assert output["polar_delta"].shape == (1, 48, 128, 128)
        assert torch.equal(output["polar_delta"], torch.zeros_like(output["polar_delta"]))
    else:
        assert output["delta_bev_logit"].shape == (1, 1, 200, 234)
        assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["proposal_xy_m"].shape == (1, 2)
    assert output["covariance"].shape == (1, 2, 2)
    assert torch.all(torch.diagonal(output["covariance"], dim1=-2, dim2=-1) > 0.0)


def test_ltge_exposes_a_past_to_current_candidate_graph():
    geometry = BEVGeometry()
    expert = LTGEExpert(geometry, candidate_count=6).eval()
    output = expert(
        torch.randn(2, 48, 128, 128),
        torch.randn(2, 128, 50, 59),
        torch.randn(2, 4, 2, 128, 128),
        torch.randn(2, 1, 200, 234),
        torch.tensor([[0.0, 8.0], [1.0, 12.0]]),
        torch.tensor([[-0.1, 7.9], [0.9, 11.8]]),
    )

    assert output["candidate_xy_m"].shape == (2, 6, 2)
    assert output["graph_history_xy_m"].shape == (2, 24, 2)
    assert output["graph_link_logits"].shape == (2, 6, 24)
    assert torch.allclose(output["candidate_mixture"].sum(dim=1), torch.ones(2), atol=1e-6)


def test_low_threshold_candidates_keep_a_fixed_causal_count():
    candidates, score = _low_threshold_polar_candidates(torch.randn(2, 5, 2, 128, 128), 6, BEVGeometry())

    assert candidates.shape == (2, 5, 6, 2)
    assert score.shape == (2, 5, 6)
    assert torch.isfinite(candidates).all()


def test_gg_srre_phase_switch_freezes_the_other_branch():
    expert = GGSRREExpert(BEVGeometry())
    expert.set_training_phase("recovery")
    assert all(parameter.requires_grad for parameter in expert.recovery.parameters())
    assert not any(parameter.requires_grad for parameter in expert.gain_encoder.parameters())
    expert.set_training_phase("gain")
    assert not any(parameter.requires_grad for parameter in expert.recovery.parameters())
    assert all(parameter.requires_grad for parameter in expert.gain_encoder.parameters())
