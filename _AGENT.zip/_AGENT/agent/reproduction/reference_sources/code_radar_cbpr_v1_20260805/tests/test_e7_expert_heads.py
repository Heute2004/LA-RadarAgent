import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.e7_experts import TECSEchoCandidateSelector


def test_tecs_is_exact_identity_before_training_and_exposes_audited_candidates():
    geometry = BEVGeometry()
    expert = TECSEchoCandidateSelector(geometry).eval()
    output = expert(
        torch.randn(2, 48, 128, 128),
        torch.randn(2, 128, 50, 59),
        torch.randn(2, 5, 2, 128, 128),
        torch.randn(2, 1, 200, 234),
        torch.tensor([[0.0, 5.0], [1.0, 7.0]]),
        torch.tensor([[-0.1, 4.9], [0.9, 6.9]]),
    )
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["candidate_xy_m"].shape == (2, 10, 2)
    assert output["candidate_selector_logits"].shape == (2, 10)
    assert torch.allclose(output["candidate_mixture"].sum(dim=1), torch.ones(2), atol=1e-6)
    assert torch.equal(output["candidate_xy_m"][:, 0], torch.tensor([[0.0, 5.0], [1.0, 7.0]]))
