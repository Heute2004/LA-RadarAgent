import pytest
import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.heterogeneous_experts import CLOREXpert, DCMDEXpert, PATEIExpert, SRREExpert


@pytest.mark.parametrize("expert_class", (CLOREXpert, DCMDEXpert, PATEIExpert, SRREExpert))
def test_heterogeneous_head_outputs_the_common_zero_residual_contract(expert_class):
    torch.manual_seed(11)
    geometry = BEVGeometry()
    expert = expert_class(geometry).eval()
    polar = torch.randn(1, 48, 128, 128)
    shared = torch.randn(1, 128, 50, 59)
    radar = torch.randn(1, 4, 2, 128, 128)
    logits = torch.randn(1, 1, 200, 234)
    base_xy = torch.tensor([[0.0, 8.0]])
    previous_xy = torch.tensor([[-0.1, 7.9]])

    with torch.no_grad():
        output = expert(polar, shared, radar, logits, base_xy, previous_xy)

    assert output["delta_bev_logit"].shape == (1, 1, 200, 234)
    assert output["covariance"].shape == (1, 2, 2)
    assert output["causal_state"].shape == (1, 64)
    assert output["proposal_xy_m"].shape == (1, 2)
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert torch.all(torch.diagonal(output["covariance"], dim1=-2, dim2=-1) > 0.0)


def test_dcmd_returns_a_normalized_candidate_mixture():
    geometry = BEVGeometry()
    expert = DCMDEXpert(geometry, candidate_count=4).eval()
    with torch.no_grad():
        output = expert(
            torch.randn(2, 48, 128, 128),
            torch.randn(2, 128, 50, 59),
            torch.randn(2, 4, 2, 128, 128),
            torch.randn(2, 1, 200, 234),
            torch.tensor([[0.0, 8.0], [1.0, 12.0]]),
            torch.tensor([[-0.1, 7.9], [0.9, 11.8]]),
        )

    assert output["candidate_xy_m"].shape == (2, 4, 2)
    assert torch.allclose(output["candidate_mixture"].sum(dim=1), torch.ones(2), atol=1e-6)
