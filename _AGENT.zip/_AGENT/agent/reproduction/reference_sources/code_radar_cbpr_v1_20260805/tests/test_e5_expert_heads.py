import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.e5_experts import LTGECENExpert, SCARExpert


def _inputs(frames: int = 4):
    return (
        torch.randn(1, 48, 128, 128),
        torch.randn(1, 128, 50, 59),
        torch.randn(1, frames, 2, 128, 128),
        torch.randn(1, 1, 200, 234),
        torch.tensor([[0.0, 8.0]]),
        torch.tensor([[-0.1, 7.9]]),
    )


def test_scar_starts_as_zero_residual_with_bounded_two_stage_proposal():
    output = SCARExpert(BEVGeometry()).eval()(*_inputs())
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert (output["coarse_xy_m"] - torch.tensor([[0.0, 8.0]])).norm(dim=1).item() <= 0.50
    assert output["fine_delta_m"].norm(dim=1).item() <= 0.18


def test_ltge_cen_has_one_dense_corridor_node_for_each_history_frame():
    output = LTGECENExpert(BEVGeometry(), candidate_count=6).eval()(*_inputs(frames=5))
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["candidate_history_xy_m"].shape == (1, 5, 6, 2)
    assert output["corridor_node_xy_m"].shape == (1, 5, 2)
    assert torch.allclose(output["candidate_mixture"].sum(dim=1), torch.ones(1), atol=1e-6)


def test_ltge_cen_rd_sidecar_is_optional_and_starts_as_zero_residual():
    expert = LTGECENExpert(BEVGeometry(), candidate_count=6, rd_mode="mti").eval()
    rd = torch.randn(1, 5, 128, 256)
    output = expert(*_inputs(frames=5), rd_mti=rd)

    assert output["rd_candidate_embedding"].shape == (1, 5, 6, 16)
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
