import torch

from radar_bev.geometry import BEVGeometry
from radar_bev.models.e4_experts import AURFLiteExpert, SDPTBDExpert


def _inputs(batch: int = 1, frames: int = 4):
    return (
        torch.randn(batch, 48, 128, 128),
        torch.randn(batch, 128, 50, 59),
        torch.randn(batch, frames, 2, 128, 128),
        torch.randn(batch, 1, 200, 234),
        torch.tensor([[0.0, 8.0]]).repeat(batch, 1),
        torch.tensor([[-0.1, 7.9]]).repeat(batch, 1),
    )


def test_aurf_lite_starts_as_an_exact_zero_residual_with_normalized_mixture():
    output = AURFLiteExpert(BEVGeometry()).eval()(*_inputs())
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["mixture_weights"].shape == (1, 2)
    assert torch.allclose(output["mixture_weights"].sum(dim=1), torch.ones(1), atol=1e-6)
    assert torch.all(output["mixture_std_rc_m"] >= 0.06)


def test_sdp_tbd_exposes_a_full_causal_candidate_trellis():
    output = SDPTBDExpert(BEVGeometry(), candidate_count=6).eval()(*_inputs(frames=5))
    assert torch.equal(output["delta_bev_logit"], torch.zeros_like(output["delta_bev_logit"]))
    assert output["candidate_history_xy_m"].shape == (1, 5, 6, 2)
    assert output["tbd_path_logits"].shape == (1, 5, 6)
    assert torch.allclose(output["candidate_mixture"].sum(dim=1), torch.ones(1), atol=1e-6)
