from __future__ import annotations

"""Train PB-MHBR Stage 1 on ordinary outdoor dry-complex sequences only."""

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import torch
from torch import Tensor
from torch.utils.data import DataLoader, WeightedRandomSampler

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from radar_bev.data import RadarWindowDataset
from radar_bev.e8_training import e8_loss_terms
from radar_bev.e9_training import (
    balanced_candidate_sample_weights,
    candidate_correction_mask,
    candidate_ranking_margin_loss,
    correctness_calibration_loss,
    selective_confidence_preservation_loss,
)
from radar_bev.evaluation import (
    evaluate_grouped_single_person_predictions,
    evaluate_single_person_predictions,
    extract_single_peak,
)
from radar_bev.geometry import BEVGeometry
from radar_bev.lockbox_v3 import (
    DEV_SPLIT,
    TRAIN_SPLIT,
    validate_training_manifest,
    validate_training_routing_manifest,
)
from radar_bev.losses import QualityAwareBEVLoss
from radar_bev.models import build_model
from radar_bev.training import has_converged_early_stop, manifest_sha256, seed_everything


PB_TRAIN_SEQUENCES = (
    "seq_107", "seq_108", "seq_110", "seq_111", "seq_115",
    "seq_116", "seq_119", "seq_120", "seq_122",
)
PB_DEV_SEQUENCES = ("seq_109", "seq_117", "seq_121")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train M4 E9 PB-MHBR Stage 1 candidate re-ranking.")
    for name in ("data-root", "manifest", "routing-manifest", "base-checkpoint", "output-dir"):
        parser.add_argument(f"--{name}", required=True)
    parser.add_argument("--train-epochs", type=int, default=20)
    parser.add_argument(
        "--train-sequences",
        default="",
        help="Optional comma-separated Train sequence override.",
    )
    parser.add_argument(
        "--model-name",
        choices=(
            "dream_e9_pbm_hbr_stage1",
            "dream_e9_pbm_hbr_stage2",
            "dream_e9_pbm_hbr_stage2_rd",
            "dream_e9_pbm_hbr_quality",
            "dream_e9_pbm_hbr_quality_rd",
        ),
        default="dream_e9_pbm_hbr_stage1",
    )
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--clip-length", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=5e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--coordinate-weight", type=float, default=0.05)
    parser.add_argument("--selector-weight", type=float, default=1.0)
    parser.add_argument("--gate-weight", type=float, default=0.0)
    parser.add_argument("--proposal-weight", type=float, default=0.30)
    parser.add_argument("--positive-weight", type=float, default=12.0)
    parser.add_argument("--ranking-weight", type=float, default=1.0)
    parser.add_argument("--ranking-margin", type=float, default=0.50)
    parser.add_argument("--ranking-correction-weight", type=float, default=1.0)
    parser.add_argument("--quality-ranking-weight", type=float, default=1.0)
    parser.add_argument("--quality-preservation-weight", type=float, default=2.0)
    parser.add_argument("--quality-suppression-weight", type=float, default=1.0)
    parser.add_argument(
        "--quality-loss",
        choices=("selective", "balanced_bce"),
        default="selective",
    )
    parser.add_argument("--correction-sampling-fraction", type=float, default=0.0)
    parser.add_argument("--early-stop-patience", type=int, default=4)
    parser.add_argument("--progress-every-batches", type=int, default=200)
    parser.add_argument("--max-train-batches", type=int, default=0)
    parser.add_argument("--max-eval-batches", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--ram-cache", action="store_true")
    parser.add_argument("--no-amp", action="store_true")
    return parser.parse_args()


def select_best_metrics(
    best: dict[str, float | int],
    record: dict[str, float | int],
    dev_metrics: dict[str, float],
) -> tuple[dict[str, float | int], bool]:
    selection_metric = "dev_ap_0p3m"
    if float(record[selection_metric]) <= float(best[selection_metric]):
        return best, False
    selected = {
        "epoch": int(record["epoch"]),
        selection_metric: float(record[selection_metric]),
        **dev_metrics,
    }
    return selected, True


def resolve_sequence_override(
    defaults: tuple[str, ...],
    specification: str,
) -> tuple[str, ...]:
    values = tuple(
        dict.fromkeys(
            value.strip()
            for value in specification.split(",")
            if value.strip()
        )
    )
    return values or defaults


def _to_device(batch: dict[str, Tensor | str], device: torch.device) -> dict[str, Tensor | str]:
    return {key: value.to(device, non_blocking=True) if isinstance(value, Tensor) else value for key, value in batch.items()}


def _forward_model(
    model: torch.nn.Module,
    batch: dict[str, Tensor | str],
) -> dict[str, Tensor]:
    auxiliary = {
        key: batch[key]
        for key in ("rd", "rd_mti")
        if key in batch
    }
    return model(batch["radar"], **auxiliary)


def _is_quality_model(model_name: str) -> bool:
    return "_quality" in model_name


def _run_epoch(
    model: torch.nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer | None,
    criterion: QualityAwareBEVLoss,
    device: torch.device,
    amp: bool,
    args: argparse.Namespace,
    max_batches: int,
) -> dict[str, float]:
    training = optimizer is not None
    model.train(training)
    names = (
        "loss", "localization", "selector", "gate", "ranking", "correction_rate",
        "safe_target_accuracy", "correction_selector_recall", "correction_gate_mean",
    )
    totals = {name: 0.0 for name in names}
    samples = 0
    predictions: list[Tensor] = []
    confidences: list[Tensor] = []
    base_predictions: list[Tensor] = []
    base_confidences: list[Tensor] = []
    proposal_predictions: list[Tensor] = []
    proposal_confidences: list[Tensor] = []
    targets: list[Tensor] = []
    acceptances: list[Tensor] = []
    sequence_names: list[str] = []
    durations: list[float] = []
    for batch_index, raw_batch in enumerate(loader, start=1):
        if max_batches and batch_index > max_batches:
            break
        batch = _to_device(raw_batch, device)
        if not training and device.type == "cuda":
            torch.cuda.synchronize(device)
        started = perf_counter()
        with torch.set_grad_enabled(training), torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp and device.type == "cuda"):
            output = _forward_model(model, batch)
            if _is_quality_model(args.model_name):
                base_error = (
                    output["base_peak_xy_m"] - batch["target_xy_m"]
                ).norm(dim=1)
                if args.quality_loss == "selective":
                    base_peak_logit = (
                        output["base_logits"]
                        .flatten(start_dim=1)
                        .amax(dim=1)
                    )
                    quality = selective_confidence_preservation_loss(
                        output["correctness_logit"][:, 0],
                        base_peak_logit,
                        base_error <= 0.30,
                        preservation_weight=args.quality_preservation_weight,
                        suppression_weight=args.quality_suppression_weight,
                        ranking_weight=args.quality_ranking_weight,
                    )
                    calibration_metric = (
                        quality.preservation + quality.suppression
                    )
                else:
                    quality = correctness_calibration_loss(
                        output["correctness_logit"][:, 0],
                        base_error <= 0.30,
                        ranking_weight=args.quality_ranking_weight,
                    )
                    calibration_metric = quality.calibration
                total_loss = quality.total
                zero = total_loss.detach() * 0.0
                metric_values = {
                    "loss": total_loss,
                    "localization": zero,
                    "selector": calibration_metric,
                    "gate": zero,
                    "ranking": quality.ranking,
                    "correction_rate": 1.0 - quality.correct_fraction,
                    "safe_target_accuracy": quality.correct_fraction,
                    "correction_selector_recall": zero,
                    "correction_gate_mean": output[
                        "correctness_logit"
                    ].sigmoid().mean().detach(),
                }
            else:
                losses = e8_loss_terms(
                    output,
                    batch["target_xy_m"],
                    batch["sample_weight"],
                    torch.zeros_like(batch["frame_id"], dtype=torch.bool),
                    criterion,
                    selector_weight=args.selector_weight,
                    gate_weight=args.gate_weight,
                    proposal_weight=args.proposal_weight,
                    positive_weight=args.positive_weight,
                )
                ranking = candidate_ranking_margin_loss(
                    output["candidate_selector_logits"],
                    output["candidate_xy_m"],
                    batch["target_xy_m"],
                    margin=args.ranking_margin,
                    correction_weight=args.ranking_correction_weight,
                )
                total_loss = losses.total + args.ranking_weight * ranking.loss
                metric_values = {
                    "loss": total_loss,
                    "localization": losses.localization,
                    "selector": losses.selector,
                    "gate": losses.gate,
                    "ranking": ranking.loss.detach(),
                    "correction_rate": losses.correction_rate,
                    "safe_target_accuracy": losses.safe_target_accuracy,
                    "correction_selector_recall": losses.correction_selector_recall,
                    "correction_gate_mean": losses.correction_gate_mean,
                }
        if training:
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.expert_parameters(), max_norm=5.0)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
        if not training and device.type == "cuda":
            torch.cuda.synchronize(device)
        count = int(batch["radar"].shape[0])
        samples += count
        durations.append(perf_counter() - started)
        for name, value in metric_values.items():
            totals[name] += float(value.detach().item()) * count
        if training and args.progress_every_batches and batch_index % args.progress_every_batches == 0:
            print(json.dumps({"phase": "train", "batch": batch_index, "mean_loss": totals["loss"] / samples}), flush=True)
        if not training:
            prediction, confidence = extract_single_peak(output["logits"], BEVGeometry())
            base_prediction, base_confidence = extract_single_peak(output["base_logits"], BEVGeometry())
            predictions.append(prediction.cpu())
            confidences.append(confidence.cpu())
            base_predictions.append(base_prediction.cpu())
            base_confidences.append(base_confidence.cpu())
            proposal_predictions.append(output["proposal_xy_m"].detach().cpu())
            proposal_confidences.append(
                (
                    base_confidence
                    * output["candidate_mixture"].detach().amax(dim=1)
                ).cpu()
            )
            targets.append(batch["target_xy_m"].cpu())
            acceptances.append(output["acceptance"].detach().cpu())
            sequence_names.extend(str(value) for value in batch["sequence"])
    result = {name: value / max(samples, 1) for name, value in totals.items()}
    result["samples"] = float(samples)
    if not training:
        target = torch.cat(targets)
        prediction = torch.cat(predictions)
        confidence = torch.cat(confidences)
        base_prediction = torch.cat(base_predictions)
        base_confidence = torch.cat(base_confidences)
        proposal_prediction = torch.cat(proposal_predictions)
        proposal_confidence = torch.cat(proposal_confidences)
        thresholds = (0.25, 0.30, 0.40, 0.50, 1.0)
        result.update(evaluate_single_person_predictions(confidence, prediction, target, distance_thresholds=thresholds))
        result.update({f"base_{key}": value for key, value in evaluate_single_person_predictions(base_confidence, base_prediction, target, distance_thresholds=thresholds).items()})
        result.update(
            {
                f"proposal_{key}": value
                for key, value in evaluate_single_person_predictions(
                    proposal_confidence,
                    proposal_prediction,
                    target,
                    distance_thresholds=thresholds,
                ).items()
            }
        )
        grouped = evaluate_grouped_single_person_predictions(
            confidence,
            prediction,
            target,
            sequence_names,
            distance_thresholds=thresholds,
        )
        grouped_base = evaluate_grouped_single_person_predictions(
            base_confidence,
            base_prediction,
            target,
            sequence_names,
            distance_thresholds=thresholds,
        )
        for sequence, metrics in grouped.items():
            result[f"{sequence}_ap_0p3m"] = metrics["ap_0p3m"]
            result[f"{sequence}_mean_location_error_m"] = metrics[
                "mean_location_error_m"
            ]
            result[f"{sequence}_base_ap_0p3m"] = grouped_base[sequence][
                "ap_0p3m"
            ]
        acceptance = torch.cat(acceptances)
        result["acceptance_mean"] = float(acceptance.mean().item())
        result["acceptance_coverage_0p5"] = float((acceptance >= 0.5).float().mean().item())
        result["fallback_rate_0p5"] = 1.0 - result["acceptance_coverage_0p5"]
        result["latency_ms_per_frame"] = 1000.0 * sum(durations) / max(samples, 1)
        result["fps"] = 1000.0 / max(result["latency_ms_per_frame"], 1e-6)
    return result


def _dataset(args: argparse.Namespace, split: str, sequences: tuple[str, ...]) -> RadarWindowDataset:
    use_rd = args.model_name.endswith("_rd")
    return RadarWindowDataset(
        data_root=Path(args.data_root),
        manifest_path=Path(args.manifest),
        split=split,
        allowed_sequences=sequences,
        clip_length=args.clip_length,
        eligibility="later",
        include_aux_views=use_rd,
        aux_views=("rd", "rd_mti") if use_rd else None,
        cache_in_memory=args.ram_cache and use_rd,
        cache_primary_in_memory=args.ram_cache,
    )


@torch.inference_mode()
def _candidate_sampling_weights(
    model: torch.nn.Module,
    dataset: RadarWindowDataset,
    device: torch.device,
    amp: bool,
    batch_size: int,
    correction_fraction: float,
) -> tuple[Tensor, dict[str, float | int]]:
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    model.eval()
    masks: list[Tensor] = []
    for raw_batch in loader:
        batch = _to_device(raw_batch, device)
        with torch.autocast(
            device_type=device.type,
            dtype=torch.bfloat16,
            enabled=amp and device.type == "cuda",
        ):
            output = _forward_model(model, batch)
        valid = batch["sample_weight"] > 0
        correction = candidate_correction_mask(
            output["candidate_xy_m"],
            batch["target_xy_m"],
        )
        masks.append((correction & valid).cpu())
    correction_mask = torch.cat(masks)
    weights = balanced_candidate_sample_weights(correction_mask, correction_fraction)
    return weights, {
        "candidate_sampling_frames": int(correction_mask.numel()),
        "candidate_sampling_corrections": int(correction_mask.sum().item()),
        "candidate_sampling_correction_rate": float(correction_mask.float().mean().item()),
        "candidate_sampling_target_fraction": float(correction_fraction),
    }


def main() -> None:
    args = parse_args()
    validate_training_manifest(Path(args.manifest), scope="base")
    validate_training_routing_manifest(Path(args.routing_manifest), scope="base")
    output_dir = Path(args.output_dir)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty output directory: {output_dir}")
    seed_everything(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    train_sequences = resolve_sequence_override(
        PB_TRAIN_SEQUENCES,
        args.train_sequences,
    )
    train_set = _dataset(args, TRAIN_SPLIT, train_sequences)
    dev_set = _dataset(args, DEV_SPLIT, PB_DEV_SEQUENCES)
    model = build_model(args.model_name)
    base_sha256 = model.load_base_checkpoint(args.base_checkpoint)
    model = model.to(device)
    sampling_metadata: dict[str, float | int] = {
        "candidate_sampling_frames": len(train_set),
        "candidate_sampling_corrections": 0,
        "candidate_sampling_correction_rate": 0.0,
        "candidate_sampling_target_fraction": 0.0,
    }
    sampler = None
    if args.correction_sampling_fraction > 0.0:
        sample_weights, sampling_metadata = _candidate_sampling_weights(
            model,
            train_set,
            device,
            not args.no_amp,
            args.batch_size,
            args.correction_sampling_fraction,
        )
        sampler = WeightedRandomSampler(
            sample_weights,
            num_samples=len(train_set),
            replacement=True,
            generator=torch.Generator().manual_seed(args.seed),
        )
    loader_args = {
        "batch_size": args.batch_size,
        "num_workers": 0 if args.ram_cache else args.num_workers,
        "pin_memory": device.type == "cuda",
        "persistent_workers": (not args.ram_cache) and args.num_workers > 0,
    }
    train_loader = DataLoader(train_set, shuffle=sampler is None, sampler=sampler, **loader_args)
    dev_loader = DataLoader(dev_set, shuffle=False, **loader_args)
    criterion = QualityAwareBEVLoss(coordinate_weight=args.coordinate_weight).to(device)
    optimizer = torch.optim.AdamW(model.expert_parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.train_epochs)
    routing_manifest = Path(args.routing_manifest)
    output_dir.mkdir(parents=True, exist_ok=False)
    metadata = {
        "stage": (
            "M4_E9_PB_MHBR_QUALITY_RD"
            if args.model_name.endswith("quality_rd")
            else "M4_E9_PB_MHBR_QUALITY"
            if args.model_name.endswith("quality")
            else
            "M4_E9_PB_MHBR_STAGE2_RD"
            if args.model_name.endswith("stage2_rd")
            else "M4_E9_PB_MHBR_STAGE2"
            if args.model_name.endswith("stage2")
            else "M4_E9_PB_MHBR_STAGE1"
        ),
        "definition": (
            "Frozen DREAM-BEV peak-preserving correctness@0.30 m calibration; "
            "confidence changes are learned from causal radar evidence while coordinates remain exactly frozen."
            if _is_quality_model(args.model_name)
            else
            "Frozen DREAM-BEV candidate re-ranking with causal local temporal evidence and previous-frame top-3 branch association; "
            "no free coordinate regressor, future context, or NLOS/RIS recovery claim."
            if args.model_name.endswith(("stage2", "stage2_rd"))
            else "Frozen DREAM-BEV candidate re-ranking only; no free coordinate regressor, learned future context, or NLOS/RIS recovery claim."
        ),
        "base_model": "DREAM-BEV/m_rodnet_lite",
        "base_checkpoint": str(Path(args.base_checkpoint).resolve()),
        "base_checkpoint_sha256": base_sha256,
        "manifest_sha256": manifest_sha256(args.manifest),
        "routing_manifest_sha256": hashlib.sha256(routing_manifest.read_bytes()).hexdigest(),
        "train_sequences": list(train_sequences),
        "dev_sequences": list(PB_DEV_SEQUENCES),
        "excluded_from_specialist_training": ["seq_112", "seq_113", "seq_114"],
        "candidate_contract": ["base", "bev_rank_2", "bev_rank_3", "polar_rank_1", "polar_rank_2", "polar_rank_3", "previous_base", "null"],
        "runtime_input_modalities": (
            ["RA", "RA-MIT", "RD", "RD-MIT"]
            if args.model_name.endswith("_rd")
            else ["RA", "RA-MIT"]
        ),
        "train_samples": len(train_set),
        "dev_samples": len(dev_set),
        "trainable_parameters": sum(parameter.numel() for parameter in model.expert_parameters()),
        "frozen_backbone_parameters": sum(parameter.numel() for parameter in model.backbone.parameters()),
        "checkpoint_selection_metric": "dev_ap_0p3m",
        "evaluation_protocol": "Lockbox V3 Train + Development Val; Locked Test is physically absent",
        **sampling_metadata,
        "args": vars(args),
    }
    (output_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    history: list[dict[str, float | int]] = []
    best: dict[str, float | int] = {"dev_ap_0p3m": -1.0}
    for epoch in range(1, args.train_epochs + 1):
        train_metrics = _run_epoch(model, train_loader, optimizer, criterion, device, not args.no_amp, args, args.max_train_batches)
        dev_metrics = _run_epoch(model, dev_loader, None, criterion, device, not args.no_amp, args, args.max_eval_batches)
        scheduler.step()
        record = {
            "epoch": epoch,
            "lr": optimizer.param_groups[0]["lr"],
            **{f"train_{key}": value for key, value in train_metrics.items()},
            **{f"dev_{key}": value for key, value in dev_metrics.items()},
        }
        history.append(record)
        print(json.dumps(record, ensure_ascii=True), flush=True)
        best, improved = select_best_metrics(best, record, dev_metrics)
        if improved:
            torch.save(
                {
                    "model": type(model).__name__,
                    "expert_family": args.model_name.removeprefix("dream_"),
                    "base_checkpoint_sha256": base_sha256,
                    "expert_state": model.expert_state_dict(),
                    "metrics": best,
                },
                output_dir / "best_expert.pt",
            )
        (output_dir / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        (output_dir / "best_metrics.json").write_text(json.dumps(best, indent=2), encoding="utf-8")
        if epoch < args.train_epochs and has_converged_early_stop([float(item["dev_ap_0p3m"]) for item in history], args.early_stop_patience):
            break
    (output_dir / "training_complete.json").write_text(
        json.dumps(
            {
                "completed": True,
                "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "requested_epochs": args.train_epochs,
                "completed_epochs": len(history),
                "best_epoch": best.get("epoch"),
                "best_metrics": best,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
