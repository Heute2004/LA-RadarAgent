from __future__ import annotations

"""Reuse the audited heterogeneous trainer with a CPB-ConvLSTM feature source."""

import json
import sys
from pathlib import Path

import train_dream_heterogeneous_expert as runner

from radar_bev.models.convlstm_expert_wrappers import (
    ConvLSTME3RouteExpertBEV,
    ConvLSTMHeterogeneousExpertBEV,
)


def _build_model(name: str, **kwargs: object):
    if name == "dream_heterogeneous_expert":
        return ConvLSTMHeterogeneousExpertBEV(**kwargs)
    if name == "dream_e3_route_expert":
        return ConvLSTME3RouteExpertBEV(**kwargs)
    raise ValueError(f"unsupported transfer model request: {name}")


def _output_dir() -> Path:
    return Path(sys.argv[sys.argv.index("--output-dir") + 1])


def _mark_transfer(output_dir: Path) -> None:
    path = output_dir / "run_metadata.json"
    metadata = json.loads(path.read_text(encoding="utf-8"))
    metadata.update(
        {
            "stage": "M4_ConvLSTM_transfer_route_expert",
            "base_model": "CPB-ConvLSTM-inspired",
            "transfer_contract": "same expert head/loss; frozen CPB-ConvLSTM current-polar + causal-shared-BEV interface",
        }
    )
    path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")


if __name__ == "__main__":
    runner.build_model = _build_model
    runner.main()
    _mark_transfer(_output_dir())
