"""Hash-bound CORA0/SE1/SE2 prediction timelines for branch-router recipes."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .branch_router_recipe import BRANCH_ORDER


BranchPredictionIndex = dict[
    str, dict[tuple[str, int], tuple[torch.Tensor, float]]
]


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_prediction_index(
    path: Path,
) -> dict[tuple[str, int], tuple[torch.Tensor, float]]:
    with np.load(path, allow_pickle=False) as archive:
        sequence = np.asarray(archive["sequence"]).astype(str)
        frame_id = np.asarray(archive["frame_id"], dtype=np.int64)
        xy_m = np.asarray(archive["xy_m"], dtype=np.float32)
        score = np.asarray(archive["score"], dtype=np.float32)
    if (
        sequence.ndim != 1
        or frame_id.shape != sequence.shape
        or xy_m.shape != (len(sequence), 2)
        or score.shape != sequence.shape
        or not np.isfinite(xy_m).all()
        or not np.isfinite(score).all()
    ):
        raise ValueError(f"invalid frozen branch prediction arrays: {path}")
    result: dict[tuple[str, int], tuple[torch.Tensor, float]] = {}
    for name, frame, xy, confidence in zip(
        sequence, frame_id, xy_m, score, strict=True
    ):
        key = (str(name).strip().lower(), int(frame))
        if key in result:
            raise ValueError(f"duplicate frozen branch prediction: {key}")
        result[key] = (torch.from_numpy(xy.copy()), float(confidence))
    return result


def load_branch_prediction_root(
    root: Path,
) -> tuple[BranchPredictionIndex, dict[str, Any]]:
    root = Path(root)
    manifest_path = root / "PREDICTION_FREEZE.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"branch prediction manifest missing: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    files = manifest.get("prediction_files")
    if not isinstance(files, dict) or tuple(sorted(files)) != tuple(
        sorted(BRANCH_ORDER)
    ):
        raise ValueError("branch recipe requires exactly CORA0, CORA-SE1, and CORA-SE2")
    result: BranchPredictionIndex = {}
    for branch in BRANCH_ORDER:
        entry = files[branch]
        if not isinstance(entry, dict):
            raise ValueError(f"branch prediction file entry is invalid: {branch}")
        path = root / str(entry.get("path", ""))
        if not path.is_file() or file_sha256(path) != str(entry.get("sha256", "")):
            raise ValueError(f"branch prediction hash mismatch: {branch}")
        result[branch] = load_prediction_index(path)
    forbidden = (
        "development_labels_read",
        "locked_test_read",
        "target_final_bev_read",
        "raw_depth_read",
        "right_rgb_read",
        "manual_ra_anchor_read",
    )
    if any(bool(manifest.get(field, False)) for field in forbidden):
        raise ValueError("branch prediction freeze reports forbidden evaluation reads")
    return result, manifest


def resolve_branch_timeline(
    branch_index: BranchPredictionIndex,
    *,
    sequence: str,
    frame_ids: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    sequence = str(sequence).strip().lower()
    identifiers = np.asarray(frame_ids, dtype=np.int64)
    coordinates: list[torch.Tensor] = []
    scores: list[torch.Tensor] = []
    for frame in identifiers:
        key = (sequence, int(frame))
        missing = [branch for branch in BRANCH_ORDER if key not in branch_index[branch]]
        if missing:
            raise ValueError(
                f"frozen branch prediction missing {sequence} frame {int(frame)}: {missing}"
            )
        coordinates.append(
            torch.stack([branch_index[branch][key][0] for branch in BRANCH_ORDER])
        )
        scores.append(
            torch.tensor(
                [branch_index[branch][key][1] for branch in BRANCH_ORDER],
                dtype=torch.float32,
            )
        )
    if not coordinates:
        raise ValueError("branch timeline is empty")
    return torch.stack(coordinates).numpy(), torch.stack(scores).numpy()
