"""Support-only parent selection for fresh route experts.

The expert library describes *what* a route expert can do.  It must not decide
which current CORA branch an expert refines.  This module makes that branch
choice from sealed Support evidence only, before any expert is materialized.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Sequence

import numpy as np


class RouteParentSelectionError(ValueError):
    """Raised when a parent-selection receipt is incomplete or unsafe."""


PARENT_SELECTION_POLICY_ID = "support-confirmation-relative-safety-v2"
FROZEN_PARENT_CONTROL_POLICY_ID = "historical-frozen-parent-control-v1"
SUPPORTED_PARENT_SELECTION_POLICY_IDS = frozenset(
    {PARENT_SELECTION_POLICY_ID, FROZEN_PARENT_CONTROL_POLICY_ID}
)


_DIRECT_BRANCHES = ("cora0", "cora_se1", "cora_se2")
_RIS_ROUTE = "corner_nlos_ris"
_FORBIDDEN_READS = (
    "development_read",
    "locked_test_read",
    "target_final_bev_read",
    "right_rgb_read",
    "raw_depth_read",
)
_BRANCH_COMPLEXITY = {"cora0": 0, "cora_se1": 1, "cora_se2": 2}
_MAXIMUM_EMPTY_FALSE_ALARM_RATE = 0.03
_MAXIMUM_TEMPORAL_REGRESSION_FROM_CORA0 = 0.02
_MAXIMUM_EMPTY_FALSE_ALARM_INCREASE_FROM_CORA0 = 0.02
_AGREEMENT_TIE_TOLERANCE = 0.005


def is_supported_parent_selection_policy(value: object) -> bool:
    """Return whether a receipt policy is executable by the current toolbox."""

    return str(value) in SUPPORTED_PARENT_SELECTION_POLICY_IDS


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json_object(path: Path, label: str) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RouteParentSelectionError(f"cannot read {label}") from error
    if not isinstance(payload, dict):
        raise RouteParentSelectionError(f"{label} must be a JSON object")
    return payload


def _finite_probability(value: object, field: str) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0 or number > 1.0:
        raise RouteParentSelectionError(f"{field} must be a finite probability")
    return number


def _sha256(value: object, field: str) -> str:
    digest = str(value).lower()
    if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
        raise RouteParentSelectionError(f"{field} must be a SHA256 digest")
    return digest


@dataclass(frozen=True)
class ParentSupportEvidence:
    """One branch evaluated on exactly the sealed Support scope."""

    branch: str
    checkpoint_sha256: str
    support_scope_sha256: str
    weighted_frames: float
    physical_support: float
    weak_candidate_agreement: float
    temporal_consistency: float
    empty_false_alarm_rate: float

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "ParentSupportEvidence":
        branch = str(raw.get("branch", ""))
        if branch not in _DIRECT_BRANCHES:
            raise RouteParentSelectionError(f"unsupported parent branch: {branch}")
        for field in _FORBIDDEN_READS:
            if bool(raw.get(field, False)):
                raise RouteParentSelectionError(f"forbidden read in parent evidence: {field}")
        weighted_frames = float(raw.get("weighted_frames", 0.0))
        if not math.isfinite(weighted_frames) or weighted_frames <= 0.0:
            raise RouteParentSelectionError("weighted_frames must be positive")
        return cls(
            branch=branch,
            checkpoint_sha256=_sha256(raw.get("checkpoint_sha256", ""), "checkpoint_sha256"),
            support_scope_sha256=_sha256(raw.get("support_scope_sha256", ""), "support_scope_sha256"),
            weighted_frames=weighted_frames,
            physical_support=_finite_probability(raw.get("physical_support"), "physical_support"),
            weak_candidate_agreement=_finite_probability(
                raw.get("weak_candidate_agreement"), "weak_candidate_agreement"
            ),
            temporal_consistency=_finite_probability(
                raw.get("temporal_consistency"), "temporal_consistency"
            ),
            empty_false_alarm_rate=_finite_probability(
                raw.get("empty_false_alarm_rate"), "empty_false_alarm_rate"
            ),
        )

    def to_dict(
        self, *, safe: bool, safety_reasons: Sequence[str]
    ) -> dict[str, Any]:
        return {
            "branch": self.branch,
            "checkpoint_sha256": self.checkpoint_sha256,
            "support_scope_sha256": self.support_scope_sha256,
            "weighted_frames": self.weighted_frames,
            "physical_support": self.physical_support,
            "weak_candidate_agreement": self.weak_candidate_agreement,
            "temporal_consistency": self.temporal_consistency,
            "empty_false_alarm_rate": self.empty_false_alarm_rate,
            "safe": bool(safe),
            "safety_reasons": list(safety_reasons),
        }


def _validate_scope(evidence: Sequence[ParentSupportEvidence]) -> None:
    scopes = {item.support_scope_sha256 for item in evidence}
    if len(scopes) != 1:
        raise RouteParentSelectionError("parent evidence must use one sealed Support scope")
    branches = [item.branch for item in evidence]
    if len(set(branches)) != len(branches):
        raise RouteParentSelectionError("parent evidence contains duplicate branches")
    if "cora0" not in branches:
        raise RouteParentSelectionError("CORA0 evidence is required for a safe fallback")


def _confirmation_rank_key(
    item: ParentSupportEvidence,
) -> tuple[float, float, float, int, str]:
    return (
        -item.physical_support,
        -item.temporal_consistency,
        item.empty_false_alarm_rate,
        _BRANCH_COMPLEXITY[item.branch],
        item.branch,
    )


def _same_quality(left: ParentSupportEvidence, right: ParentSupportEvidence) -> bool:
    return (
        left.physical_support == right.physical_support
        and left.weak_candidate_agreement == right.weak_candidate_agreement
        and left.temporal_consistency == right.temporal_consistency
        and left.empty_false_alarm_rate == right.empty_false_alarm_rate
    )


def _relative_safety(
    item: ParentSupportEvidence, *, cora0: ParentSupportEvidence
) -> tuple[bool, tuple[str, ...]]:
    """Measure adaptation harm against the current CORA0 fallback.

    CORA0 is the immutable reference and remains available even when a route's
    natural temporal consistency is below an arbitrary global target.  An
    adapted branch may compete only when it stays within the authorized two
    percentage-point temporal budget and the stricter of the absolute and
    CORA0-relative empty-scene budgets.
    """

    if item.branch == "cora0":
        return True, ()
    reasons: list[str] = []
    if (
        item.temporal_consistency
        < cora0.temporal_consistency
        - _MAXIMUM_TEMPORAL_REGRESSION_FROM_CORA0
    ):
        reasons.append("temporal_regression_exceeds_0p02")
    empty_limit = min(
        _MAXIMUM_EMPTY_FALSE_ALARM_RATE,
        cora0.empty_false_alarm_rate
        + _MAXIMUM_EMPTY_FALSE_ALARM_INCREASE_FROM_CORA0,
    )
    if item.empty_false_alarm_rate > empty_limit:
        reasons.append("empty_false_alarm_regression_exceeds_budget")
    return not reasons, tuple(reasons)


def resolve_runtime_parent_branch(
    *, route: str,
    semantic_parent: str,
    selected_parent: str | None,
) -> str:
    """Resolve a concrete runtime parent from a semantic template declaration."""

    normalized_route = str(route).strip()
    semantic = str(semantic_parent).strip()
    selected = None if selected_parent is None else str(selected_parent).strip()
    if normalized_route == _RIS_ROUTE:
        if semantic != "cora0":
            raise RouteParentSelectionError("matched RIS semantic parent must be CORA0")
        if selected not in {None, "cora0"}:
            raise RouteParentSelectionError("cannot override matched RIS physical parent")
        return "cora0"
    if semantic != "route_selected":
        raise RouteParentSelectionError("direct expert semantic parent must defer to Support selection")
    if selected not in _DIRECT_BRANCHES:
        raise RouteParentSelectionError("direct expert requires a selected parent branch")
    return selected


def load_verified_parent_selection(
    *,
    candidate_result: Mapping[str, Any],
    expected_route: str,
    parent_checkpoint_sha256: Mapping[str, str],
) -> dict[str, Any]:
    """Load the Support-selected parent sealed into a route-pool result.

    Post-freeze evaluation must follow the branch that actually supplied the
    expert training runtime.  A route-level default is insufficient because
    CORA0, SE1, and SE2 are compared independently for every direct route.
    """

    route = str(expected_route).strip()
    if not route or route == _RIS_ROUTE:
        raise RouteParentSelectionError("direct route parent receipt required")
    read_audit = candidate_result.get("read_audit")
    if not isinstance(read_audit, Mapping) or any(bool(value) for value in read_audit.values()):
        raise RouteParentSelectionError("candidate result contains a forbidden read")
    native_path = Path(str(candidate_result.get("native_result_path", ""))).resolve()
    native_sha = _sha256(candidate_result.get("raw_result_sha256", ""), "raw_result_sha256")
    if not native_path.is_file() or _file_sha256(native_path) != native_sha:
        raise RouteParentSelectionError("route-pool training result hash mismatch")
    training = _load_json_object(native_path, "route-pool training result")
    if training.get("schema_version") != "agent_jsac_prospective_route_pool_training_v1":
        raise RouteParentSelectionError("unexpected route-pool training schema")
    if str(training.get("route", "")) != route:
        raise RouteParentSelectionError("route-pool training route mismatch")
    for field in (
        "development_read",
        "query_read",
        "locked_test_read",
        "target_final_bev_read",
        "raw_depth_read",
        "right_rgb_read",
        "manual_ra_anchor_read",
    ):
        if training.get(field) is not False:
            raise RouteParentSelectionError(f"route-pool training read guard failed: {field}")

    binding = training.get("parent_selection")
    lineage = training.get("source_lineage")
    if not isinstance(binding, Mapping) or not isinstance(lineage, Mapping):
        raise RouteParentSelectionError("route-pool result lacks parent binding")
    receipt_path = Path(str(binding.get("path", ""))).resolve()
    receipt_sha = _sha256(binding.get("sha256", ""), "parent_selection.sha256")
    if not receipt_path.is_file() or _file_sha256(receipt_path) != receipt_sha:
        raise RouteParentSelectionError("parent-selection receipt hash mismatch")
    receipt = _load_json_object(receipt_path, "parent-selection receipt")
    if receipt.get("schema_version") != "agent_jsac_route_parent_selection_receipt_v1":
        raise RouteParentSelectionError("unexpected parent-selection receipt schema")
    if not is_supported_parent_selection_policy(receipt.get("selection_policy_id")):
        raise RouteParentSelectionError("stale or unsupported parent-selection policy")
    selected = str(receipt.get("selected_parent_branch", ""))
    if selected not in _DIRECT_BRANCHES:
        raise RouteParentSelectionError("parent-selection receipt has no direct CORA branch")
    expected_checkpoint = _sha256(
        parent_checkpoint_sha256.get(selected, ""),
        f"parent_checkpoint_sha256[{selected}]",
    )
    selected_checkpoint = _sha256(
        receipt.get("selected_parent_checkpoint_sha256", ""),
        "selected_parent_checkpoint_sha256",
    )
    support_scope = _sha256(receipt.get("support_scope_sha256", ""), "support_scope_sha256")
    if (
        str(receipt.get("route", "")) != route
        or selected_checkpoint != expected_checkpoint
        or str(binding.get("selected_parent_branch", "")) != selected
        or str(lineage.get("selected_parent_branch", "")) != selected
        or str(binding.get("selected_parent_checkpoint_sha256", "")) != selected_checkpoint
        or str(lineage.get("selected_parent_checkpoint_sha256", "")) != selected_checkpoint
        or str(binding.get("support_scope_sha256", "")) != support_scope
    ):
        raise RouteParentSelectionError("selected parent is not bound to the current checkpoint lineage")
    forbidden = receipt.get("forbidden_reads")
    if not isinstance(forbidden, Mapping) or any(bool(value) for value in forbidden.values()):
        raise RouteParentSelectionError("parent-selection receipt contains a forbidden read")
    return receipt


def summarize_runtime_archives(
    archives: Sequence[Mapping[str, Any]],
    *,
    support_radius_m: float = 0.30,
    maximum_adjacent_step_m: float = 0.30,
) -> dict[str, Any]:
    """Measure one frozen parent against its sealed measured-candidate support.

    The archives contain no coordinate labels.  Slot zero is the parent
    coordinate; only slots one onward are treated as measured radar candidates.
    ``allowed_weight`` is an existing Support-set likelihood, not a generated
    coordinate target.
    """

    if not archives or support_radius_m <= 0.0 or maximum_adjacent_step_m <= 0.0:
        raise RouteParentSelectionError("runtime archives and positive radii are required")
    forbidden = (
        "development_label_read",
        "locked_test_read",
        "target_final_bev_read",
        "right_rgb_read",
        "depth_read",
    )
    support_weight = 0.0
    physical_hits = 0.0
    agreement_mass = 0.0
    continuity_hits = 0.0
    continuity_count = 0
    scope_rows: list[tuple[str, tuple[int, ...]]] = []
    for archive in archives:
        for field in forbidden:
            if bool(np.asarray(archive.get(field, False)).item()):
                raise RouteParentSelectionError(f"forbidden read in runtime archive: {field}")
        sequence = str(np.asarray(archive["sequence"]).item()).strip().lower()
        frame_id = np.asarray(archive["frame_id"], dtype=np.int64).reshape(-1)
        base = np.asarray(archive["base_xy_m"], dtype=np.float32)
        candidate_xy = np.asarray(archive["candidate_xy_m"], dtype=np.float32)
        candidate_valid = np.asarray(archive["candidate_valid"], dtype=bool)
        allowed_weight = np.asarray(archive["allowed_weight"], dtype=np.float32)
        sample_weight = np.asarray(archive["sample_weight"], dtype=np.float32).reshape(-1)
        if (
            base.shape != (len(frame_id), 2)
            or candidate_xy.ndim != 3
            or candidate_xy.shape[:2] != candidate_valid.shape
            or candidate_xy.shape[:2] != allowed_weight.shape
            or candidate_xy.shape[0] != len(frame_id)
            or candidate_xy.shape[1] < 2
            or sample_weight.shape != (len(frame_id),)
        ):
            raise RouteParentSelectionError("runtime archive shape mismatch")
        physical_xy = candidate_xy[:, 1:]
        physical_valid = candidate_valid[:, 1:] & np.isfinite(physical_xy).all(axis=-1)
        distance = np.linalg.norm(physical_xy - base[:, None, :], axis=-1)
        nearby = physical_valid & np.isfinite(distance) & (distance <= support_radius_m)
        weight = np.clip(sample_weight.astype(np.float64), 0.0, None)
        usable = weight > 0.0
        if usable.any():
            support_weight += float(weight[usable].sum())
            physical_hits += float((weight * nearby.any(axis=1)).sum())
            nearby_mass = np.where(nearby, allowed_weight[:, 1:], 0.0).sum(axis=1)
            agreement_mass += float((weight * np.clip(nearby_mass, 0.0, 1.0)).sum())
        if len(frame_id) > 1:
            consecutive = frame_id[1:] == frame_id[:-1] + 1
            finite = np.isfinite(base[1:]).all(axis=1) & np.isfinite(base[:-1]).all(axis=1)
            eligible = consecutive & finite
            if eligible.any():
                step = np.linalg.norm(base[1:] - base[:-1], axis=1)
                continuity_hits += float((step[eligible] <= maximum_adjacent_step_m).sum())
                continuity_count += int(eligible.sum())
        scope_rows.append((sequence, tuple(int(item) for item in frame_id)))
    if support_weight <= 0.0:
        raise RouteParentSelectionError("runtime support has no positive sample weight")
    canonical_scope = json.dumps(scope_rows, ensure_ascii=True, separators=(",", ":"))
    return {
        "support_scope_sha256": hashlib.sha256(canonical_scope.encode("ascii")).hexdigest(),
        "weighted_frames": support_weight,
        "physical_support": physical_hits / support_weight,
        "weak_candidate_agreement": agreement_mass / support_weight,
        "temporal_consistency": (
            1.0 if continuity_count == 0 else continuity_hits / float(continuity_count)
        ),
    }


def select_route_parent(*, route: str, evidence: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Select one safe parent from current Support-only evidence.

    For direct routes, every available branch is compared on the same sealed
    Support scope.  The selector rejects unsafe branches before ranking.  It
    uses the simpler branch only as a deterministic tie-breaker, never as a
    static route policy.  Matched RIS is explicitly fixed to CORA0 because its
    physical observation chain is separate from the direct branches.
    """

    normalized_route = str(route).strip()
    if not normalized_route:
        raise RouteParentSelectionError("route must not be empty")
    parsed = tuple(ParentSupportEvidence.from_mapping(item) for item in evidence)
    if not parsed:
        raise RouteParentSelectionError("parent evidence must not be empty")
    _validate_scope(parsed)

    by_branch = MappingProxyType({item.branch: item for item in parsed})
    cora0 = by_branch["cora0"]
    safety = {
        item.branch: _relative_safety(item, cora0=cora0) for item in parsed
    }
    if normalized_route == _RIS_ROUTE:
        if set(by_branch) != {"cora0"}:
            raise RouteParentSelectionError("matched RIS must provide CORA0 evidence only")
        selected = by_branch["cora0"]
        basis = "matched_ris_physical_parent"
        reason = "matched_ris_requires_cora0"
    else:
        safe = tuple(item for item in parsed if safety[item.branch][0])
        if not safe:
            raise RouteParentSelectionError("no parent passes temporal and empty-scene safety")
        best_agreement = max(item.weak_candidate_agreement for item in safe)
        confirmation_ties = sorted(
            (
                item
                for item in safe
                if best_agreement - item.weak_candidate_agreement
                <= _AGREEMENT_TIE_TOLERANCE
            ),
            key=_confirmation_rank_key,
        )
        selected = confirmation_ties[0]
        basis = "support_only_three_branch_confirmation_first"
        if len(safe) == 1:
            reason = "only_safe_parent"
        elif len(confirmation_ties) > 1 and _same_quality(
            confirmation_ties[0], confirmation_ties[1]
        ):
            reason = "safe_metric_tie_prefer_simpler_parent"
        elif len(confirmation_ties) > 1:
            reason = "agreement_tie_prefer_physical_temporal_safety"
        else:
            reason = "highest_safe_confirmed_candidate_agreement"

    return {
        "schema_version": "agent_jsac_route_parent_selection_receipt_v1",
        "selection_policy_id": PARENT_SELECTION_POLICY_ID,
        "route": normalized_route,
        "selection_basis": basis,
        "selection_reason": reason,
        "selected_parent_branch": selected.branch,
        "selected_parent_checkpoint_sha256": selected.checkpoint_sha256,
        "support_scope_sha256": selected.support_scope_sha256,
        "safety_reference": {
            "branch": "cora0",
            "cora0_temporal_consistency": cora0.temporal_consistency,
            "cora0_empty_false_alarm_rate": cora0.empty_false_alarm_rate,
            "maximum_temporal_regression": _MAXIMUM_TEMPORAL_REGRESSION_FROM_CORA0,
            "maximum_empty_false_alarm_increase": _MAXIMUM_EMPTY_FALSE_ALARM_INCREASE_FROM_CORA0,
            "maximum_absolute_empty_false_alarm_rate": _MAXIMUM_EMPTY_FALSE_ALARM_RATE,
        },
        "available_parent_evidence": [
            item.to_dict(
                safe=safety[item.branch][0],
                safety_reasons=safety[item.branch][1],
            )
            for item in sorted(parsed, key=lambda row: row.branch)
        ],
        "forbidden_reads": {field: False for field in _FORBIDDEN_READS},
    }


def select_frozen_parent_control(
    *,
    route: str,
    selected_parent_branch: str,
    evidence: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Bind a pre-registered historical parent for an isolated control run.

    This mode never changes the production Support selector.  It validates the
    same sealed evidence and forbidden-read contract, but deliberately holds
    the parent branch fixed so expert training can be isolated from parent
    selection.
    """

    normalized_route = str(route).strip()
    selected_branch = str(selected_parent_branch).strip()
    parsed = tuple(ParentSupportEvidence.from_mapping(item) for item in evidence)
    if not parsed:
        raise RouteParentSelectionError("parent evidence must not be empty")
    _validate_scope(parsed)
    by_branch = MappingProxyType({item.branch: item for item in parsed})
    if normalized_route == _RIS_ROUTE:
        if selected_branch != "cora0":
            raise RouteParentSelectionError("matched RIS requires CORA0")
    elif selected_branch not in _DIRECT_BRANCHES:
        raise RouteParentSelectionError("frozen control requires a direct CORA branch")
    if selected_branch not in by_branch:
        raise RouteParentSelectionError("frozen control branch lacks sealed Support evidence")
    if normalized_route != _RIS_ROUTE and set(by_branch) != set(_DIRECT_BRANCHES):
        raise RouteParentSelectionError(
            "direct frozen control must audit CORA0, SE1, and SE2"
        )

    cora0 = by_branch["cora0"]
    selected = by_branch[selected_branch]
    safety = {
        item.branch: _relative_safety(item, cora0=cora0) for item in parsed
    }
    return {
        "schema_version": "agent_jsac_route_parent_selection_receipt_v1",
        "selection_policy_id": FROZEN_PARENT_CONTROL_POLICY_ID,
        "route": normalized_route,
        "selection_basis": "preregistered_historical_frozen_parent_control",
        "selection_reason": "isolate_expert_training_from_parent_selection",
        "selected_parent_branch": selected.branch,
        "selected_parent_checkpoint_sha256": selected.checkpoint_sha256,
        "support_scope_sha256": selected.support_scope_sha256,
        "control_only": True,
        "runtime_promotion_allowed": False,
        "safety_reference": {
            "branch": "cora0",
            "cora0_temporal_consistency": cora0.temporal_consistency,
            "cora0_empty_false_alarm_rate": cora0.empty_false_alarm_rate,
            "maximum_temporal_regression": _MAXIMUM_TEMPORAL_REGRESSION_FROM_CORA0,
            "maximum_empty_false_alarm_increase": _MAXIMUM_EMPTY_FALSE_ALARM_INCREASE_FROM_CORA0,
            "maximum_absolute_empty_false_alarm_rate": _MAXIMUM_EMPTY_FALSE_ALARM_RATE,
        },
        "available_parent_evidence": [
            item.to_dict(
                safe=safety[item.branch][0],
                safety_reasons=safety[item.branch][1],
            )
            for item in sorted(parsed, key=lambda row: row.branch)
        ],
        "forbidden_reads": {field: False for field in _FORBIDDEN_READS},
    }
