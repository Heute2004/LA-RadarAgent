"""Fail-closed planning and Support-only ranking for route expert search.

This module deliberately has no training side effects.  It converts one constrained
Agent request into the fixed five fresh expert structures allowed for a route, and
deterministically ranks their already-audited shadow receipts.  The Dispatcher owns
all actual cache construction, training, Canary execution, promotion, and rollback.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Sequence


class RouteExpertSearchError(ValueError):
    """Raised when a search plan weakens the frozen prospective contract."""


_SCHEMA = "agent_jsac_route_expert_template_library_v1"
_POLICY_SCHEMA = "agent_jsac_route_expert_search_policy_v1"
_ROUTES = (
    "open_indoor_los",
    "indoor_clutter",
    "open_outdoor_weak_return",
    "outdoor_dry_complex",
    "outdoor_wet_return",
    "corner_nlos_ris",
)
_DIRECT_ROUTES = (
    "open_indoor_los",
    "indoor_clutter",
    "open_outdoor_weak_return",
    "outdoor_dry_complex",
    "outdoor_wet_return",
)
_DIRECT_PARENT_TOKEN = "route_selected"
_DIRECT_EVIDENCE = (
    "source_bev_replay",
    "empty_guard",
    "radar_candidate_set",
    "evolved_posterior",
)
_RIS_EVIDENCE = ("risecho",)
_TEMPLATE_KEYS = {
    "identifier",
    "primitive",
    "parent_branch",
    "required_evidence",
    "historical_checkpoint_import",
    "runtime_raw_depth_input",
    "target_final_bev_read",
    "offline_depth_soft_likelihood_allowed",
    "description",
}
_TOP_KEYS = {
    "schema_version",
    "route_parent_branches",
    "route_support_overrides",
    "routes",
}
_METRIC_KEYS = (
    "physical_support",
    "weak_label_agreement_delta",
    "trajectory_jump_delta",
    "empty_false_alarm_delta",
    "identity_regret",
    "directional_consistency",
    "p90_proxy_delta",
    "intervention_coverage",
)
_POLICY_THRESHOLD_KEYS = {
    "minimum_physical_support",
    "minimum_weak_label_agreement_delta",
    "maximum_trajectory_jump_delta",
    "maximum_empty_false_alarm_delta",
    "maximum_identity_regret",
    "minimum_directional_consistency",
    "maximum_p90_proxy_delta",
    "minimum_intervention_coverage",
}


def _sequence_list(value: object, field: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value or not all(isinstance(item, str) for item in value):
        raise RouteExpertSearchError(f"{field} must be a non-empty sequence list")
    result = tuple(str(item).strip().lower() for item in value)
    if any(not item.startswith("seq_") or len(item) != 7 for item in result):
        raise RouteExpertSearchError(f"{field} contains an invalid sequence")
    if len(set(result)) != len(result):
        raise RouteExpertSearchError(f"{field} contains duplicate sequences")
    return result


def _mapping(value: object, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise RouteExpertSearchError(f"{field} must be an object")
    return value


@dataclass(frozen=True)
class RouteExpertTemplate:
    identifier: str
    route: str
    primitive: str
    parent_branch: str
    required_evidence: tuple[str, ...]
    historical_checkpoint_import: bool
    runtime_raw_depth_input: bool
    target_final_bev_read: bool
    offline_depth_soft_likelihood_allowed: bool
    description: str


@dataclass(frozen=True)
class RouteExpertTemplateLibrary:
    routes: Mapping[str, tuple[RouteExpertTemplate, ...]]
    route_parent_branches: Mapping[str, str]
    route_support_overrides: Mapping[str, Mapping[str, tuple[str, ...]]]

    def branch_for(self, route: str) -> str:
        try:
            return self.route_parent_branches[route]
        except KeyError as error:
            raise RouteExpertSearchError(f"unknown route: {route}") from error


@dataclass(frozen=True)
class RouteExpertSearchPolicy:
    policy_id: str
    candidate_count_per_route: int
    admission_thresholds: Mapping[str, float]


def load_route_expert_search_policy(path: Path) -> RouteExpertSearchPolicy:
    """Load one complete admission policy for newly trained experts."""

    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise RouteExpertSearchError("route expert search policy is not valid JSON") from error
    value = _mapping(raw, "policy")
    required = {
        "schema_version",
        "policy_id",
        "candidate_count_per_route",
        "direct_runtime_topology",
        "ris_runtime_topology",
        "direct_training_evidence",
        "depth_policy",
        "forbidden_reads",
        "admission_thresholds",
        "ranking_order",
        "promotion_flow",
        "failure_action",
    }
    if set(value) != required or value.get("schema_version") != _POLICY_SCHEMA:
        raise RouteExpertSearchError("unsupported route expert search policy schema")
    if int(value["candidate_count_per_route"]) != 5:
        raise RouteExpertSearchError("route expert search policy requires five candidates per route")
    if value["direct_runtime_topology"] != "CORA0 -> route-selected {CORA-SE1, CORA-SE2} -> fresh route expert -> RouteBEV":
        raise RouteExpertSearchError("direct runtime topology does not attach after SE branches")
    if value["ris_runtime_topology"] != "CORA0 -> matched RISEcho -> fresh RIS specialist -> RouteBEV":
        raise RouteExpertSearchError("RIS runtime topology is invalid")
    if tuple(value["direct_training_evidence"]) != (
        "SourceBEV replay",
        "EmptyGuard",
        "RadarCandidateSet",
        "EvolvedPosterior",
    ):
        raise RouteExpertSearchError("direct training evidence contract mismatch")
    depth = _mapping(value["depth_policy"], "depth_policy")
    if depth != {
        "calibrated_depth_role": "offline_soft_range_likelihood_for_existing_candidate_reordering",
        "runtime_raw_depth_input": False,
        "free_coordinate_generation": False,
    }:
        raise RouteExpertSearchError("calibrated-depth policy is invalid")
    forbidden = _mapping(value["forbidden_reads"], "forbidden_reads")
    if any(bool(item) for item in forbidden.values()):
        raise RouteExpertSearchError("route expert policy enables a forbidden read")
    thresholds = _mapping(value["admission_thresholds"], "admission_thresholds")
    if set(thresholds) != _POLICY_THRESHOLD_KEYS:
        raise RouteExpertSearchError("route expert admission threshold fields mismatch")
    parsed = {key: float(thresholds[key]) for key in _POLICY_THRESHOLD_KEYS}
    if not all(math.isfinite(item) for item in parsed.values()):
        raise RouteExpertSearchError("route expert admission thresholds must be finite")
    return RouteExpertSearchPolicy(
        policy_id=str(value["policy_id"]),
        candidate_count_per_route=5,
        admission_thresholds=MappingProxyType(parsed),
    )


def load_route_expert_template_library(path: Path) -> RouteExpertTemplateLibrary:
    """Load a fixed five-candidate library without permitting historical imports."""

    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise RouteExpertSearchError("route expert template library is not valid JSON") from error
    value = _mapping(raw, "library")
    if set(value) != _TOP_KEYS or value.get("schema_version") != _SCHEMA:
        raise RouteExpertSearchError("unsupported route expert template library schema")

    raw_branches = _mapping(value["route_parent_branches"], "route_parent_branches")
    if set(raw_branches) != set(_ROUTES):
        raise RouteExpertSearchError("route parent branches must cover every route exactly once")
    branches = {route: str(raw_branches[route]) for route in _ROUTES}
    expected_branches = {
        **{route: _DIRECT_PARENT_TOKEN for route in _DIRECT_ROUTES},
        "corner_nlos_ris": "cora0",
    }
    if branches != expected_branches:
        raise RouteExpertSearchError("route parent branch map violates dynamic-direct/RIS topology")

    raw_overrides = _mapping(value["route_support_overrides"], "route_support_overrides")
    overrides: dict[str, Mapping[str, tuple[str, ...]]] = {}
    for route, record in raw_overrides.items():
        if route not in _DIRECT_ROUTES:
            raise RouteExpertSearchError("only direct source routes may define support overrides")
        record = _mapping(record, f"route_support_overrides.{route}")
        if set(record) != {"support_fit", "support_canary"}:
            raise RouteExpertSearchError("support override fields mismatch")
        fit = _sequence_list(record["support_fit"], f"{route}.support_fit")
        canary = _sequence_list(record["support_canary"], f"{route}.support_canary")
        if set(fit) & set(canary):
            raise RouteExpertSearchError("support override fit and Canary sets overlap")
        overrides[str(route)] = MappingProxyType({"support_fit": fit, "support_canary": canary})

    raw_routes = _mapping(value["routes"], "routes")
    if set(raw_routes) != set(_ROUTES):
        raise RouteExpertSearchError("template routes must cover every route exactly once")
    templates: dict[str, tuple[RouteExpertTemplate, ...]] = {}
    identifiers: set[str] = set()
    for route in _ROUTES:
        rows = raw_routes[route]
        if not isinstance(rows, list) or len(rows) != 5:
            raise RouteExpertSearchError(f"{route} requires exactly five fresh templates")
        parsed: list[RouteExpertTemplate] = []
        for index, item in enumerate(rows):
            record = _mapping(item, f"{route}[{index}]")
            if set(record) != _TEMPLATE_KEYS:
                raise RouteExpertSearchError(f"{route}[{index}] template fields mismatch")
            identifier = str(record["identifier"]).strip()
            if not identifier or identifier in identifiers:
                raise RouteExpertSearchError("expert template identifiers must be globally unique")
            identifiers.add(identifier)
            parent = str(record["parent_branch"])
            if parent != branches[route]:
                raise RouteExpertSearchError(f"{route} template has an illegal parent branch")
            required = tuple(str(item) for item in record["required_evidence"])
            expected = _RIS_EVIDENCE if route == "corner_nlos_ris" else _DIRECT_EVIDENCE
            if required != expected:
                raise RouteExpertSearchError(f"{route} template evidence contract mismatch")
            if record["historical_checkpoint_import"] is not False:
                raise RouteExpertSearchError("historical checkpoint import is forbidden")
            if record["runtime_raw_depth_input"] is not False:
                raise RouteExpertSearchError("raw depth is forbidden at expert runtime")
            if record["target_final_bev_read"] is not False:
                raise RouteExpertSearchError("Target Final-BEV access is forbidden")
            if not isinstance(record["offline_depth_soft_likelihood_allowed"], bool):
                raise RouteExpertSearchError("offline depth likelihood flag must be boolean")
            description = str(record["description"]).strip()
            if not description:
                raise RouteExpertSearchError("template description must not be empty")
            parsed.append(
                RouteExpertTemplate(
                    identifier=identifier,
                    route=route,
                    primitive=str(record["primitive"]),
                    parent_branch=parent,
                    required_evidence=required,
                    historical_checkpoint_import=False,
                    runtime_raw_depth_input=False,
                    target_final_bev_read=False,
                    offline_depth_soft_likelihood_allowed=bool(record["offline_depth_soft_likelihood_allowed"]),
                    description=description,
                )
            )
        templates[route] = tuple(parsed)
    return RouteExpertTemplateLibrary(
        routes=MappingProxyType(templates),
        route_parent_branches=MappingProxyType(branches),
        route_support_overrides=MappingProxyType(overrides),
    )


def _support_for_route(
    library: RouteExpertTemplateLibrary,
    route: str,
    episodes: Mapping[str, Any],
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    if route in library.route_support_overrides:
        override = library.route_support_overrides[route]
        return override["support_fit"], override["support_canary"]
    record = _mapping(episodes[route], f"episodes.{route}")
    return (
        _sequence_list(record["support_fit"], f"episodes.{route}.support_fit"),
        _sequence_list(record["support_canary"], f"episodes.{route}.support_canary"),
    )


def build_route_expert_search_plan(
    library: RouteExpertTemplateLibrary,
    episode_manifest: Mapping[str, Any],
    *,
    policy: RouteExpertSearchPolicy | None = None,
) -> dict[str, Any]:
    """Materialize the deterministic 30-candidate plan without side effects."""

    manifest = _mapping(episode_manifest, "episode_manifest")
    if manifest.get("schema_version") != "agent_jsac_prospective_episode_order_v1":
        raise RouteExpertSearchError("unexpected prospective episode manifest schema")
    routes = _mapping(manifest.get("routes"), "episode_manifest.routes")
    route_order = tuple(str(item) for item in manifest.get("route_order", ()))
    if set(route_order) != set(_ROUTES) or set(routes) != set(_ROUTES):
        raise RouteExpertSearchError("episode manifest does not cover the registered expert routes")

    expected_candidates = 5 if policy is None else policy.candidate_count_per_route
    candidates: list[dict[str, Any]] = []
    for route in _ROUTES:
        fit, canary = _support_for_route(library, route, routes)
        if set(fit) & set(canary):
            raise RouteExpertSearchError("Support fit and Canary sequences overlap")
        if len(library.routes[route]) != expected_candidates:
            raise RouteExpertSearchError("template count conflicts with search policy")
        for ordinal, template in enumerate(library.routes[route], start=1):
            candidates.append(
                {
                    "candidate_id": f"{route}--{ordinal:02d}--{template.identifier}",
                    "route": route,
                    "template_id": template.identifier,
                    "primitive": template.primitive,
                    "parent_branch": template.parent_branch,
                    "required_evidence": list(template.required_evidence),
                    "support_fit_sequences": list(fit),
                    "support_canary_sequences": list(canary),
                    "historical_checkpoint_import": False,
                    "runtime_raw_depth_input": False,
                    "target_final_bev_read": False,
                    "offline_depth_soft_likelihood_allowed": template.offline_depth_soft_likelihood_allowed,
                    "execution_weight": 0.0,
                    "identity_fallback": template.parent_branch,
                }
            )
    plan = {
        "schema_version": "agent_jsac_route_expert_search_plan_v1",
        "candidate_count": len(candidates),
        "candidates": candidates,
        "promotion_policy": "support_then_zero_weight_canary_then_one_route_winner_or_identity",
        "policy_id": None if policy is None else policy.policy_id,
    }
    if len(candidates) != 30:
        raise RouteExpertSearchError("search plan must contain thirty candidates")
    return plan


def apply_route_parent_selection(
    plan: Mapping[str, Any], selection_receipt: Mapping[str, Any]
) -> dict[str, Any]:
    """Bind one direct route's fresh candidates to its Support-selected parent.

    The plan retains semantic parent ``route_selected`` until the current
    Support receipt exists.  This function is the only place where that token
    becomes a concrete CORA0/SE1/SE2 runtime branch.
    """

    value = _mapping(plan, "route expert search plan")
    if value.get("schema_version") != "agent_jsac_route_expert_search_plan_v1":
        raise RouteExpertSearchError("only an unbound V1 search plan can receive a parent selection")
    receipt = _mapping(selection_receipt, "parent selection receipt")
    from .route_parent_selection import is_supported_parent_selection_policy

    selection_policy_id = str(receipt.get("selection_policy_id", ""))
    if not is_supported_parent_selection_policy(selection_policy_id):
        raise RouteExpertSearchError(
            "parent selection was produced by a stale or unknown policy"
        )
    route = str(receipt.get("route", ""))
    if route not in _DIRECT_ROUTES:
        raise RouteExpertSearchError("only direct routes use Support-selected parents")
    branch = str(receipt.get("selected_parent_branch", ""))
    if branch not in {"cora0", "cora_se1", "cora_se2"}:
        raise RouteExpertSearchError("parent selection has an unsupported concrete branch")
    for field in ("selected_parent_checkpoint_sha256", "support_scope_sha256"):
        digest = str(receipt.get(field, "")).lower()
        if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
            raise RouteExpertSearchError(f"parent selection has an invalid {field}")
    forbidden = _mapping(receipt.get("forbidden_reads"), "parent selection forbidden_reads")
    expected_forbidden = {
        "development_read",
        "locked_test_read",
        "target_final_bev_read",
        "right_rgb_read",
        "raw_depth_read",
    }
    if set(forbidden) != expected_forbidden or any(bool(value) for value in forbidden.values()):
        raise RouteExpertSearchError("parent selection enables a forbidden read")
    raw_candidates = value.get("candidates")
    if not isinstance(raw_candidates, list) or len(raw_candidates) != 30:
        raise RouteExpertSearchError("parent selection requires the complete semantic candidate plan")
    selected_count = 0
    updated: list[dict[str, Any]] = []
    for raw in raw_candidates:
        candidate = dict(_mapping(raw, "search candidate"))
        if str(candidate.get("route", "")) == route:
            if candidate.get("parent_branch") != _DIRECT_PARENT_TOKEN:
                raise RouteExpertSearchError("direct candidate has already lost its semantic parent binding")
            candidate["semantic_parent_branch"] = _DIRECT_PARENT_TOKEN
            candidate["parent_branch"] = branch
            candidate["identity_fallback"] = branch
            candidate["parent_selection"] = {
                "selection_policy_id": selection_policy_id,
                "selected_parent_checkpoint_sha256": str(receipt["selected_parent_checkpoint_sha256"]),
                "support_scope_sha256": str(receipt["support_scope_sha256"]),
            }
            selected_count += 1
        updated.append(candidate)
    if selected_count != 5:
        raise RouteExpertSearchError("parent selection must bind exactly five route candidates")
    return dict(value) | {"candidates": updated}


def bind_route_expert_plan_implementations(
    plan: Mapping[str, Any],
    bindings: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Bind every semantic candidate to one verified executable implementation.

    Planning and execution are intentionally separate, but an executable plan
    must never leave implementation resolution to the launcher.  The supplied
    bindings are expected to come from the already hash-verified execution
    registry; this function verifies their semantic identity before copying the
    implementation receipt into a V2 plan.
    """

    value = _mapping(plan, "route expert search plan")
    if value.get("schema_version") != "agent_jsac_route_expert_search_plan_v1":
        raise RouteExpertSearchError("only an unbound V1 search plan can be bound")
    raw_candidates = value.get("candidates")
    if not isinstance(raw_candidates, list) or len(raw_candidates) != 30:
        raise RouteExpertSearchError("implementation binding requires thirty candidates")
    template_ids = tuple(str(candidate.get("template_id", "")) for candidate in raw_candidates)
    if any(not template_id for template_id in template_ids) or len(set(template_ids)) != len(template_ids):
        raise RouteExpertSearchError("search plan template identifiers are invalid")
    if set(bindings) != set(template_ids):
        raise RouteExpertSearchError("implementation bindings must cover every planned template exactly once")

    bound_candidates: list[dict[str, Any]] = []
    implementation_ids: set[str] = set()
    for candidate in raw_candidates:
        template_id = str(candidate["template_id"])
        binding = _mapping(bindings[template_id], f"bindings.{template_id}")
        for field in ("route", "primitive"):
            if str(binding.get(field, "")) != str(candidate.get(field, "")):
                raise RouteExpertSearchError(f"implementation {field} mismatch for {template_id}")
        semantic_parent = str(candidate.get("semantic_parent_branch", candidate.get("parent_branch", "")))
        binding_parent = str(binding.get("parent_branch", ""))
        if binding_parent != semantic_parent:
            raise RouteExpertSearchError(f"implementation parent_branch mismatch for {template_id}")
        if semantic_parent == _DIRECT_PARENT_TOKEN:
            actual_parent = str(candidate.get("parent_branch", ""))
            if actual_parent != _DIRECT_PARENT_TOKEN and actual_parent not in {
                "cora0",
                "cora_se1",
                "cora_se2",
            }:
                raise RouteExpertSearchError(f"selected runtime parent is invalid for {template_id}")
        elif str(candidate.get("parent_branch", "")) != binding_parent:
            raise RouteExpertSearchError(f"implementation parent_branch mismatch for {template_id}")
        implementation_id = str(binding.get("implementation_id", "")).strip()
        entrypoint = str(binding.get("entrypoint_relative_path", "")).replace("\\", "/").strip()
        digest = str(binding.get("entrypoint_sha256", "")).lower()
        output_contract = str(binding.get("output_contract", "")).strip()
        if not implementation_id or implementation_id in implementation_ids:
            raise RouteExpertSearchError("implementation identifiers must be non-empty and unique")
        if not entrypoint or Path(entrypoint).is_absolute() or ".." in Path(entrypoint).parts:
            raise RouteExpertSearchError("implementation entrypoint must be a safe relative path")
        if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
            raise RouteExpertSearchError("implementation entrypoint SHA256 is invalid")
        if not output_contract:
            raise RouteExpertSearchError("implementation output contract is missing")
        implementation_ids.add(implementation_id)
        bound_candidates.append(
            dict(candidate)
            | {
                "implementation_id": implementation_id,
                "entrypoint_relative_path": entrypoint,
                "entrypoint_sha256": digest,
                "output_contract": output_contract,
            }
        )

    return (
        dict(value)
        | {
            "schema_version": "agent_jsac_route_expert_search_plan_v2",
            "implementation_binding": "hash_bound_registered_execution_library",
            "candidates": bound_candidates,
        }
    )


def _metric(value: Mapping[str, Any], key: str) -> float:
    try:
        result = float(value[key])
    except (KeyError, TypeError, ValueError) as error:
        raise RouteExpertSearchError(f"candidate audit lacks numeric {key}") from error
    if not math.isfinite(result):
        raise RouteExpertSearchError(f"candidate audit contains non-finite {key}")
    return result


def _survives(
    value: Mapping[str, Any], policy: RouteExpertSearchPolicy | None = None
) -> bool:
    thresholds = (
        {
            "minimum_physical_support": 0.95,
            "minimum_weak_label_agreement_delta": 0.0,
            "maximum_trajectory_jump_delta": 0.0,
            "maximum_empty_false_alarm_delta": 0.005,
            "maximum_identity_regret": 0.01,
            "minimum_directional_consistency": 0.75,
            "maximum_p90_proxy_delta": 0.0,
            "minimum_intervention_coverage": 0.05,
        }
        if policy is None
        else policy.admission_thresholds
    )
    return (
        _metric(value, "physical_support") >= thresholds["minimum_physical_support"]
        and _metric(value, "weak_label_agreement_delta") >= thresholds["minimum_weak_label_agreement_delta"]
        and _metric(value, "trajectory_jump_delta") <= thresholds["maximum_trajectory_jump_delta"]
        and _metric(value, "empty_false_alarm_delta") <= thresholds["maximum_empty_false_alarm_delta"]
        and _metric(value, "identity_regret") <= thresholds["maximum_identity_regret"]
        and _metric(value, "directional_consistency") >= thresholds["minimum_directional_consistency"]
        and _metric(value, "p90_proxy_delta") <= thresholds["maximum_p90_proxy_delta"]
        and _metric(value, "intervention_coverage") >= thresholds["minimum_intervention_coverage"]
    )


def rank_surviving_candidates(
    candidates: Sequence[Mapping[str, Any]],
    *,
    policy: RouteExpertSearchPolicy | None = None,
) -> Mapping[str, Any] | None:
    """Choose a safe Support winner, or return exact branch identity fallback."""

    survivors = [candidate for candidate in candidates if _survives(candidate, policy)]
    if not survivors:
        return None
    return max(
        survivors,
        key=lambda candidate: (
            _metric(candidate, "physical_support"),
            -_metric(candidate, "trajectory_jump_delta"),
            _metric(candidate, "weak_label_agreement_delta"),
            -_metric(candidate, "p90_proxy_delta"),
            -_metric(candidate, "intervention_coverage"),
            str(candidate.get("candidate_id", "")),
        ),
    )
