"""Hash-bound execution bindings for prospective route-expert primitives.

The semantic template library says *which* expert mechanism is eligible for a
route.  This registry says exactly *which current-project code* implements it.
It prevents a language model, launcher, or future maintainer from silently
substituting an old script, reusing one generic implementation under many names,
or returning a free BEV coordinate between measured radar candidates.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from .route_expert_search import RouteExpertTemplateLibrary
from .route_expert_recipe_registry import recipe_for_implementation


class RouteExpertExecutionRegistryError(ValueError):
    """Raised when a semantic primitive cannot be executed safely."""


_SCHEMA = "agent_jsac_registered_route_expert_execution_library_v2"
_DEFAULT_OUTPUT_CONTRACT = "identity_or_discrete_current_radar_candidate"
_RECIPE_OUTPUT_CONTRACT = {
    "branch_router": "identity_or_frozen_cora_branch_coordinate",
}
_ENTRY_KEYS = {
    "template_id",
    "primitive",
    "route",
    "parent_branch",
    "implementation_id",
    "entrypoint",
    "output_contract",
    "required_evidence",
    "forbidden_reads",
    "identity_fallback",
    "historical_algorithm_reference",
}
_TOP_KEYS = {
    "schema_version",
    "template_library",
    "canonical_supervision_registry",
    "zero_weight_training_policy",
    "route_training_bindings",
    "shared_entrypoint_core",
    "application_contracts",
    "entries",
}
_ZERO_WEIGHT_TRAINING_POLICY_KEYS = {
    "historical_postfoundation_checkpoint_import",
    "historical_code_reuse",
    "historical_metrics_or_predictions_as_training_targets",
    "all_selected_entries_must_emit_recipe_receipt",
    "all_selected_entries_must_use_a_fresh_parent_from_same_lineage",
}
_FORBIDDEN_READS = {
    "target_final_bev_read",
    "development_label_read",
    "locked_test_read",
    "raw_depth_read",
    "right_rgb_read",
    "manual_ra_anchor_read",
    "historical_checkpoint_import",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _mapping(value: object, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise RouteExpertExecutionRegistryError(f"{field} must be an object")
    return value


@dataclass(frozen=True)
class RegisteredRouteExpert:
    """One resolved, current-project-only semantic expert implementation."""

    template_id: str
    primitive: str
    route: str
    parent_branch: str
    implementation_id: str
    entrypoint_relative_path: str
    entrypoint_path: Path
    entrypoint_sha256: str
    output_contract: str
    application_contract: Mapping[str, Any]
    required_evidence: tuple[str, ...]
    identity_fallback: str
    historical_algorithm_reference: Mapping[str, str]

    def public_receipt(self) -> dict[str, object]:
        """Return the minimal semantic receipt that can be exposed to Qwen memory."""

        return {
            "route": self.route,
            "primitive": self.primitive,
            "template_id": self.template_id,
            "implementation_id": self.implementation_id,
            "output_contract": self.output_contract,
            "application_contract": dict(self.application_contract),
            "identity_fallback": self.identity_fallback,
        }


@dataclass(frozen=True)
class RouteExpertExecutionLibrary:
    """Complete immutable primitive-to-entrypoint registry."""

    entries: tuple[RegisteredRouteExpert, ...]
    _by_route_primitive: Mapping[tuple[str, str], RegisteredRouteExpert]
    _by_primitive: Mapping[str, RegisteredRouteExpert]
    shared_entrypoint_core_path: Path
    shared_entrypoint_core_sha256: str

    @property
    def primitives(self) -> tuple[str, ...]:
        return tuple(sorted(self._by_primitive))

    def resolve(self, *, route: str, primitive: str) -> RegisteredRouteExpert:
        try:
            return self._by_route_primitive[(str(route), str(primitive))]
        except KeyError as error:
            if str(primitive) in self._by_primitive:
                raise RouteExpertExecutionRegistryError(
                    f"primitive {primitive!r} is not registered for route {route!r}"
                ) from error
            raise RouteExpertExecutionRegistryError(f"unregistered route-expert primitive: {primitive!r}") from error


def _template_index(template_library: RouteExpertTemplateLibrary) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for route, templates in template_library.routes.items():
        for template in templates:
            if template.identifier in result:
                raise RouteExpertExecutionRegistryError("template library contains duplicate identifiers")
            result[template.identifier] = (route, template)
    return result


def _resolve_entrypoint(project_root: Path, raw: Mapping[str, Any]) -> tuple[str, Path, str]:
    if set(raw) != {"path", "sha256"}:
        raise RouteExpertExecutionRegistryError("entrypoint must contain exactly path and sha256")
    relative_path = str(raw["path"]).replace("\\", "/")
    relative = Path(relative_path)
    if not relative.parts or relative.is_absolute() or ".." in relative.parts:
        raise RouteExpertExecutionRegistryError("entrypoint path must be a safe project-relative path")
    entrypoint = (project_root / relative).resolve()
    try:
        entrypoint.relative_to(project_root)
    except ValueError as error:
        raise RouteExpertExecutionRegistryError("entrypoint path escapes project root") from error
    if not entrypoint.is_file():
        raise RouteExpertExecutionRegistryError(f"entrypoint script is missing: {relative_path}")
    expected = str(raw["sha256"]).lower()
    if len(expected) != 64 or any(char not in "0123456789abcdef" for char in expected):
        raise RouteExpertExecutionRegistryError("entrypoint SHA256 must be a lowercase 64-character hex digest")
    actual = _sha256(entrypoint)
    if actual != expected:
        raise RouteExpertExecutionRegistryError(
            f"entrypoint SHA256 mismatch: {relative_path}; expected {expected}, got {actual}"
        )
    return relative_path, entrypoint, actual


def _validate_application_contract(raw: object, *, field: str) -> Mapping[str, Any]:
    contract = _mapping(raw, field)
    expected = {
        "mode",
        "posterior_scale",
        "maximum_correction_m",
        "identity_fallback_required",
    }
    if set(contract) != expected:
        raise RouteExpertExecutionRegistryError(f"{field} fields mismatch")
    mode = str(contract["mode"])
    scale = contract["posterior_scale"]
    maximum = contract["maximum_correction_m"]
    if not isinstance(scale, (int, float)) or not math.isfinite(float(scale)):
        raise RouteExpertExecutionRegistryError(f"{field} posterior_scale must be finite")
    scale = float(scale)
    if contract["identity_fallback_required"] is not True:
        raise RouteExpertExecutionRegistryError(f"{field} must require identity fallback")
    if mode in {"exact_observed_candidate", "exact_frozen_branch"}:
        if scale != 1.0 or maximum is not None:
            raise RouteExpertExecutionRegistryError(
                f"{field} exact discrete-selection contract is inconsistent"
            )
        maximum_value = None
    elif mode == "bounded_convex_candidate_update":
        if not 0.0 < scale <= 1.0:
            raise RouteExpertExecutionRegistryError(
                f"{field} posterior_scale must lie in (0, 1]"
            )
        if (
            not isinstance(maximum, (int, float))
            or not math.isfinite(float(maximum))
            or float(maximum) <= 0.0
        ):
            raise RouteExpertExecutionRegistryError(
                f"{field} maximum_correction_m must be positive and finite"
            )
        maximum_value = float(maximum)
    else:
        raise RouteExpertExecutionRegistryError(f"{field} mode is unsupported")
    return MappingProxyType(
        {
            "mode": mode,
            "posterior_scale": scale,
            "maximum_correction_m": maximum_value,
            "identity_fallback_required": True,
        }
    )


def validate_application_contract(raw: object) -> dict[str, Any]:
    """Return a portable validated application contract."""

    return dict(_validate_application_contract(raw, field="application_contract"))


def _pool_42_application_contract(
    *, project_root: Path, implementation_id: str
) -> dict[str, Any]:
    """Resolve newly registered Pool-42 implementations with integrity checks."""

    pool_path = project_root / "configs" / "expert_pool_42.json"
    try:
        pool = json.loads(pool_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise RouteExpertExecutionRegistryError(
            "expert_pool_42 is not valid JSON"
        ) from error
    if (
        not isinstance(pool, Mapping)
        or pool.get("schema_version") != "agent_jsac_expert_pool_42_v1"
        or pool.get("pool_size") != 42
        or not isinstance(pool.get("experts"), list)
        or len(pool["experts"]) != 42
    ):
        raise RouteExpertExecutionRegistryError("expert_pool_42 contract is invalid")
    matches = [
        row
        for row in pool["experts"]
        if isinstance(row, Mapping)
        and str(row.get("implementation_id", "")) == str(implementation_id)
    ]
    if len(matches) != 1:
        raise RouteExpertExecutionRegistryError(
            f"implementation has no unique application contract: {implementation_id!r}"
        )
    row = matches[0]
    if (
        row.get("historical_checkpoint_import") is not False
        or row.get("runtime_raw_depth_input") is not False
        or row.get("target_final_bev_read") is not False
    ):
        raise RouteExpertExecutionRegistryError(
            f"expert_pool_42 implementation enables a forbidden source: {implementation_id!r}"
        )
    relative = Path(str(row.get("entrypoint_relative_path", "")))
    if not relative.parts or relative.is_absolute() or ".." in relative.parts:
        raise RouteExpertExecutionRegistryError(
            f"expert_pool_42 entrypoint is unsafe: {implementation_id!r}"
        )
    entrypoint = (project_root / relative).resolve()
    try:
        entrypoint.relative_to(project_root)
    except ValueError as error:
        raise RouteExpertExecutionRegistryError(
            f"expert_pool_42 entrypoint escapes project root: {implementation_id!r}"
        ) from error
    expected_sha256 = str(row.get("entrypoint_sha256", "")).lower()
    if not entrypoint.is_file() or _sha256(entrypoint) != expected_sha256:
        raise RouteExpertExecutionRegistryError(
            f"expert_pool_42 entrypoint integrity mismatch: {implementation_id!r}"
        )
    return dict(
        _validate_application_contract(
            row.get("application_contract"),
            field=f"expert_pool_42.{implementation_id}.application_contract",
        )
    )


def application_contract_for_implementation(
    *, project_root: Path, implementation_id: str
) -> dict[str, Any]:
    """Resolve one implementation's hash-bound application behavior."""

    root = Path(project_root).resolve()
    from .route_expert_search import load_route_expert_template_library

    library = load_registered_route_expert_execution_library(
        root / "configs" / "registered_route_expert_execution_library.json",
        template_library=load_route_expert_template_library(
            root / "configs" / "route_expert_template_library_v1.json"
        ),
        project_root=root,
    )
    matches = [
        entry
        for entry in library.entries
        if entry.implementation_id == str(implementation_id)
    ]
    if len(matches) > 1:
        raise RouteExpertExecutionRegistryError(
            f"implementation has no unique application contract: {implementation_id!r}"
        )
    if len(matches) == 1:
        return dict(matches[0].application_contract)
    return _pool_42_application_contract(
        project_root=root,
        implementation_id=str(implementation_id),
    )


def load_registered_route_expert_execution_library(
    path: Path,
    *,
    template_library: RouteExpertTemplateLibrary,
    project_root: Path,
) -> RouteExpertExecutionLibrary:
    """Load a complete, hash-verified one-to-one execution registry."""

    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise RouteExpertExecutionRegistryError("execution registry is not valid JSON") from error
    root = Path(project_root).resolve()
    value = _mapping(raw, "execution registry")
    if set(value) != _TOP_KEYS or value.get("schema_version") != _SCHEMA:
        raise RouteExpertExecutionRegistryError("unsupported execution registry schema")
    if value.get("template_library") != "configs/route_expert_template_library_v1.json":
        raise RouteExpertExecutionRegistryError("execution registry is bound to an unexpected semantic template library")
    supervision_registry = str(value["canonical_supervision_registry"])
    if not supervision_registry.startswith("configs/") or not (root / supervision_registry).is_file():
        raise RouteExpertExecutionRegistryError("execution registry lacks a readable canonical supervision registry")
    zero_weight_policy = _mapping(
        value["zero_weight_training_policy"], "zero_weight_training_policy"
    )
    if set(zero_weight_policy) != _ZERO_WEIGHT_TRAINING_POLICY_KEYS:
        raise RouteExpertExecutionRegistryError("zero_weight_training_policy fields mismatch")
    if (
        zero_weight_policy["historical_postfoundation_checkpoint_import"] is not False
        or zero_weight_policy["historical_metrics_or_predictions_as_training_targets"] is not False
        or zero_weight_policy["all_selected_entries_must_emit_recipe_receipt"] is not True
        or zero_weight_policy["all_selected_entries_must_use_a_fresh_parent_from_same_lineage"] is not True
        or zero_weight_policy["historical_code_reuse"] != "algorithmic_structure_only"
    ):
        raise RouteExpertExecutionRegistryError("zero-weight training policy is unsafe")
    route_bindings = _mapping(value["route_training_bindings"], "route_training_bindings")
    _, core_path, core_digest = _resolve_entrypoint(
        root, _mapping(value["shared_entrypoint_core"], "shared_entrypoint_core")
    )
    application_contracts = _mapping(
        value["application_contracts"], "application_contracts"
    )
    if set(application_contracts) != {"default", "overrides"}:
        raise RouteExpertExecutionRegistryError("application_contracts fields mismatch")
    default_application = _validate_application_contract(
        application_contracts["default"], field="application_contracts.default"
    )
    raw_overrides = _mapping(
        application_contracts["overrides"], "application_contracts.overrides"
    )
    application_overrides = {
        str(implementation_id): _validate_application_contract(
            contract,
            field=f"application_contracts.overrides.{implementation_id}",
        )
        for implementation_id, contract in raw_overrides.items()
    }
    rows = value.get("entries")
    if not isinstance(rows, list):
        raise RouteExpertExecutionRegistryError("execution registry entries must be a list")

    templates = _template_index(template_library)
    if set(route_bindings) != set(template_library.routes):
        raise RouteExpertExecutionRegistryError("route_training_bindings must cover every semantic route")
    for route, binding in route_bindings.items():
        binding_value = _mapping(binding, f"route_training_bindings.{route}")
        required_binding_fields = {
            "parent_branch",
            "supervision_recipe",
            "allowed_historical_structure",
        }
        if not required_binding_fields.issubset(binding_value):
            raise RouteExpertExecutionRegistryError(
                f"route_training_bindings.{route} lacks required provenance fields"
            )
        if not all(isinstance(binding_value[field], str) and binding_value[field] for field in required_binding_fields):
            raise RouteExpertExecutionRegistryError(
                f"route_training_bindings.{route} has invalid provenance fields"
            )
    if len(rows) != len(templates):
        raise RouteExpertExecutionRegistryError("execution registry must cover every template exactly once")

    seen_templates: set[str] = set()
    seen_primitives: set[str] = set()
    seen_implementation_ids: set[str] = set()
    seen_entrypoints: set[str] = set()
    entries: list[RegisteredRouteExpert] = []
    for index, raw_entry in enumerate(rows):
        entry = _mapping(raw_entry, f"entries[{index}]")
        if set(entry) != _ENTRY_KEYS:
            raise RouteExpertExecutionRegistryError(f"entries[{index}] has unsupported fields")
        template_id = str(entry["template_id"])
        try:
            route, template = templates[template_id]
        except KeyError as error:
            raise RouteExpertExecutionRegistryError(f"unknown template_id: {template_id!r}") from error
        if template_id in seen_templates:
            raise RouteExpertExecutionRegistryError("execution registry contains duplicate template_id")
        seen_templates.add(template_id)
        primitive = str(entry["primitive"])
        if primitive != template.primitive or primitive in seen_primitives:
            raise RouteExpertExecutionRegistryError("execution registry primitive must match one unique semantic template")
        seen_primitives.add(primitive)
        if str(entry["route"]) != route or str(entry["parent_branch"]) != template.parent_branch:
            raise RouteExpertExecutionRegistryError("execution registry route or parent branch does not match semantic template")
        if tuple(entry["required_evidence"]) != template.required_evidence:
            raise RouteExpertExecutionRegistryError("execution registry evidence contract does not match semantic template")
        if str(entry["identity_fallback"]) != template.parent_branch:
            raise RouteExpertExecutionRegistryError("execution registry identity fallback does not match parent branch")
        implementation_id = str(entry["implementation_id"])
        expected_output_contract = _RECIPE_OUTPUT_CONTRACT.get(
            recipe_for_implementation(implementation_id), _DEFAULT_OUTPUT_CONTRACT
        )
        if str(entry["output_contract"]) != expected_output_contract:
            raise RouteExpertExecutionRegistryError(
                "execution registry output contract does not match its executable recipe"
            )
        forbidden = _mapping(entry["forbidden_reads"], f"entries[{index}].forbidden_reads")
        if set(forbidden) != _FORBIDDEN_READS or any(bool(value) for value in forbidden.values()):
            raise RouteExpertExecutionRegistryError("execution registry enables a forbidden read")
        if not implementation_id or implementation_id in seen_implementation_ids:
            raise RouteExpertExecutionRegistryError("execution registry implementation_id must be globally unique")
        seen_implementation_ids.add(implementation_id)
        relative_path, entrypoint_path, digest = _resolve_entrypoint(root, _mapping(entry["entrypoint"], "entrypoint"))
        if relative_path in seen_entrypoints:
            raise RouteExpertExecutionRegistryError("execution registry entrypoint must be one-to-one with a semantic primitive")
        seen_entrypoints.add(relative_path)
        reference = _mapping(entry["historical_algorithm_reference"], "historical_algorithm_reference")
        if set(reference) != {"source_script", "source_sha256", "reuse_scope"}:
            raise RouteExpertExecutionRegistryError("historical algorithm reference fields mismatch")
        if str(reference["reuse_scope"]) != "algorithmic_structure_only_no_weights_or_results":
            raise RouteExpertExecutionRegistryError("historical algorithm reference has an unsafe reuse scope")
        entries.append(
            RegisteredRouteExpert(
                template_id=template_id,
                primitive=primitive,
                route=route,
                parent_branch=template.parent_branch,
                implementation_id=implementation_id,
                entrypoint_relative_path=relative_path,
                entrypoint_path=entrypoint_path,
                entrypoint_sha256=digest,
                output_contract=expected_output_contract,
                application_contract=application_overrides.get(
                    implementation_id, default_application
                ),
                required_evidence=template.required_evidence,
                identity_fallback=template.parent_branch,
                historical_algorithm_reference=MappingProxyType({str(key): str(value) for key, value in reference.items()}),
            )
        )
    if seen_templates != set(templates):
        raise RouteExpertExecutionRegistryError("execution registry does not cover every semantic template")
    unknown_overrides = set(application_overrides) - seen_implementation_ids
    if unknown_overrides:
        raise RouteExpertExecutionRegistryError(
            "application contract override references an unknown implementation_id"
        )
    by_pair = {(item.route, item.primitive): item for item in entries}
    by_primitive = {item.primitive: item for item in entries}
    return RouteExpertExecutionLibrary(
        entries=tuple(entries),
        _by_route_primitive=MappingProxyType(by_pair),
        _by_primitive=MappingProxyType(by_primitive),
        shared_entrypoint_core_path=core_path,
        shared_entrypoint_core_sha256=core_digest,
    )
