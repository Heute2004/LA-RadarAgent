"""Contracts for one-shot Development evaluation of Agent-selected Shadows.

The Agent can select a zero-weight Shadow candidate after a label-free Canary.
This module keeps the subsequent Development pass honest: route choices are
validated before inference, predictions are frozen before labels are opened,
and no Locked Test sequence can enter the evaluation scope.
"""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping, Sequence

from .route_expert_execution_registry import validate_application_contract


class AgentShadowDevelopmentError(ValueError):
    """Raised when a Development evaluation violates the frozen Agent contract."""


ROUTE_ORDER = (
    "open_indoor_los",
    "indoor_clutter",
    "open_outdoor_weak_return",
    "outdoor_dry_complex",
    "outdoor_wet_return",
    "corner_nlos_ris",
)

ROUTE_PARENT_BRANCH = {
    "open_indoor_los": "cora_se1",
    "indoor_clutter": "cora_se2",
    "open_outdoor_weak_return": "cora_se1",
    "outdoor_dry_complex": "cora_se2",
    "outdoor_wet_return": "cora_se2",
    "corner_nlos_ris": "cora0",
}

_CORA_BRANCHES = frozenset(ROUTE_PARENT_BRANCH.values())

LOCKED_TEST_SEQUENCE_NUMBERS = frozenset({5, 11, 20, 32, 52, 118, 132, 153})

_SAFE_RUNTIME_RECORD_FIELDS = frozenset(
    {
        "sequence",
        "v3_split",
        "empty_site",
        "scene_geometry",
        "acquisition_group",
        "radar_context",
        "weather",
        "illumination",
        "role",
    }
)


def file_sha256(path: Path) -> str:
    return sha256(Path(path).read_bytes()).hexdigest()


def sequence_number(sequence: str) -> int:
    normalized = str(sequence).strip().lower()
    if not normalized.startswith("seq_") or len(normalized) != 7 or not normalized[4:].isdigit():
        raise AgentShadowDevelopmentError(f"invalid sequence identifier: {sequence!r}")
    return int(normalized[4:])


def validate_development_query_sequences(sequences: Sequence[str]) -> tuple[str, ...]:
    normalized = tuple(str(item).strip().lower() for item in sequences)
    if not normalized or len(normalized) != len(set(normalized)):
        raise AgentShadowDevelopmentError("Development query sequences must be nonempty and unique")
    locked = [item for item in normalized if sequence_number(item) in LOCKED_TEST_SEQUENCE_NUMBERS]
    if locked:
        raise AgentShadowDevelopmentError(f"Locked Test sequences are forbidden: {locked}")
    return normalized


def resolve_sequence_runtime_policy(
    *,
    sequence: str,
    route: str,
    runtime_overrides: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    """Resolve a sequence runtime independently from its paper-facing route.

    Route names remain useful for reporting, while a configuration-level
    override can bind a sequence to a different frozen CORA branch or force
    identity execution. This prevents scene taxonomy from silently changing
    the historically validated inference path.
    """

    normalized_sequence = str(sequence).strip().lower()
    normalized_route = str(route).strip()
    if normalized_route not in ROUTE_PARENT_BRANCH:
        raise AgentShadowDevelopmentError(f"unknown runtime route: {route!r}")
    raw = runtime_overrides.get(normalized_sequence)
    if raw is None:
        return {
            "parent_branch": ROUTE_PARENT_BRANCH[normalized_route],
            "expert_enabled": True,
            "source": "route_default",
        }
    if not isinstance(raw, Mapping):
        raise AgentShadowDevelopmentError("sequence runtime override must be a mapping")
    allowed = {"parent_branch", "expert_policy", "paper_route", "reason"}
    unknown = sorted(set(raw) - allowed)
    if unknown:
        raise AgentShadowDevelopmentError(f"unknown sequence runtime override fields: {unknown}")
    if "paper_route" in raw and str(raw["paper_route"]) != normalized_route:
        raise AgentShadowDevelopmentError("sequence runtime override paper route mismatch")
    parent_branch = str(raw.get("parent_branch", ROUTE_PARENT_BRANCH[normalized_route]))
    if parent_branch not in _CORA_BRANCHES:
        raise AgentShadowDevelopmentError(f"invalid CORA parent branch: {parent_branch!r}")
    expert_policy = str(raw.get("expert_policy", "route_selected"))
    if expert_policy not in {"route_selected", "identity"}:
        raise AgentShadowDevelopmentError(f"invalid expert policy: {expert_policy!r}")
    return {
        "parent_branch": parent_branch,
        "expert_enabled": expert_policy == "route_selected",
        "source": "sequence_override",
    }


def build_label_blind_runtime_records(
    query_sequences: Sequence[str],
    known_records: Mapping[str, Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Resolve radar input records without carrying target labels or coordinates.

    Some legitimate Development queries were intentionally absent from the
    self-evolution support manifest.  Their raw RA/RA-MTI frames still live at
    the canonical ``Data_train/seq_xxx/Radar`` path, so the Agent needs only a
    sequence identifier to construct an input reader.  Existing records are
    reduced to an allowlist of descriptive metadata before use.
    """

    sequences = validate_development_query_sequences(query_sequences)
    resolved: dict[str, dict[str, Any]] = {}
    for sequence in sequences:
        raw = known_records.get(sequence)
        if raw is None:
            resolved[sequence] = {
                "sequence": sequence,
                "role": "development_query_radar_input_only",
                "runtime_supervision": "none",
            }
            continue
        record = {
            key: value
            for key, value in raw.items()
            if key in _SAFE_RUNTIME_RECORD_FIELDS and key != "sequence"
        }
        record["sequence"] = sequence
        if "role" not in record:
            record["role"] = "development_query_radar_input_only"
        resolved[sequence] = record
    return resolved


def resolve_shadow_checkpoint_runtime(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Resolve one sealed Shadow checkpoint to its exact inference contract.

    Direct-route checkpoints use the registered implementation metadata added
    by the current expert entrypoint.  The selected frozen RIS gate predates
    that registry and is a structurally different ``SEBranchCandidateExpert``.
    Its compatibility exception is deliberately narrow: no other legacy
    checkpoint may enter the Development evaluator by inference or guessing.
    """

    kwargs = payload.get("model_kwargs")
    state = payload.get("model_state")
    if not isinstance(kwargs, Mapping) or not isinstance(state, Mapping):
        raise AgentShadowDevelopmentError("Shadow checkpoint lacks model metadata or state")
    if payload.get("schema_version") == "agent_jsac_branch_router_checkpoint_v1":
        if payload.get("recipe_type") != "branch_router" or tuple(
            payload.get("branch_order", ())
        ) != ("cora0", "cora_se1", "cora_se2"):
            raise AgentShadowDevelopmentError("branch-router checkpoint contract is invalid")
        try:
            input_dim = int(kwargs["input_dim"])
            hidden_dim = int(kwargs["hidden_dim"])
            margin = float(payload["selection_margin"])
        except (KeyError, TypeError, ValueError) as error:
            raise AgentShadowDevelopmentError(
                "branch-router checkpoint dimensions or margin are invalid"
            ) from error
        if input_dim != 18 or hidden_dim < 16 or not 0.0 <= margin <= 1.0:
            raise AgentShadowDevelopmentError("branch-router checkpoint parameters are unsafe")
        parent = str(payload.get("parent_branch", ""))
        if parent not in {"cora0", "cora_se1", "cora_se2"}:
            raise AgentShadowDevelopmentError("branch-router parent branch is invalid")
        return {
            "kind": "branch_router",
            "implementation_id": str(payload.get("implementation_id", "")),
            "parent_branch": parent,
            "input_dim": input_dim,
            "hidden_dim": hidden_dim,
            "selection_margin": margin,
        }
    try:
        feature_dim = int(kwargs["feature_dim"])
        hidden_dim = int(kwargs["hidden_dim"])
    except (KeyError, TypeError, ValueError) as error:
        raise AgentShadowDevelopmentError("Shadow checkpoint has invalid model dimensions") from error
    if feature_dim < 1 or hidden_dim < 16:
        raise AgentShadowDevelopmentError("Shadow checkpoint model dimensions are unsafe")

    implementation_id = payload.get("implementation_id")
    if isinstance(implementation_id, str) and implementation_id:
        application = payload.get(
            "application_contract",
            {
                "mode": "exact_observed_candidate",
                "posterior_scale": 1.0,
                "maximum_correction_m": None,
                "identity_fallback_required": True,
            },
        )
        return {
            "kind": "registered",
            "implementation_id": implementation_id,
            "feature_dim": feature_dim,
            "hidden_dim": hidden_dim,
            "application_contract": validate_application_contract(application),
        }

    if (
        payload.get("schema_version") == "agent_jsac_se_branch_route_expert_checkpoint_v1"
        and payload.get("route") == "corner_nlos_ris"
        and payload.get("primitive") == "risecho_temporal_gate"
        and implementation_id is None
    ):
        return {
            "kind": "legacy_se_branch",
            "primitive": "risecho_temporal_gate",
            "feature_dim": feature_dim,
            "hidden_dim": hidden_dim,
        }
    raise AgentShadowDevelopmentError(
        "legacy checkpoint is not the sealed corner_nlos_ris risecho_temporal_gate"
    )


def checkpoint_acceptance_threshold(checkpoint: Mapping[str, Any]) -> float:
    """Resolve one calibrated candidate-expert threshold without script imports."""

    schema = str(
        checkpoint.get(
            "schema_version", "agent_jsac_se_branch_route_expert_checkpoint_v1"
        )
    )
    if "acceptance_threshold" in checkpoint:
        threshold = float(checkpoint["acceptance_threshold"])
        if not 0.0 <= threshold <= 1.0:
            raise ValueError(
                "checkpoint calibrated acceptance threshold is outside [0, 1]"
            )
        return threshold
    if schema == "agent_jsac_se_branch_route_expert_checkpoint_v1":
        return 0.05
    raise ValueError("checkpoint lacks calibrated acceptance threshold")


def validate_agent_shadow_decision(payload: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """Validate the immutable, post-Canary Agent selection before Dev inference."""

    if payload.get("schema_version") != "agent_jsac_agent_selected_shadow_pool_v1":
        raise AgentShadowDevelopmentError("unexpected Agent shadow decision schema")
    if payload.get("global_execution_weight") != 0.0:
        raise AgentShadowDevelopmentError("Agent Shadow decision must remain zero weight before evaluation")
    if payload.get("requires_authorised_development_evaluation_before_promotion") is not True:
        raise AgentShadowDevelopmentError("Development authorisation guard is missing")
    rows = payload.get("routes")
    if not isinstance(rows, list) or tuple(str(row.get("route", "")) for row in rows if isinstance(row, Mapping)) != ROUTE_ORDER:
        raise AgentShadowDevelopmentError("Agent shadow decision must cover the six canonical routes in order")
    result: dict[str, dict[str, Any]] = {}
    for raw in rows:
        if not isinstance(raw, Mapping):
            raise AgentShadowDevelopmentError("Agent route decision must be an object")
        route = str(raw["route"])
        selection = str(raw.get("selection", ""))
        candidate_id = raw.get("candidate_id")
        if selection not in {"exact_parent_identity", "shadow_candidate"}:
            raise AgentShadowDevelopmentError(f"unknown Agent selection for {route}: {selection}")
        if (selection == "shadow_candidate") != (candidate_id is not None):
            raise AgentShadowDevelopmentError(f"candidate/selection mismatch for {route}")
        if float(raw.get("execution_weight", 1.0)) != 0.0:
            raise AgentShadowDevelopmentError(f"route {route} has a nonzero pre-Dev execution weight")
        result[route] = dict(raw)
    return result


def build_prediction_freeze_payload(
    *,
    query_sequences: Sequence[str],
    decision_sha256: str,
    prediction_manifest_sha256: str,
    predictions_sha256: str,
    runtime_sha256: str,
) -> dict[str, Any]:
    """Build a legacy-compatible one-shot Dev freeze with stronger lineage fields."""

    sequences = validate_development_query_sequences(query_sequences)
    hashes = {
        "decision_sha256": decision_sha256,
        "prediction_manifest_sha256": prediction_manifest_sha256,
        "predictions_sha256": predictions_sha256,
        "runtime_sha256": runtime_sha256,
    }
    if any(len(str(value)) != 64 for value in hashes.values()):
        raise AgentShadowDevelopmentError("Development prediction freeze requires SHA256 lineage")
    return {
        "schema_version": "agent_jsac_scaa_development_prediction_freeze_v1",
        "sequences": list(sequences),
        # Existing one-shot label reader requires a checkpoint hash.  The runtime
        # hash is a hash of all selected parent/expert checkpoints and policy.
        "checkpoint_sha256": str(runtime_sha256),
        "threshold_frozen": True,
        "promotion_state_frozen": True,
        "source_commit": "agent-shadow-development-evaluation",
        "locked_test_read": False,
        "development_labels_read_before_prediction_freeze": False,
        **hashes,
    }
