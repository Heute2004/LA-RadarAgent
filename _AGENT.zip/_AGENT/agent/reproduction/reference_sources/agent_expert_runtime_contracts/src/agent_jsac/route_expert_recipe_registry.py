"""Bind semantic expert identifiers to executable training recipes.

An implementation identifier must never silently fall back to the generic
candidate scorer.  The mapping here is intentionally explicit and auditable.
"""

from __future__ import annotations


_RECIPE_IMPLEMENTATIONS: dict[str, frozenset[str]] = {
    "branch_router": frozenset(
        {
            "branch_persistence_selector_v1",
            "graph_branch_linker_v1",
        }
    ),
    "consensus_branch_router": frozenset(
        {
            "anisotropic_wet_mixture_v1",
            "risk_controlled_recovery_v1",
            "robust_quantile_recovery_v1",
            "weather_risk_selector_v1",
            "wet_temporal_integrator_v1",
        }
    ),
    "bev_residual_adapter": frozenset(
        {
            "innovation_gated_offset_v1",
            "local_offset_gru_v1",
            "polar_bev_cross_refiner_v1",
            "subcell_uncertainty_refiner_v1",
            "temporal_precision_tail_v1",
            "path_temporal_integrator_v1",
            "polar_evidence_gate_v1",
            "range_conditioned_tcn_v1",
            "track_before_detect_v1",
        }
    ),
    "candidate_set_specialist": frozenset(
        {
            "candidate_attention_set_v1",
            "candidate_graph_temporal_v1",
            "candidate_survival_graph_v1",
            "dual_domain_set_mixer_v1",
            "echo_extent_disambiguator_v1",
            "mti_agreement_rescuer_v1",
            "multi_hypothesis_path_v1",
            "selective_branch_recovery_v1",
            "weak_return_mixture_v1",
            "state_consistent_local_refiner_v1",
            "local_shape_consensus_v1",
            "empty_guard_constrained_disambiguator_v1",
            "causal_tracklet_consensus_v1",
            "adaptive_threshold_tracklet_v1",
            "evidence_hysteresis_selector_v1",
            "angular_consistency_associator_v1",
            "background_guard_branch_pruner_v1",
            "wet_guard_contrast_recovery_v1",
            "anomaly_hysteresis_gate_v1",
        }
    ),
    "ris_temporal_gate": frozenset(
        {
            "risecho_codebook_consensus_v1",
            "risecho_dual_path_mixture_v1",
            "risecho_path_integrator_v1",
            "risecho_selective_recovery_v1",
            "risecho_temporal_gate_v1",
            "risecho_geometry_consensus_v1",
            "risecho_dual_stream_stability_v1",
        }
    ),
}

_IMPLEMENTATION_TO_RECIPE = {
    implementation_id: recipe
    for recipe, implementation_ids in _RECIPE_IMPLEMENTATIONS.items()
    for implementation_id in implementation_ids
}

_REGISTERED_CANDIDATE_RECIPES = frozenset(
    {
        "candidate_set_specialist",
        "consensus_branch_router",
        "bev_residual_adapter",
        "ris_temporal_gate",
    }
)


def recipe_for_implementation(implementation_id: str) -> str:
    """Return the only executable recipe registered for an implementation."""

    try:
        return _IMPLEMENTATION_TO_RECIPE[str(implementation_id)]
    except KeyError as error:
        raise ValueError(
            f"unregistered route-expert recipe implementation: {implementation_id!r}"
        ) from error


def registered_recipe_implementations() -> tuple[str, ...]:
    return tuple(sorted(_IMPLEMENTATION_TO_RECIPE))


def trainer_family_for_implementation(implementation_id: str) -> str:
    """Resolve an implementation to its executable trainer family.

    The shared registered-candidate trainer is infrastructure, not a shared
    architecture: it instantiates the hash-bound implementation-specific model
    before training.  Only frozen-branch selectors use the separate branch
    router trainer.
    """

    recipe = recipe_for_implementation(implementation_id)
    if recipe == "branch_router":
        return "branch_router"
    if recipe in _REGISTERED_CANDIDATE_RECIPES:
        return "registered_candidate"
    raise ValueError(
        f"registered recipe has no executable trainer family: {recipe!r}"
    )


def execution_signature_for_implementation(implementation_id: str) -> str:
    """Describe the actual trainer/model path used by one semantic candidate."""

    family = trainer_family_for_implementation(implementation_id)
    if family == "branch_router":
        return "branch_router:causal_branch_router_18x48_v1"
    from .registered_route_expert_models import registered_architecture_signature

    return "registered_candidate:" + registered_architecture_signature(implementation_id)
