"""Hash-bound evidence receipts for registered route-expert promotion.

The helpers in this module deliberately separate training fit from promotion
evidence.  A registered expert may be ranked only after its implementation,
source retention, same-modality empty safety, and label-free Canary receipts
have all been materialized.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np

from .route_expert_execution_registry import RegisteredRouteExpert


_HEX = frozenset("0123456789abcdef")
_BINDING_FIELDS = (
    "candidate_id",
    "route",
    "primitive",
    "implementation_id",
    "parent_branch",
)
_ROUTE_CANARY_FIELDS = (
    "physical_support_rate",
    "candidate_set_agreement_delta",
    "trajectory_jump_rate_delta",
    "identity_regret_rate",
    "directional_episode_fraction",
    "p90_proxy_delta_m",
    "intervention_coverage",
    "support_canary_coverage_quantile_10",
)
_ROUTE_CANARY_V2_FIELDS = (
    "conditional_candidate_agreement_delta",
    "conditional_regret_rate",
    "harmful_jump_rate_delta",
    "false_branch_rate_delta",
    "conditional_raw_score_delta",
    "conditional_ra_mti_agreement_delta",
    "conditional_background_clean_delta",
    "conditional_persistence_delta",
    "conditional_evidence_score_delta",
    "conditional_evidence_dominance_rate",
    "conditional_shift_mean_m",
    "conditional_shift_p90_m",
    "conditional_shift_max_m",
    "total_frame_count",
    "intervention_frame_count",
    "effective_evidence_count",
    "nonfinite_output_count",
)


def _valid_sha256(value: Any) -> bool:
    text = str(value).lower()
    return len(text) == 64 and all(character in _HEX for character in text)


def _false_read_count(mapping: Mapping[str, Any]) -> int:
    return sum(int(bool(value)) for value in mapping.values())


def build_registered_binding_receipt(
    *,
    registered: RegisteredRouteExpert,
    checkpoint: Mapping[str, Any],
    training_receipt: Mapping[str, Any],
    checkpoint_sha256: str,
    training_receipt_sha256: str,
    empty_guard_sha256: str,
) -> dict[str, Any]:
    """Verify that a checkpoint is the exact implementation requested by the registry."""

    expected = {
        "route": registered.route,
        "primitive": registered.primitive,
        "implementation_id": registered.implementation_id,
    }
    concrete_parent_branch: str | None = None
    parent_selection_sha256: str | None = None
    for field in _BINDING_FIELDS:
        if field == "candidate_id":
            left = checkpoint.get(field)
            right = training_receipt.get(field)
            if not left or left != right:
                raise ValueError("candidate_id binding mismatch")
            continue
        if field == "parent_branch":
            left = str(checkpoint.get(field, ""))
            right = str(training_receipt.get(field, ""))
            if left != right:
                raise ValueError("parent_branch binding mismatch")
            if registered.parent_branch == "route_selected":
                if left not in {"cora0", "cora_se1", "cora_se2"}:
                    raise ValueError("selected runtime parent is invalid")
                checkpoint_selection = checkpoint.get("parent_selection_sha256")
                receipt_selection = training_receipt.get("parent_selection_sha256")
                if (
                    checkpoint_selection != receipt_selection
                    or not _valid_sha256(checkpoint_selection)
                ):
                    raise ValueError("selected runtime parent lacks a signed parent-selection receipt")
                parent_selection_sha256 = str(checkpoint_selection)
            elif left != registered.parent_branch:
                raise ValueError("parent_branch binding mismatch")
            concrete_parent_branch = left
            continue
        expected_value = expected[field]
        if checkpoint.get(field) != expected_value or training_receipt.get(field) != expected_value:
            raise ValueError(f"{field} binding mismatch")
    if not _valid_sha256(checkpoint_sha256) or not _valid_sha256(training_receipt_sha256):
        raise ValueError("artifact SHA256 is invalid")
    if training_receipt.get("checkpoint_sha256") != checkpoint_sha256:
        raise ValueError("checkpoint SHA256 does not match the training receipt")
    if not _valid_sha256(empty_guard_sha256) or training_receipt.get(
        "empty_guard_sha256"
    ) != empty_guard_sha256:
        raise ValueError("EmptyGuard SHA256 does not match the training receipt")
    if float(checkpoint.get("execution_weight", -1.0)) != 0.0 or float(
        training_receipt.get("execution_weight", -1.0)
    ) != 0.0:
        raise ValueError("a shadow checkpoint must retain zero execution weight")
    if bool(checkpoint.get("historical_checkpoint_import", True)):
        raise ValueError("historical checkpoint import is forbidden")

    checkpoint_reads = checkpoint.get("forbidden_reads")
    if not isinstance(checkpoint_reads, Mapping):
        raise ValueError("checkpoint misses forbidden-read audit")
    receipt_reads = {
        "support_canary_read": training_receipt.get("support_canary_read"),
        "development_read": training_receipt.get("development_read"),
        "locked_test_read": training_receipt.get("locked_test_read"),
    }
    forbidden_read_count = _false_read_count(checkpoint_reads) + _false_read_count(receipt_reads)
    required_provenance = (
        training_receipt.get("target_fit_sequences"),
        training_receipt.get("source_replay_sequences"),
        training_receipt.get("empty_guard_sha256"),
    )
    provenance_complete = (
        all(bool(value) for value in required_provenance)
        and _valid_sha256(training_receipt.get("empty_guard_sha256"))
        and forbidden_read_count == 0
    )
    if not provenance_complete:
        raise ValueError("training receipt provenance is incomplete")

    return {
        "schema_version": "agent_jsac_registered_route_expert_binding_receipt_v1",
        "candidate_id": checkpoint["candidate_id"],
        "route": registered.route,
        "primitive": registered.primitive,
        "template_id": registered.template_id,
        "implementation_id": registered.implementation_id,
        "parent_branch": concrete_parent_branch,
        "semantic_parent_branch": registered.parent_branch,
        "parent_selection_sha256": parent_selection_sha256,
        "output_contract": registered.output_contract,
        "application_contract": dict(registered.application_contract),
        "entrypoint_relative_path": registered.entrypoint_relative_path,
        "entrypoint_sha256": registered.entrypoint_sha256,
        "checkpoint_sha256": checkpoint_sha256,
        "training_receipt_sha256": training_receipt_sha256,
        "empty_guard_sha256": empty_guard_sha256,
        "artifact_integrity": 1.0,
        "provenance_completeness": 1.0,
        "registered_primitive_binding": True,
        "parent_branch_binding": True,
        "application_contract_binding": True,
        "bounded_risk_recovery_contract": bool(
            registered.route == "outdoor_wet_return"
            and registered.application_contract["mode"]
            == "bounded_convex_candidate_update"
            and float(registered.application_contract["posterior_scale"]) <= 0.5
            and float(registered.application_contract["maximum_correction_m"]) <= 0.5
        ),
        "application_posterior_scale": float(
            registered.application_contract["posterior_scale"]
        ),
        "application_maximum_correction_m": registered.application_contract[
            "maximum_correction_m"
        ],
        "forbidden_read_count": forbidden_read_count,
        "non_promoted_runtime_weight": 0.0,
    }


def build_source_retention_receipt(
    *,
    archives: Sequence[Mapping[str, Any]],
    final_indices: Sequence[np.ndarray],
) -> dict[str, Any]:
    """Measure source candidate-set hit retention using sealed source supervision.

    The metric is an AP-retention proxy at the source replay attachment radius.
    It is intentionally computed only on source-domain frames, where source
    labels are authorized, and never on target Support, Development, or Test.
    """

    if not archives or len(archives) != len(final_indices):
        raise ValueError("source archives and prediction streams must be non-empty and aligned")
    parent_hit = 0
    candidate_hit = 0
    supervised_frames = 0
    for archive, indices in zip(archives, final_indices, strict=True):
        allowed = np.asarray(archive["allowed_weight"], dtype=np.float32)
        weights = np.asarray(archive["sample_weight"], dtype=np.float32)
        radar_valid = np.asarray(archive["radar_training_valid"], dtype=bool)
        candidate_valid = np.asarray(archive["candidate_valid"], dtype=bool)
        selected = np.asarray(indices, dtype=np.int64)
        if (
            allowed.ndim != 2
            or candidate_valid.shape != allowed.shape
            or weights.shape != (allowed.shape[0],)
            or radar_valid.shape != weights.shape
            or selected.shape != weights.shape
        ):
            raise ValueError("source replay receipt shapes are invalid")
        supervised = (weights > 0.0) & radar_valid & (allowed.sum(axis=1) > 0.0)
        if np.any((selected < 0) | (selected >= allowed.shape[1])):
            raise ValueError("source prediction selects an out-of-range candidate")
        selected_valid = candidate_valid[np.arange(allowed.shape[0]), selected]
        if not np.all(selected_valid[supervised]):
            raise ValueError("source prediction selects an invalid physical candidate")
        supervised_frames += int(supervised.sum())
        parent_hit += int((allowed[supervised, 0] > 0.0).sum())
        candidate_hit += int(
            (
                allowed[np.arange(allowed.shape[0]), selected] > 0.0
            )[supervised].sum()
        )
    if supervised_frames <= 0:
        raise ValueError("source replay contains no supervised retention frames")
    parent_rate = parent_hit / float(supervised_frames)
    candidate_rate = candidate_hit / float(supervised_frames)
    source_candidate_hit_drop = parent_rate - candidate_rate
    return {
        "schema_version": "agent_jsac_source_retention_receipt_v1",
        "metric_id": "source_candidate_set_hit_drop",
        "metric_alias": "source_ap_drop",
        "measurement_scope": "authorized_source_replay_only",
        "source_supervised_frames": supervised_frames,
        "parent_hit_rate": parent_rate,
        "candidate_hit_rate": candidate_rate,
        "source_candidate_hit_drop": source_candidate_hit_drop,
        "source_ap_drop": source_candidate_hit_drop,
        "development_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }


def build_branch_source_retention_receipt(
    *,
    archives: Sequence[Mapping[str, Any]],
    final_xy_m: Sequence[np.ndarray],
    attachment_radius_m: float = 0.30,
) -> dict[str, Any]:
    """Audit exact frozen-branch coordinates on authorized source replay.

    A branch router does not output a raw candidate index.  Retention is
    therefore measured geometrically against the authorized source candidate
    set without replacing or snapping the branch coordinate.
    """

    if (
        not archives
        or len(archives) != len(final_xy_m)
        or attachment_radius_m <= 0.0
    ):
        raise ValueError("source archives and branch coordinates must be aligned")
    parent_hit = 0
    candidate_hit = 0
    supervised_frames = 0
    for archive, raw_final in zip(archives, final_xy_m, strict=True):
        xy = np.asarray(archive["candidate_xy_m"], dtype=np.float32)
        valid = np.asarray(archive["candidate_valid"], dtype=bool)
        base = np.asarray(archive["base_xy_m"], dtype=np.float32)
        allowed = np.asarray(archive["allowed_weight"], dtype=np.float32)
        weights = np.asarray(archive["sample_weight"], dtype=np.float32)
        radar_valid = np.asarray(archive["radar_training_valid"], dtype=bool)
        final = np.asarray(raw_final, dtype=np.float32)
        if (
            xy.ndim != 3
            or xy.shape[-1] != 2
            or valid.shape != xy.shape[:2]
            or allowed.shape != valid.shape
            or base.shape != (xy.shape[0], 2)
            or final.shape != base.shape
            or weights.shape != (xy.shape[0],)
            or radar_valid.shape != weights.shape
        ):
            raise ValueError("source branch-coordinate receipt shapes are invalid")
        if not np.isfinite(final).all():
            raise ValueError("source branch-coordinate output is nonfinite")
        supervised = (weights > 0.0) & radar_valid & (allowed.sum(axis=1) > 0.0)
        for frame in np.flatnonzero(supervised):
            legal = valid[frame] & (allowed[frame] > 0.0)
            if not bool(legal.any()):
                continue
            legal_xy = xy[frame, legal]
            parent_hit += int(
                float(np.linalg.norm(legal_xy - base[frame], axis=1).min())
                <= float(attachment_radius_m)
            )
            candidate_hit += int(
                float(np.linalg.norm(legal_xy - final[frame], axis=1).min())
                <= float(attachment_radius_m)
            )
            supervised_frames += 1
    if supervised_frames <= 0:
        raise ValueError("source replay contains no supervised branch-retention frames")
    parent_rate = parent_hit / float(supervised_frames)
    candidate_rate = candidate_hit / float(supervised_frames)
    source_drop = parent_rate - candidate_rate
    return {
        "schema_version": "agent_jsac_branch_source_retention_receipt_v1",
        "metric_id": "source_candidate_set_hit_drop",
        "metric_alias": "source_ap_drop",
        "measurement_scope": "authorized_source_replay_branch_coordinate_only",
        "attachment_radius_m": float(attachment_radius_m),
        "source_supervised_frames": int(supervised_frames),
        "parent_hit_rate": float(parent_rate),
        "candidate_hit_rate": float(candidate_rate),
        "source_candidate_hit_drop": float(source_drop),
        "source_ap_drop": float(source_drop),
        "development_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }


def _jump_rate(path: np.ndarray, *, threshold_m: float = 0.30) -> float:
    if len(path) < 2:
        return 0.0
    steps = np.linalg.norm(np.diff(path, axis=0), axis=1)
    return float((steps > float(threshold_m)).mean())


def _conditional_jump_delta(
    parent: np.ndarray,
    candidate: np.ndarray,
    active: np.ndarray,
    *,
    threshold_m: float = 1.00,
) -> tuple[float, int]:
    """Return candidate-minus-parent jump rate on intervention-adjacent steps."""

    if len(candidate) < 2:
        return 0.0, 0
    affected = np.asarray(active[1:] | active[:-1], dtype=bool)
    if not bool(affected.any()):
        return 0.0, 0
    parent_steps = np.linalg.norm(np.diff(parent, axis=0), axis=1)
    candidate_steps = np.linalg.norm(np.diff(candidate, axis=0), axis=1)
    parent_rate = float((parent_steps[affected] > float(threshold_m)).mean())
    candidate_rate = float((candidate_steps[affected] > float(threshold_m)).mean())
    return candidate_rate - parent_rate, int(affected.sum())


def _directional_fraction(candidate: np.ndarray, proxy: np.ndarray) -> float:
    if len(candidate) < 2:
        return 1.0
    candidate_step = np.diff(candidate, axis=0)
    proxy_step = np.diff(proxy, axis=0)
    candidate_norm = np.linalg.norm(candidate_step, axis=1)
    proxy_norm = np.linalg.norm(proxy_step, axis=1)
    active = (candidate_norm > 0.03) | (proxy_norm > 0.03)
    if not bool(active.any()):
        return 1.0
    cosine = np.zeros(len(candidate_step), dtype=np.float64)
    jointly_moving = (candidate_norm > 0.03) & (proxy_norm > 0.03)
    cosine[jointly_moving] = (
        (candidate_step[jointly_moving] * proxy_step[jointly_moving]).sum(axis=1)
        / (candidate_norm[jointly_moving] * proxy_norm[jointly_moving])
    )
    both_stationary = (candidate_norm <= 0.03) & (proxy_norm <= 0.03)
    cosine[both_stationary] = 1.0
    return float((cosine[active] >= 0.0).mean())


def _raw_physical_proxy_index(feature: np.ndarray, valid: np.ndarray) -> np.ndarray:
    if feature.ndim != 3 or feature.shape[:2] != valid.shape or feature.shape[2] < 6:
        raise ValueError("Canary candidate features must follow the RawRouteRuntime contract")
    if valid.shape[1] < 2 or not bool(valid[:, 1:].any(axis=1).all()):
        raise ValueError("Canary requires at least one current-frame physical candidate")
    score = (
        0.45 * feature[..., 0]
        + 0.20 * feature[..., 3]
        + 0.20 * feature[..., 4]
        + 0.15 * feature[..., 5]
    )
    score = np.where(valid, score, -np.inf)
    score[:, 0] = -np.inf
    return score.argmax(axis=1).astype(np.int64)


def build_label_free_canary_receipt(
    *,
    archives: Sequence[Mapping[str, Any]],
    final_indices: Sequence[np.ndarray],
    intervened: Sequence[np.ndarray],
    agreement_radius_m: float = 0.30,
) -> dict[str, Any]:
    """Compare a route expert with its parent using current raw radar evidence only."""

    if (
        not archives
        or len(archives) != len(final_indices)
        or len(archives) != len(intervened)
        or agreement_radius_m <= 0.0
    ):
        raise ValueError("Canary archives and prediction streams must be non-empty and aligned")
    physical_hits = 0
    physical_trials = 0
    parent_agreement: list[np.ndarray] = []
    candidate_agreement: list[np.ndarray] = []
    parent_errors: list[np.ndarray] = []
    candidate_errors: list[np.ndarray] = []
    regrets: list[np.ndarray] = []
    parent_jumps: list[float] = []
    candidate_jumps: list[float] = []
    directional: list[float] = []
    coverages: list[float] = []
    conditional_parent_agreement_hits = 0
    conditional_candidate_agreement_hits = 0
    conditional_regret_hits = 0
    intervention_frame_count = 0
    total_frame_count = 0
    effective_evidence_count = 0
    conditional_jump_weighted_sum = 0.0
    conditional_jump_transition_count = 0
    nonfinite_output_count = 0
    evidence_delta_parts: list[np.ndarray] = []
    evidence_dominance_hits = 0
    intervention_shift_parts: list[np.ndarray] = []
    for archive, raw_indices, raw_intervened in zip(
        archives, final_indices, intervened, strict=True
    ):
        xy = np.asarray(archive["candidate_xy_m"], dtype=np.float32)
        valid = np.asarray(archive["candidate_valid"], dtype=bool)
        feature = np.asarray(archive["candidate_feature"], dtype=np.float32)
        base = np.asarray(archive["base_xy_m"], dtype=np.float32)
        indices = np.asarray(raw_indices, dtype=np.int64)
        active = np.asarray(raw_intervened, dtype=bool)
        if (
            xy.ndim != 3
            or xy.shape[-1] != 2
            or valid.shape != xy.shape[:2]
            or feature.shape[:2] != valid.shape
            or base.shape != (xy.shape[0], 2)
            or indices.shape != (xy.shape[0],)
            or active.shape != indices.shape
        ):
            raise ValueError("Canary archive and prediction shapes are invalid")
        if np.any((indices < 0) | (indices >= valid.shape[1])):
            raise ValueError("Canary prediction selects an out-of-range candidate")
        selected_valid = valid[np.arange(len(indices)), indices]
        physical_trials += int(active.sum())
        physical_hits += int((selected_valid & (indices > 0) & active).sum())
        if not np.all(selected_valid):
            raise ValueError("Canary prediction selects an invalid candidate")

        proxy_indices = _raw_physical_proxy_index(feature, valid)
        proxy_xy = xy[np.arange(len(indices)), proxy_indices]
        candidate_xy = xy[np.arange(len(indices)), indices]
        nonfinite_output_count += int((~np.isfinite(candidate_xy)).sum())
        parent_error = np.linalg.norm(base - proxy_xy, axis=1)
        candidate_error = np.linalg.norm(candidate_xy - proxy_xy, axis=1)
        parent_errors.append(parent_error)
        candidate_errors.append(candidate_error)
        parent_agreement.append(parent_error <= float(agreement_radius_m))
        candidate_agreement.append(candidate_error <= float(agreement_radius_m))
        regrets.append(candidate_error > parent_error + 1.0e-9)
        parent_jumps.append(_jump_rate(base))
        candidate_jumps.append(_jump_rate(candidate_xy))
        jump_delta, jump_transitions = _conditional_jump_delta(base, candidate_xy, active)
        conditional_jump_weighted_sum += jump_delta * jump_transitions
        conditional_jump_transition_count += jump_transitions
        directional.append(_directional_fraction(candidate_xy, proxy_xy))
        coverages.append(float(active.mean()))
        total_frame_count += int(len(active))
        active_count = int(active.sum())
        intervention_frame_count += active_count
        effective_evidence_count += int((active & selected_valid & (indices > 0)).sum())
        if active_count:
            conditional_parent_agreement_hits += int(
                (parent_error[active] <= float(agreement_radius_m)).sum()
            )
            conditional_candidate_agreement_hits += int(
                (candidate_error[active] <= float(agreement_radius_m)).sum()
            )
            conditional_regret_hits += int(
                (candidate_error[active] > parent_error[active] + 1.0e-9).sum()
            )
            selected_feature = feature[np.arange(len(indices)), indices]
            feature_delta = selected_feature[active][:, (0, 3, 4, 5)] - feature[active, 0][
                :, (0, 3, 4, 5)
            ]
            evidence_delta_parts.append(feature_delta)
            evidence_dominance_hits += int(
                ((feature_delta >= 0.0).sum(axis=1) >= 2).sum()
            )
            intervention_shift_parts.append(
                np.linalg.norm(candidate_xy[active] - base[active], axis=1)
            )

    parent_error_all = np.concatenate(parent_errors)
    candidate_error_all = np.concatenate(candidate_errors)
    parent_agreement_rate = float(np.concatenate(parent_agreement).mean())
    candidate_agreement_rate = float(np.concatenate(candidate_agreement).mean())
    physical_support_rate = 1.0 if physical_trials == 0 else physical_hits / float(physical_trials)
    if intervention_frame_count:
        conditional_parent_rate = conditional_parent_agreement_hits / float(
            intervention_frame_count
        )
        conditional_candidate_rate = conditional_candidate_agreement_hits / float(
            intervention_frame_count
        )
        conditional_agreement_delta = conditional_candidate_rate - conditional_parent_rate
        conditional_regret_rate = conditional_regret_hits / float(intervention_frame_count)
    else:
        conditional_agreement_delta = 0.0
        conditional_regret_rate = 0.0
    harmful_jump_rate_delta = (
        conditional_jump_weighted_sum / float(conditional_jump_transition_count)
        if conditional_jump_transition_count
        else 0.0
    )
    if evidence_delta_parts:
        evidence_delta = np.concatenate(evidence_delta_parts, axis=0)
        evidence_mean = evidence_delta.mean(axis=0)
        evidence_score_delta = float(
            np.mean(
                0.35 * evidence_delta[:, 0]
                + 0.25 * evidence_delta[:, 1]
                + 0.20 * evidence_delta[:, 2]
                + 0.20 * evidence_delta[:, 3]
            )
        )
        evidence_dominance_rate = evidence_dominance_hits / float(
            intervention_frame_count
        )
    else:
        evidence_mean = np.zeros(4, dtype=np.float64)
        evidence_score_delta = 0.0
        evidence_dominance_rate = 0.0
    if intervention_shift_parts:
        intervention_shift = np.concatenate(intervention_shift_parts)
        shift_mean = float(np.mean(intervention_shift))
        shift_p90 = float(np.quantile(intervention_shift, 0.90))
        shift_max = float(np.max(intervention_shift))
    else:
        shift_mean = shift_p90 = shift_max = 0.0
    return {
        "schema_version": "agent_jsac_label_free_route_canary_receipt_v1",
        "proxy_definition": "raw_RA_RA_MTI_agreement_background_persistence_composite",
        "agreement_radius_m": float(agreement_radius_m),
        "physical_support_rate": float(physical_support_rate),
        "candidate_set_agreement_delta": candidate_agreement_rate - parent_agreement_rate,
        "conditional_candidate_agreement_delta": float(conditional_agreement_delta),
        "conditional_regret_rate": float(conditional_regret_rate),
        "harmful_jump_rate_delta": float(harmful_jump_rate_delta),
        "false_branch_rate_delta": float(-conditional_agreement_delta),
        "conditional_raw_score_delta": float(evidence_mean[0]),
        "conditional_ra_mti_agreement_delta": float(evidence_mean[1]),
        "conditional_background_clean_delta": float(evidence_mean[2]),
        "conditional_persistence_delta": float(evidence_mean[3]),
        "conditional_evidence_score_delta": float(evidence_score_delta),
        "conditional_evidence_dominance_rate": float(evidence_dominance_rate),
        "conditional_shift_mean_m": shift_mean,
        "conditional_shift_p90_m": shift_p90,
        "conditional_shift_max_m": shift_max,
        "trajectory_jump_rate_delta": float(np.mean(candidate_jumps) - np.mean(parent_jumps)),
        "identity_regret_rate": float(np.concatenate(regrets).mean()),
        "directional_episode_fraction": float(np.mean(directional)),
        "p90_proxy_delta_m": float(
            np.quantile(candidate_error_all, 0.90) - np.quantile(parent_error_all, 0.90)
        ),
        "total_frame_count": int(total_frame_count),
        "intervention_frame_count": int(intervention_frame_count),
        "effective_evidence_count": int(effective_evidence_count),
        "nonfinite_output_count": int(nonfinite_output_count),
        "intervention_coverage": float(np.mean(coverages)),
        "support_canary_coverage_quantile_10": float(np.quantile(coverages, 0.10)),
        "development_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }


def build_branch_coordinate_canary_receipt(
    *,
    archives: Sequence[Mapping[str, Any]],
    final_xy_m: Sequence[np.ndarray],
    intervened: Sequence[np.ndarray],
    agreement_radius_m: float = 0.30,
    physical_support_radius_m: float = 0.30,
) -> dict[str, Any]:
    """Audit an exact frozen-branch coordinate without snapping it to a peak."""

    if (
        not archives
        or len(archives) != len(final_xy_m)
        or len(archives) != len(intervened)
        or agreement_radius_m <= 0.0
        or physical_support_radius_m <= 0.0
    ):
        raise ValueError("branch Canary inputs must be non-empty and aligned")
    physical_hits = 0
    physical_trials = 0
    parent_agreement: list[np.ndarray] = []
    candidate_agreement: list[np.ndarray] = []
    parent_errors: list[np.ndarray] = []
    candidate_errors: list[np.ndarray] = []
    regrets: list[np.ndarray] = []
    parent_jumps: list[float] = []
    candidate_jumps: list[float] = []
    directional: list[float] = []
    coverages: list[float] = []
    conditional_parent_agreement_hits = 0
    conditional_candidate_agreement_hits = 0
    conditional_regret_hits = 0
    intervention_frame_count = 0
    total_frame_count = 0
    effective_evidence_count = 0
    conditional_jump_weighted_sum = 0.0
    conditional_jump_transition_count = 0
    nonfinite_output_count = 0
    evidence_delta_parts: list[np.ndarray] = []
    evidence_dominance_hits = 0
    intervention_shift_parts: list[np.ndarray] = []
    for archive, raw_final, raw_intervened in zip(
        archives, final_xy_m, intervened, strict=True
    ):
        xy = np.asarray(archive["candidate_xy_m"], dtype=np.float32)
        valid = np.asarray(archive["candidate_valid"], dtype=bool)
        feature = np.asarray(archive["candidate_feature"], dtype=np.float32)
        base = np.asarray(archive["base_xy_m"], dtype=np.float32)
        final = np.asarray(raw_final, dtype=np.float32)
        active = np.asarray(raw_intervened, dtype=bool)
        if (
            xy.ndim != 3
            or xy.shape[-1] != 2
            or valid.shape != xy.shape[:2]
            or feature.shape[:2] != valid.shape
            or base.shape != (xy.shape[0], 2)
            or final.shape != base.shape
            or active.shape != (xy.shape[0],)
        ):
            raise ValueError("branch Canary archive and prediction shapes are invalid")
        if valid.shape[1] < 2 or not bool(valid[:, 1:].any(axis=1).all()):
            raise ValueError("branch Canary needs a measured physical candidate per frame")

        finite_frame = np.isfinite(final).all(axis=1)
        nonfinite_output_count += int((~np.isfinite(final)).sum())
        safe_final = np.nan_to_num(final, nan=0.0, posinf=0.0, neginf=0.0)
        physical_xy = xy[:, 1:]
        physical_valid = valid[:, 1:]
        distance = np.linalg.norm(
            physical_xy - safe_final[:, None, :], axis=-1
        )
        distance = np.where(physical_valid, distance, np.inf)
        nearest_physical = distance.argmin(axis=1) + 1
        nearest_distance = distance.min(axis=1)
        supported = finite_frame & (
            nearest_distance <= float(physical_support_radius_m)
        )
        physical_trials += int(active.sum())
        physical_hits += int((active & supported).sum())

        proxy_indices = _raw_physical_proxy_index(feature, valid)
        proxy_xy = xy[np.arange(len(active)), proxy_indices]
        parent_error = np.linalg.norm(base - proxy_xy, axis=1)
        candidate_error = np.linalg.norm(safe_final - proxy_xy, axis=1)
        candidate_error = np.where(finite_frame, candidate_error, np.inf)
        parent_errors.append(parent_error)
        candidate_errors.append(candidate_error)
        parent_agreement.append(parent_error <= float(agreement_radius_m))
        candidate_agreement.append(candidate_error <= float(agreement_radius_m))
        regrets.append(candidate_error > parent_error + 1.0e-9)
        parent_jumps.append(_jump_rate(base))
        candidate_jumps.append(_jump_rate(safe_final))
        jump_delta, jump_transitions = _conditional_jump_delta(
            base, safe_final, active
        )
        conditional_jump_weighted_sum += jump_delta * jump_transitions
        conditional_jump_transition_count += jump_transitions
        directional.append(_directional_fraction(safe_final, proxy_xy))
        coverages.append(float(active.mean()))
        total_frame_count += int(len(active))
        active_count = int(active.sum())
        intervention_frame_count += active_count
        effective_evidence_count += int((active & supported).sum())
        if active_count:
            conditional_parent_agreement_hits += int(
                (parent_error[active] <= float(agreement_radius_m)).sum()
            )
            conditional_candidate_agreement_hits += int(
                (candidate_error[active] <= float(agreement_radius_m)).sum()
            )
            conditional_regret_hits += int(
                (candidate_error[active] > parent_error[active] + 1.0e-9).sum()
            )
            selected_feature = feature[
                np.arange(len(active)), nearest_physical
            ]
            feature_delta = selected_feature[active][:, (0, 3, 4, 5)] - feature[
                active, 0
            ][:, (0, 3, 4, 5)]
            evidence_delta_parts.append(feature_delta)
            evidence_dominance_hits += int(
                ((feature_delta >= 0.0).sum(axis=1) >= 2).sum()
            )
            intervention_shift_parts.append(
                np.linalg.norm(safe_final[active] - base[active], axis=1)
            )

    parent_error_all = np.concatenate(parent_errors)
    candidate_error_all = np.concatenate(candidate_errors)
    parent_agreement_rate = float(np.concatenate(parent_agreement).mean())
    candidate_agreement_rate = float(np.concatenate(candidate_agreement).mean())
    physical_support_rate = (
        1.0 if physical_trials == 0 else physical_hits / float(physical_trials)
    )
    if intervention_frame_count:
        conditional_parent_rate = conditional_parent_agreement_hits / float(
            intervention_frame_count
        )
        conditional_candidate_rate = conditional_candidate_agreement_hits / float(
            intervention_frame_count
        )
        conditional_agreement_delta = (
            conditional_candidate_rate - conditional_parent_rate
        )
        conditional_regret_rate = conditional_regret_hits / float(
            intervention_frame_count
        )
    else:
        conditional_agreement_delta = 0.0
        conditional_regret_rate = 0.0
    harmful_jump_rate_delta = (
        conditional_jump_weighted_sum / float(conditional_jump_transition_count)
        if conditional_jump_transition_count
        else 0.0
    )
    if evidence_delta_parts:
        evidence_delta = np.concatenate(evidence_delta_parts, axis=0)
        evidence_mean = evidence_delta.mean(axis=0)
        evidence_score_delta = float(
            np.mean(
                0.35 * evidence_delta[:, 0]
                + 0.25 * evidence_delta[:, 1]
                + 0.20 * evidence_delta[:, 2]
                + 0.20 * evidence_delta[:, 3]
            )
        )
        evidence_dominance_rate = evidence_dominance_hits / float(
            intervention_frame_count
        )
    else:
        evidence_mean = np.zeros(4, dtype=np.float64)
        evidence_score_delta = 0.0
        evidence_dominance_rate = 0.0
    if intervention_shift_parts:
        intervention_shift = np.concatenate(intervention_shift_parts)
        shift_mean = float(np.mean(intervention_shift))
        shift_p90 = float(np.quantile(intervention_shift, 0.90))
        shift_max = float(np.max(intervention_shift))
    else:
        shift_mean = shift_p90 = shift_max = 0.0
    return {
        "schema_version": "agent_jsac_label_free_branch_coordinate_canary_receipt_v1",
        "output_contract": "identity_or_frozen_cora_branch_coordinate",
        "proxy_definition": "raw_RA_RA_MTI_agreement_background_persistence_composite",
        "agreement_radius_m": float(agreement_radius_m),
        "physical_support_radius_m": float(physical_support_radius_m),
        "physical_support_rate": float(physical_support_rate),
        "candidate_set_agreement_delta": candidate_agreement_rate
        - parent_agreement_rate,
        "conditional_candidate_agreement_delta": float(
            conditional_agreement_delta
        ),
        "conditional_regret_rate": float(conditional_regret_rate),
        "harmful_jump_rate_delta": float(harmful_jump_rate_delta),
        "false_branch_rate_delta": float(-conditional_agreement_delta),
        "conditional_raw_score_delta": float(evidence_mean[0]),
        "conditional_ra_mti_agreement_delta": float(evidence_mean[1]),
        "conditional_background_clean_delta": float(evidence_mean[2]),
        "conditional_persistence_delta": float(evidence_mean[3]),
        "conditional_evidence_score_delta": float(evidence_score_delta),
        "conditional_evidence_dominance_rate": float(evidence_dominance_rate),
        "conditional_shift_mean_m": shift_mean,
        "conditional_shift_p90_m": shift_p90,
        "conditional_shift_max_m": shift_max,
        "trajectory_jump_rate_delta": float(
            np.mean(candidate_jumps) - np.mean(parent_jumps)
        ),
        "identity_regret_rate": float(np.concatenate(regrets).mean()),
        "directional_episode_fraction": float(np.mean(directional)),
        "p90_proxy_delta_m": float(
            np.quantile(candidate_error_all, 0.90)
            - np.quantile(parent_error_all, 0.90)
        ),
        "total_frame_count": int(total_frame_count),
        "intervention_frame_count": int(intervention_frame_count),
        "effective_evidence_count": int(effective_evidence_count),
        "nonfinite_output_count": int(nonfinite_output_count),
        "intervention_coverage": float(np.mean(coverages)),
        "support_canary_coverage_quantile_10": float(
            np.quantile(coverages, 0.10)
        ),
        "development_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }


def build_same_modality_empty_receipt(
    *,
    guard: Mapping[str, Any],
    output_contract: str,
    presence_owner: str,
) -> dict[str, Any]:
    """Bind a coordinate-only expert to the measured same-modality empty guard.

    Route experts cannot create presence.  The candidate and parent therefore
    execute the exact same measured SceneSentinel/parent presence path; only a
    coordinate may be selected after presence has already been accepted.
    """

    if output_contract not in {
        "identity_or_discrete_current_radar_candidate",
        "identity_or_frozen_cora_branch_coordinate",
    }:
        raise ValueError("empty safety inheritance requires a coordinate-only output contract")
    if presence_owner != "SceneSentinel+selected_parent":
        raise ValueError("empty safety must use the frozen same-modality presence owner")
    if guard.get("schema_version") != "agent_jsac_empty_guard_audit_v1":
        raise ValueError("unexpected EmptyGuard schema")
    if any(
        bool(guard.get(field))
        for field in ("locked_test_read", "final_bev_read", "target_human_label_read")
    ):
        raise ValueError("EmptyGuard reports a forbidden read")
    frames = int(guard.get("source_empty_frames", 0))
    parent_rate = float(guard.get("source_safe_false_candidate_rate", float("nan")))
    if frames <= 0 or not np.isfinite(parent_rate) or not 0.0 <= parent_rate <= 1.0:
        raise ValueError("EmptyGuard has no valid measured empty-scene baseline")
    return {
        "schema_version": "agent_jsac_same_modality_empty_safety_receipt_v1",
        "metric_id": "empty_false_alarm_delta",
        "source_empty_frames": frames,
        "presence_owner": presence_owner,
        "presence_path_unchanged": True,
        "parent_false_alarm_rate": parent_rate,
        "candidate_false_alarm_rate": parent_rate,
        "empty_false_alarm_delta": 0.0,
        "measurement_basis": "measured_empty_guard_plus_coordinate_only_expert_contract",
        "locked_test_read": False,
        "target_final_bev_read": False,
    }


def _require_fields(receipt: Mapping[str, Any], fields: Sequence[str], name: str) -> None:
    missing = [field for field in fields if receipt.get(field) is None]
    if missing:
        raise ValueError(f"{name} receipt misses {', '.join(missing)}")


def compose_frozen_aligned_route_metrics(
    *,
    binding_receipt: Mapping[str, Any],
    source_receipt: Mapping[str, Any],
    empty_receipt: Mapping[str, Any],
    canary_receipt: Mapping[str, Any],
) -> dict[str, Any]:
    """Compose, without defaults, the complete frozen route-expert metric row."""

    binding_fields = (
        "artifact_integrity",
        "provenance_completeness",
        "registered_primitive_binding",
        "parent_branch_binding",
        "application_contract_binding",
        "bounded_risk_recovery_contract",
        "forbidden_read_count",
    )
    _require_fields(binding_receipt, binding_fields, "binding")
    if source_receipt.get("source_candidate_hit_drop") is None and source_receipt.get(
        "source_ap_drop"
    ) is None:
        raise ValueError("source receipt misses source_candidate_hit_drop")
    _require_fields(empty_receipt, ("empty_false_alarm_delta",), "empty")
    _require_fields(canary_receipt, _ROUTE_CANARY_FIELDS, "canary")
    source_drop = source_receipt.get(
        "source_candidate_hit_drop", source_receipt.get("source_ap_drop")
    )
    return {
        "candidate_type": "route_expert",
        **{field: binding_receipt[field] for field in binding_fields},
        "non_promoted_runtime_weight": binding_receipt.get(
            "non_promoted_runtime_weight", 0.0
        ),
        "source_candidate_hit_drop": source_drop,
        "source_ap_drop": source_receipt.get("source_ap_drop", source_drop),
        "empty_false_alarm_delta": empty_receipt["empty_false_alarm_delta"],
        **{field: canary_receipt[field] for field in _ROUTE_CANARY_FIELDS},
        **{
            field: canary_receipt[field]
            for field in _ROUTE_CANARY_V2_FIELDS
            if canary_receipt.get(field) is not None
        },
    }
