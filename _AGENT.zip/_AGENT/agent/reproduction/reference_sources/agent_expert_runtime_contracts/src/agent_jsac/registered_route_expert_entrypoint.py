"""Archive-only envelope for superseded generic route-expert entrypoints.

The old semantic wrappers mapped many names to two shared generic trainers.  That
mapping was not equivalent to the validated native expert production lines.  The
wrappers remain describable for historical audits, but train/audit execution is
blocked.  Active dispatch must use ``native_expert_production_lines_v1.json``.
"""

from __future__ import annotations

import argparse
import json
from typing import Sequence

from .route_expert_recipe_registry import recipe_for_implementation


def fixed_entrypoint_payload(*, primitive: str, implementation_id: str) -> dict[str, object]:
    """Build the opaque fixed request a Dispatcher validates before execution."""

    return {
        "schema_version": "agent_jsac_registered_route_expert_entrypoint_v1",
        "primitive": str(primitive),
        "implementation_id": str(implementation_id),
        "recipe_type": recipe_for_implementation(implementation_id),
        "allowed_modes": ["describe"],
        "dispatcher_required": True,
        "free_primitive_override": False,
        "free_implementation_override": False,
        "execution_weight": 0.0,
        "status": "archive_only_superseded_generic_entrypoint",
        "replacement_registry": "configs/native_expert_production_lines_v1.json",
    }


def run_registered_route_expert_entrypoint(
    *, primitive: str, implementation_id: str, argv: Sequence[str] | None = None
) -> int:
    """Launch a fixed current-project trainer/auditor through immutable constants."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("describe", "train", "audit"), default="describe")
    parser.add_argument("--describe", action="store_true")
    args = parser.parse_args(argv)
    payload = fixed_entrypoint_payload(primitive=primitive, implementation_id=implementation_id)
    payload["requested_mode"] = args.mode
    if args.describe or args.mode == "describe":
        print(json.dumps(payload, ensure_ascii=True, sort_keys=True))
        return 0

    parser.error(
        "this generic route-expert entrypoint is archive-only; materialize the "
        "route's five native candidates from configs/native_expert_production_lines_v1.json"
    )
