"""Fresh three-branch stability router for CORA0, CORA-SE1, and CORA-SE2."""

from __future__ import annotations

import torch
from torch import Tensor, nn


BRANCH_ORDER = ("cora0", "cora_se1", "cora_se2")


def branch_feature_tensor(branch_xy_m: Tensor, branch_score: Tensor) -> Tensor:
    """Build scale-stable causal features from three frozen branch outputs."""

    if branch_xy_m.ndim != 3 or branch_xy_m.shape[1:] != (len(BRANCH_ORDER), 2):
        raise ValueError("branch_xy_m must be [frames,3,2]")
    if branch_score.shape != branch_xy_m.shape[:2]:
        raise ValueError("branch_score must be [frames,3]")
    scale = torch.tensor(
        [10.0, 20.0] * len(BRANCH_ORDER),
        device=branch_xy_m.device,
        dtype=branch_xy_m.dtype,
    )
    xy = branch_xy_m.reshape(branch_xy_m.shape[0], -1) / scale
    motion = torch.zeros_like(branch_xy_m)
    if branch_xy_m.shape[0] > 1:
        motion[1:] = branch_xy_m[1:] - branch_xy_m[:-1]
    motion = motion.reshape(branch_xy_m.shape[0], -1).clamp(-2.0, 2.0) / 2.0
    pairwise = torch.stack(
        (
            torch.linalg.vector_norm(branch_xy_m[:, 0] - branch_xy_m[:, 1], dim=-1),
            torch.linalg.vector_norm(branch_xy_m[:, 0] - branch_xy_m[:, 2], dim=-1),
            torch.linalg.vector_norm(branch_xy_m[:, 1] - branch_xy_m[:, 2], dim=-1),
        ),
        dim=-1,
    ).clamp(0.0, 4.0) / 4.0
    return torch.cat((xy, motion, branch_score.clamp(0.0, 1.0), pairwise), dim=-1)


def set_mass_branch_targets(
    branch_xy_m: Tensor,
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    candidate_weight: Tensor,
    *,
    sigma_m: float = 0.35,
    temperature: float = 0.15,
) -> tuple[Tensor, Tensor]:
    """Project a physical candidate set into a preference over frozen branches."""

    if branch_xy_m.ndim != 3 or candidate_xy_m.ndim != 3:
        raise ValueError("branch and candidate coordinates must be rank-3")
    if (
        branch_xy_m.shape[0] != candidate_xy_m.shape[0]
        or branch_xy_m.shape[1:] != (len(BRANCH_ORDER), 2)
    ):
        raise ValueError("candidate and branch timelines are incompatible")
    if candidate_valid.shape != candidate_xy_m.shape[:2] or candidate_weight.shape != candidate_valid.shape:
        raise ValueError("candidate validity/weight shapes are incompatible")
    safe_candidate_xy = torch.where(
        candidate_valid.unsqueeze(-1), candidate_xy_m, torch.zeros_like(candidate_xy_m)
    )
    distance_sq = (
        branch_xy_m.unsqueeze(2) - safe_candidate_xy.unsqueeze(1)
    ).square().sum(dim=-1)
    kernel = torch.exp(-0.5 * distance_sq / (float(sigma_m) ** 2))
    weights = candidate_weight.clamp_min(0.0) * candidate_valid.to(candidate_weight.dtype)
    utility = (kernel * weights.unsqueeze(1)).sum(dim=-1)
    frame_valid = weights.sum(dim=-1) > 0.0
    target = torch.softmax(
        torch.log(utility.clamp_min(1.0e-7)) / float(temperature), dim=-1
    )
    return target, frame_valid


def hard_branch_selection(
    logits: Tensor, *, base_index: int, margin: float
) -> tuple[Tensor, Tensor]:
    """Select another frozen branch only when it beats the parent by margin."""

    if logits.ndim != 2 or logits.shape[1] != len(BRANCH_ORDER):
        raise ValueError("logits must be [frames,3]")
    if base_index < 0 or base_index >= len(BRANCH_ORDER):
        raise ValueError("base_index out of range")
    probability = logits.softmax(dim=-1)
    candidate = probability.argmax(dim=-1)
    candidate_probability = probability.gather(1, candidate.unsqueeze(1)).squeeze(1)
    accepted = (
        (candidate != base_index)
        & (candidate_probability - probability[:, base_index] >= float(margin))
    )
    selected = torch.where(accepted, candidate, torch.full_like(candidate, base_index))
    return selected, accepted


class CausalBranchRouter(nn.Module):
    """A compact causal selector over three frozen CORA branches."""

    def __init__(self, input_dim: int = 18, hidden_dim: int = 48) -> None:
        super().__init__()
        self.input_dim = int(input_dim)
        self.hidden_dim = int(hidden_dim)
        self.normalization = nn.LayerNorm(self.input_dim)
        self.gru = nn.GRU(self.input_dim, self.hidden_dim, batch_first=True)
        self.head = nn.Sequential(
            nn.Linear(self.hidden_dim, self.hidden_dim),
            nn.SiLU(),
            nn.Linear(self.hidden_dim, len(BRANCH_ORDER)),
        )

    def forward(self, feature: Tensor) -> Tensor:
        if feature.ndim == 2:
            feature = feature.unsqueeze(0)
        if feature.ndim != 3 or feature.shape[-1] != self.input_dim:
            raise ValueError(f"feature must be [batch,frames,{self.input_dim}]")
        state, _ = self.gru(self.normalization(feature))
        return self.head(state)
