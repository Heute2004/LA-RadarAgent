"""Support-only runtime cache helpers for fresh SE-branch route experts.

The cache contains deployable RA/RA-MTI candidate features and a train-only
set-valued supervision overlay.  Target overlays are limited to the sealed
physical candidate set.  Source overlays may use SourceBEV replay labels.
Neither path emits a free coordinate.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np


SCHEMA_VERSION = "agent_jsac_se_branch_route_runtime_v1"
_FORBIDDEN_READ_FIELDS = (
    "target_final_bev_read",
    "development_label_read",
    "locked_test_read",
    "depth_read",
    "right_rgb_read",
    "manual_ra_anchor_read",
)


@dataclass(frozen=True)
class RouteRuntimeSupport:
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    supervision_origin: str


def calibrated_depth_lineage(candidate_manifest: Mapping[str, Any]) -> dict[str, Any]:
    """Extract the offline-only calibrated-depth provenance from R11."""

    raw = candidate_manifest.get("auxiliary_calibration_lineage")
    if not isinstance(raw, Mapping):
        raise ValueError("candidate manifest lacks calibrated-depth lineage")
    if raw.get("calibrated_depth_auxiliary") is not True:
        raise ValueError("calibrated-depth lineage is not enabled")
    if raw.get("depth_role") != "soft_range_likelihood_for_existing_candidate_reordering":
        raise ValueError("calibrated-depth role is invalid")
    if raw.get("free_coordinate_generation") is not False:
        raise ValueError("calibrated depth may not emit coordinates")
    return {
        "used": True,
        "role": "soft_range_likelihood_for_existing_candidate_reordering",
        "free_coordinate_generation": False,
        "raw_depth_reopened_in_this_runtime": False,
    }


def _normalise_mass(value: np.ndarray) -> np.ndarray:
    result = np.asarray(value, dtype=np.float32).copy()
    result /= np.maximum(result.sum(axis=1, keepdims=True), 1.0e-8)
    return result


def attach_source_bev_set_mass(
    *,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    base_xy_m: np.ndarray,
    frame_id: np.ndarray,
    source_track_csv: Path,
    radius_m: float = 0.35,
) -> RouteRuntimeSupport:
    """Map source-only SourceBEV replay labels to current physical candidates.

    Candidate zero remains the frozen SE parent.  Every non-zero positive
    action is one observed current-frame RA/RA-MTI candidate.  Frames with no
    close physical candidate abstain instead of synthesising a coordinate.
    """

    if radius_m <= 0.0:
        raise ValueError("source replay radius must be positive")
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    base = np.asarray(base_xy_m, dtype=np.float32)
    ids = np.asarray(frame_id, dtype=np.int64)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("candidate arrays must be [frames,candidates,(xy)]")
    if xy.shape[0] != ids.size or base.shape != (ids.size, 2):
        raise ValueError("source replay timeline mismatch")
    rows: dict[int, tuple[float, float]] = {}
    with Path(source_track_csv).open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if str(row.get("final_label_valid", "")).strip().lower() not in {"1", "true", "yes"}:
                continue
            raw_x = str(row.get("final_radar_x_m") or "").strip()
            raw_y = str(row.get("final_radar_y_m") or "").strip()
            if raw_x and raw_y:
                rows[int(row["frame_id"])] = (float(raw_x), float(raw_y))
    allowed = np.zeros(valid.shape, dtype=np.float32)
    sample_weight = np.zeros(ids.shape, dtype=np.float32)
    for position, current_frame in enumerate(ids.tolist()):
        target = rows.get(int(current_frame))
        if target is None:
            continue
        target_xy = np.asarray(target, dtype=np.float32)
        physical = np.flatnonzero(valid[position, 1:]) + 1
        if not physical.size:
            continue
        distance = np.linalg.norm(xy[position, physical] - target_xy[None, :], axis=1)
        nearest = int(physical[int(np.argmin(distance))])
        if float(distance.min()) > float(radius_m):
            continue
        allowed[position, nearest] = 1.0
        if float(np.linalg.norm(base[position] - target_xy)) <= float(radius_m):
            allowed[position, 0] = 1.0
        sample_weight[position] = 1.0
    return RouteRuntimeSupport(
        allowed_weight=_normalise_mass(allowed),
        sample_weight=sample_weight,
        supervision_origin="SourceBEV_replay",
    )


def validate_runtime_payload(payload: Mapping[str, np.ndarray]) -> None:
    """Reject an archive if it contains label leakage or a free candidate."""

    if str(np.asarray(payload["schema_version"]).item()) != SCHEMA_VERSION:
        raise ValueError("unexpected SE-branch route runtime schema")
    for field in _FORBIDDEN_READ_FIELDS:
        if bool(np.asarray(payload[field]).item()):
            raise ValueError(f"route runtime reports forbidden read: {field}")
    valid = np.asarray(payload["candidate_valid"], dtype=bool)
    xy = np.asarray(payload["candidate_xy_m"], dtype=np.float32)
    base = np.asarray(payload["base_xy_m"], dtype=np.float32)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("route runtime candidate geometry is invalid")
    if base.shape != (xy.shape[0], 2) or not np.allclose(xy[:, 0], base):
        raise ValueError("candidate zero must equal the frozen SE parent")
    if not np.all(valid[:, 0]) or not np.isfinite(xy[valid]).all():
        raise ValueError("route runtime candidate validity is invalid")
    allowed = np.asarray(payload["allowed_weight"], dtype=np.float32)
    weights = np.asarray(payload["sample_weight"], dtype=np.float32)
    if allowed.shape != valid.shape or weights.shape != (valid.shape[0],):
        raise ValueError("route runtime supervision shapes are invalid")
    if (allowed < 0.0).any() or (weights < 0.0).any() or not np.isfinite(allowed).all():
        raise ValueError("route runtime supervision values are invalid")


def write_runtime_manifest(
    *,
    output_dir: Path,
    records: list[Mapping[str, Any]],
    lineage: Mapping[str, Any] | None,
    role: str,
    route: str,
) -> None:
    """Write one readable, audit-safe cache manifest."""

    payload = {
        "schema_version": "agent_jsac_se_branch_route_runtime_manifest_v1",
        "route": route,
        "role": role,
        "records": list(records),
        "offline_calibrated_depth_lineage": None if lineage is None else dict(lineage),
        "runtime_inputs": [
            "raw_RA",
            "raw_RA_MTI",
            "same_frame_observed_physical_candidates",
            "causal_peak_persistence",
            "frozen_selected_SE_branch",
        ],
        "train_only_supervision": ["SourceBEV_replay_or_sealed_RadarCandidateSet"],
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
        },
    }
    (Path(output_dir) / "ROUTE_RUNTIME_MANIFEST.json").write_text(
        json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
