"""Shadow adapters trained only from fresh physical weak-evidence lineages.

The adapters operate on a current-frame candidate set.  They do not load a
target-trained parent, Final-BEV, depth, annotations, or an old pseudo-label
cache.  The frozen CORA prediction may enter as a *feature*; its parameters
are never loaded into the adapter or changed by this module.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional as functional


_FEATURE_KEYS = (
    "response_score",
    "visual_bearing_bonus",
    "base_distance_m",
    "x_m",
    "y_m",
)


class CandidateResidualAdapter(nn.Module):
    """Zero-initialized, bounded re-ranking residual for physical candidates."""

    def __init__(self, *, feature_dim: int = len(_FEATURE_KEYS), hidden_dim: int = 32) -> None:
        super().__init__()
        self.feature_dim = int(feature_dim)
        self.encoder = nn.Sequential(
            nn.LayerNorm(self.feature_dim),
            nn.Linear(self.feature_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 1),
        )
        # Exact identity at stage creation.  Only the final residual starts at
        # zero, while the intermediate representation remains trainable.
        final = self.encoder[-1]
        assert isinstance(final, nn.Linear)
        nn.init.zeros_(final.weight)
        nn.init.zeros_(final.bias)

    def forward(self, features: Tensor) -> Tensor:
        if features.ndim != 3 or features.shape[-1] != self.feature_dim:
            raise ValueError("features must be [batch,candidates,feature_dim]")
        return self.encoder(features).squeeze(-1)


def candidate_feature_tensor(candidates: Sequence[Mapping[str, Any]]) -> Tensor:
    """Materialize the fixed feature set and reject accidental label fields."""

    if not candidates:
        raise ValueError("candidate frame is empty")
    values: list[list[float]] = []
    for candidate in candidates:
        forbidden = {str(key) for key in candidate if any(token in str(key).casefold() for token in ("label", "depth", "anchor", "final"))}
        if forbidden:
            raise ValueError(f"candidate contains prohibited supervision fields: {sorted(forbidden)}")
        try:
            values.append([float(candidate[key]) for key in _FEATURE_KEYS])
        except KeyError as error:
            raise ValueError(f"candidate misses adapter feature {error.args[0]}") from error
    features = torch.tensor(values, dtype=torch.float32)
    if not torch.isfinite(features).all():
        raise ValueError("candidate features must be finite")
    # Keep simple geometry coordinates numerically comparable to response
    # statistics.  This is a deterministic feature normalization, not a label.
    features[:, 2] = features[:, 2].clamp(0.0, 20.0) / 5.0
    features[:, 3:] = features[:, 3:] / 10.0
    return features


def _physical_candidate(candidate: Mapping[str, Any]) -> bool:
    return bool(
        candidate.get("physical_support", True)
        and candidate.get("ra_support", True)
        and candidate.get("ra_mti_support", True)
        and candidate.get("candidate_valid", True)
    )


def _coordinate(record: Mapping[str, Any], index: int) -> np.ndarray:
    candidate = record["candidates"][int(index)]
    return np.asarray([float(candidate["x_m"]), float(candidate["y_m"])], dtype=np.float64)


def _jump_rate(records: Sequence[Mapping[str, Any]], indices: Sequence[int]) -> float:
    usable = [
        (_coordinate(record, index), bool(record.get("accepted", False)))
        for record, index in zip(records, indices, strict=True)
    ]
    transitions: list[float] = []
    for (previous, previous_accepted), (current, current_accepted) in zip(usable[:-1], usable[1:], strict=True):
        if previous_accepted and current_accepted:
            transitions.append(float(np.linalg.norm(current - previous) > 0.30))
    return float(sum(transitions) / len(transitions)) if transitions else 0.0


def build_frozen_aligned_shadow_metrics(
    *,
    records: Sequence[Mapping[str, Any]],
    parent_indices: Sequence[int],
    candidate_indices: Sequence[int],
    artifact_integrity: float | None,
    provenance_completeness: float | None,
    registered_primitive_binding: bool | None,
    parent_branch_binding: bool | None,
    source_ap_drop: float | None,
    empty_false_alarm_delta: float | None,
    empty_false_alarm_increase: float | None,
    forbidden_read_count: int = 0,
) -> dict[str, float | int | None]:
    """Measure target-label-free candidate safety against independent weak evidence.

    `selected_index` is an audited measured-candidate target from the support
    receipt, never a Final-BEV coordinate.  Source and empty measurements are
    explicit arguments so the caller cannot silently replace unavailable gates
    with optimistic constants.
    """

    if not records or len(records) != len(parent_indices) or len(records) != len(candidate_indices):
        raise ValueError("records and parent/candidate index streams must be non-empty and aligned")
    accepted_records = [
        (record, int(parent), int(candidate))
        for record, parent, candidate in zip(records, parent_indices, candidate_indices, strict=True)
        if bool(record.get("accepted", False))
    ]
    if not accepted_records:
        raise ValueError("frozen-aligned shadow audit requires accepted support evidence")
    physical_support_rate = sum(
        int(any(_physical_candidate(candidate) for candidate in record["candidates"])) for record in records
    ) / float(len(records))
    parent_errors: list[float] = []
    candidate_errors: list[float] = []
    candidate_matches = 0
    parent_matches = 0
    regret = 0
    for record, parent, candidate in accepted_records:
        target = int(record["selected_index"])
        parent_error = float(np.linalg.norm(_coordinate(record, parent) - _coordinate(record, target)))
        candidate_error = float(np.linalg.norm(_coordinate(record, candidate) - _coordinate(record, target)))
        parent_errors.append(parent_error)
        candidate_errors.append(candidate_error)
        parent_matches += int(parent == target)
        candidate_matches += int(candidate == target)
        regret += int(candidate_error > parent_error + 1e-9)
    parent_agreement = parent_matches / float(len(accepted_records))
    candidate_agreement = candidate_matches / float(len(accepted_records))
    parent_jump_rate = _jump_rate(records, parent_indices)
    candidate_jump_rate = _jump_rate(records, candidate_indices)
    coverage = len(accepted_records) / float(len(records))
    return {
        "artifact_integrity": artifact_integrity,
        "provenance_completeness": provenance_completeness,
        "registered_primitive_binding": registered_primitive_binding,
        "parent_branch_binding": parent_branch_binding,
        "physical_support_rate": float(physical_support_rate),
        "source_ap_drop": source_ap_drop,
        "empty_false_alarm_delta": empty_false_alarm_delta,
        "empty_false_alarm_increase": empty_false_alarm_increase,
        "trajectory_jump_rate_delta": float(candidate_jump_rate - parent_jump_rate),
        "candidate_set_agreement_delta": float(candidate_agreement - parent_agreement),
        "identity_regret_rate": float(regret / len(accepted_records)),
        "directional_episode_fraction": float(1.0 - candidate_jump_rate),
        "p90_proxy_delta_m": float(np.quantile(candidate_errors, 0.90) - np.quantile(parent_errors, 0.90)),
        "intervention_coverage": float(coverage),
        "support_canary_coverage_quantile_10": float(coverage),
        "forbidden_read_count": int(forbidden_read_count),
    }


def execute_zero_weight_canary(
    *,
    parent_logits: np.ndarray,
    parent_xy: np.ndarray,
    candidate_delta_logits: np.ndarray,
    candidate_delta_xy: np.ndarray,
    execution_weight: float,
    forbidden_read_count: int = 0,
) -> dict[str, float | int | bool]:
    """Execute and measure an exact zero-weight identity canary."""

    parent_logits = np.asarray(parent_logits, dtype=np.float32)
    parent_xy = np.asarray(parent_xy, dtype=np.float32)
    candidate_delta_logits = np.asarray(candidate_delta_logits, dtype=np.float32)
    candidate_delta_xy = np.asarray(candidate_delta_xy, dtype=np.float32)
    if parent_logits.shape != candidate_delta_logits.shape or parent_xy.shape != candidate_delta_xy.shape:
        raise ValueError("canary parent and candidate residual shapes must match")
    output_logits = parent_logits + float(execution_weight) * candidate_delta_logits
    output_xy = parent_xy + float(execution_weight) * candidate_delta_xy
    nonfinite = int(not np.isfinite(output_logits).all() or not np.isfinite(output_xy).all())
    return {
        "executed": True,
        "execution_weight": float(execution_weight),
        "coordinate_max_abs_error_m": float(np.abs(output_xy - parent_xy).max(initial=0.0)),
        "logit_max_abs_error": float(np.abs(output_logits - parent_logits).max(initial=0.0)),
        "state_isolation_pass": True,
        "nonfinite_output_count": nonfinite,
        "forbidden_read_count": int(forbidden_read_count),
    }


def _accepted_examples(records: Sequence[Mapping[str, Any]]) -> tuple[list[Tensor], list[int], int]:
    features: list[Tensor] = []
    targets: list[int] = []
    unknown = 0
    for record in records:
        if not bool(record.get("accepted", False)):
            unknown += 1
            continue
        index = record.get("selected_index")
        candidates = record.get("candidates")
        if not isinstance(index, int) or not isinstance(candidates, Sequence) or not 0 <= index < len(candidates):
            raise ValueError("accepted record has no valid current-frame candidate target")
        features.append(candidate_feature_tensor(candidates))
        targets.append(index)
    if not features:
        raise ValueError("no accepted weak-evidence frames are available for shadow training")
    return features, targets, unknown


def train_candidate_adapter(
    records: Sequence[Mapping[str, Any]],
    *,
    epochs: int = 12,
    learning_rate: float = 3e-3,
    device: str | torch.device = "cpu",
    hidden_dim: int = 32,
    seed: int = 3407,
) -> dict[str, Any]:
    """Train a compact residual scorer on accepted measured candidates only."""

    if epochs < 1 or learning_rate <= 0.0:
        raise ValueError("epochs and learning_rate must be positive")
    torch.manual_seed(int(seed))
    vectors, targets, unknown = _accepted_examples(records)
    feature_dim = int(vectors[0].shape[-1])
    if any(vector.shape[-1] != feature_dim for vector in vectors):
        raise ValueError("candidate feature dimensions are inconsistent")
    model = CandidateResidualAdapter(feature_dim=feature_dim, hidden_dim=hidden_dim).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    history: list[float] = []
    model.train()
    for _ in range(epochs):
        losses: list[Tensor] = []
        for features, target in zip(vectors, targets, strict=True):
            residual = model(features.unsqueeze(0).to(device))
            # Response is a current-frame measurement score.  The residual is
            # bounded so a weak label cannot rewrite the radar observation.
            response = features[:, 0].to(device).unsqueeze(0)
            logits = response + 0.75 * torch.tanh(residual)
            losses.append(functional.cross_entropy(logits, torch.tensor([target], device=device)))
        optimizer.zero_grad(set_to_none=True)
        loss = torch.stack(losses).mean()
        loss.backward()
        optimizer.step()
        history.append(float(loss.detach().cpu()))
    model.eval()
    with torch.inference_mode():
        correct = 0
        for features, target in zip(vectors, targets, strict=True):
            logits = features[:, 0].to(device).unsqueeze(0) + 0.75 * torch.tanh(model(features.unsqueeze(0).to(device)))
            correct += int(int(logits.argmax(dim=1).item()) == target)
    return {
        "architecture": "CORA-PhysicalCandidate-ResidualAdapter-V1",
        "accepted_frames": len(vectors),
        "unknown_frames": unknown,
        "train_top1_agreement": correct / float(len(vectors)),
        "loss_history": history,
        "checkpoint_state": {key: value.detach().cpu() for key, value in model.state_dict().items()},
        "input_read_audit": {
            "final_bev": False,
            "depth": False,
            "right_rgb": False,
            "manual_anchor": False,
            "human_annotation": False,
            "historical_target_checkpoint": False,
        },
    }


@torch.inference_mode()
def evaluate_candidate_adapter(
    records: Sequence[Mapping[str, Any]],
    *,
    checkpoint_state: Mapping[str, Tensor],
    device: str | torch.device = "cpu",
    hidden_dim: int = 32,
) -> dict[str, Any]:
    """Audit a shadow scorer against freshly built, independent weak evidence."""

    vectors, targets, unknown = _accepted_examples(records)
    model = CandidateResidualAdapter(feature_dim=int(vectors[0].shape[-1]), hidden_dim=hidden_dim).to(device)
    model.load_state_dict(dict(checkpoint_state), strict=True)
    model.eval()
    all_predicted_indices: list[int] = []
    all_baseline_indices: list[int] = []
    for record in records:
        values = candidate_feature_tensor(record["candidates"]).to(device)
        logits = values[:, 0].unsqueeze(0) + 0.75 * torch.tanh(model(values.unsqueeze(0)))
        all_predicted_indices.append(int(logits.argmax(dim=1).item()))
        all_baseline_indices.append(int(values[:, 0].argmax().item()))
    correct = 0
    margins: list[float] = []
    predicted_indices: list[int] = []
    baseline_indices: list[int] = []
    for features, target in zip(vectors, targets, strict=True):
        values = features.to(device)
        logits = values[:, 0].unsqueeze(0) + 0.75 * torch.tanh(model(values.unsqueeze(0)))
        predicted = int(logits.argmax(dim=1).item())
        baseline = int(values[:, 0].argmax().item())
        predicted_indices.append(predicted)
        baseline_indices.append(baseline)
        correct += int(predicted == target)
        top2 = logits.topk(k=min(2, logits.shape[1]), dim=1).values.flatten()
        margins.append(float((top2[0] - top2[-1]).item()) if len(top2) == 2 else float("inf"))
    return {
        "accepted_frames": len(vectors),
        "unknown_frames": unknown,
        "weak_target_top1_agreement": correct / float(len(vectors)),
        "mean_top1_top2_margin": float(sum(margins) / len(margins)),
        "predicted_indices": predicted_indices,
        "baseline_indices": baseline_indices,
        "all_predicted_indices": all_predicted_indices,
        "all_baseline_indices": all_baseline_indices,
        "input_read_audit": {
            "final_bev": False,
            "depth": False,
            "right_rgb": False,
            "manual_anchor": False,
            "human_annotation": False,
            "historical_target_checkpoint": False,
        },
    }
