"""Route-aware, label-free promotion metrics for shadow candidates.

This module is intentionally pure.  It classifies metric receipts but never
loads Development truth, model checkpoints, or runtime data.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Mapping


_PROFILE_PATH = (
    Path(__file__).resolve().parents[2]
    / "configs"
    / "route_aware_promotion_metrics_v2.json"
)

_CANDIDATE_STATES = {
    "shadow_eligible",
    "identity_no_effect",
    "rejected_harm",
    "rejected_insufficient_evidence",
    "rejected_integrity",
}
_ROUTE_PARENT_BRANCHES = {
    "open_indoor_los": "cora_se1",
    "indoor_clutter": "cora_se2",
    "open_outdoor_weak_return": "cora_se1",
    "outdoor_dry_complex": "cora_se2",
    "outdoor_wet_return": "cora_se2",
    "corner_nlos_ris": "cora0",
}


def load_route_aware_profile(path: str | Path = _PROFILE_PATH) -> dict[str, Any]:
    """Load and validate the route-aware metric profile."""

    profile = json.loads(Path(path).read_text(encoding="utf-8"))
    if profile.get("schema_version") != "agent_jsac_route_aware_promotion_metrics_v2":
        raise ValueError("unexpected route-aware metric profile schema")
    for section in (
        "internal_stage",
        "route_expert",
        "zero_weight_canary",
        "global_invariants",
    ):
        if not isinstance(profile.get(section), Mapping):
            raise ValueError(f"route-aware metric profile misses section: {section}")
    route_definitions = profile["route_expert"].get("routes")
    if not isinstance(route_definitions, Mapping) or not route_definitions:
        raise ValueError("route-aware metric profile has no route definitions")
    return profile


def route_parent_branch(route: str) -> str:
    """Return the immutable SE parent used when a route expert is not promoted."""

    try:
        return _ROUTE_PARENT_BRANCHES[str(route)]
    except KeyError as error:
        raise ValueError(f"route has no registered SE parent: {route}") from error


def find_retrospective_fields(
    payload: Any,
    profile: Mapping[str, Any],
) -> tuple[str, ...]:
    """Find fields that are legal only in the sealed retrospective audit."""

    forbidden = set(
        profile.get("retrospective_alignment_fields_forbidden_in_prospective_runtime", ())
    )
    found: set[str] = set()

    def visit(value: Any) -> None:
        if isinstance(value, Mapping):
            for key, item in value.items():
                name = str(key)
                if name in forbidden:
                    found.add(name)
                visit(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                visit(item)

    visit(payload)
    return tuple(sorted(found))


def _is_finite_scalar(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    )


def _comparison_passes(actual: Any, comparison: str, expected: Any) -> bool:
    if isinstance(expected, bool):
        return comparison == "==" and isinstance(actual, bool) and actual is expected
    if not _is_finite_scalar(actual) or not _is_finite_scalar(expected):
        return False
    left = float(actual)
    right = float(expected)
    if comparison == ">=":
        return left >= right
    if comparison == "<=":
        return left <= right
    if comparison == "==":
        return left == right
    raise ValueError(f"unsupported gate comparison: {comparison}")


def _evaluate_group(
    metrics: Mapping[str, Any],
    definitions: Mapping[str, Mapping[str, Any]],
    *,
    group: str,
    key_prefix: str = "",
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    gates: dict[str, dict[str, Any]] = {}
    failed: list[str] = []
    for metric_name, definition in definitions.items():
        comparison = str(definition["comparison"])
        expected = definition["value"]
        actual = metrics.get(metric_name)
        passed = _comparison_passes(actual, comparison, expected)
        gate_key = f"{key_prefix}{metric_name}"
        gates[gate_key] = {
            "metric": metric_name,
            "group": group,
            "actual": actual,
            "comparison": comparison,
            "expected": expected,
            "passed": passed,
        }
        if not passed:
            failed.append(metric_name)
    return gates, failed


def _require_candidate_type(metrics: Mapping[str, Any], expected: str) -> None:
    actual = metrics.get("candidate_type")
    if actual != expected:
        raise ValueError(
            f"candidate_type must be {expected!r} for this evaluator; got {actual!r}"
        )


def _result(
    *,
    profile: Mapping[str, Any],
    stage: str,
    candidate_state: str,
    gates: Mapping[str, Any],
    failed_gates: list[str],
    route: str | None = None,
    utility_alternative: str | None = None,
) -> dict[str, Any]:
    if candidate_state not in _CANDIDATE_STATES:
        raise AssertionError(f"unknown candidate state: {candidate_state}")
    payload: dict[str, Any] = {
        "profile_id": profile["profile_id"],
        "stage": stage,
        "candidate_state": candidate_state,
        "eligible": candidate_state == "shadow_eligible",
        "passed": candidate_state == "shadow_eligible",
        "failed_gates": list(dict.fromkeys(failed_gates)),
        "gates": dict(gates),
    }
    if route is not None:
        payload["route"] = route
    if utility_alternative is not None:
        payload["utility_alternative"] = utility_alternative
    return payload


def evaluate_internal_stage_v2(
    metrics: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    """Classify a CORA-SE internal adaptation stage."""

    _require_candidate_type(metrics, "internal_stage")
    section = profile["internal_stage"]
    gates: dict[str, Any] = {}

    integrity_gates, integrity_failed = _evaluate_group(
        metrics, section["integrity_gates"], group="integrity"
    )
    gates.update(integrity_gates)
    if integrity_failed:
        return _result(
            profile=profile,
            stage="internal_stage",
            candidate_state="rejected_integrity",
            gates=gates,
            failed_gates=integrity_failed,
        )

    harm_gates, harm_failed = _evaluate_group(
        metrics, section["harm_gates"], group="harm"
    )
    gates.update(harm_gates)
    if harm_failed:
        return _result(
            profile=profile,
            stage="internal_stage",
            candidate_state="rejected_harm",
            gates=gates,
            failed_gates=harm_failed,
        )

    evidence_gates, evidence_failed = _evaluate_group(
        metrics, section["evidence_gates"], group="evidence"
    )
    gates.update(evidence_gates)
    utility_gates, utility_failed = _evaluate_group(
        metrics, section["utility_gates"], group="utility"
    )
    gates.update(utility_gates)
    failed = evidence_failed + utility_failed
    state = "shadow_eligible" if not failed else "rejected_insufficient_evidence"
    return _result(
        profile=profile,
        stage="internal_stage",
        candidate_state=state,
        gates=gates,
        failed_gates=failed,
    )


def evaluate_route_expert_v2(
    route: str,
    metrics: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    """Classify a sparse route expert under its mechanism-specific contract."""

    _require_candidate_type(metrics, "route_expert")
    section = profile["route_expert"]
    routes = section["routes"]
    if route not in routes:
        raise ValueError(f"route has no V2 metric contract: {route}")
    route_definition = routes[route]
    if route_definition.get("external_contract_only") is True:
        raise ValueError(f"route uses a separate external contract: {route}")

    gates: dict[str, Any] = {}
    integrity_gates, integrity_failed = _evaluate_group(
        metrics, section["integrity_gates"], group="integrity"
    )
    gates.update(integrity_gates)
    if integrity_failed:
        return _result(
            profile=profile,
            stage="route_expert",
            route=route,
            candidate_state="rejected_integrity",
            gates=gates,
            failed_gates=integrity_failed,
        )

    harm_gates, harm_failed = _evaluate_group(
        metrics, section["harm_gates"], group="harm"
    )
    gates.update(harm_gates)
    if harm_failed:
        return _result(
            profile=profile,
            stage="route_expert",
            route=route,
            candidate_state="rejected_harm",
            gates=gates,
            failed_gates=harm_failed,
        )

    observation_gates, observation_failed = _evaluate_group(
        metrics, section["observation_gates"], group="observation"
    )
    gates.update(observation_gates)
    if observation_failed:
        return _result(
            profile=profile,
            stage="route_expert",
            route=route,
            candidate_state="rejected_insufficient_evidence",
            gates=gates,
            failed_gates=observation_failed,
        )

    intervention_count = metrics.get("intervention_frame_count")
    if _is_finite_scalar(intervention_count) and float(intervention_count) == 0.0:
        return _result(
            profile=profile,
            stage="route_expert",
            route=route,
            candidate_state="identity_no_effect",
            gates=gates,
            failed_gates=[],
        )

    evidence_gates, evidence_failed = _evaluate_group(
        metrics, section["evidence_gates"], group="evidence"
    )
    gates.update(evidence_gates)
    if evidence_failed:
        return _result(
            profile=profile,
            stage="route_expert",
            route=route,
            candidate_state="rejected_insufficient_evidence",
            gates=gates,
            failed_gates=evidence_failed,
        )

    contract_definitions = route_definition.get("required_contract_metrics", {})
    if not isinstance(contract_definitions, Mapping):
        raise ValueError(f"route contract metrics are invalid: {route}")
    contract_gates, contract_failed = _evaluate_group(
        metrics,
        contract_definitions,
        group="route_contract",
        key_prefix="route_contract.",
    )
    gates.update(contract_gates)
    if contract_failed:
        return _result(
            profile=profile,
            stage="route_expert",
            route=route,
            candidate_state="rejected_insufficient_evidence",
            gates=gates,
            failed_gates=contract_failed,
        )

    alternatives = route_definition.get("utility_any_of", [])
    if not isinstance(alternatives, list) or not alternatives:
        raise ValueError(f"route utility contract is empty: {route}")
    failed_alternatives: list[str] = []
    for alternative in alternatives:
        alternative_id = str(alternative["id"])
        alternative_gates, alternative_failed = _evaluate_group(
            metrics,
            alternative["required_metrics"],
            group="route_utility",
            key_prefix=f"route_utility.{alternative_id}.",
        )
        gates.update(alternative_gates)
        if not alternative_failed:
            return _result(
                profile=profile,
                stage="route_expert",
                route=route,
                candidate_state="shadow_eligible",
                gates=gates,
                failed_gates=[],
                utility_alternative=alternative_id,
            )
        failed_alternatives.append(alternative_id)

    return _result(
        profile=profile,
        stage="route_expert",
        route=route,
        candidate_state="rejected_insufficient_evidence",
        gates=gates,
        failed_gates=[f"route_utility:{item}" for item in failed_alternatives],
    )


def evaluate_zero_weight_canary_v2(
    metrics: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    """Validate that a Shadow candidate cannot affect runtime before promotion."""

    gates, failed = _evaluate_group(
        metrics,
        profile["zero_weight_canary"]["required_metrics"],
        group="zero_weight_canary",
    )
    return {
        "profile_id": profile["profile_id"],
        "stage": "zero_weight_canary",
        "passed": not failed,
        "failed_gates": failed,
        "gates": gates,
    }
