"""Fail-closed loading and Top-5 retrieval for the unified 42-expert pool."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Sequence

from .registered_route_expert_models import registered_implementation_ids
from .route_expert_recipe_registry import recipe_for_implementation


class AdaptiveExpertLibraryError(ValueError):
    """Raised when an adaptive-expert catalog is incomplete or unsafe."""


_SCHEMA = "agent_jsac_expert_pool_42_v1"
_ROUTES = (
    "open_indoor_los",
    "indoor_clutter",
    "open_outdoor_weak_return",
    "outdoor_dry_complex",
    "outdoor_wet_return",
    "corner_nlos_ris",
)
_DIRECT_EVIDENCE = (
    "source_bev_replay",
    "empty_guard",
    "radar_candidate_set",
    "evolved_posterior",
)
_RIS_EVIDENCE = ("risecho",)
_EXPERT_KEYS = {
    "expert_id",
    "route",
    "primitive",
    "mechanism_family",
    "mechanism_tags",
    "signal_tags",
    "parent_branch",
    "required_evidence",
    "historical_checkpoint_import",
    "runtime_raw_depth_input",
    "target_final_bev_read",
    "offline_depth_soft_likelihood_allowed",
    "description",
    "implementation_id",
    "entrypoint_relative_path",
    "entrypoint_sha256",
    "application_contract",
}
_TOP_KEYS = {
    "schema_version",
    "pool_size",
    "selection",
    "experts",
}
_DEFAULT_APPLICATION_CONTRACT = MappingProxyType(
    {
        "mode": "exact_observed_candidate",
        "posterior_scale": 1.0,
        "maximum_correction_m": None,
        "identity_fallback_required": True,
    }
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _mapping(value: object, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise AdaptiveExpertLibraryError(f"{field} must be an object")
    return value


def _tags(value: object, field: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value or not all(isinstance(item, str) for item in value):
        raise AdaptiveExpertLibraryError(f"{field} must be a non-empty string list")
    result = tuple(str(item).strip() for item in value)
    if any(not item for item in result) or len(set(result)) != len(result):
        raise AdaptiveExpertLibraryError(f"{field} contains blank or duplicate tags")
    return result


def _safe_relative_path(root: Path, relative_path: str, expected_sha256: str) -> tuple[Path, str]:
    relative = Path(str(relative_path).replace("\\", "/"))
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        raise AdaptiveExpertLibraryError("extension entrypoint must be a safe project-relative path")
    path = (root / relative).resolve()
    try:
        path.relative_to(root)
    except ValueError as error:
        raise AdaptiveExpertLibraryError("extension entrypoint escapes project root") from error
    if not path.is_file():
        raise AdaptiveExpertLibraryError(f"extension entrypoint is missing: {relative.as_posix()}")
    expected = str(expected_sha256).lower()
    if len(expected) != 64 or any(character not in "0123456789abcdef" for character in expected):
        raise AdaptiveExpertLibraryError("extension entrypoint SHA256 must be lowercase hex")
    actual = _sha256(path)
    if actual != expected:
        raise AdaptiveExpertLibraryError(
            f"extension entrypoint SHA256 mismatch: {relative.as_posix()}; expected {expected}, got {actual}"
        )
    return path, actual


@dataclass(frozen=True)
class AdaptiveExpertEntry:
    template_id: str
    route: str
    primitive: str
    mechanism_family: str
    mechanism_tags: tuple[str, ...]
    signal_tags: tuple[str, ...]
    parent_branch: str
    required_evidence: tuple[str, ...]
    historical_checkpoint_import: bool
    runtime_raw_depth_input: bool
    target_final_bev_read: bool
    offline_depth_soft_likelihood_allowed: bool
    description: str
    implementation_id: str
    entrypoint_relative_path: str
    entrypoint_path: Path
    entrypoint_sha256: str
    application_contract: Mapping[str, Any]

    @property
    def output_contract(self) -> str:
        if recipe_for_implementation(self.implementation_id) == "branch_router":
            return "identity_or_frozen_cora_branch_coordinate"
        return "identity_or_discrete_current_radar_candidate"

    @property
    def identity_fallback(self) -> str:
        return self.parent_branch

    def public_receipt(self) -> dict[str, object]:
        return {
            "route": self.route,
            "primitive": self.primitive,
            "expert_id": self.template_id,
            "mechanism_family": self.mechanism_family,
            "implementation_id": self.implementation_id,
            "identity_fallback": self.identity_fallback,
            "output_contract": self.output_contract,
            "application_contract": dict(self.application_contract),
        }


@dataclass(frozen=True)
class AdaptiveExpertSemanticLibrary:
    entries: tuple[AdaptiveExpertEntry, ...]
    shortlist_size: int
    minimum_distinct_mechanism_families: int
    weights: Mapping[str, float]
    _by_route: Mapping[str, tuple[AdaptiveExpertEntry, ...]]

    @property
    def routes(self) -> tuple[str, ...]:
        return tuple(_ROUTES)

    def entries_for_route(self, route: str) -> tuple[AdaptiveExpertEntry, ...]:
        try:
            return self._by_route[str(route)]
        except KeyError as error:
            raise AdaptiveExpertLibraryError(f"unknown adaptive-expert route: {route!r}") from error


def load_adaptive_expert_semantic_library(path: Path) -> AdaptiveExpertSemanticLibrary:
    """Load the one flat 42-entry pool and verify every registered entrypoint."""

    catalog_path = Path(path).resolve()
    root = catalog_path.parents[1]
    try:
        raw = json.loads(catalog_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as error:
        raise AdaptiveExpertLibraryError("expert pool is not valid JSON") from error
    value = _mapping(raw, "expert pool")
    if set(value) != _TOP_KEYS or value.get("schema_version") != _SCHEMA:
        raise AdaptiveExpertLibraryError("unsupported expert-pool schema")
    if int(value["pool_size"]) != 42:
        raise AdaptiveExpertLibraryError("expert pool must declare exactly forty-two entries")

    selection = _mapping(value["selection"], "selection")
    if set(selection) != {"shortlist_size", "minimum_distinct_mechanism_families", "weights"}:
        raise AdaptiveExpertLibraryError("adaptive selection fields mismatch")
    shortlist_size = int(selection["shortlist_size"])
    minimum_families = int(selection["minimum_distinct_mechanism_families"])
    weights_raw = _mapping(selection["weights"], "selection.weights")
    if shortlist_size != 5 or minimum_families != 3 or set(weights_raw) != {"semantic", "signal", "historical"}:
        raise AdaptiveExpertLibraryError("adaptive selection policy violates the fixed Top-5 contract")
    weights = {key: float(weights_raw[key]) for key in weights_raw}
    if not all(math.isfinite(item) and item >= 0.0 for item in weights.values()) or not math.isclose(
        sum(weights.values()), 1.0, rel_tol=0.0, abs_tol=1.0e-9
    ):
        raise AdaptiveExpertLibraryError("adaptive selection weights must be finite, non-negative, and sum to one")

    entries: list[AdaptiveExpertEntry] = []
    raw_experts = value["experts"]
    if not isinstance(raw_experts, list) or len(raw_experts) != 42:
        raise AdaptiveExpertLibraryError("expert pool requires exactly forty-two entries")
    for index, raw_expert in enumerate(raw_experts):
        entry = _mapping(raw_expert, f"experts[{index}]")
        if set(entry) != _EXPERT_KEYS:
            raise AdaptiveExpertLibraryError(f"experts[{index}] fields mismatch")
        route = str(entry["route"])
        if route not in _ROUTES:
            raise AdaptiveExpertLibraryError("expert route is not registered")
        expected_evidence = _RIS_EVIDENCE if route == "corner_nlos_ris" else _DIRECT_EVIDENCE
        if tuple(entry["required_evidence"]) != expected_evidence:
            raise AdaptiveExpertLibraryError("expert evidence contract mismatch")
        parent = str(entry["parent_branch"])
        expected_parent = "cora0" if route == "corner_nlos_ris" else "route_selected"
        if parent != expected_parent:
            raise AdaptiveExpertLibraryError("expert parent branch conflicts with the route topology")
        if any(
            bool(entry[key])
            for key in ("historical_checkpoint_import", "runtime_raw_depth_input", "target_final_bev_read")
        ):
            raise AdaptiveExpertLibraryError("expert enables a forbidden historical, depth, or target-label read")
        template_id = str(entry["expert_id"]).strip()
        primitive = str(entry["primitive"]).strip()
        implementation_id = str(entry["implementation_id"]).strip()
        description = str(entry["description"]).strip()
        family = str(entry["mechanism_family"]).strip()
        if not all((template_id, primitive, implementation_id, description, family)):
            raise AdaptiveExpertLibraryError("expert identifiers and description must be non-empty")
        entrypoint_path, digest = _safe_relative_path(
            root, str(entry["entrypoint_relative_path"]), str(entry["entrypoint_sha256"])
        )
        application_contract = _mapping(entry["application_contract"], f"experts[{index}].application_contract")
        if set(application_contract) != set(_DEFAULT_APPLICATION_CONTRACT):
            raise AdaptiveExpertLibraryError("expert application contract fields mismatch")
        if application_contract.get("identity_fallback_required") is not True:
            raise AdaptiveExpertLibraryError("expert must preserve identity fallback")
        entries.append(
            AdaptiveExpertEntry(
                template_id=template_id,
                route=route,
                primitive=primitive,
                mechanism_family=family,
                mechanism_tags=_tags(entry["mechanism_tags"], f"experts[{index}].mechanism_tags"),
                signal_tags=_tags(entry["signal_tags"], f"experts[{index}].signal_tags"),
                parent_branch=parent,
                required_evidence=expected_evidence,
                historical_checkpoint_import=False,
                runtime_raw_depth_input=False,
                target_final_bev_read=False,
                offline_depth_soft_likelihood_allowed=bool(entry["offline_depth_soft_likelihood_allowed"]),
                description=description,
                implementation_id=implementation_id,
                entrypoint_relative_path=str(entry["entrypoint_relative_path"]).replace("\\", "/"),
                entrypoint_path=entrypoint_path,
                entrypoint_sha256=digest,
                application_contract=MappingProxyType(dict(application_contract)),
            )
        )

    if len(entries) != 42:
        raise AdaptiveExpertLibraryError("expert pool must resolve exactly forty-two entries")
    for attribute in ("template_id", "primitive", "implementation_id", "entrypoint_relative_path"):
        values = [str(getattr(entry, attribute)) for entry in entries]
        if len(values) != len(set(values)):
            raise AdaptiveExpertLibraryError(f"expert pool has duplicate {attribute}")
    supported_implementations = set(registered_implementation_ids())
    if set(entry.implementation_id for entry in entries) != supported_implementations:
        raise AdaptiveExpertLibraryError("expert pool/model implementation coverage mismatch")

    by_route = {route: tuple(entry for entry in entries if entry.route == route) for route in _ROUTES}
    if any(len(route_entries) != 7 for route_entries in by_route.values()):
        raise AdaptiveExpertLibraryError("every route must expose exactly seven experts")
    if any(len({entry.mechanism_family for entry in route_entries}) < 3 for route_entries in by_route.values()):
        raise AdaptiveExpertLibraryError("every route must expose at least three mechanism families")
    return AdaptiveExpertSemanticLibrary(
        entries=tuple(entries),
        shortlist_size=shortlist_size,
        minimum_distinct_mechanism_families=minimum_families,
        weights=MappingProxyType(weights),
        _by_route=MappingProxyType(by_route),
    )


@dataclass(frozen=True)
class DiagnosticPacket:
    """Constrained semantic and signal evidence for one active route episode."""

    route: str
    mechanism_scores: Mapping[str, float]
    signal_scores: Mapping[str, float]
    historical_scores: Mapping[str, float] | None = None
    agent_diagnosis: str | None = None


@dataclass(frozen=True)
class AdaptiveExpertSelection:
    route: str
    entries: tuple[AdaptiveExpertEntry, ...]
    scores: Mapping[str, float]
    agent_diagnosis: str | None

    def public_receipt(self) -> dict[str, object]:
        return {
            "route": self.route,
            "shortlist_size": len(self.entries),
            "agent_diagnosis": self.agent_diagnosis,
            "candidates": [entry.public_receipt() for entry in self.entries],
        }


def _bounded_scores(value: Mapping[str, float], field: str) -> dict[str, float]:
    result: dict[str, float] = {}
    for key, raw_score in value.items():
        name = str(key).strip()
        try:
            score = float(raw_score)
        except (TypeError, ValueError) as error:
            raise AdaptiveExpertLibraryError(f"{field}.{name} must be numeric") from error
        if not name or not math.isfinite(score) or not 0.0 <= score <= 1.0:
            raise AdaptiveExpertLibraryError(f"{field}.{name} must lie in [0, 1]")
        result[name] = score
    return result


def _mean_score(tags: Sequence[str], scores: Mapping[str, float]) -> float:
    return sum(float(scores.get(tag, 0.0)) for tag in tags) / len(tags)


def _validate_packet(
    library: AdaptiveExpertSemanticLibrary, packet: DiagnosticPacket
) -> tuple[tuple[AdaptiveExpertEntry, ...], dict[str, float], dict[str, float], dict[str, float]]:
    entries = library.entries_for_route(packet.route)
    mechanism = _bounded_scores(packet.mechanism_scores, "mechanism_scores")
    signal = _bounded_scores(packet.signal_scores, "signal_scores")
    historical = _bounded_scores(packet.historical_scores or {}, "historical_scores")
    known_mechanisms = {tag for entry in entries for tag in entry.mechanism_tags}
    known_signals = {tag for entry in entries for tag in entry.signal_tags}
    unknown_mechanisms = set(mechanism) - known_mechanisms
    unknown_signals = set(signal) - known_signals
    unknown_history = set(historical) - {entry.template_id for entry in entries}
    if unknown_mechanisms:
        raise AdaptiveExpertLibraryError(f"unknown mechanism evidence for route: {sorted(unknown_mechanisms)}")
    if unknown_signals:
        raise AdaptiveExpertLibraryError(f"unknown signal evidence for route: {sorted(unknown_signals)}")
    if unknown_history:
        raise AdaptiveExpertLibraryError(f"unknown historical receipt for route: {sorted(unknown_history)}")
    if packet.agent_diagnosis is not None and str(packet.agent_diagnosis) not in known_mechanisms:
        raise AdaptiveExpertLibraryError("agent diagnosis is not registered for the active route")
    return entries, mechanism, signal, historical


def _score_entry(
    entry: AdaptiveExpertEntry,
    *,
    weights: Mapping[str, float],
    mechanism: Mapping[str, float],
    signal: Mapping[str, float],
    historical: Mapping[str, float],
    agent_diagnosis: str | None,
) -> float:
    semantic = _mean_score(entry.mechanism_tags, mechanism)
    if agent_diagnosis is not None and str(agent_diagnosis) in entry.mechanism_tags:
        semantic = min(1.0, semantic + 0.15)
    evidence = _mean_score(entry.signal_tags, signal)
    prior = float(historical.get(entry.template_id, 0.5))
    return (
        float(weights["semantic"]) * semantic
        + float(weights["signal"]) * evidence
        + float(weights["historical"]) * prior
    )


def select_diverse_top5(
    library: AdaptiveExpertSemanticLibrary, packet: DiagnosticPacket
) -> AdaptiveExpertSelection:
    """Return five route-local semantic candidates with deterministic family diversity.

    The caller may obtain `agent_diagnosis` from a constrained Qwen option set, but
    the diagnosis is only one bounded ranking input. It cannot add a candidate,
    select a script, or bypass route/evidence validation.
    """

    entries, mechanism, signal, historical = _validate_packet(library, packet)
    scores = {
        entry.template_id: _score_entry(
            entry,
            weights=library.weights,
            mechanism=mechanism,
            signal=signal,
            historical=historical,
            agent_diagnosis=packet.agent_diagnosis,
        )
        for entry in entries
    }
    ranked = tuple(sorted(entries, key=lambda entry: (-scores[entry.template_id], entry.template_id)))
    family_best: list[AdaptiveExpertEntry] = []
    seen_families: set[str] = set()
    for entry in ranked:
        if entry.mechanism_family not in seen_families:
            family_best.append(entry)
            seen_families.add(entry.mechanism_family)
    selected = family_best[: library.minimum_distinct_mechanism_families]
    selected_ids = {entry.template_id for entry in selected}
    for entry in ranked:
        if len(selected) >= library.shortlist_size:
            break
        if entry.template_id not in selected_ids:
            selected.append(entry)
            selected_ids.add(entry.template_id)
    if len(selected) != library.shortlist_size:
        raise AdaptiveExpertLibraryError("cannot form the fixed five-candidate shortlist")
    return AdaptiveExpertSelection(
        route=str(packet.route),
        entries=tuple(selected),
        scores=MappingProxyType(scores),
        agent_diagnosis=None if packet.agent_diagnosis is None else str(packet.agent_diagnosis),
    )
