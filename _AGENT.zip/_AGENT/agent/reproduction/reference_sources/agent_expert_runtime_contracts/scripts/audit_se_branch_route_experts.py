#!/usr/bin/env python3
"""Run a label-free Canary audit for fresh SE-branch shadow experts.

The audit deliberately does *not* compute AP or read coordinate labels.  It
checks that each shadow model stays inside the measured candidate set, that
its accepted corrections are temporally physical on the sealed Canary, and
that the frozen EmptyGuard sidecar remains safe.  A recommendation remains at
execution weight zero until a later, separately authorised evaluation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from agent_jsac.registered_route_expert_models import (
    build_registered_route_expert,
    decode_discrete_physical_candidate,
)
from agent_jsac.branch_prediction_freeze import (
    BranchPredictionIndex,
    load_branch_prediction_root,
    resolve_branch_timeline,
)
from agent_jsac.branch_router_recipe import (
    BRANCH_ORDER,
    CausalBranchRouter,
    branch_feature_tensor,
    hard_branch_selection,
)
from agent_jsac.agent_shadow_development import checkpoint_acceptance_threshold
from agent_jsac.adaptive_expert_retrieval import (
    AdaptiveExpertEntry,
    load_adaptive_expert_semantic_library,
)
from agent_jsac.registered_route_expert_evidence import (
    build_branch_coordinate_canary_receipt,
    build_branch_source_retention_receipt,
    build_label_free_canary_receipt,
    build_registered_binding_receipt,
    build_same_modality_empty_receipt,
    build_source_retention_receipt,
    compose_frozen_aligned_route_metrics,
)
from agent_jsac.route_expert_recipe_registry import recipe_for_implementation
from agent_jsac.route_aware_promotion_metrics import (
    evaluate_route_expert_v2,
    evaluate_zero_weight_canary_v2,
    load_route_aware_profile,
)
from agent_jsac.prospective_shadow_adaptation import execute_zero_weight_canary
from agent_jsac.route_expert_execution_registry import (
    RegisteredRouteExpert,
    load_registered_route_expert_execution_library,
)
from agent_jsac.route_expert_search import load_route_expert_template_library
from agent_jsac.se_branch_expert_models import SEBranchCandidateExpert
from agent_jsac.se_branch_route_runtime import validate_runtime_payload


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_source_replay_origin(*, route: str, origin: str) -> None:
    expected = (
        "zero_weight_ris_canary_or_identity_replay"
        if route == "corner_nlos_ris"
        else "SourceBEV_replay"
    )
    if origin != expected:
        raise ValueError(
            f"source replay supervision origin mismatch: expected {expected!r}, got {origin!r}"
        )


def _runtime_archives(root: Path, route: str, role: str) -> list[dict[str, np.ndarray]]:
    paths = sorted(root.glob("seq_*.npz"))
    if not paths:
        raise FileNotFoundError(f"{role} runtime cache is empty: {root}")
    archives: list[dict[str, np.ndarray]] = []
    for path in paths:
        with np.load(path, allow_pickle=False) as payload:
            record = {key: payload[key] for key in payload.files}
        validate_runtime_payload(record)
        if str(np.asarray(record["route"]).item()) != route:
            raise ValueError(f"Canary route mismatch: {path}")
        if str(np.asarray(record["role"]).item()) != role:
            raise ValueError(f"runtime role mismatch: {path}")
        if role == "canary" and np.asarray(record["sample_weight"], dtype=np.float32).any():
            raise ValueError(f"Canary unexpectedly has coordinate supervision: {path}")
        if role == "source_replay":
            try:
                validate_source_replay_origin(
                    route=route,
                    origin=str(np.asarray(record["supervision_origin"]).item()),
                )
            except ValueError as error:
                raise ValueError(f"{error}: {path}") from error
        archives.append(record)
    return archives


def _canary_archives(root: Path, route: str) -> list[dict[str, np.ndarray]]:
    return _runtime_archives(root, route, "canary")


def _fit_loss(receipt: dict[str, Any]) -> float:
    values = [float(row["target_fit_loss"]) for row in receipt["history"]]
    return min(values) if values else float("inf")


def build_zero_weight_identity_source_receipt(
    *, archives: list[dict[str, np.ndarray]], execution_weight: float
) -> dict[str, Any]:
    """Audit RIS shadow isolation when no supervised source replay exists."""

    if not archives:
        raise ValueError("zero-weight RIS replay is empty")
    if float(execution_weight) != 0.0:
        raise ValueError("zero-weight RIS source isolation requires shadow execution weight")
    if any(bool(np.any(np.asarray(row["sample_weight"], dtype=np.float32) > 0.0)) for row in archives):
        raise ValueError("RIS source isolation replay unexpectedly contains supervision")
    return {
        "schema_version": "agent_jsac_zero_weight_identity_source_receipt_v1",
        "metric_id": "non_promoted_identity_source_isolation",
        "metric_alias": "source_ap_drop",
        "measurement_scope": "matched_risecho_zero_weight_replay",
        "source_supervised_frames": 0,
        "source_candidate_hit_drop": 0.0,
        "source_ap_drop": 0.0,
        "execution_weight": 0.0,
        "development_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }


def evaluate_bound_route_audit(
    *, route: str, metrics: dict[str, Any], profile: dict[str, Any]
) -> dict[str, Any]:
    if route == "corner_nlos_ris":
        return {
            "schema_version": "agent_jsac_external_route_audit_pending_v1",
            "stage": "external_contract",
            "route": route,
            "candidate_state": "shadow_external_contract_pending",
            "gates": {},
            "failed_gates": [],
            "development_read": False,
            "locked_test_read": False,
        }
    return evaluate_route_expert_v2(route, metrics, profile)


def load_audit_execution_index(path: Path) -> dict[tuple[str, str], AdaptiveExpertEntry]:
    """Load all 42 hash-bound base and extension implementations for audit."""

    library = load_adaptive_expert_semantic_library(path)
    return {(entry.route, entry.primitive): entry for entry in library.entries}


def _load_model(checkpoint: dict[str, Any]) -> torch.nn.Module:
    if checkpoint.get("schema_version") == "agent_jsac_branch_router_checkpoint_v1":
        if checkpoint.get("recipe_type") != "branch_router" or tuple(
            checkpoint.get("branch_order", ())
        ) != BRANCH_ORDER:
            raise ValueError("invalid branch-router checkpoint contract")
        model = CausalBranchRouter(**dict(checkpoint["model_kwargs"])).cpu().eval()
        model.load_state_dict(checkpoint["model_state"], strict=True)
        return model
    implementation_id = checkpoint.get("implementation_id")
    model = (
        build_registered_route_expert(str(implementation_id), **dict(checkpoint["model_kwargs"]))
        if implementation_id
        else SEBranchCandidateExpert(
            primitive=str(checkpoint["primitive"]), **dict(checkpoint["model_kwargs"])
        )
    ).cpu().eval()
    model.load_state_dict(checkpoint["model_state"], strict=True)
    return model


@torch.inference_mode()
def _prediction_streams(
    checkpoint: dict[str, Any],
    archives: list[dict[str, np.ndarray]],
    *,
    branch_index: BranchPredictionIndex | None = None,
) -> dict[str, list[np.ndarray]]:
    model = _load_model(checkpoint)
    final_indices: list[np.ndarray] = []
    intervened: list[np.ndarray] = []
    acceptance: list[np.ndarray] = []
    candidate_logits: list[np.ndarray] = []
    proposed_delta_xy: list[np.ndarray] = []
    parent_xy: list[np.ndarray] = []
    final_xy: list[np.ndarray] = []
    recipe_type = recipe_for_implementation(str(checkpoint["implementation_id"]))
    if recipe_type == "branch_router" and branch_index is None:
        raise ValueError("branch-router audit requires a frozen branch prediction root")
    acceptance_threshold = (
        None
        if recipe_type == "branch_router"
        else checkpoint_acceptance_threshold(checkpoint)
    )
    for record in archives:
        if recipe_type == "branch_router":
            sequence = str(np.asarray(record["sequence"]).item()).strip().lower()
            branch_xy, branch_score = resolve_branch_timeline(
                branch_index,
                sequence=sequence,
                frame_ids=np.asarray(record["frame_id"], dtype=np.int64),
            )
            feature = branch_feature_tensor(
                torch.from_numpy(branch_xy), torch.from_numpy(branch_score)
            )
            logits = model(feature)[0]
            base_index = BRANCH_ORDER.index(str(checkpoint["parent_branch"]))
            current_indices, active = hard_branch_selection(
                logits,
                base_index=base_index,
                margin=float(checkpoint["selection_margin"]),
            )
            branch_xy_tensor = torch.from_numpy(branch_xy)
            proposed = branch_xy_tensor.gather(
                1, current_indices[:, None, None].expand(-1, 1, 2)
            ).squeeze(1)
            base = branch_xy_tensor[:, base_index]
            probability = logits.softmax(dim=-1)
            chosen_confidence = probability.gather(
                1, current_indices.unsqueeze(1)
            ).squeeze(1)
            final_indices.append(current_indices.cpu().numpy())
            intervened.append(active.cpu().numpy())
            acceptance.append(chosen_confidence.cpu().numpy())
            candidate_logits.append(logits.cpu().numpy())
            proposed_delta_xy.append((proposed - base).cpu().numpy())
            parent_xy.append(base.cpu().numpy())
            final_xy.append(proposed.cpu().numpy())
            continue
        feature = torch.from_numpy(np.asarray(record["candidate_feature"], dtype=np.float32)).unsqueeze(0)
        xy = torch.from_numpy(np.asarray(record["candidate_xy_m"], dtype=np.float32)).unsqueeze(0)
        valid = torch.from_numpy(np.asarray(record["candidate_valid"], dtype=bool)).unsqueeze(0)
        output = model(feature, xy, valid)
        if checkpoint.get("implementation_id"):
            decoded = decode_discrete_physical_candidate(
                output,
                xy,
                valid,
                acceptance_threshold=float(acceptance_threshold),
                application_contract=checkpoint.get("application_contract"),
            )
            current_indices = torch.where(
                decoded.intervened, decoded.choice_index, torch.zeros_like(decoded.choice_index)
            )
            proposed = decoded.proposed_xy_m
            active = decoded.intervened
        else:
            probability = output.candidate_logits.softmax(dim=-1)
            proposed = (
                probability.unsqueeze(-1) * torch.nan_to_num(xy, nan=0.0)
            ).sum(dim=2)
            active = output.acceptance.ge(float(acceptance_threshold))
            current_indices = torch.where(
                active,
                output.candidate_logits.argmax(dim=-1),
                torch.zeros_like(active, dtype=torch.long),
            )
        base = xy[:, :, 0]
        final_indices.append(current_indices[0].cpu().numpy())
        intervened.append(active[0].cpu().numpy())
        acceptance.append(output.acceptance[0].cpu().numpy())
        candidate_logits.append(output.candidate_logits[0].cpu().numpy())
        proposed_delta_xy.append((proposed - base)[0].cpu().numpy())
        parent_xy.append(base[0].cpu().numpy())
        final_xy.append(
            torch.where(active.unsqueeze(-1), proposed, base)[0].cpu().numpy()
        )
    return {
        "final_indices": final_indices,
        "intervened": intervened,
        "acceptance": acceptance,
        "candidate_logits": candidate_logits,
        "proposed_delta_xy": proposed_delta_xy,
        "parent_xy": parent_xy,
        "final_xy": final_xy,
        "recipe_type": recipe_type,
    }


def build_candidate_audit_row(
    *,
    checkpoint: dict[str, Any],
    training_receipt: dict[str, Any],
    checkpoint_sha256: str,
    training_receipt_sha256: str,
    empty_guard_sha256: str,
    registered: RegisteredRouteExpert | AdaptiveExpertEntry,
    canary_archives: list[dict[str, np.ndarray]],
    source_archives: list[dict[str, np.ndarray]],
    empty_guard: dict[str, Any],
    profile: dict[str, Any],
    branch_index: BranchPredictionIndex | None = None,
) -> dict[str, Any]:
    """Execute every frozen promotion receipt for one registered candidate."""

    binding = build_registered_binding_receipt(
        registered=registered,
        checkpoint=checkpoint,
        training_receipt=training_receipt,
        checkpoint_sha256=checkpoint_sha256,
        training_receipt_sha256=training_receipt_sha256,
        empty_guard_sha256=empty_guard_sha256,
    )
    canary_prediction = _prediction_streams(
        checkpoint, canary_archives, branch_index=branch_index
    )
    source_prediction = _prediction_streams(
        checkpoint, source_archives, branch_index=branch_index
    )
    if registered.route == "corner_nlos_ris":
        source = build_zero_weight_identity_source_receipt(
            archives=source_archives,
            execution_weight=float(checkpoint.get("execution_weight", 1.0)),
        )
    elif canary_prediction["recipe_type"] == "branch_router":
        source = build_branch_source_retention_receipt(
            archives=source_archives,
            final_xy_m=source_prediction["final_xy"],
        )
    else:
        source = build_source_retention_receipt(
            archives=source_archives,
            final_indices=source_prediction["final_indices"],
        )
    empty = build_same_modality_empty_receipt(
        guard=empty_guard,
        output_contract=registered.output_contract,
        presence_owner="SceneSentinel+selected_parent",
    )
    if canary_prediction["recipe_type"] == "branch_router":
        canary = build_branch_coordinate_canary_receipt(
            archives=canary_archives,
            final_xy_m=canary_prediction["final_xy"],
            intervened=canary_prediction["intervened"],
        )
    else:
        canary = build_label_free_canary_receipt(
            archives=canary_archives,
            final_indices=canary_prediction["final_indices"],
            intervened=canary_prediction["intervened"],
        )
    metrics = compose_frozen_aligned_route_metrics(
        binding_receipt=binding,
        source_receipt=source,
        empty_receipt=empty,
        canary_receipt=canary,
    )
    frozen_audit = evaluate_bound_route_audit(
        route=registered.route, metrics=metrics, profile=profile
    )
    logits = np.concatenate(canary_prediction["candidate_logits"], axis=0)
    parent = np.concatenate(canary_prediction["parent_xy"], axis=0)
    candidate_delta = np.concatenate(canary_prediction["proposed_delta_xy"], axis=0)
    zero_weight = execute_zero_weight_canary(
        parent_logits=np.zeros_like(logits, dtype=np.float32),
        parent_xy=parent,
        candidate_delta_logits=logits,
        candidate_delta_xy=candidate_delta,
        execution_weight=0.0,
        forbidden_read_count=int(binding["forbidden_read_count"]),
    )
    zero_weight_audit = evaluate_zero_weight_canary_v2(zero_weight, profile)
    candidate_state = str(frozen_audit["candidate_state"])
    return {
        "candidate_id": training_receipt["candidate_id"],
        "primitive": training_receipt["primitive"],
        "implementation_id": training_receipt.get("implementation_id"),
        "parent_branch": training_receipt["parent_branch"],
        "target_fit_loss": _fit_loss(training_receipt),
        "checkpoint_sha256": checkpoint_sha256,
        "training_receipt_sha256": training_receipt_sha256,
        "binding_receipt": binding,
        "source_retention_receipt": source,
        "empty_safety_receipt": empty,
        "label_free_canary_receipt": canary,
        "zero_weight_canary": zero_weight,
        "zero_weight_canary_audit": zero_weight_audit,
        "frozen_aligned_metrics": metrics,
        "frozen_aligned_audit": frozen_audit,
        "candidate_state": candidate_state,
        "safety_eligible": bool(
            candidate_state == "shadow_eligible" and zero_weight_audit["passed"]
        ),
        "execution_weight": 0.0,
    }


@torch.inference_mode()
def _canary_stats(checkpoint: dict[str, Any], archives: list[dict[str, np.ndarray]]) -> dict[str, float | bool]:
    implementation_id = checkpoint.get("implementation_id")
    model = (
        build_registered_route_expert(str(implementation_id), **dict(checkpoint["model_kwargs"]))
        if implementation_id
        else SEBranchCandidateExpert(
            primitive=str(checkpoint["primitive"]), **dict(checkpoint["model_kwargs"])
        )
    ).cpu().eval()
    model.load_state_dict(checkpoint["model_state"], strict=True)
    acceptance: list[np.ndarray] = []
    selected_valid: list[np.ndarray] = []
    step_rate: list[float] = []
    parent_step_rate: list[float] = []
    finite = True
    acceptance_threshold = checkpoint_acceptance_threshold(checkpoint)
    for record in archives:
        feature = torch.from_numpy(np.asarray(record["candidate_feature"], dtype=np.float32)).unsqueeze(0)
        xy = torch.from_numpy(np.asarray(record["candidate_xy_m"], dtype=np.float32)).unsqueeze(0)
        valid = torch.from_numpy(np.asarray(record["candidate_valid"], dtype=bool)).unsqueeze(0)
        output = model(feature, xy, valid)
        choice = output.candidate_logits.argmax(dim=-1)
        safe_xy = torch.nan_to_num(xy, nan=0.0, posinf=0.0, neginf=0.0)
        base_xy = torch.from_numpy(np.asarray(record["base_xy_m"], dtype=np.float32)).unsqueeze(0)
        if implementation_id:
            decoded = decode_discrete_physical_candidate(
                output,
                xy,
                valid,
                acceptance_threshold=acceptance_threshold,
                application_contract=checkpoint.get("application_contract"),
            )
            final_xy = decoded.final_xy_m
        else:
            probability = output.candidate_logits.softmax(dim=-1)
            proposed_xy = (probability.unsqueeze(-1) * safe_xy).sum(dim=2)
            final_xy = base_xy + output.acceptance.unsqueeze(-1) * (proposed_xy - base_xy)
        current = final_xy[0].numpy()
        parent = base_xy[0].numpy()
        finite = finite and bool(np.isfinite(current).all())
        acceptance.append(output.acceptance[0].numpy())
        selected_valid.append(valid[0].gather(1, choice[0].unsqueeze(1)).squeeze(1).numpy())
        if len(current) > 1:
            step_rate.append(float((np.linalg.norm(np.diff(current, axis=0), axis=1) > 1.0).mean()))
            parent_step_rate.append(float((np.linalg.norm(np.diff(parent, axis=0), axis=1) > 1.0).mean()))
    return {
        "finite_output": finite,
        "physical_choice_rate": float(np.concatenate(selected_valid).mean()),
        "acceptance_mean": float(np.concatenate(acceptance).mean()),
        "intervention_coverage": float(
            (np.concatenate(acceptance) >= acceptance_threshold).mean()
        ),
        "large_step_rate": float(np.mean(step_rate)) if step_rate else 0.0,
        "parent_large_step_rate": float(np.mean(parent_step_rate)) if parent_step_rate else 0.0,
    }


def rank_candidates(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Rank only fully audited candidates by the frozen evidence order."""

    eligible = [row for row in rows if row["safety_eligible"]]
    return sorted(
        eligible,
        key=lambda row: (
            -float(row["frozen_aligned_metrics"]["physical_support_rate"]),
            float(row["frozen_aligned_metrics"]["trajectory_jump_rate_delta"]),
            -float(row["frozen_aligned_metrics"]["candidate_set_agreement_delta"]),
            float(row["frozen_aligned_metrics"]["p90_proxy_delta_m"]),
            -float(row["frozen_aligned_metrics"]["intervention_coverage"]),
            str(row["candidate_id"]),
        ),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", required=True)
    parser.add_argument("--shadow-root", type=Path, required=True)
    parser.add_argument("--source-replay-root", type=Path, required=True)
    parser.add_argument("--canary-root", type=Path, required=True)
    parser.add_argument("--empty-guard-manifest", type=Path, required=True)
    parser.add_argument(
        "--template-library",
        type=Path,
        default=ROOT / "configs" / "route_expert_template_library_v1.json",
    )
    parser.add_argument(
        "--execution-library",
        type=Path,
        default=ROOT / "configs" / "registered_route_expert_execution_library.json",
    )
    parser.add_argument(
        "--metric-profile",
        type=Path,
        default=ROOT / "configs" / "route_aware_promotion_metrics_v2.json",
    )
    parser.add_argument(
        "--adaptive-library",
        type=Path,
        default=ROOT / "configs" / "expert_pool_42.json",
    )
    parser.add_argument(
        "--branch-prediction-root",
        type=Path,
        help="Hash-bound CORA0/SE1/SE2 predictions covering Canary and source replay.",
    )
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output.exists():
        raise FileExistsError(f"audit output already exists: {args.output}")
    archives = _canary_archives(args.canary_root, args.route)
    source_archives = _runtime_archives(args.source_replay_root, args.route, "source_replay")
    guard = json.loads(args.empty_guard_manifest.read_text(encoding="utf-8"))
    guard_sha256 = sha256(args.empty_guard_manifest)
    profile = load_route_aware_profile(args.metric_profile)
    expected_template = args.adaptive_library.parent / "route_expert_template_library_v1.json"
    expected_execution = args.adaptive_library.parent / "registered_route_expert_execution_library.json"
    if args.template_library.resolve() != expected_template.resolve():
        raise ValueError("adaptive audit template-library path mismatch")
    if args.execution_library.resolve() != expected_execution.resolve():
        raise ValueError("adaptive audit execution-library path mismatch")
    execution_index = load_audit_execution_index(args.adaptive_library)
    branch_index: BranchPredictionIndex | None = None
    branch_manifest: dict[str, Any] | None = None
    if args.branch_prediction_root is not None:
        branch_index, branch_manifest = load_branch_prediction_root(
            args.branch_prediction_root
        )
    rows: list[dict[str, Any]] = []
    for receipt_path in sorted(args.shadow_root.glob("*/TRAINING_RECEIPT.json")):
        checkpoint_path = receipt_path.parent / "best.pt"
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        if str(checkpoint.get("route")) != args.route or receipt.get("route") != args.route:
            raise ValueError(f"shadow route mismatch: {receipt_path}")
        try:
            registered = execution_index[(args.route, str(receipt.get("primitive")))]
        except KeyError as error:
            raise ValueError(
                f"unregistered adaptive route-expert primitive: {receipt.get('primitive')!r}"
            ) from error
        rows.append(
            build_candidate_audit_row(
                checkpoint=checkpoint,
                training_receipt=receipt,
                checkpoint_sha256=sha256(checkpoint_path),
                training_receipt_sha256=sha256(receipt_path),
                empty_guard_sha256=guard_sha256,
                registered=registered,
                canary_archives=archives,
                source_archives=source_archives,
                empty_guard=guard,
                profile=profile,
                branch_index=branch_index,
            )
        )
    if len(rows) != 5:
        raise ValueError(f"exactly five shadow candidates expected, found {len(rows)}")
    ranked = rank_candidates(rows)
    payload = {
        "schema_version": "agent_jsac_se_branch_route_shadow_canary_audit_v3",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "canary_coordinate_labels_read": False,
        "development_read": False,
        "locked_test_read": False,
        "empty_guard_manifest": str(args.empty_guard_manifest.resolve()),
        "empty_guard_sha256": guard_sha256,
        "source_replay_root": str(args.source_replay_root.resolve()),
        "metric_profile": str(args.metric_profile.resolve()),
        "metric_profile_sha256": sha256(args.metric_profile),
        "execution_library": str(args.execution_library.resolve()),
        "execution_library_sha256": sha256(args.execution_library),
        "adaptive_library": str(args.adaptive_library.resolve()),
        "adaptive_library_sha256": sha256(args.adaptive_library),
        "branch_prediction_root": None
        if args.branch_prediction_root is None
        else str(args.branch_prediction_root.resolve()),
        "branch_prediction_manifest_sha256": None
        if args.branch_prediction_root is None
        else sha256(args.branch_prediction_root / "PREDICTION_FREEZE.json"),
        "branch_prediction_forbidden_reads": None
        if branch_manifest is None
        else {
            field: bool(branch_manifest.get(field, False))
            for field in (
                "development_labels_read",
                "locked_test_read",
                "target_final_bev_read",
                "raw_depth_read",
                "right_rgb_read",
                "manual_ra_anchor_read",
            )
        },
        "candidates": rows,
        "recommended_shadow_candidate": None if not ranked else ranked[0]["candidate_id"],
        "recommendation_execution_weight": 0.0,
        "fallback": "exact_selected_SE_branch_identity" if not ranked else "retain_zero_weight_until_authorised_evaluation",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"route": args.route, "recommended": payload["recommended_shadow_candidate"], "eligible": len(ranked)}))


if __name__ == "__main__":
    main()
