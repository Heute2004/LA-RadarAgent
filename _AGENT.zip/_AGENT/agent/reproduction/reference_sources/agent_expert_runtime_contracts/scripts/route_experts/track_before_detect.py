from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from agent_jsac.registered_route_expert_entrypoint import run_registered_route_expert_entrypoint

PRIMITIVE = "track_before_detect"
IMPLEMENTATION_ID = "track_before_detect_v1"

if __name__ == "__main__":
    raise SystemExit(run_registered_route_expert_entrypoint(primitive=PRIMITIVE, implementation_id=IMPLEMENTATION_ID))
