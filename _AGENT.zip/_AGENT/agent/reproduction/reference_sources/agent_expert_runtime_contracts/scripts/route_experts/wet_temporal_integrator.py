from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from agent_jsac.registered_route_expert_entrypoint import run_registered_route_expert_entrypoint

PRIMITIVE = "wet_temporal_integrator"
IMPLEMENTATION_ID = "wet_temporal_integrator_v1"

if __name__ == "__main__":
    raise SystemExit(run_registered_route_expert_entrypoint(primitive=PRIMITIVE, implementation_id=IMPLEMENTATION_ID))
