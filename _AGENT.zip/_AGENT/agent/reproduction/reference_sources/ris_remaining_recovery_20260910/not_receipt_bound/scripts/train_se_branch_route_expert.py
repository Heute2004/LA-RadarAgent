#!/usr/bin/env python3
"""Train one fresh zero-weight SE-branch route expert from Support-fit only.

Checkpoint selection is deliberately based on Support-fit loss.  The separate
Canary is never opened by this process and therefore remains a true no-label,
zero-weight safety audit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor
from torch.nn import functional as functional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from agent_jsac.registered_route_expert_models import (
    RegisteredDiscreteCandidateExpert,
    build_registered_route_expert,
    registered_implementation_ids,
)
from agent_jsac.se_branch_expert_models import SEBranchCandidateExpert, expert_family
from agent_jsac.se_branch_route_runtime import SCHEMA_VERSION, validate_runtime_payload


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = True
    torch.set_float32_matmul_precision("high")


@dataclass(frozen=True)
class Episode:
    sequence: str
    route: str
    role: str
    parent_branch: str
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_feature: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    radar_training_valid: np.ndarray
    supervision_origin: str


def load_episodes(root: Path, *, expected_route: str, expected_role: str) -> list[Episode]:
    paths = sorted(Path(root).glob("seq_*.npz"))
    if not paths:
        raise FileNotFoundError(f"no route runtime archives: {root}")
    result: list[Episode] = []
    for path in paths:
        with np.load(path, allow_pickle=False) as archive:
            payload = {name: archive[name] for name in archive.files}
        validate_runtime_payload(payload)
        route = str(np.asarray(payload["route"]).item())
        role = str(np.asarray(payload["role"]).item())
        if route != expected_route or role != expected_role:
            raise ValueError(f"runtime route/role mismatch: {path}")
        result.append(
            Episode(
                sequence=str(np.asarray(payload["sequence"]).item()),
                route=route,
                role=role,
                parent_branch=str(np.asarray(payload["parent_branch"]).item()),
                candidate_xy_m=np.asarray(payload["candidate_xy_m"], dtype=np.float32).copy(),
                candidate_valid=np.asarray(payload["candidate_valid"], dtype=bool).copy(),
                candidate_feature=np.asarray(payload["candidate_feature"], dtype=np.float32).copy(),
                allowed_weight=np.asarray(payload["allowed_weight"], dtype=np.float32).copy(),
                sample_weight=np.asarray(payload["sample_weight"], dtype=np.float32).copy(),
                radar_training_valid=np.asarray(payload["radar_training_valid"], dtype=bool).copy(),
                supervision_origin=str(np.asarray(payload["supervision_origin"]).item()),
            )
        )
    return result


def tensors(episode: Episode, device: torch.device) -> dict[str, Tensor]:
    return {
        "xy": torch.from_numpy(episode.candidate_xy_m.copy()).unsqueeze(0).to(device),
        "valid": torch.from_numpy(episode.candidate_valid.copy()).unsqueeze(0).to(device),
        "feature": torch.from_numpy(episode.candidate_feature.copy()).unsqueeze(0).to(device),
        "allowed": torch.from_numpy(episode.allowed_weight.copy()).unsqueeze(0).to(device),
        "weight": torch.from_numpy(episode.sample_weight.copy()).unsqueeze(0).to(device),
        "radar_valid": torch.from_numpy(episode.radar_training_valid.copy()).unsqueeze(0).to(device),
    }


def episode_loss(
    model: SEBranchCandidateExpert | RegisteredDiscreteCandidateExpert,
    episode: Episode,
    device: torch.device,
) -> tuple[Tensor, dict[str, float]]:
    value = tensors(episode, device)
    output = model(value["feature"], value["xy"], value["valid"])
    probability = torch.softmax(output.candidate_logits, dim=-1)
    supervised = value["weight"].gt(0.0) & value["radar_valid"] & value["allowed"].sum(dim=-1).gt(0.0)
    if not bool(supervised.any()):
        zero = output.candidate_logits.sum() * 0.0
        return zero, {"loss": 0.0, "set_mass": 0.0, "acceptance_bce": 0.0, "continuity": 0.0, "supervised_frames": 0.0}
    legal_mass = (probability * value["allowed"]).sum(dim=-1).clamp_min(1.0e-6)
    set_loss = -(legal_mass[supervised].log() * value["weight"][supervised]).sum() / value["weight"][supervised].sum().clamp_min(1.0)
    requires_intervention = value["allowed"][..., 0].lt(0.50).float()
    acceptance = output.acceptance.clamp(1.0e-5, 1.0 - 1.0e-5)
    acceptance_loss = functional.binary_cross_entropy(acceptance[supervised], requires_intervention[supervised])
    expected_xy = (probability.unsqueeze(-1) * torch.nan_to_num(value["xy"], nan=0.0)).sum(dim=2)
    step = torch.linalg.vector_norm(expected_xy[:, 1:] - expected_xy[:, :-1], dim=-1)
    temporal_valid = value["radar_valid"][:, 1:] & value["radar_valid"][:, :-1]
    continuity = functional.relu(step[temporal_valid] - 0.75).square().mean() if bool(temporal_valid.any()) else set_loss * 0.0
    total = set_loss + 0.10 * acceptance_loss + 0.02 * continuity
    return total, {
        "loss": float(total.detach()),
        "set_mass": float(legal_mass[supervised].mean().detach()),
        "acceptance_bce": float(acceptance_loss.detach()),
        "continuity": float(continuity.detach()),
        "supervised_frames": float(supervised.sum().detach()),
    }


def train(
    *, model: SEBranchCandidateExpert | RegisteredDiscreteCandidateExpert, target_fit: list[Episode], source_replay: list[Episode], device: torch.device,
    epochs: int, learning_rate: float, weight_decay: float, source_replay_weight: float
) -> tuple[dict[str, Tensor], list[dict[str, float]], int]:
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    best_loss, best_epoch = float("inf"), 0
    best_state: dict[str, Tensor] | None = None
    history: list[dict[str, float]] = []
    for epoch in range(1, epochs + 1):
        model.train()
        ordered = [("target", item) for item in target_fit] + [("source", item) for item in source_replay]
        random.shuffle(ordered)
        values: list[dict[str, float]] = []
        for group, episode in ordered:
            optimizer.zero_grad(set_to_none=True)
            loss, stats = episode_loss(model, episode, device)
            (loss * (source_replay_weight if group == "source" else 1.0)).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            values.append(stats | {"is_source_replay": 1.0 if group == "source" else 0.0})
        scheduler.step()
        target_loss = float(np.mean([item["loss"] for item in values if item["is_source_replay"] == 0.0]))
        row = {
            "epoch": float(epoch),
            "target_fit_loss": target_loss,
            "all_loss": float(np.mean([item["loss"] for item in values])),
            "learning_rate": float(scheduler.get_last_lr()[0]),
        }
        history.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if target_loss < best_loss:
            best_loss, best_epoch = target_loss, epoch
            best_state = {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}
    if best_state is None:
        raise RuntimeError("expert training produced no checkpoint")
    return best_state, history, best_epoch


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-id", required=True)
    parser.add_argument("--route", required=True)
    parser.add_argument("--primitive", required=True)
    parser.add_argument("--implementation-id", choices=registered_implementation_ids())
    parser.add_argument("--parent-branch", choices=("cora0", "cora_se1", "cora_se2"), required=True)
    parser.add_argument("--target-fit-root", type=Path, required=True)
    parser.add_argument("--source-replay-root", type=Path, required=True)
    parser.add_argument("--empty-guard-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=24)
    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--learning-rate", type=float, default=3.0e-4)
    parser.add_argument("--weight-decay", type=float, default=1.0e-4)
    parser.add_argument("--source-replay-weight", type=float, default=0.35)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"expert output already exists: {args.output_dir}")
    if args.epochs < 1 or args.source_replay_weight <= 0.0:
        raise ValueError("epochs and source-replay-weight must be positive")
    if not args.empty_guard_manifest.is_file():
        raise FileNotFoundError("signed EmptyGuard manifest is required")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for route-expert shadow training")
    seed_everything(args.seed)
    target_fit = load_episodes(args.target_fit_root, expected_route=args.route, expected_role="fit")
    source_replay = load_episodes(args.source_replay_root, expected_route=args.route, expected_role="source_replay")
    if any(item.parent_branch != args.parent_branch for item in [*target_fit, *source_replay]):
        raise ValueError("runtime parent branch does not match the candidate contract")
    feature_dim = target_fit[0].candidate_feature.shape[-1]
    if any(item.candidate_feature.shape[-1] != feature_dim for item in [*target_fit, *source_replay]):
        raise ValueError("route runtime feature dimensions differ")
    model = (
        build_registered_route_expert(
            args.implementation_id, feature_dim=feature_dim, hidden_dim=args.hidden_dim
        )
        if args.implementation_id
        else SEBranchCandidateExpert(
            primitive=args.primitive, feature_dim=feature_dim, hidden_dim=args.hidden_dim
        )
    ).to(device)
    state, history, best_epoch = train(
        model=model,
        target_fit=target_fit,
        source_replay=source_replay,
        device=device,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        source_replay_weight=args.source_replay_weight,
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "agent_jsac_se_branch_route_expert_checkpoint_v1",
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "family": (
            "registered:" + model.architecture_signature
            if args.implementation_id
            else expert_family(args.primitive)
        ),
        "implementation_id": args.implementation_id,
        "parent_branch": args.parent_branch,
        "model_kwargs": {"feature_dim": feature_dim, "hidden_dim": args.hidden_dim},
        "model_state": state,
        "selected_epoch": best_epoch,
        "execution_weight": 0.0,
        "historical_checkpoint_import": False,
        "runtime_raw_depth_input": False,
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    receipt = {
        "schema_version": "agent_jsac_se_branch_route_expert_training_receipt_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "family": (
            "registered:" + model.architecture_signature
            if args.implementation_id
            else expert_family(args.primitive)
        ),
        "implementation_id": args.implementation_id,
        "parent_branch": args.parent_branch,
        "target_fit_sequences": [item.sequence for item in target_fit],
        "source_replay_sequences": [item.sequence for item in source_replay],
        "support_canary_read": False,
        "development_read": False,
        "locked_test_read": False,
        "selected_epoch": best_epoch,
        "checkpoint_path": str(checkpoint_path.resolve()),
        "checkpoint_sha256": sha256(checkpoint_path),
        "execution_weight": 0.0,
        "empty_guard_manifest": str(args.empty_guard_manifest.resolve()),
        "empty_guard_sha256": sha256(args.empty_guard_manifest),
        "history": history,
    }
    (args.output_dir / "TRAINING_RECEIPT.json").write_text(
        json.dumps(receipt, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps({key: receipt[key] for key in ("candidate_id", "route", "family", "selected_epoch", "checkpoint_sha256")}, sort_keys=True))


if __name__ == "__main__":
    main()
