#!/usr/bin/env python3
"""Launch the five fresh shadow experts registered for one SE route.

This launcher never accepts a Canary, Development, or Locked-Test input.  It
only turns the immutable search plan into independent Support-fit training
jobs, then records the exact commands and return codes for the Agent audit.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _rows(plan_path: Path, route: str) -> list[dict[str, Any]]:
    payload = json.loads(plan_path.read_text(encoding="utf-8"))
    rows = [dict(row) for row in payload["plan"]["candidates"] if row["route"] == route]
    if len(rows) != 5:
        raise ValueError(f"route {route} must have exactly five registered fresh candidates, found {len(rows)}")
    if any(row.get("execution_weight") != 0.0 or row.get("historical_checkpoint_import") for row in rows):
        raise ValueError("fresh route-expert launcher accepts only zero-weight non-historical candidates")
    if any(not str(row.get("implementation_id", "")).strip() for row in rows):
        raise ValueError("every adaptive route-expert candidate requires a hash-bound implementation ID")
    return rows


def _command(args: argparse.Namespace, row: dict[str, Any], output_dir: Path) -> list[str]:
    return [
        str(args.python), str(args.trainer),
        "--candidate-id", str(row["candidate_id"]),
        "--route", str(row["route"]),
        "--primitive", str(row["primitive"]),
        "--implementation-id", str(row["implementation_id"]),
        "--parent-branch", str(row["parent_branch"]),
        "--target-fit-root", str(args.target_fit_root),
        "--source-replay-root", str(args.source_replay_root),
        "--empty-guard-manifest", str(args.empty_guard_manifest),
        "--output-dir", str(output_dir),
        "--epochs", str(args.epochs),
        "--seed", str(args.seed),
        "--device", "cuda",
    ]


def _run(command: list[str], gpu: str, log_path: Path) -> dict[str, Any]:
    environment = dict(os.environ)
    environment["CUDA_VISIBLE_DEVICES"] = gpu
    with log_path.open("w", encoding="utf-8", newline="\n") as stream:
        process = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, env=environment, check=False)
    return {"gpu": gpu, "returncode": int(process.returncode), "log": str(log_path), "command": command}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--route", required=True)
    parser.add_argument("--target-fit-root", type=Path, required=True)
    parser.add_argument("--source-replay-root", type=Path, required=True)
    parser.add_argument("--empty-guard-manifest", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--trainer", type=Path, default=Path(__file__).with_name("train_se_branch_route_expert.py"))
    parser.add_argument("--gpus", default="0,1")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=24)
    parser.add_argument("--seed", type=int, default=3407)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_root.exists():
        raise FileExistsError(f"candidate output root already exists: {args.output_root}")
    if not args.empty_guard_manifest.is_file():
        raise FileNotFoundError(f"EmptyGuard manifest missing: {args.empty_guard_manifest}")
    for required in (args.target_fit_root, args.source_replay_root, args.trainer, args.plan):
        if not required.exists():
            raise FileNotFoundError(f"required route-search asset missing: {required}")
    gpus = tuple(item.strip() for item in args.gpus.split(",") if item.strip())
    if not gpus or args.workers < 1:
        raise ValueError("at least one GPU and one worker are required")
    rows = _rows(args.plan, args.route)
    args.output_root.mkdir(parents=True, exist_ok=False)
    jobs: list[tuple[dict[str, Any], str, list[str], Path]] = []
    for index, row in enumerate(rows):
        output_dir = args.output_root / str(row["candidate_id"])
        command = _command(args, row, output_dir)
        jobs.append((row, gpus[index % len(gpus)], command, args.output_root / f"{row['candidate_id']}.log"))
    receipt: dict[str, Any] = {
        "schema_version": "agent_jsac_se_branch_route_launch_receipt_v1",
        "started_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "candidate_count": len(jobs),
        "training_inputs": {
            "support_fit": str(args.target_fit_root.resolve()),
            "source_replay": str(args.source_replay_root.resolve()),
            "empty_guard": str(args.empty_guard_manifest.resolve()),
        },
        "forbidden_inputs": ["support_canary", "development", "locked_test"],
        "execution_weight": 0.0,
        "jobs": [],
    }
    with ThreadPoolExecutor(max_workers=min(args.workers, len(jobs))) as executor:
        future_to_row = {
            executor.submit(_run, command, gpu, log_path): row
            for row, gpu, command, log_path in jobs
        }
        for future in as_completed(future_to_row):
            row = future_to_row[future]
            result = future.result()
            result["candidate_id"] = row["candidate_id"]
            result["primitive"] = row["primitive"]
            receipt["jobs"].append(result)
            print(json.dumps(result, ensure_ascii=False), flush=True)
    receipt["completed_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    receipt["all_succeeded"] = all(job["returncode"] == 0 for job in receipt["jobs"])
    (args.output_root / "LAUNCH_RECEIPT.json").write_text(
        json.dumps(receipt, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )
    if not receipt["all_succeeded"]:
        raise RuntimeError("one or more route-expert shadow jobs failed")


if __name__ == "__main__":
    main()
