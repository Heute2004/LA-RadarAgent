#!/usr/bin/env python3
"""Build Support-only candidate runtimes for fresh SE-branch route experts.

The generated feature tensor is deployable: raw RA/RA-MTI peak evidence plus
the selected frozen SE parent.  Supervision is attached out-of-band and is
either SourceBEV replay (source scenes only) or the sealed calibrated physical
candidate set (target Support-fit only).  Canary has no coordinate labels.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import torch
from torch import Tensor, nn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from agent_jsac.route_expert_search import load_route_expert_template_library
from agent_jsac.se_branch_route_runtime import (
    SCHEMA_VERSION,
    RouteRuntimeSupport,
    attach_source_bev_set_mass,
    calibrated_depth_lineage,
    validate_runtime_payload,
    write_runtime_manifest,
)


# The two foundation domains are intentionally absent from the prospective
# target-adaptation split.  They remain a sealed SourceBEV replay pool used
# only to preserve the selected SE branch while a new target-route expert is
# trained.  These minimal records provide the metadata required by V4's radar
# frame loader; they do not grant any Target, Development, or Locked-Test read.
_SOURCE_DOMAIN_RECORDS: dict[str, dict[str, str]] = {
    "seq_038": {"sequence": "seq_038", "scene_geometry": "open_indoor", "weather": "indoor"},
    "seq_039": {"sequence": "seq_039", "scene_geometry": "open_indoor", "weather": "indoor"},
    "seq_042": {"sequence": "seq_042", "scene_geometry": "open_indoor", "weather": "indoor"},
    "seq_061": {"sequence": "seq_061", "scene_geometry": "open_outdoor", "weather": "dry"},
    "seq_062": {"sequence": "seq_062", "scene_geometry": "open_outdoor", "weather": "dry"},
    "seq_065": {"sequence": "seq_065", "scene_geometry": "open_outdoor", "weather": "dry"},
    "seq_066": {"sequence": "seq_066", "scene_geometry": "open_outdoor", "weather": "dry"},
    "seq_067": {"sequence": "seq_067", "scene_geometry": "open_outdoor", "weather": "dry"},
    "seq_070": {"sequence": "seq_070", "scene_geometry": "open_outdoor", "weather": "dry"},
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _install_v4(v4_root: Path) -> None:
    source = str((v4_root / "src").resolve())
    if source not in sys.path:
        sys.path.insert(0, source)


def _canonical_data_root(data_root: Path) -> Path:
    root = data_root.resolve()
    return root.parent if root.name.lower() == "data_train" else root


def _causal_batch(sequence: np.ndarray, start: int, end: int, *, length: int) -> Tensor:
    items = []
    for position in range(start, end):
        indices = [max(0, position - length + 1 + offset) for offset in range(length)]
        items.append(torch.from_numpy(sequence[indices].copy()))
    return torch.stack(items, dim=0)


@torch.inference_mode()
def _infer_parent(
    model: nn.Module, radar: np.ndarray, device: torch.device, *, batch_size: int
) -> tuple[np.ndarray, np.ndarray]:
    from brace_v4.dream_bev import decode_peak

    coordinates: list[np.ndarray] = []
    scores: list[np.ndarray] = []
    model.eval()
    for start in range(0, radar.shape[0], batch_size):
        clip = _causal_batch(radar, start, min(start + batch_size, radar.shape[0]), length=16).to(device)
        output = model(clip)
        xy_m, peak = decode_peak(output["logits"])
        coordinates.append(xy_m.cpu().numpy().astype(np.float32, copy=False))
        scores.append(
            (peak * output["presence_logit"][:, 0].sigmoid())
            .cpu()
            .numpy()
            .astype(np.float32, copy=False)
        )
    return np.concatenate(coordinates), np.concatenate(scores)


def _read_normalized(source: Any) -> np.ndarray:
    return torch.stack([source.read_normalized(frame) for frame in source.frame_ids]).numpy().astype(np.float32, copy=False)


def _track_path(data_root: Path, sequence: str) -> Path:
    root = data_root / "Data_train" / sequence
    for name in ("BEVFinalLabels", "BEVFinalLabelsV1"):
        candidate = root / name / "final_bev_track.csv"
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"SourceBEV replay track missing for {sequence}")


def _load_target_overlay(
    candidate_root: Path, sequence: str, expected_route: str
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    path = candidate_root / f"{sequence}.npz"
    if not path.is_file():
        raise FileNotFoundError(f"sealed candidate overlay missing: {path}")
    with np.load(path, allow_pickle=False) as archive:
        if str(np.asarray(archive["sequence"]).item()).strip().lower() != sequence:
            raise ValueError(f"candidate overlay sequence mismatch: {sequence}")
        if str(np.asarray(archive["route"]).item()).strip().lower() != expected_route:
            raise ValueError(f"candidate overlay route mismatch: {sequence}")
        for field in (
            "target_final_bev_read",
            "development_read",
            "locked_test_read",
            "right_rgb_read",
            "manual_ra_anchor_at_label_stage",
        ):
            if bool(np.asarray(archive[field]).item()):
                raise ValueError(f"candidate overlay reports forbidden read {field}: {sequence}")
        return (
            np.asarray(archive["frame_id"], dtype=np.int64).copy(),
            np.asarray(archive["candidate_xy_m"], dtype=np.float32).copy(),
            np.asarray(archive["candidate_valid"], dtype=bool).copy(),
            np.asarray(archive["candidate_weight"], dtype=np.float32).copy(),
        ), np.asarray(archive["sample_weight"], dtype=np.float32).copy()


def _support_sequences(
    *, route: str, role: str, episodes: Mapping[str, Any], library: Any
) -> tuple[str, ...]:
    if route not in episodes:
        raise ValueError(f"route is absent from episode manifest: {route}")
    if role == "source_replay":
        return ("seq_038", "seq_039", "seq_061", "seq_062")
    if route in library.route_support_overrides:
        return library.route_support_overrides[route]["support_fit" if role == "fit" else "support_canary"]
    field = "support_fit" if role == "fit" else "support_canary"
    return tuple(str(item).lower() for item in episodes[route][field])


def _origin_for(route: str, role: str) -> str:
    if role == "canary":
        return "canary"
    if role == "source_replay" or route in {"open_indoor_los", "open_outdoor_weak_return"}:
        return "source"
    return "target"


def _records_for_sequences(
    *, split_config: Path, sequences: tuple[str, ...], origin: str, load_episode_records: Any
) -> dict[str, dict[str, Any]]:
    """Resolve either prospective target records or sealed source replay records."""

    target_records = {
        str(item["sequence"]).lower(): item for item in load_episode_records(split_config, "train")
    }
    if origin == "target":
        missing = sorted(set(sequences) - set(target_records))
        if missing:
            raise ValueError(f"requested support sequence is absent from Agent Train: {missing}")
        return {sequence: target_records[sequence] for sequence in sequences}

    result: dict[str, dict[str, Any]] = {}
    for sequence in sequences:
        if sequence in target_records:
            result[sequence] = target_records[sequence]
        elif sequence in _SOURCE_DOMAIN_RECORDS:
            result[sequence] = dict(_SOURCE_DOMAIN_RECORDS[sequence])
        else:
            raise ValueError(f"unregistered non-target support sequence: {sequence}")
    return result


def _save(
    output: Path,
    *,
    sequence: str,
    route: str,
    role: str,
    parent_branch: str,
    frame_id: np.ndarray,
    runtime: Any,
    support: RouteRuntimeSupport,
    radar_training_valid: np.ndarray,
    lineage: Mapping[str, Any] | None,
) -> None:
    np.savez_compressed(
        output,
        schema_version=np.asarray(SCHEMA_VERSION),
        sequence=np.asarray(sequence),
        route=np.asarray(route),
        role=np.asarray(role),
        parent_branch=np.asarray(parent_branch),
        frame_id=np.asarray(frame_id, dtype=np.int64),
        candidate_xy_m=runtime.candidate_xy_m,
        candidate_valid=runtime.candidate_valid,
        candidate_feature=runtime.candidate_feature,
        base_xy_m=runtime.base_xy_m,
        base_index=runtime.base_index,
        allowed_weight=support.allowed_weight,
        sample_weight=support.sample_weight,
        supervision_origin=np.asarray(support.supervision_origin),
        radar_training_valid=np.asarray(radar_training_valid, dtype=bool),
        offline_calibrated_depth_lineage_json=np.asarray(
            "" if lineage is None else json.dumps(dict(lineage), sort_keys=True)
        ),
        target_final_bev_read=np.asarray(False),
        development_label_read=np.asarray(False),
        locked_test_read=np.asarray(False),
        depth_read=np.asarray(False),
        right_rgb_read=np.asarray(False),
        manual_ra_anchor_read=np.asarray(False),
    )
    with np.load(output, allow_pickle=False) as archive:
        validate_runtime_payload({key: archive[key] for key in archive.files})


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--v4-root", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--candidate-root", type=Path, required=True)
    parser.add_argument("--episode-manifest", type=Path, default=ROOT / "configs" / "prospective_episode_order_v1.json")
    parser.add_argument("--template-library", type=Path, default=ROOT / "configs" / "route_expert_template_library_v1.json")
    parser.add_argument("--split-config", type=Path, required=True)
    parser.add_argument("--route", required=True)
    parser.add_argument("--role", choices=("fit", "canary", "source_replay"), required=True)
    parser.add_argument("--cora0-checkpoint", type=Path, required=True)
    parser.add_argument("--se1-checkpoint", type=Path, required=True)
    parser.add_argument("--se2-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"route runtime output already exists: {args.output_dir}")
    if args.batch_size < 1:
        raise ValueError("batch-size must be positive")
    _install_v4(args.v4_root)
    from brace_v4.cora_se2_r11 import load_cora, load_se2_detector
    from brace_v4.r8_raw96_runtime import build_raw96_candidate_evidence
    from brace_v4.route_specialists_se2_runtime import attach_r11_set_mass, build_raw_route_runtime
    from brace_v4.self_evolution_data import RadarSequenceFrames, load_episode_records

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for route runtime construction")
    data_root = _canonical_data_root(args.data_root)
    episode_payload = json.loads(args.episode_manifest.read_text(encoding="utf-8-sig"))
    episodes = episode_payload["routes"]
    library = load_route_expert_template_library(args.template_library)
    if args.route == "corner_nlos_ris":
        raise ValueError("RIS requires the separate matched RISEcho runtime contract")
    parent_branch = library.branch_for(args.route)
    sequences = _support_sequences(route=args.route, role=args.role, episodes=episodes, library=library)
    origin = _origin_for(args.route, args.role)
    records = _records_for_sequences(
        split_config=args.split_config,
        sequences=sequences,
        origin=origin,
        load_episode_records=load_episode_records,
    )
    candidate_manifest = json.loads((args.candidate_root / "R11_MANIFEST.json").read_text(encoding="utf-8"))
    depth_lineage = calibrated_depth_lineage(candidate_manifest) if origin == "target" else None
    models: dict[str, nn.Module] = {
        "cora0": load_cora(args.cora0_checkpoint, device),
        "cora_se1": load_cora(args.se1_checkpoint, device),
        "cora_se2": load_se2_detector(args.cora0_checkpoint, args.se1_checkpoint, args.se2_checkpoint, device)[0],
    }
    args.output_dir.mkdir(parents=True, exist_ok=False)
    manifest_rows: list[dict[str, Any]] = []
    for ordinal, sequence in enumerate(sequences, start=1):
        source = RadarSequenceFrames.create(data_root, records[sequence])
        radar = _read_normalized(source)
        raw = build_raw96_candidate_evidence(radar)
        base_xy, base_score = _infer_parent(models[parent_branch], radar, device, batch_size=args.batch_size)
        runtime = build_raw_route_runtime(
            candidate_xy_m=raw.candidate_xy_m,
            candidate_valid=raw.candidate_valid,
            radar_score=raw.raw_candidate_score,
            ra_mti_agreement=raw.ra_mti_agreement,
            background_risk=raw.background_risk,
            temporal_persistence=raw.temporal_persistence,
            base_xy_m=base_xy,
            base_score=base_score,
        )
        if origin == "source":
            support = attach_source_bev_set_mass(
                candidate_xy_m=runtime.candidate_xy_m,
                candidate_valid=runtime.candidate_valid,
                base_xy_m=runtime.base_xy_m,
                frame_id=np.asarray(source.frame_ids, dtype=np.int64),
                source_track_csv=_track_path(data_root, sequence),
            )
        elif origin == "target":
            overlay, overlay_weight = _load_target_overlay(args.candidate_root, sequence, args.route)
            overlay_frame, overlay_xy, overlay_valid, overlay_mass = overlay
            if not np.array_equal(overlay_frame, np.asarray(source.frame_ids, dtype=np.int64)):
                raise ValueError(f"candidate overlay/radar timeline mismatch: {sequence}")
            attached = attach_r11_set_mass(
                runtime,
                overlay_xy,
                overlay_valid,
                overlay_mass,
                overlay_weight * source.training_valid.astype(np.float32),
                radius_m=0.25,
            )
            support = RouteRuntimeSupport(
                allowed_weight=attached.allowed_weight,
                sample_weight=attached.sample_weight,
                supervision_origin="sealed_RadarCandidateSet_with_offline_calibrated_depth_lineage",
            )
        else:
            support = RouteRuntimeSupport(
                allowed_weight=np.zeros(runtime.candidate_valid.shape, dtype=np.float32),
                sample_weight=np.zeros((runtime.candidate_valid.shape[0],), dtype=np.float32),
                supervision_origin="zero_weight_canary_without_coordinate_labels",
            )
        output = args.output_dir / f"{sequence}.npz"
        _save(
            output,
            sequence=sequence,
            route=args.route,
            role=args.role,
            parent_branch=parent_branch,
            frame_id=np.asarray(source.frame_ids, dtype=np.int64),
            runtime=runtime,
            support=support,
            radar_training_valid=source.training_valid,
            lineage=depth_lineage,
        )
        row = {
            "sequence": sequence,
            "frames": len(source.frame_ids),
            "supervised_frames": int((support.sample_weight > 0.0).sum()),
            "supervision_origin": support.supervision_origin,
            "sha256": sha256(output),
        }
        manifest_rows.append(row)
        print(json.dumps({"progress": f"{ordinal}/{len(sequences)}", **row}, ensure_ascii=False), flush=True)
    write_runtime_manifest(
        output_dir=args.output_dir,
        records=manifest_rows,
        lineage=depth_lineage,
        role=args.role,
        route=args.route,
    )


if __name__ == "__main__":
    main()
