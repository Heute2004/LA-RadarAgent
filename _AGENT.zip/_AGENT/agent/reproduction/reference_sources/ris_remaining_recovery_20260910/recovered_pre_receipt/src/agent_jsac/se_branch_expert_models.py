"""Fresh candidate-selection experts for the SE-branch search.

All modules score only candidate zero (the frozen parent) and measured raw
RA/RA-MTI candidates.  They never emit a free BEV coordinate.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn


_ATTENTION_PRIMITIVES = {
    "candidate_attention",
    "dual_domain_set_mixer",
    "echo_extent_disambiguator",
    "risk_controlled_recovery",
    "robust_quantile_recovery",
    "weather_risk_selector",
    "anisotropic_wet_mixture",
    "risecho_codebook_consensus",
    "risecho_selective_recovery",
    "risecho_dual_path_mixture",
}
_GRAPH_PRIMITIVES = {
    "temporal_candidate_graph",
    "graph_branch_linker",
    "multi_hypothesis_path",
    "candidate_survival_graph",
    "path_temporal_integrator",
    "track_before_detect",
    "weak_return_mixture",
    "risecho_path_integrator",
}
_TEMPORAL_PRIMITIVES = {
    "branch_persistence_selector",
    "range_conditioned_tcn",
    "wet_temporal_integrator",
    "polar_evidence_gate",
    "risecho_temporal_gate",
    "temporal_precision_tail",
}
_LOCAL_PRIMITIVES = {
    "local_offset_gru",
    "clor_local_offset",
    "polar_bev_cross_refiner",
    "subcell_uncertainty_refiner",
    "innovation_gated_offset",
    "mti_agreement_rescuer",
    "selective_branch_recovery",
}


@dataclass(frozen=True)
class CandidateExpertOutput:
    candidate_logits: Tensor
    acceptance: Tensor


def expert_family(primitive: str) -> str:
    if primitive in _ATTENTION_PRIMITIVES:
        return "attention"
    if primitive in _GRAPH_PRIMITIVES:
        return "graph"
    if primitive in _TEMPORAL_PRIMITIVES:
        return "temporal"
    if primitive in _LOCAL_PRIMITIVES:
        return "local"
    raise ValueError(f"unregistered route-expert primitive: {primitive}")


class SEBranchCandidateExpert(nn.Module):
    """A small, fresh candidate scorer with primitive-specific evidence mixing."""

    def __init__(self, *, primitive: str, feature_dim: int = 10, hidden_dim: int = 64) -> None:
        super().__init__()
        if hidden_dim < 16:
            raise ValueError("hidden_dim must be at least 16")
        self.primitive = str(primitive)
        self.family = expert_family(self.primitive)
        self.token = nn.Sequential(
            nn.LayerNorm(feature_dim),
            nn.Linear(feature_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
        )
        self.context_gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.score = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1)
        )
        self.accept = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2), nn.GELU(), nn.Linear(hidden_dim // 2, 1)
        )
        if self.family == "attention":
            self.candidate_attention = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)
        elif self.family == "graph":
            self.graph_message = nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim)
            )
        elif self.family == "temporal":
            self.temporal = nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=2, groups=1)
        elif self.family == "local":
            self.local_gate = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.Sigmoid())

        # A fresh shadow expert begins as exact parent identity at runtime;
        # only its acceptance head may later enable candidate selection.
        nn.init.zeros_(self.accept[-1].weight)
        nn.init.constant_(self.accept[-1].bias, -6.0)

    def forward(
        self, candidate_feature: Tensor, candidate_xy_m: Tensor, candidate_valid: Tensor
    ) -> CandidateExpertOutput:
        if candidate_feature.ndim != 4 or candidate_xy_m.shape != candidate_feature.shape[:3] + (2,):
            raise ValueError("candidate feature/coordinate shape mismatch")
        if candidate_valid.shape != candidate_feature.shape[:3]:
            raise ValueError("candidate valid shape mismatch")
        # Invalid slots in a fixed-size candidate set may carry NaN geometry
        # or features.  Neutralise them before any shared LayerNorm/graph
        # operation, then keep them excluded by the validity mask below.
        safe_feature = torch.nan_to_num(candidate_feature, nan=0.0, posinf=0.0, neginf=0.0)
        safe_xy = torch.nan_to_num(candidate_xy_m, nan=0.0, posinf=0.0, neginf=0.0)
        token = self.token(safe_feature)
        mask = candidate_valid.unsqueeze(-1)
        denom = mask.sum(dim=2).clamp_min(1)
        context = (token * mask).sum(dim=2) / denom
        context, _ = self.context_gru(context)
        if self.family == "attention":
            rows = token.reshape(-1, token.shape[2], token.shape[3])
            invalid = ~candidate_valid.reshape(-1, candidate_valid.shape[2])
            mixed, _ = self.candidate_attention(rows, rows, rows, key_padding_mask=invalid)
            token = mixed.reshape_as(token)
        elif self.family == "graph":
            distance = torch.cdist(safe_xy.reshape(-1, safe_xy.shape[2], 2), safe_xy.reshape(-1, safe_xy.shape[2], 2))
            reachable = (distance <= 0.75).to(token.dtype).reshape(token.shape[:3] + (token.shape[2],))
            adjacency = reachable * candidate_valid.unsqueeze(-1).to(token.dtype)
            adjacency = adjacency / adjacency.sum(dim=-1, keepdim=True).clamp_min(1.0)
            token = token + self.graph_message(torch.einsum("btij,btjh->btih", adjacency, token))
        elif self.family == "temporal":
            temporal = self.temporal(context.transpose(1, 2))[..., : context.shape[1]].transpose(1, 2)
            context = context + temporal
        elif self.family == "local":
            token = token * self.local_gate(token)
        expanded = context.unsqueeze(2).expand_as(token)
        logits = self.score(torch.cat((token, expanded), dim=-1)).squeeze(-1)
        logits = logits.masked_fill(~candidate_valid, -1.0e4)
        return CandidateExpertOutput(
            candidate_logits=logits,
            acceptance=torch.sigmoid(self.accept(context).squeeze(-1)),
        )
