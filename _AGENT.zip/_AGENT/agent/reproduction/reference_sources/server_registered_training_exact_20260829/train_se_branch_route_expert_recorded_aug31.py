#!/usr/bin/env python3
"""Train one fresh zero-weight SE-branch route expert from Support only.

The supplied Support pool is split by complete sequence into fit and internal
calibration partitions.  Canary, Development, and Locked Test remain unopened.
Checkpoint and acceptance-threshold selection use only the internal Support
calibration partition.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor
from torch.nn import functional as functional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from agent_jsac.registered_route_expert_models import (
    RegisteredDiscreteCandidateExpert,
    build_registered_route_expert,
    registered_implementation_ids,
)
from agent_jsac.route_expert_execution_registry import (
    application_contract_for_implementation,
)
from agent_jsac.route_parent_selection import PARENT_SELECTION_POLICY_ID
from agent_jsac.se_branch_expert_models import SEBranchCandidateExpert, expert_family


_PRODUCTION_FAMILY_BY_ROUTE = {
    "open_indoor_los": "source_tail_refinement",
    "indoor_clutter": "selective_candidate_composite",
    "open_outdoor_weak_return": "source_tail_refinement",
    "outdoor_dry_complex": "branch_stability_router",
    "outdoor_wet_return": "bounded_wet_return_router",
}

_DIRECT_ROUTES = frozenset(_PRODUCTION_FAMILY_BY_ROUTE)


def validate_production_trainer_family(*, route: str, family: str) -> None:
    expected = _PRODUCTION_FAMILY_BY_ROUTE.get(str(route))
    if expected is None or str(family) != expected:
        raise ValueError(
            "production trainer family mismatch: "
            f"route={route!r}, expected={expected!r}, received={family!r}"
        )


def validate_generic_trainer_family(family: str) -> None:
    supported = {
        "source_tail_refinement",
        "selective_candidate_composite",
        "branch_stability_router",
        "bounded_wet_return_router",
    }
    if str(family) not in supported:
        raise ValueError(
            f"production family {family!r} requires its dedicated trainer"
        )


from agent_jsac.se_branch_route_runtime import SCHEMA_VERSION, validate_runtime_payload


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def valid_sha256(value: object) -> bool:
    text = str(value).lower()
    return len(text) == 64 and all(character in "0123456789abcdef" for character in text)


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = True
    torch.set_float32_matmul_precision("high")


@dataclass(frozen=True)
class Episode:
    sequence: str
    route: str
    role: str
    parent_branch: str
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_feature: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    radar_training_valid: np.ndarray
    supervision_origin: str


def load_episodes(root: Path, *, expected_route: str, expected_role: str) -> list[Episode]:
    paths = sorted(Path(root).glob("seq_*.npz"))
    if not paths:
        raise FileNotFoundError(f"no route runtime archives: {root}")
    result: list[Episode] = []
    for path in paths:
        with np.load(path, allow_pickle=False) as archive:
            payload = {name: archive[name] for name in archive.files}
        validate_runtime_payload(payload)
        route = str(np.asarray(payload["route"]).item())
        role = str(np.asarray(payload["role"]).item())
        if route != expected_route or role != expected_role:
            raise ValueError(f"runtime route/role mismatch: {path}")
        result.append(
            Episode(
                sequence=str(np.asarray(payload["sequence"]).item()),
                route=route,
                role=role,
                parent_branch=str(np.asarray(payload["parent_branch"]).item()),
                candidate_xy_m=np.asarray(payload["candidate_xy_m"], dtype=np.float32).copy(),
                candidate_valid=np.asarray(payload["candidate_valid"], dtype=bool).copy(),
                candidate_feature=np.asarray(payload["candidate_feature"], dtype=np.float32).copy(),
                allowed_weight=np.asarray(payload["allowed_weight"], dtype=np.float32).copy(),
                sample_weight=np.asarray(payload["sample_weight"], dtype=np.float32).copy(),
                radar_training_valid=np.asarray(payload["radar_training_valid"], dtype=bool).copy(),
                supervision_origin=str(np.asarray(payload["supervision_origin"]).item()),
            )
        )
    return result


def tensors(episode: Episode, device: torch.device) -> dict[str, Tensor]:
    return {
        "xy": torch.from_numpy(episode.candidate_xy_m.copy()).unsqueeze(0).to(device),
        "valid": torch.from_numpy(episode.candidate_valid.copy()).unsqueeze(0).to(device),
        "feature": torch.from_numpy(episode.candidate_feature.copy()).unsqueeze(0).to(device),
        "allowed": torch.from_numpy(episode.allowed_weight.copy()).unsqueeze(0).to(device),
        "weight": torch.from_numpy(episode.sample_weight.copy()).unsqueeze(0).to(device),
        "radar_valid": torch.from_numpy(episode.radar_training_valid.copy()).unsqueeze(0).to(device),
    }


def intervention_required_from_allowed_set(allowed_weight: Tensor) -> Tensor:
    """Return one only when the exact identity action is absent from the legal set."""

    if allowed_weight.ndim < 1 or allowed_weight.shape[-1] < 1:
        raise ValueError("allowed weights must include candidate zero as identity")
    return allowed_weight[..., 0].le(0.0).to(dtype=allowed_weight.dtype)


def acceptance_target_from_preference(
    allowed_weight: Tensor, *, minimum_advantage: float = 0.0
) -> Tensor:
    """Teach intervention only when a non-identity action beats identity.

    Candidate-set membership alone is insufficient because identity and a
    useful physical candidate may both be legal.  The preference mass carries
    the teacher's relative confidence and therefore defines the gate target.
    """

    if allowed_weight.ndim < 1 or allowed_weight.shape[-1] < 2:
        raise ValueError("preference weights must include identity and a candidate")
    margin = float(minimum_advantage)
    if not math.isfinite(margin) or margin < 0.0:
        raise ValueError("minimum advantage must be non-negative and finite")
    identity = allowed_weight[..., 0]
    best_candidate = allowed_weight[..., 1:].amax(dim=-1)
    return best_candidate.gt(identity + margin).to(dtype=allowed_weight.dtype)


def assert_disjoint_optimization_roles(
    *,
    target_fit: list[Episode],
    target_calibration: list[Episode],
    source_replay: list[Episode],
) -> None:
    """Reject any sequence reused for fitting and train-internal calibration."""

    fit_names = {item.sequence for item in target_fit}
    calibration_names = {item.sequence for item in target_calibration}
    replay_names = {item.sequence for item in source_replay}
    if fit_names & calibration_names:
        raise ValueError("target fit and calibration sequences overlap")
    if calibration_names & replay_names:
        raise ValueError("calibration sequences overlap source replay optimization")


def legal_set_mass(probability: Tensor, allowed_weight: Tensor) -> Tensor:
    """Sum probability over legal actions, independent of preference weights."""

    if probability.shape != allowed_weight.shape:
        raise ValueError("probability and allowed weights must have identical shapes")
    legal = allowed_weight.gt(0.0).to(dtype=probability.dtype)
    return (probability * legal).sum(dim=-1)


def split_fit_calibration_episodes(
    episodes: list[Episode], *, calibration_fraction: float, seed: int
) -> tuple[list[Episode], list[Episode]]:
    """Create a deterministic sequence-disjoint Support split."""

    if not 0.0 < calibration_fraction < 1.0:
        raise ValueError("calibration_fraction must lie strictly between zero and one")
    if len(episodes) < 2:
        raise ValueError("at least two Support sequences are required for calibration")
    by_sequence = {item.sequence: item for item in episodes}
    if len(by_sequence) != len(episodes):
        raise ValueError("Support contains duplicate sequence episodes")
    ordered = sorted(
        episodes,
        key=lambda item: hashlib.sha256(
            f"{int(seed)}:{item.sequence}".encode("utf-8")
        ).hexdigest(),
    )
    calibration_count = min(
        len(ordered) - 1,
        max(1, int(round(len(ordered) * float(calibration_fraction)))),
    )
    calibration_names = {item.sequence for item in ordered[:calibration_count]}
    fit = sorted(
        (item for item in episodes if item.sequence not in calibration_names),
        key=lambda item: item.sequence,
    )
    calibration = sorted(
        (item for item in episodes if item.sequence in calibration_names),
        key=lambda item: item.sequence,
    )
    return fit, calibration


def select_calibrated_acceptance_threshold(
    *,
    acceptance: np.ndarray,
    choice_index: np.ndarray,
    allowed_weight: np.ndarray,
    sample_weight: np.ndarray,
    thresholds: tuple[float, ...],
    harm_budget: float,
) -> dict[str, Any]:
    """Choose the best non-harmful gate threshold on held-out Support."""

    score = np.asarray(acceptance, dtype=np.float64).reshape(-1)
    choice = np.asarray(choice_index, dtype=np.int64).reshape(-1)
    allowed = np.asarray(allowed_weight, dtype=np.float64)
    weight = np.asarray(sample_weight, dtype=np.float64).reshape(-1)
    if allowed.ndim != 2 or allowed.shape[0] != score.size:
        raise ValueError("calibration allowed-set timeline mismatch")
    if choice.shape != score.shape or weight.shape != score.shape:
        raise ValueError("calibration score/choice/weight timeline mismatch")
    if not thresholds or any(not 0.0 <= float(value) <= 1.0 for value in thresholds):
        raise ValueError("calibration thresholds must lie in [0, 1]")
    if not 0.0 <= harm_budget <= 1.0:
        raise ValueError("harm_budget must lie in [0, 1]")
    supervised = (weight > 0.0) & (allowed.sum(axis=1) > 0.0)
    if not bool(supervised.any()):
        raise ValueError("calibration partition has no supervised frames")
    if (choice < 0).any() or (choice >= allowed.shape[1]).any():
        raise ValueError("calibration choice index is out of range")
    legal = allowed > 0.0
    denominator = float(weight[supervised].sum())
    identity_legal = legal[:, 0]
    candidate_legal = legal[np.arange(score.size), choice]
    options: list[dict[str, float]] = []
    for threshold in sorted({float(value) for value in thresholds}):
        active = (score >= threshold) & (choice != 0)
        final_choice = np.where(active, choice, 0)
        final_preference = allowed[np.arange(score.size), final_choice]
        utility = float(
            (final_preference[supervised] * weight[supervised]).sum() / denominator
        )
        identity_preference = allowed[:, 0]
        candidate_preference = allowed[np.arange(score.size), choice]
        harmful = active & (candidate_preference + 1.0e-12 < identity_preference)
        harm_rate = float((harmful[supervised] * weight[supervised]).sum() / denominator)
        coverage = float((active[supervised] * weight[supervised]).sum() / denominator)
        options.append(
            {
                "threshold": threshold,
                "utility": utility,
                "harm_rate": harm_rate,
                "coverage": coverage,
            }
        )
    identity_preference = allowed[:, 0]
    candidate_preference = allowed[np.arange(score.size), choice]
    base_utility = float(
        (identity_preference[supervised] * weight[supervised]).sum() / denominator
    )
    candidate_utility = float(
        (candidate_preference[supervised] * weight[supervised]).sum() / denominator
    )
    eligible = [
        item
        for item in options
        if item["harm_rate"] <= float(harm_budget) + 1.0e-12
        and item["utility"] >= base_utility - float(harm_budget) - 1.0e-12
    ]
    selected = max(
        eligible or options,
        key=lambda item: (item["utility"], -item["harm_rate"], item["coverage"]),
    )
    return {
        **selected,
        "base_utility": base_utility,
        "candidate_utility": candidate_utility,
        "harm_budget": float(harm_budget),
        "options": options,
    }


def acceptance_positive_weight(episodes: list[Episode]) -> float:
    """Balance intervention-required and identity-legal Support supervision."""

    positive = 0.0
    negative = 0.0
    for episode in episodes:
        supervised = (
            (episode.sample_weight > 0.0)
            & episode.radar_training_valid
            & (episode.allowed_weight.sum(axis=1) > 0.0)
        )
        required = (
            acceptance_target_from_preference(
                torch.from_numpy(episode.allowed_weight.astype(np.float32, copy=False))
            )
            .numpy()
            .astype(bool, copy=False)
        )
        frame_weight = episode.sample_weight.astype(np.float64, copy=False)
        positive += float(frame_weight[supervised & required].sum())
        negative += float(frame_weight[supervised & ~required].sum())
    if positive <= 0.0 or negative <= 0.0:
        return 1.0
    return float(np.clip(negative / positive, 0.25, 8.0))


def production_objective_terms(
    *,
    probability: Tensor,
    candidate_xy_m: Tensor,
    preference: Tensor,
    supervised: Tensor,
    sample_weight: Tensor,
    family: str,
    application_contract: dict[str, Any],
) -> dict[str, Tensor]:
    """Compute the route-specific terms that distinguish production experts."""

    validate_generic_trainer_family(family)
    denominator = sample_weight[supervised].sum().clamp_min(1.0)
    safe_xy = torch.nan_to_num(candidate_xy_m, nan=0.0, posinf=0.0, neginf=0.0)
    expected_xy = (probability.unsqueeze(-1) * safe_xy).sum(dim=2)
    preference_mass = preference.sum(dim=-1, keepdim=True).clamp_min(1.0e-6)
    normalized_preference = preference / preference_mass
    target_xy = (normalized_preference.unsqueeze(-1) * safe_xy).sum(dim=2)

    zero = probability.sum() * 0.0
    coordinate = zero
    identity_regret = zero
    correction_bound = zero
    if family == "source_tail_refinement":
        per_frame = functional.smooth_l1_loss(
            expected_xy, target_xy, reduction="none"
        ).sum(dim=-1)
        coordinate = (
            per_frame[supervised] * sample_weight[supervised]
        ).sum() / denominator
    elif family in {"selective_candidate_composite", "branch_stability_router"}:
        soft_preference = (probability * preference).sum(dim=-1)
        regret = functional.relu(preference[..., 0] - soft_preference)
        identity_regret = (
            regret[supervised] * sample_weight[supervised]
        ).sum() / denominator
    elif family == "bounded_wet_return_router":
        if application_contract.get("mode") != "bounded_convex_candidate_update":
            raise ValueError("wet-return trainer requires a bounded application contract")
        scale = float(application_contract.get("posterior_scale", 0.0))
        maximum = application_contract.get("maximum_correction_m")
        if not math.isfinite(scale) or scale <= 0.0 or maximum is None:
            raise ValueError("wet-return application contract is incomplete")
        maximum = float(maximum)
        if not math.isfinite(maximum) or maximum <= 0.0:
            raise ValueError("wet-return correction bound must be positive")
        applied_delta = scale * (expected_xy - safe_xy[..., 0, :])
        excess = functional.relu(
            torch.linalg.vector_norm(applied_delta, dim=-1) - maximum
        ).square()
        correction_bound = (
            excess[supervised] * sample_weight[supervised]
        ).sum() / denominator
        soft_preference = (probability * preference).sum(dim=-1)
        regret = functional.relu(preference[..., 0] - soft_preference)
        identity_regret = (
            regret[supervised] * sample_weight[supervised]
        ).sum() / denominator
    return {
        "coordinate": coordinate,
        "identity_regret": identity_regret,
        "bound": correction_bound,
    }


def episode_loss(
    model: SEBranchCandidateExpert | RegisteredDiscreteCandidateExpert,
    episode: Episode,
    device: torch.device,
    *,
    acceptance_pos_weight: float = 1.0,
    production_trainer_family: str,
    application_contract: dict[str, Any],
) -> tuple[Tensor, dict[str, float]]:
    value = tensors(episode, device)
    output = model(value["feature"], value["xy"], value["valid"])
    probability = torch.softmax(output.candidate_logits, dim=-1)
    supervised = value["weight"].gt(0.0) & value["radar_valid"] & value["allowed"].sum(dim=-1).gt(0.0)
    if not bool(supervised.any()):
        zero = output.candidate_logits.sum() * 0.0
        return zero, {"loss": 0.0, "set_mass": 0.0, "acceptance_bce": 0.0, "continuity": 0.0, "supervised_frames": 0.0}
    legal_mass = legal_set_mass(probability, value["allowed"]).clamp_min(1.0e-6)
    set_loss = -(legal_mass[supervised].log() * value["weight"][supervised]).sum() / value["weight"][supervised].sum().clamp_min(1.0)
    preference_loss = -(
        value["allowed"] * probability.clamp_min(1.0e-6).log()
    ).sum(dim=-1)
    preference_loss = (
        preference_loss[supervised] * value["weight"][supervised]
    ).sum() / value["weight"][supervised].sum().clamp_min(1.0)
    requires_intervention = acceptance_target_from_preference(value["allowed"])
    acceptance = output.acceptance.clamp(1.0e-5, 1.0 - 1.0e-5)
    acceptance_bce = functional.binary_cross_entropy(
        acceptance[supervised], requires_intervention[supervised], reduction="none"
    )
    gate_weight = value["weight"][supervised] * torch.where(
        requires_intervention[supervised].gt(0.5),
        torch.full_like(acceptance_bce, float(acceptance_pos_weight)),
        torch.ones_like(acceptance_bce),
    )
    acceptance_loss = (acceptance_bce * gate_weight).sum() / gate_weight.sum().clamp_min(1.0)
    expected_xy = (probability.unsqueeze(-1) * torch.nan_to_num(value["xy"], nan=0.0)).sum(dim=2)
    step = torch.linalg.vector_norm(expected_xy[:, 1:] - expected_xy[:, :-1], dim=-1)
    temporal_valid = value["radar_valid"][:, 1:] & value["radar_valid"][:, :-1]
    continuity = functional.relu(step[temporal_valid] - 0.75).square().mean() if bool(temporal_valid.any()) else set_loss * 0.0
    production = production_objective_terms(
        probability=probability,
        candidate_xy_m=value["xy"],
        preference=value["allowed"],
        supervised=supervised,
        sample_weight=value["weight"],
        family=production_trainer_family,
        application_contract=application_contract,
    )
    family_weights = {
        "source_tail_refinement": {
            "preference": 0.25,
            "acceptance": 0.50,
            "continuity": 0.02,
            "coordinate": 1.00,
            "regret": 0.00,
            "bound": 0.00,
        },
        "selective_candidate_composite": {
            "preference": 0.35,
            "acceptance": 0.75,
            "continuity": 0.03,
            "coordinate": 0.00,
            "regret": 0.75,
            "bound": 0.00,
        },
        "branch_stability_router": {
            "preference": 0.35,
            "acceptance": 0.75,
            "continuity": 0.10,
            "coordinate": 0.00,
            "regret": 0.75,
            "bound": 0.00,
        },
        "bounded_wet_return_router": {
            "preference": 0.25,
            "acceptance": 0.75,
            "continuity": 0.05,
            "coordinate": 0.00,
            "regret": 0.50,
            "bound": 2.00,
        },
    }[production_trainer_family]
    total = (
        set_loss
        + family_weights["preference"] * preference_loss
        + family_weights["acceptance"] * acceptance_loss
        + family_weights["continuity"] * continuity
        + family_weights["coordinate"] * production["coordinate"]
        + family_weights["regret"] * production["identity_regret"]
        + family_weights["bound"] * production["bound"]
    )
    return total, {
        "loss": float(total.detach()),
        "set_mass": float(legal_mass[supervised].mean().detach()),
        "preference_ce": float(preference_loss.detach()),
        "acceptance_bce": float(acceptance_loss.detach()),
        "continuity": float(continuity.detach()),
        "coordinate": float(production["coordinate"].detach()),
        "identity_regret": float(production["identity_regret"].detach()),
        "bound": float(production["bound"].detach()),
        "supervised_frames": float(supervised.sum().detach()),
    }


@torch.inference_mode()
def calibration_statistics(
    model: SEBranchCandidateExpert | RegisteredDiscreteCandidateExpert,
    episodes: list[Episode],
    device: torch.device,
    *,
    thresholds: tuple[float, ...],
    harm_budget: float,
) -> dict[str, Any]:
    model.eval()
    acceptance: list[np.ndarray] = []
    choice: list[np.ndarray] = []
    allowed: list[np.ndarray] = []
    weight: list[np.ndarray] = []
    for episode in episodes:
        value = tensors(episode, device)
        output = model(value["feature"], value["xy"], value["valid"])
        supervised = (
            value["weight"].gt(0.0)
            & value["radar_valid"]
            & value["allowed"].sum(dim=-1).gt(0.0)
        )[0]
        if not bool(supervised.any()):
            continue
        acceptance.append(output.acceptance[0][supervised].cpu().numpy())
        choice.append(output.candidate_logits[0][supervised].argmax(dim=-1).cpu().numpy())
        allowed.append(value["allowed"][0][supervised].cpu().numpy())
        weight.append(value["weight"][0][supervised].cpu().numpy())
    if not acceptance:
        raise ValueError("Support calibration split has no supervised model outputs")
    return select_calibrated_acceptance_threshold(
        acceptance=np.concatenate(acceptance),
        choice_index=np.concatenate(choice),
        allowed_weight=np.concatenate(allowed),
        sample_weight=np.concatenate(weight),
        thresholds=thresholds,
        harm_budget=harm_budget,
    )


def train(
    *,
    model: SEBranchCandidateExpert | RegisteredDiscreteCandidateExpert,
    target_fit: list[Episode],
    target_calibration: list[Episode],
    source_replay: list[Episode],
    device: torch.device,
    epochs: int,
    learning_rate: float,
    weight_decay: float,
    source_replay_weight: float,
    calibration_thresholds: tuple[float, ...],
    calibration_harm_budget: float,
    production_trainer_family: str,
    application_contract: dict[str, Any],
) -> tuple[dict[str, Tensor], list[dict[str, Any]], int, dict[str, Any]]:
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    best_key: tuple[float, float, float, float] | None = None
    best_epoch = 0
    best_state: dict[str, Tensor] | None = None
    best_calibration: dict[str, Any] | None = None
    history: list[dict[str, Any]] = []
    positive_weight = acceptance_positive_weight([*target_fit, *source_replay])
    for epoch in range(1, epochs + 1):
        model.train()
        ordered = [("target", item) for item in target_fit] + [("source", item) for item in source_replay]
        random.shuffle(ordered)
        values: list[dict[str, float]] = []
        for group, episode in ordered:
            optimizer.zero_grad(set_to_none=True)
            loss, stats = episode_loss(
                model,
                episode,
                device,
                acceptance_pos_weight=positive_weight,
                production_trainer_family=production_trainer_family,
                application_contract=application_contract,
            )
            (loss * (source_replay_weight if group == "source" else 1.0)).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            values.append(stats | {"is_source_replay": 1.0 if group == "source" else 0.0})
        scheduler.step()
        target_loss = float(np.mean([item["loss"] for item in values if item["is_source_replay"] == 0.0]))
        calibration = calibration_statistics(
            model,
            target_calibration,
            device,
            thresholds=calibration_thresholds,
            harm_budget=calibration_harm_budget,
        )
        row = {
            "epoch": float(epoch),
            "target_fit_loss": target_loss,
            "all_loss": float(np.mean([item["loss"] for item in values])),
            "learning_rate": float(scheduler.get_last_lr()[0]),
            "acceptance_positive_weight": positive_weight,
            "calibration_threshold": calibration["threshold"],
            "calibration_utility": calibration["utility"],
            "calibration_base_utility": calibration["base_utility"],
            "calibration_candidate_utility": calibration["candidate_utility"],
            "calibration_harm_rate": calibration["harm_rate"],
            "calibration_coverage": calibration["coverage"],
        }
        history.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
        selection_key = (
            float(calibration["utility"]),
            -float(calibration["harm_rate"]),
            float(calibration["candidate_utility"]),
            -target_loss,
        )
        if best_key is None or selection_key > best_key:
            best_key, best_epoch = selection_key, epoch
            best_state = {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}
            best_calibration = calibration
    if best_state is None or best_calibration is None:
        raise RuntimeError("expert training produced no checkpoint")
    return best_state, history, best_epoch, best_calibration


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-id", required=True)
    parser.add_argument("--route", required=True)
    parser.add_argument("--primitive", required=True)
    parser.add_argument("--implementation-id", choices=registered_implementation_ids())
    parser.add_argument("--parent-branch", choices=("cora0", "cora_se1", "cora_se2"), required=True)
    parser.add_argument("--parent-selection-sha256")
    parser.add_argument("--parent-selection-policy-id")
    parser.add_argument("--production-trainer-family", required=True)
    parser.add_argument("--target-fit-root", type=Path, required=True)
    parser.add_argument("--source-replay-root", type=Path, required=True)
    parser.add_argument("--empty-guard-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=24)
    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--learning-rate", type=float, default=3.0e-4)
    parser.add_argument("--weight-decay", type=float, default=1.0e-4)
    parser.add_argument("--source-replay-weight", type=float, default=0.35)
    parser.add_argument("--calibration-fraction", type=float, default=0.25)
    parser.add_argument("--calibration-harm-budget", type=float, default=0.02)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    validate_production_trainer_family(
        route=args.route, family=args.production_trainer_family
    )
    validate_generic_trainer_family(args.production_trainer_family)
    if args.route in _DIRECT_ROUTES and not valid_sha256(args.parent_selection_sha256):
        raise ValueError("direct-route expert requires a signed parent-selection SHA256")
    if args.route in _DIRECT_ROUTES and args.parent_selection_policy_id != PARENT_SELECTION_POLICY_ID:
        raise ValueError("direct-route expert requires the current parent-selection policy")
    if args.output_dir.exists():
        raise FileExistsError(f"expert output already exists: {args.output_dir}")
    if args.epochs < 1 or args.source_replay_weight <= 0.0:
        raise ValueError("epochs and source-replay-weight must be positive")
    if not 0.0 < args.calibration_fraction < 1.0:
        raise ValueError("calibration-fraction must lie strictly between zero and one")
    if not 0.0 <= args.calibration_harm_budget <= 1.0:
        raise ValueError("calibration-harm-budget must lie in [0, 1]")
    if not args.empty_guard_manifest.is_file():
        raise FileNotFoundError("signed EmptyGuard manifest is required")
    for runtime_root in (args.target_fit_root, args.source_replay_root):
        if not (runtime_root / "ROUTE_RUNTIME_MANIFEST.json").is_file():
            raise FileNotFoundError(
                f"hash-bound route runtime manifest is required: {runtime_root}"
            )
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for route-expert shadow training")
    seed_everything(args.seed)
    target_support = load_episodes(args.target_fit_root, expected_route=args.route, expected_role="fit")
    target_fit, target_calibration = split_fit_calibration_episodes(
        target_support,
        calibration_fraction=args.calibration_fraction,
        seed=args.seed,
    )
    source_replay = load_episodes(args.source_replay_root, expected_route=args.route, expected_role="source_replay")
    assert_disjoint_optimization_roles(
        target_fit=target_fit,
        target_calibration=target_calibration,
        source_replay=source_replay,
    )
    if any(item.parent_branch != args.parent_branch for item in [*target_support, *source_replay]):
        raise ValueError("runtime parent branch does not match the candidate contract")
    feature_dim = target_fit[0].candidate_feature.shape[-1]
    if any(item.candidate_feature.shape[-1] != feature_dim for item in [*target_support, *source_replay]):
        raise ValueError("route runtime feature dimensions differ")
    model = (
        build_registered_route_expert(
            args.implementation_id, feature_dim=feature_dim, hidden_dim=args.hidden_dim
        )
        if args.implementation_id
        else SEBranchCandidateExpert(
            primitive=args.primitive, feature_dim=feature_dim, hidden_dim=args.hidden_dim
        )
    ).to(device)
    application_contract = (
        application_contract_for_implementation(
            project_root=ROOT, implementation_id=args.implementation_id
        )
        if args.implementation_id
        else {
            "mode": "exact_observed_candidate",
            "posterior_scale": 1.0,
            "maximum_correction_m": None,
            "identity_fallback_required": True,
        }
    )
    calibration_thresholds = tuple(float(value) for value in np.linspace(0.0, 1.0, 41))
    state, history, best_epoch, calibration = train(
        model=model,
        target_fit=target_fit,
        target_calibration=target_calibration,
        source_replay=source_replay,
        device=device,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        source_replay_weight=args.source_replay_weight,
        calibration_thresholds=calibration_thresholds,
        calibration_harm_budget=args.calibration_harm_budget,
        production_trainer_family=args.production_trainer_family,
        application_contract=application_contract,
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "agent_jsac_se_branch_route_expert_checkpoint_v2",
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "family": (
            "registered:" + model.architecture_signature
            if args.implementation_id
            else expert_family(args.primitive)
        ),
        "implementation_id": args.implementation_id,
        "parent_branch": args.parent_branch,
        "parent_selection_sha256": args.parent_selection_sha256,
        "parent_selection_policy_id": args.parent_selection_policy_id,
        "production_trainer_family": args.production_trainer_family,
        "model_kwargs": {"feature_dim": feature_dim, "hidden_dim": args.hidden_dim},
        "model_state": state,
        "selected_epoch": best_epoch,
        "acceptance_threshold": calibration["threshold"],
        "support_calibration": calibration,
        "application_contract": application_contract,
        "execution_weight": 0.0,
        "historical_checkpoint_import": False,
        "runtime_raw_depth_input": False,
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    receipt = {
        "schema_version": "agent_jsac_se_branch_route_expert_training_receipt_v2",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "candidate_id": args.candidate_id,
        "route": args.route,
        "production_trainer_family": args.production_trainer_family,
        "primitive": args.primitive,
        "family": (
            "registered:" + model.architecture_signature
            if args.implementation_id
            else expert_family(args.primitive)
        ),
        "implementation_id": args.implementation_id,
        "parent_branch": args.parent_branch,
        "parent_selection_sha256": args.parent_selection_sha256,
        "parent_selection_policy_id": args.parent_selection_policy_id,
        "target_fit_sequences": [item.sequence for item in target_fit],
        "target_calibration_sequences": [item.sequence for item in target_calibration],
        "source_replay_sequences": [item.sequence for item in source_replay],
        "support_canary_read": False,
        "development_read": False,
        "locked_test_read": False,
        "selected_epoch": best_epoch,
        "acceptance_threshold": calibration["threshold"],
        "support_calibration": calibration,
        "application_contract": application_contract,
        "calibration_fraction": args.calibration_fraction,
        "calibration_harm_budget": args.calibration_harm_budget,
        "calibration_threshold_grid": list(calibration_thresholds),
        "checkpoint_path": str(checkpoint_path.resolve()),
        "checkpoint_sha256": sha256(checkpoint_path),
        "execution_weight": 0.0,
        "empty_guard_manifest": str(args.empty_guard_manifest.resolve()),
        "empty_guard_sha256": sha256(args.empty_guard_manifest),
        "runtime_manifests": {
            "target_support": {
                "path": str((args.target_fit_root / "ROUTE_RUNTIME_MANIFEST.json").resolve()),
                "sha256": sha256(args.target_fit_root / "ROUTE_RUNTIME_MANIFEST.json"),
            },
            "source_replay": {
                "path": str((args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json").resolve()),
                "sha256": sha256(args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json"),
            },
        },
        "implementation_files": {
            "trainer": {
                "path": str(Path(__file__).resolve()),
                "sha256": sha256(Path(__file__).resolve()),
            },
            "model": {
                "path": str((ROOT / "src" / "agent_jsac" / "registered_route_expert_models.py").resolve()),
                "sha256": sha256(ROOT / "src" / "agent_jsac" / "registered_route_expert_models.py"),
            },
        },
        "history": history,
    }
    (args.output_dir / "TRAINING_RECEIPT.json").write_text(
        json.dumps(receipt, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps({key: receipt[key] for key in ("candidate_id", "route", "family", "selected_epoch", "checkpoint_sha256")}, sort_keys=True))


if __name__ == "__main__":
    main()
