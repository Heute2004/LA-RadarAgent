# Exact Historical Registered Expert Sources

Recovered read-only from the laboratory server on 2026-09-10.

Server release:
`/home/hyc/radar+ris/AGENT-JSAC/releases/portable_toolbox_full_lifecycle_ready_20260829`

| Local file | Original release-relative path | SHA256 |
| --- | --- | --- |
| registered_route_expert_models.py | src/agent_jsac/registered_route_expert_models.py | 3b379ea9955f23183b38b4368a096836f0cc50667943993ae58156e9a81ea9b8 |
| train_se_branch_route_expert.py | scripts/train_se_branch_route_expert.py | c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70 |

Both hashes match the recorded pair in 252 catalog-matching training receipts outside failed-attempt directories in ALL_RECORDED_EXPERT_SOURCE_INDEX_20260910.json. This count is not a count of independent architectures or promoted experts. Local downloaded files were independently hashed and match the server hashes.

These are unchanged historical source artifacts, not substitute implementations. This directory alone is not a complete executable dependency closure. Production binding, dependency recovery, label contracts, and preparation acceptance remain separate work. No checkpoints or dataset payloads were copied; no training or Locked Test evaluation was run.
