"""Daytime wet-return physical-candidate association with safe parent fallback.

The physical association softmax contains measured RA/RA-MTI candidates only.
The frozen parent is handled by a separate benefit gate and therefore cannot
become the trivial optimum of the candidate-ranking objective.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional


NIGHT_WET_SEQUENCES = frozenset(f"seq_{index:03d}" for index in range(123, 141))


def _normalize_sequences(values: Iterable[str]) -> tuple[str, ...]:
    output = tuple(str(value).strip().lower() for value in values)
    if not output or any(not value.startswith("seq_") for value in output):
        raise ValueError("sequence sets must be non-empty normalized seq identifiers")
    if len(set(output)) != len(output):
        raise ValueError("sequence sets must not contain duplicates")
    return output


def validate_daytime_wet_split(
    *,
    fit_sequences: Iterable[str],
    calibration_sequences: Iterable[str],
    development_sequences: Iterable[str],
) -> None:
    """Fail closed when nighttime wet data leaks into daytime development."""

    fit = set(_normalize_sequences(fit_sequences))
    calibration = set(_normalize_sequences(calibration_sequences))
    development = set(_normalize_sequences(development_sequences))
    if (fit | calibration | development) & NIGHT_WET_SEQUENCES:
        raise ValueError("nighttime wet sequences are forbidden in daytime WRCA development")
    if fit & calibration or fit & development or calibration & development:
        raise ValueError("fit, calibration, and Development sequences must be disjoint")


def map_offline_teacher_to_physical_candidates(
    record: Mapping[str, np.ndarray],
    teacher: Mapping[str, np.ndarray],
    *,
    allowed_sequences: Iterable[str],
    maximum_mapping_error_m: float = 0.30,
    target_sigma_m: float = 0.12,
) -> tuple[dict[str, np.ndarray], dict[str, float | int | str]]:
    """Project an offline teacher trajectory onto the current measured bank.

    The teacher is used only to rank candidates already extracted from the
    current RA/RA-MTI frame. Candidate zero remains the frozen parent action;
    it receives distance-based support for the separate benefit gate but is
    never included in physical-candidate classification.
    """

    if maximum_mapping_error_m <= 0.0 or target_sigma_m <= 0.0:
        raise ValueError("teacher mapping scales must be positive")
    sequence = str(np.asarray(record["sequence"]).item()).strip().lower()
    teacher_sequence = str(np.asarray(teacher["sequence"]).item()).strip().lower()
    allowed = set(_normalize_sequences(allowed_sequences))
    if sequence != teacher_sequence:
        raise ValueError("offline teacher sequence mismatch")
    if sequence in NIGHT_WET_SEQUENCES or sequence not in allowed:
        raise ValueError(f"forbidden offline teacher sequence: {sequence}")

    frame_id = np.asarray(record["frame_id"]).reshape(-1)
    teacher_frame_id = np.asarray(teacher["frame_id"]).reshape(-1)
    if not np.array_equal(frame_id, teacher_frame_id):
        raise ValueError("offline teacher frame_id mismatch")

    candidate_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)
    candidate_valid = np.asarray(record["candidate_valid"], dtype=bool)
    teacher_xy = np.asarray(teacher["selected_candidate_xy_m"], dtype=np.float32)
    if candidate_xy.ndim != 3 or candidate_xy.shape[-1] != 2:
        raise ValueError("candidate_xy_m must be [time,identity+physical,2]")
    if candidate_valid.shape != candidate_xy.shape[:2]:
        raise ValueError("candidate_valid must align with candidate_xy_m")
    if teacher_xy.shape != (candidate_xy.shape[0], 2):
        raise ValueError("offline teacher coordinates must align with candidate frames")
    if candidate_xy.shape[1] < 2:
        raise ValueError("offline teacher mapping requires measured candidates")

    training_mask = np.asarray(teacher["training_mask"], dtype=bool).reshape(-1)
    radar_valid = np.asarray(teacher["radar_training_valid"], dtype=bool).reshape(-1)
    visual_supported = np.asarray(
        teacher["visual_measurement_supported"], dtype=bool
    ).reshape(-1)
    teacher_weight = np.asarray(teacher["sample_weight"], dtype=np.float32).reshape(-1)
    length = candidate_xy.shape[0]
    if any(value.shape != (length,) for value in (training_mask, radar_valid, visual_supported, teacher_weight)):
        raise ValueError("offline teacher masks and weights must align with candidate frames")
    if np.any(teacher_weight < 0.0):
        raise ValueError("offline teacher sample weights must be nonnegative")

    finite_teacher = np.isfinite(teacher_xy).all(axis=1)
    requested = training_mask & radar_valid & visual_supported & finite_teacher
    distance = np.linalg.norm(candidate_xy - teacher_xy[:, None, :], axis=-1)
    distance = np.where(candidate_valid, distance, np.inf)
    physical_distance = distance[:, 1:]
    nearest_mapping_error = np.min(physical_distance, axis=1)
    mapped = requested & (nearest_mapping_error <= float(maximum_mapping_error_m))

    support = np.exp(-0.5 * np.square(distance / float(target_sigma_m))).astype(np.float32)
    support = np.where(candidate_valid & mapped[:, None], support, 0.0)
    support_sum = support.sum(axis=1, keepdims=True)
    support = np.divide(
        support,
        np.maximum(support_sum, 1.0e-12),
        out=np.zeros_like(support),
        where=support_sum > 0.0,
    )

    output = {key: np.asarray(value).copy() for key, value in record.items()}
    output["target_weight"] = support.astype(np.float32)
    output["sample_weight"] = np.where(mapped, teacher_weight, 0.0).astype(np.float32)
    audit: dict[str, float | int | str] = {
        "sequence": sequence,
        "requested_frames": int(requested.sum()),
        "active_frames": int(mapped.sum()),
        "rejected_mapping_frames": int((requested & ~mapped).sum()),
        "coverage": float(mapped.mean()),
        "mapping_error_median_m": float(np.median(nearest_mapping_error[mapped])) if mapped.any() else float("nan"),
        "mapping_error_p90_m": float(np.quantile(nearest_mapping_error[mapped], 0.9)) if mapped.any() else float("nan"),
    }
    return output, audit


def physical_only_targets(
    full_target_weight: Tensor,
    sample_weight: Tensor,
) -> tuple[Tensor, Tensor, Tensor]:
    """Remove identity mass and return physical targets, weights, and benefit.

    Candidate zero in ``full_target_weight`` is the frozen parent action. It is
    never part of physical candidate classification. Frames with no physical
    target mass are excluded from the association loss. The benefit target is
    one only when the strongest measured candidate has more weak-set support
    than the parent action.
    """

    if full_target_weight.ndim != 3 or full_target_weight.shape[-1] < 2:
        raise ValueError("full_target_weight must be [batch,time,identity+physical]")
    if sample_weight.shape != full_target_weight.shape[:2]:
        raise ValueError("sample_weight must align with target frames")
    if torch.any(full_target_weight < 0.0) or torch.any(sample_weight < 0.0):
        raise ValueError("target and sample weights must be nonnegative")
    physical = full_target_weight[..., 1:].float()
    physical_mass = physical.sum(dim=-1)
    normalized = physical / physical_mass[..., None].clamp_min(1.0e-8)
    normalized = torch.where(physical_mass[..., None] > 0.0, normalized, torch.zeros_like(normalized))
    association_weight = sample_weight.float() * physical_mass
    identity_mass = full_target_weight[..., 0].float()
    benefit = (physical.max(dim=-1).values > identity_mass).float()
    return normalized, association_weight, benefit


class WetReturnCandidateAssociationExpert(nn.Module):
    """Causal N-scan association over measured candidates with a separate gate."""

    def __init__(
        self,
        *,
        candidate_count: int,
        token_dim: int = 8,
        hidden_dim: int = 96,
        maximum_step_m: float = 0.35,
        transition_scale_m: float = 0.14,
        use_candidate_patches: bool = True,
        use_existence_state: bool = False,
        background_emphasis: float = 1.0,
    ) -> None:
        super().__init__()
        if candidate_count < 2 or token_dim < 1 or hidden_dim < 8:
            raise ValueError("invalid WRCA dimensions")
        if maximum_step_m <= 0.0 or transition_scale_m <= 0.0 or background_emphasis <= 0.0:
            raise ValueError("WRCA physical scales must be positive")
        self.candidate_count = int(candidate_count)
        self.token_dim = int(token_dim)
        self.hidden_dim = int(hidden_dim)
        self.maximum_step_m = float(maximum_step_m)
        self.transition_scale_m = float(transition_scale_m)
        self.use_candidate_patches = bool(use_candidate_patches)
        self.use_existence_state = bool(use_existence_state)
        self.background_emphasis = float(background_emphasis)
        heads = 4 if hidden_dim % 4 == 0 else 1

        self.type_embedding = nn.Embedding(candidate_count, 8)
        self.token_encoder = nn.Sequential(
            nn.Linear(token_dim + 11, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
        )
        patch_hidden = max(hidden_dim // 2, 16)
        self.patch_encoder = (
            nn.Sequential(
                nn.Conv2d(2, patch_hidden, kernel_size=3, padding=1),
                nn.SiLU(inplace=True),
                nn.Conv2d(patch_hidden, patch_hidden, kernel_size=3, padding=1),
                nn.SiLU(inplace=True),
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
                nn.Linear(patch_hidden, hidden_dim),
                nn.SiLU(inplace=True),
            )
            if self.use_candidate_patches
            else None
        )
        self.candidate_attention = nn.MultiheadAttention(hidden_dim, heads, batch_first=True)
        self.candidate_norm = nn.LayerNorm(hidden_dim)
        self.state_cell = nn.GRUCell(hidden_dim + 8, hidden_dim)
        self.candidate_head = nn.Linear(hidden_dim, 1)
        self.benefit_head = nn.Sequential(
            nn.Linear(hidden_dim + 5, hidden_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )

    def _validate(
        self,
        *,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
        parent_xy_m: Tensor,
        candidate_patch: Tensor | None,
    ) -> tuple[int, int, int]:
        if candidate_token.ndim != 4 or candidate_token.shape[-1] != self.token_dim:
            raise ValueError("candidate_token must be [batch,time,candidates,token_dim]")
        batch, steps, candidates = candidate_token.shape[:3]
        if candidates != self.candidate_count:
            raise ValueError("candidate count mismatch")
        if candidate_xy_m.shape != (batch, steps, candidates, 2):
            raise ValueError("candidate_xy_m must align with physical candidates")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be boolean and align with candidates")
        if candidate_unary_logits.shape != (batch, steps, candidates):
            raise ValueError("candidate_unary_logits must align with candidates")
        if global_state.shape != (batch, steps, 8) or parent_xy_m.shape != (batch, steps, 2):
            raise ValueError("global_state or parent_xy_m has invalid shape")
        if not bool(torch.isfinite(parent_xy_m).all()):
            raise ValueError("parent coordinates must be finite")
        if self.use_candidate_patches:
            if candidate_patch is None or candidate_patch.shape != (batch, steps, candidates, 2, 9, 9):
                raise ValueError("candidate_patch must be [batch,time,candidates,2,9,9]")
        return batch, steps, candidates

    def forward(
        self,
        *,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
        parent_xy_m: Tensor,
        candidate_patch: Tensor | None = None,
    ) -> dict[str, Tensor]:
        batch, steps, candidates = self._validate(
            candidate_token=candidate_token,
            candidate_xy_m=candidate_xy_m,
            candidate_valid=candidate_valid,
            candidate_unary_logits=candidate_unary_logits,
            global_state=global_state,
            parent_xy_m=parent_xy_m,
            candidate_patch=candidate_patch,
        )
        valid = candidate_valid & torch.isfinite(candidate_xy_m).all(dim=-1)
        if not bool(valid.any(dim=-1).all()):
            raise ValueError("every frame requires at least one measured candidate")

        type_id = torch.arange(candidates, device=candidate_token.device).view(1, 1, candidates)
        type_embedding = self.type_embedding(type_id.expand(batch, steps, -1))
        parent_delta = candidate_xy_m.float() - parent_xy_m[:, :, None, :].float()
        geometry = torch.cat(
            (parent_delta / 4.0, torch.linalg.vector_norm(parent_delta, dim=-1, keepdim=True) / 4.0),
            dim=-1,
        )
        adjusted_token = candidate_token.float().clone()
        if self.background_emphasis != 1.0 and adjusted_token.shape[-1] >= 6:
            adjusted_token[..., 5] = adjusted_token[..., 5] * self.background_emphasis
        token = self.token_encoder(torch.cat((adjusted_token, geometry, type_embedding), dim=-1))
        if self.patch_encoder is not None:
            assert candidate_patch is not None
            patch_state = self.patch_encoder(
                candidate_patch.float().reshape(batch * steps * candidates, 2, 9, 9)
            ).reshape(batch, steps, candidates, self.hidden_dim)
            token = token + patch_state * valid[..., None].to(patch_state.dtype)

        flat = token.reshape(batch * steps, candidates, self.hidden_dim)
        flat_valid = valid.reshape(batch * steps, candidates)
        attended, _ = self.candidate_attention(
            flat,
            flat,
            flat,
            key_padding_mask=~flat_valid,
            need_weights=False,
        )
        token = self.candidate_norm(flat + attended).reshape(batch, steps, candidates, self.hidden_dim)

        state = torch.zeros(batch, self.hidden_dim, dtype=token.dtype, device=token.device)
        previous_log_probability: Tensor | None = None
        previous_xy: Tensor | None = None
        previous_valid: Tensor | None = None
        previous_existence: Tensor | None = None
        logits_history: list[Tensor] = []
        state_history: list[Tensor] = []
        reachable_history: list[Tensor] = []
        existence_history: list[Tensor] = []
        for step in range(steps):
            pooled = (token[:, step] * valid[:, step, :, None]).sum(dim=1)
            pooled = pooled / valid[:, step].sum(dim=1, keepdim=True).clamp_min(1)
            state = self.state_cell(torch.cat((pooled, global_state[:, step].float()), dim=-1), state)
            unary = candidate_unary_logits[:, step].float() + self.candidate_head(
                token[:, step] + state[:, None, :]
            ).squeeze(-1)
            unary = unary.masked_fill(~valid[:, step], -torch.inf)
            if previous_log_probability is None:
                logits = unary
                reachable = valid[:, step]
                existence = torch.sigmoid(unary).masked_fill(~valid[:, step], 0.0)
            else:
                assert previous_xy is not None and previous_valid is not None
                distance = torch.cdist(candidate_xy_m[:, step].float(), previous_xy.float())
                edge = valid[:, step, :, None] & previous_valid[:, None, :] & distance.le(self.maximum_step_m)
                inherited = (
                    previous_log_probability[:, None, :] - distance / self.transition_scale_m
                ).masked_fill(~edge, -torch.inf).logsumexp(dim=-1)
                reachable = edge.any(dim=-1)
                logits = unary + 0.45 * torch.where(reachable, inherited, torch.zeros_like(inherited))
                if self.use_existence_state:
                    assert previous_existence is not None
                    inherited_existence = previous_existence[:, None, :].masked_fill(~edge, 0.0).max(dim=-1).values
                    existence = 0.60 * torch.sigmoid(unary) + 0.40 * inherited_existence
                    logits = logits + existence.clamp_min(1.0e-4).log()
                else:
                    existence = torch.sigmoid(logits)
                logits = logits.masked_fill(~valid[:, step], -torch.inf)
            probability = functional.softmax(logits, dim=-1)
            previous_log_probability = probability.clamp_min(1.0e-8).log()
            previous_xy = candidate_xy_m[:, step]
            previous_valid = valid[:, step]
            previous_existence = existence
            logits_history.append(logits)
            state_history.append(state)
            reachable_history.append(reachable)
            existence_history.append(existence)

        logits = torch.stack(logits_history, dim=1)
        probability = functional.softmax(logits, dim=-1)
        selected = probability.argmax(dim=-1)
        rows = torch.arange(batch, device=token.device)[:, None]
        times = torch.arange(steps, device=token.device)[None, :]
        proposal = candidate_xy_m[rows, times, selected]
        top = probability.topk(k=2, dim=-1).values
        margin = top[..., 0] - top[..., 1]
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1)
        entropy = entropy / torch.log(torch.tensor(float(candidates), device=probability.device))
        innovation = torch.linalg.vector_norm(proposal - parent_xy_m, dim=-1) / 4.0
        benefit_feature = torch.cat(
            (
                torch.stack(state_history, dim=1),
                entropy[..., None],
                margin[..., None],
                innovation[..., None],
                global_state[..., 2:3].float(),
                probability.max(dim=-1).values[..., None],
            ),
            dim=-1,
        )
        benefit_logit = self.benefit_head(benefit_feature).squeeze(-1)
        return {
            "physical_candidate_logits": logits,
            "physical_candidate_probability": probability,
            "selected_physical_index": selected,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "posterior_entropy": entropy,
            "posterior_margin": margin,
            "reachable": torch.stack(reachable_history, dim=1),
            "existence_probability": torch.stack(existence_history, dim=1),
        }

    @staticmethod
    def select_with_parent(
        output: Mapping[str, Tensor],
        parent_xy_m: Tensor,
        *,
        threshold: float,
    ) -> Tensor:
        """Apply a proposal only when the separate risk gate accepts it."""

        if not 0.0 <= threshold <= 1.0:
            raise ValueError("threshold must lie in [0,1]")
        proposal = output["proposal_xy_m"]
        benefit = output["benefit_probability"]
        if proposal.shape != parent_xy_m.shape or benefit.shape != parent_xy_m.shape[:2]:
            raise ValueError("proposal, benefit, and parent coordinates must align")
        accepted = benefit.ge(float(threshold)) & torch.isfinite(proposal).all(dim=-1)
        return torch.where(accepted[..., None], proposal, parent_xy_m)
