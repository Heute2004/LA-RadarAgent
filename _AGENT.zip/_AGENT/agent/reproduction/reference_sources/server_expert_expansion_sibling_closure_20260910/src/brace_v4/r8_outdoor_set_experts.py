"""Radar-only outdoor experts trained from R8 set-valued supervision.

R8 may supervise a set of observed physical candidates, but none of its
teacher-only visual/depth evidence is exposed to the deployed expert.  The
runtime model consumes radar-only candidate evidence and either emits one
existing candidate or falls back exactly to the frozen radar base candidate.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional

from brace_v4.r7_tcbav_indoor import TemporalCandidateBranchAssociationVerifier


R8_ROUTES = ("outdoor_dry_complex", "outdoor_wet_return")


@dataclass(frozen=True)
class R8RouteSplit:
    route: str
    fit: tuple[str, ...]
    calibration: tuple[str, ...]
    development: tuple[str, ...]

    @classmethod
    def for_route(cls, route: str) -> "R8RouteSplit":
        if route == "outdoor_dry_complex":
            return cls(
                route=route,
                fit=("seq_108", "seq_119", "seq_120"),
                calibration=("seq_116", "seq_122"),
                development=("seq_109", "seq_117", "seq_121"),
            )
        if route == "outdoor_wet_return":
            return cls(
                route=route,
                fit=("seq_141", "seq_145", "seq_150", "seq_154"),
                calibration=("seq_142", "seq_147"),
                development=("seq_105", "seq_106", "seq_143", "seq_146", "seq_149", "seq_152", "seq_155"),
            )
        raise ValueError(f"unsupported R8 route: {route}")


@dataclass(frozen=True)
class RadarOnlyCandidateFeatures:
    candidate_token: np.ndarray
    candidate_unary_logits: np.ndarray
    base_index: np.ndarray
    base_xy_m: np.ndarray
    global_state: np.ndarray


def prepare_development_radar_record(
    record: Mapping[str, np.ndarray],
    *,
    source_candidate_score: np.ndarray,
    adapted_candidate_score: np.ndarray,
    candidate_count: int = 97,
) -> dict[str, np.ndarray]:
    """Pad a radar-only Development candidate bank to the training contract.

    The function deliberately copies only physical radar evidence.  Visual,
    depth, pseudo-label and Final-BEV fields present in an upstream archive are
    ignored rather than propagated into the deployed expert cache.
    """

    xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)
    raw_key = "radar_score" if "radar_score" in record else "raw_polar_score"
    raw = np.asarray(record[raw_key], dtype=np.float32)
    source = np.asarray(source_candidate_score, dtype=np.float32)
    adapted = np.asarray(adapted_candidate_score, dtype=np.float32)
    agreement = np.asarray(record["candidate_ra_mti_agreement"], dtype=np.float32)
    background = np.asarray(record["candidate_background_risk"], dtype=np.float32)
    persistence = np.asarray(record["candidate_temporal_persistence"], dtype=np.float32)
    if xy.ndim != 3 or xy.shape[-1] != 2:
        raise ValueError("candidate_xy_m must be [frames,candidates,2]")
    shape = xy.shape[:2]
    if any(value.shape != shape for value in (raw, source, adapted, agreement, background, persistence)):
        raise ValueError("Development radar evidence must align with candidate geometry")
    if shape[1] > candidate_count:
        raise ValueError("candidate_count is smaller than the physical candidate bank")

    valid = np.isfinite(xy).all(axis=-1) & np.isfinite(raw)
    if "candidate_coordinate_allowed" in record:
        valid &= np.asarray(record["candidate_coordinate_allowed"], dtype=np.bool_)
    valid &= np.isfinite(source) & np.isfinite(adapted)
    frames, available = shape
    padded_xy = np.zeros((frames, candidate_count, 2), dtype=np.float32)
    padded_valid = np.zeros((frames, candidate_count), dtype=np.bool_)
    padded_xy[:, :available] = np.nan_to_num(xy, nan=0.0)
    padded_valid[:, :available] = valid

    def pad(value: np.ndarray, fill: float) -> np.ndarray:
        output = np.full((frames, candidate_count), fill, dtype=np.float32)
        output[:, :available] = np.nan_to_num(value, nan=fill, posinf=fill, neginf=fill)
        return output

    return {
        "candidate_xy_m": padded_xy,
        "candidate_valid": padded_valid,
        "raw_candidate_score": pad(raw, -100.0),
        "source_candidate_score": pad(source, -100.0),
        "adapted_candidate_score": pad(adapted, -100.0),
        "candidate_ra_mti_agreement": pad(agreement, 0.0),
        "candidate_background_risk": pad(background, 1.0),
        "candidate_temporal_persistence": pad(persistence, 0.0),
    }


def prepend_exact_identity_candidate(
    record: Mapping[str, np.ndarray],
    identity_xy_m: np.ndarray,
    identity_peak_probability: np.ndarray,
) -> dict[str, np.ndarray]:
    """Prepend the exact frozen CORA-SE1 peak as candidate zero.

    Candidate zero is an identity action, not a new radar pseudo-label.  Its
    auxiliary radar statistics are copied from the nearest valid measured
    candidate, while its adapted score is the exact frozen peak probability in
    logit space.  All original physical candidates retain their ordering.
    """

    required = (
        "candidate_xy_m", "candidate_valid", "raw_candidate_score",
        "source_candidate_score", "adapted_candidate_score",
        "candidate_ra_mti_agreement", "candidate_background_risk",
        "candidate_temporal_persistence",
    )
    missing = [key for key in required if key not in record]
    if missing:
        raise KeyError(f"missing identity-runtime fields: {missing}")
    xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)
    valid = np.asarray(record["candidate_valid"], dtype=np.bool_)
    identity = np.asarray(identity_xy_m, dtype=np.float32)
    probability = np.asarray(identity_peak_probability, dtype=np.float32)
    if identity.shape != (xy.shape[0], 2) or probability.shape != (xy.shape[0],):
        raise ValueError("identity peak arrays must align with runtime frames")
    if not np.isfinite(identity).all() or not np.isfinite(probability).all():
        raise ValueError("identity peak arrays must be finite")
    distance = np.linalg.norm(xy - identity[:, None, :], axis=-1)
    distance = np.where(valid, distance, np.inf)
    if np.any(~np.isfinite(distance).any(axis=1)):
        raise ValueError("every frame needs at least one valid physical candidate")
    nearest = distance.argmin(axis=1)
    rows = np.arange(xy.shape[0])
    clipped = np.clip(probability, 1e-6, 1.0 - 1e-6)
    identity_adapted_logit = np.log(clipped / (1.0 - clipped)).astype(np.float32)
    output: dict[str, np.ndarray] = {
        "candidate_xy_m": np.concatenate((identity[:, None, :], xy), axis=1),
        "candidate_valid": np.concatenate((np.ones((xy.shape[0], 1), dtype=np.bool_), valid), axis=1),
        "base_index": np.zeros(xy.shape[0], dtype=np.int64),
        "base_xy_m": identity.copy(),
        "identity_base_inserted": np.asarray(True),
    }
    for key in (
        "raw_candidate_score", "source_candidate_score",
        "candidate_ra_mti_agreement", "candidate_background_risk",
        "candidate_temporal_persistence",
    ):
        value = np.asarray(record[key], dtype=np.float32)
        identity_value = value[rows, nearest]
        output[key] = np.concatenate((identity_value[:, None], value), axis=1)
    adapted = np.asarray(record["adapted_candidate_score"], dtype=np.float32)
    output["adapted_candidate_score"] = np.concatenate(
        (identity_adapted_logit[:, None], adapted), axis=1
    )
    return output


def _masked_standardize(value: np.ndarray, valid: np.ndarray) -> np.ndarray:
    finite = valid & np.isfinite(value)
    safe = np.where(finite, value, np.nan)
    mean = np.nanmean(safe, axis=1, keepdims=True)
    scale = np.nanstd(safe, axis=1, keepdims=True)
    mean = np.nan_to_num(mean, nan=0.0)
    scale = np.nan_to_num(scale, nan=1.0).clip(min=1e-3)
    return np.where(finite, (value - mean) / scale, 0.0).astype(np.float32)


def _top2(value: np.ndarray, valid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    safe = np.where(valid & np.isfinite(value), value, -np.inf)
    ordered = np.sort(safe, axis=1)
    top1 = np.nan_to_num(ordered[:, -1], neginf=0.0, posinf=0.0)
    top2 = np.nan_to_num(ordered[:, -2] if ordered.shape[1] > 1 else ordered[:, -1], neginf=0.0, posinf=0.0)
    return top1.astype(np.float32), top2.astype(np.float32)


def build_radar_only_candidate_features(record: Mapping[str, np.ndarray]) -> RadarOnlyCandidateFeatures:
    """Build runtime features without reading any R8 teacher-only field."""

    required = (
        "candidate_xy_m",
        "candidate_valid",
        "raw_candidate_score",
        "source_candidate_score",
        "adapted_candidate_score",
        "candidate_ra_mti_agreement",
        "candidate_background_risk",
        "candidate_temporal_persistence",
    )
    missing = [key for key in required if key not in record]
    if missing:
        raise KeyError(f"missing radar-only candidate fields: {missing}")
    xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)
    valid = np.asarray(record["candidate_valid"], dtype=np.bool_)
    raw = np.asarray(record["raw_candidate_score"], dtype=np.float32)
    source = np.asarray(record["source_candidate_score"], dtype=np.float32)
    adapted = np.asarray(record["adapted_candidate_score"], dtype=np.float32)
    agreement = np.clip(np.asarray(record["candidate_ra_mti_agreement"], dtype=np.float32), 0.0, 1.0)
    background_safe = 1.0 - np.clip(np.asarray(record["candidate_background_risk"], dtype=np.float32), 0.0, 1.0)
    persistence = np.clip(np.asarray(record["candidate_temporal_persistence"], dtype=np.float32), 0.0, 1.0)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("candidate geometry must be [frames,candidates,2]")
    if any(value.shape != valid.shape for value in (raw, source, adapted, agreement, background_safe, persistence)):
        raise ValueError("radar-only evidence arrays must match candidate validity")

    raw_z = _masked_standardize(raw, valid)
    source_z = _masked_standardize(source, valid)
    adapted_z = _masked_standardize(adapted, valid)
    x = np.nan_to_num(xy[..., 0], nan=0.0)
    y = np.nan_to_num(xy[..., 1], nan=0.0)
    token = np.stack(
        (raw_z, source_z, adapted_z, agreement, background_safe, persistence, x / 10.0, y / 25.0),
        axis=-1,
    ).astype(np.float32)
    token *= valid[..., None]

    # CORA-SE1 is radar-only at inference; its top candidate is the exact
    # identity fallback below the R8 route expert.
    if "base_index" in record:
        requested_base = np.asarray(record["base_index"], dtype=np.int64)
        if requested_base.shape != (xy.shape[0],):
            raise ValueError("base_index must be [frames]")
        if np.any(requested_base < 0) or np.any(requested_base >= xy.shape[1]):
            raise ValueError("base_index is outside the candidate bank")
        if np.any(~valid[np.arange(xy.shape[0]), requested_base]):
            raise ValueError("base_index must reference a valid candidate")
    else:
        requested_base = np.where(valid, adapted_z, -np.inf).argmax(axis=1)
    rows = np.arange(xy.shape[0])
    base_index = requested_base.astype(np.int64)
    base_xy = xy[rows, base_index].astype(np.float32)
    if "base_xy_m" in record:
        explicit_base_xy = np.asarray(record["base_xy_m"], dtype=np.float32)
        if explicit_base_xy.shape != base_xy.shape or not np.isfinite(explicit_base_xy).all():
            raise ValueError("base_xy_m must be finite and shaped [frames,2]")
        base_xy = explicit_base_xy

    raw_top1, raw_top2 = _top2(raw_z, valid)
    adapted_top1, adapted_top2 = _top2(adapted_z, valid)
    global_state = np.stack(
        (
            raw_top1,
            raw_top2,
            raw_top1 - raw_top2,
            adapted_top1,
            adapted_top2,
            adapted_top1 - adapted_top2,
            np.sum(np.where(valid, agreement, 0.0), axis=1) / np.maximum(valid.sum(axis=1), 1),
            np.sum(np.where(valid, background_safe, 0.0), axis=1) / np.maximum(valid.sum(axis=1), 1),
        ),
        axis=-1,
    ).astype(np.float32)
    unary = (
        0.20 * raw_z
        + 0.20 * source_z
        + 0.30 * adapted_z
        + 0.10 * agreement
        + 0.10 * background_safe
        + 0.10 * persistence
    ).astype(np.float32)
    unary = np.where(valid, unary, -20.0).astype(np.float32)
    return RadarOnlyCandidateFeatures(token, unary, base_index, base_xy, global_state)


class R8OutdoorSetExpert(nn.Module):
    """PB-MHBR-style branch posterior with optional GG-SRRE risk recovery."""

    def __init__(
        self,
        *,
        route: str,
        candidate_count: int = 97,
        token_dim: int = 8,
        hidden_dim: int = 96,
        maximum_step_m: float = 0.30,
        maximum_correction_m: float = 0.30,
    ) -> None:
        super().__init__()
        if route not in R8_ROUTES:
            raise ValueError(f"unsupported R8 route: {route}")
        self.route = route
        self.maximum_correction_m = float(maximum_correction_m)
        if self.maximum_correction_m <= 0.0:
            raise ValueError("maximum_correction_m must be positive")
        self.core = TemporalCandidateBranchAssociationVerifier(
            token_dim=token_dim,
            hidden_dim=hidden_dim,
            candidate_count=candidate_count,
            maximum_step_m=maximum_step_m,
            association_temperature_m=0.08,
        )
        self.wet_risk_head = None
        if route == "outdoor_wet_return":
            self.wet_risk_head = nn.Sequential(
                nn.Linear(6, 32),
                nn.SiLU(inplace=True),
                nn.Linear(32, 1),
            )
            nn.init.zeros_(self.wet_risk_head[-1].weight)
            nn.init.zeros_(self.wet_risk_head[-1].bias)

    def forward(self, **inputs: Tensor) -> dict[str, Tensor]:
        candidate_xy = inputs["candidate_xy_m"].float()
        base_xy = inputs["base_xy_m"].float()
        valid = inputs["candidate_valid"].bool()
        distance = torch.linalg.vector_norm(candidate_xy - base_xy[:, :, None], dim=-1)
        identity = torch.zeros_like(valid)
        identity[..., 0] = True
        eligible = valid & (identity | (distance <= self.maximum_correction_m + 1e-6))
        core_inputs = dict(inputs)
        core_inputs["candidate_valid"] = eligible
        output = self.core(**core_inputs)
        output["candidate_eligible"] = eligible
        if self.wet_risk_head is not None:
            global_state = inputs["global_state"].float()
            risk_feature = torch.stack(
                (
                    output["posterior_entropy"],
                    output["posterior_margin"],
                    output["non_identity_probability"],
                    global_state[..., 2],
                    global_state[..., 5],
                    global_state[..., 6],
                ),
                dim=-1,
            )
            output["benefit_logit"] = output["benefit_logit"] + self.wet_risk_head(risk_feature).squeeze(-1)
        return output


def candidate_set_mass_loss(
    output: Mapping[str, Tensor],
    positive_mask: Tensor,
    candidate_valid: Tensor,
    supervision_weight: Tensor,
    base_index: Tensor,
    *,
    target_distribution: Tensor | None = None,
    consensus_weight: float = 0.50,
    benefit_weight: float = 0.25,
    continuity_weight: float = 0.15,
) -> tuple[Tensor, dict[str, Tensor]]:
    """MIL loss: maximize probability mass over the complete R8 candidate set."""

    logits = output["candidate_logits"]
    if positive_mask.shape != logits.shape or candidate_valid.shape != logits.shape:
        raise ValueError("positive_mask and candidate_valid must match candidate logits")
    if supervision_weight.shape != logits.shape[:2] or base_index.shape != logits.shape[:2]:
        raise ValueError("weights and base_index must be [batch,time]")
    valid = candidate_valid.bool()
    if "candidate_eligible" in output:
        valid = valid & output["candidate_eligible"].bool()
    positive = positive_mask.bool() & valid
    supported = positive.any(dim=-1) & supervision_weight.gt(0)
    safe_logits = logits.float().masked_fill(~valid, -1e9)
    positive_logits = safe_logits.masked_fill(~positive, -1e9)
    set_nll = torch.logsumexp(safe_logits, dim=-1) - torch.logsumexp(positive_logits, dim=-1)
    set_nll = torch.where(supported, set_nll, torch.zeros_like(set_nll))

    if target_distribution is None:
        consensus_target = positive.to(logits.dtype)
        consensus_target = consensus_target / consensus_target.sum(dim=-1, keepdim=True).clamp_min(1.0)
        gathered_base = positive.gather(
            -1, base_index.long().clamp(0, logits.shape[-1] - 1)[..., None]
        ).squeeze(-1)
        benefit_target = (~gathered_base).to(logits.dtype)
    else:
        if target_distribution.shape != logits.shape:
            raise ValueError("target_distribution must match candidate logits")
        consensus_target = target_distribution.float() * positive.to(logits.dtype)
        consensus_target = consensus_target / consensus_target.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        base_probability = consensus_target.gather(
            -1, base_index.long().clamp(0, logits.shape[-1] - 1)[..., None]
        ).squeeze(-1)
        benefit_target = consensus_target.amax(dim=-1).gt(base_probability + 1e-6).to(logits.dtype)
    consensus_ce = -(consensus_target * safe_logits.log_softmax(dim=-1)).sum(dim=-1)
    benefit_bce = functional.binary_cross_entropy_with_logits(
        output["benefit_logit"].float(), benefit_target.float(), reduction="none"
    )

    probability = output["candidate_probability"].float()
    xy = output["candidate_xy_m"].float()
    if logits.shape[1] > 1:
        expected_xy = (probability[..., None] * torch.nan_to_num(xy)).sum(dim=2)
        expected_step = torch.linalg.vector_norm(expected_xy[:, 1:] - expected_xy[:, :-1], dim=-1)
        continuity = torch.cat((torch.zeros_like(expected_step[:, :1]), functional.relu(expected_step - 0.30)), dim=1)
    else:
        continuity = torch.zeros_like(set_nll)
    weight = supervision_weight.float().clamp_min(0.0) * supported.to(supervision_weight.dtype)
    per_frame = (
        set_nll
        + float(consensus_weight) * consensus_ce
        + float(benefit_weight) * benefit_bce
        + float(continuity_weight) * continuity
    )
    loss = (weight * per_frame).sum() / weight.sum().clamp_min(1e-8)
    return loss, {
        "set_nll": set_nll.detach(),
        "consensus_ce": consensus_ce.detach(),
        "benefit_bce": benefit_bce.detach(),
        "benefit_target": benefit_target.detach(),
        "continuity": continuity.detach(),
        "supported": supported.detach(),
    }


def apply_identity_safe_candidate(
    candidate_xy_m: Tensor,
    selected_index: Tensor,
    base_index: Tensor,
    accepted: Tensor,
) -> Tensor:
    """Return an observed candidate, using the exact radar base on rejection."""

    if candidate_xy_m.ndim != 4 or candidate_xy_m.shape[-1] != 2:
        raise ValueError("candidate_xy_m must be [batch,time,candidates,2]")
    if selected_index.shape != candidate_xy_m.shape[:2] or base_index.shape != selected_index.shape:
        raise ValueError("candidate indices must be [batch,time]")
    if accepted.shape != selected_index.shape:
        raise ValueError("accepted must be [batch,time]")
    index = torch.where(accepted.bool(), selected_index.long(), base_index.long())
    index = index.clamp(0, candidate_xy_m.shape[2] - 1)
    return candidate_xy_m.gather(2, index[..., None, None].expand(-1, -1, 1, 2)).squeeze(2)
