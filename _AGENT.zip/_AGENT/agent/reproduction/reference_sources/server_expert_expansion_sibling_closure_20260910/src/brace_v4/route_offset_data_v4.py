"""Train/shadow datasets for V4 continuous causal weak supervision."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import Dataset

from .route_supervision_v4 import route_teacher_track


class CausalTeacherOffsetDataset(Dataset[dict[str, torch.Tensor | str]]):
    """Build offset targets solely from frozen base tracks and causal teachers."""

    def __init__(
        self,
        cache_dir: str | Path,
        route: str,
        partition: str,
        *,
        history_length: int,
        shadow_fraction: float = 0.2,
    ) -> None:
        if partition not in {"train", "shadow", "all"}:
            raise ValueError("partition must be train, shadow or all")
        if int(history_length) < 1:
            raise ValueError("history_length must be positive")
        if not 0.0 < float(shadow_fraction) < 1.0:
            raise ValueError("shadow_fraction must be in (0,1)")
        self.history_length = int(history_length)
        self.sequences: list[dict[str, Any]] = []
        self.samples: list[tuple[int, int]] = []

        for path in sorted(Path(cache_dir).glob("seq_*.npz")):
            with np.load(path, allow_pickle=False) as archive:
                cached_route = str(archive["route"].item())
                if cached_route != route:
                    continue
                record = {key: archive[key].copy() for key in archive.files}
            base_track = np.asarray(record["candidate_xy_m"][:, 0], dtype=np.float32)
            teacher_track = route_teacher_track(route, base_track)
            record["base_track_xy_m"] = base_track
            record["teacher_track_xy_m"] = teacher_track
            if "radar_training_valid" not in record:
                record["radar_training_valid"] = np.ones(len(base_track), dtype=np.bool_)
            sequence_index = len(self.sequences)
            self.sequences.append(record)
            frame_count = len(base_track)
            split_at = max(1, min(frame_count - 1, int(round(frame_count * (1.0 - shadow_fraction)))))
            if partition == "train":
                positions = range(split_at)
            elif partition == "shadow":
                positions = range(split_at, frame_count)
            else:
                positions = range(frame_count)
            self.samples.extend((sequence_index, position) for position in positions)
        if not self.samples:
            raise ValueError(f"no offset-supervision samples for route={route!r}, partition={partition!r}")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor | str]:
        sequence_index, position = self.samples[index]
        record = self.sequences[sequence_index]
        history = [max(0, position - self.history_length + 1 + offset) for offset in range(self.history_length)]
        base_xy = np.asarray(record["base_track_xy_m"][position], dtype=np.float32)
        teacher_xy = np.asarray(record["teacher_track_xy_m"][position], dtype=np.float32)
        target_offset = teacher_xy - base_xy
        valid = bool(record["radar_training_valid"][position])
        return {
            "history_tokens": torch.from_numpy(record["tokens"][history].astype(np.float32, copy=False)),
            "history_base_xy": torch.from_numpy(record["base_track_xy_m"][history].astype(np.float32, copy=False)),
            "base_xy": torch.from_numpy(base_xy),
            "teacher_xy": torch.from_numpy(teacher_xy),
            "target_offset_xy": torch.from_numpy(target_offset),
            "target_acceptance": torch.tensor(float(np.linalg.norm(target_offset) >= 0.01), dtype=torch.float32),
            "sample_weight": torch.tensor(1.0 if valid else 0.05, dtype=torch.float32),
            "radar_training_valid": torch.tensor(valid, dtype=torch.bool),
            "frame_id": torch.tensor(int(record["frame_id"][position]), dtype=torch.long),
            "sequence": str(record["sequence"].item()),
        }

