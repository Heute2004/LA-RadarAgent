"""Physical-candidate association primitives for the R11 weak-label contract.

The module deliberately never regresses a BEV coordinate.  Candidate zero is
the frozen base prediction; every other slot must be a measured current-frame
RA/RA-MTI candidate.  R11 set-valued supervision is mapped only onto that
finite physical set and is absent at deployment.
"""

from __future__ import annotations

from typing import Mapping

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional


PCA_RUNTIME_SCHEMA = "brace_v4_r11_pca_runtime_v1"


def _as_xy(value: np.ndarray, name: str) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim != 3 or array.shape[-1] != 2:
        raise ValueError(f"{name} must be [frames,candidates,2]")
    return array


def select_identity_branch_xy(
    identity_branch: str,
    *,
    cora0_xy_m: np.ndarray,
    se1_xy_m: np.ndarray,
    se2_xy_m: np.ndarray,
) -> np.ndarray:
    """Return the frozen branch used as candidate-zero identity.

    The physical candidate bank stays unchanged.  This function only chooses
    which already-frozen radar branch is the exact fallback action.
    """

    branch = str(identity_branch).strip().lower()
    choices = {
        "cora0": cora0_xy_m,
        "se1": se1_xy_m,
        "se2": se2_xy_m,
    }
    if branch not in choices:
        raise ValueError(f"unsupported identity branch: {identity_branch}")
    identity = np.asarray(choices[branch], dtype=np.float32)
    if identity.ndim != 2 or identity.shape[-1] != 2 or not np.isfinite(identity).all():
        raise ValueError(f"{branch} identity coordinates must be finite [frames,2]")
    return identity.copy()


def build_identity_augmented_targets(
    raw_candidate_xy_m: np.ndarray,
    raw_candidate_valid: np.ndarray,
    weak_candidate_xy_m: np.ndarray,
    weak_candidate_valid: np.ndarray,
    weak_candidate_weight: np.ndarray,
    identity_xy_m: np.ndarray,
    *,
    association_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Map R11 set mass to measured raw candidates with an exact base slot.

    A weak member is first associated to an observed current-frame candidate.
    It falls back to candidate zero only when no observed candidate lies within
    ``association_radius_m``.  Unmatched weak mass is dropped, rather than
    creating a new coordinate or snapping it to an arbitrary peak.
    """

    if association_radius_m <= 0.0:
        raise ValueError("association_radius_m must be positive")
    raw_xy = _as_xy(raw_candidate_xy_m, "raw_candidate_xy_m")
    raw_valid = np.asarray(raw_candidate_valid, dtype=np.bool_)
    weak_xy = _as_xy(weak_candidate_xy_m, "weak_candidate_xy_m")
    weak_valid = np.asarray(weak_candidate_valid, dtype=np.bool_)
    weak_weight = np.asarray(weak_candidate_weight, dtype=np.float32)
    identity = np.asarray(identity_xy_m, dtype=np.float32)
    if raw_valid.shape != raw_xy.shape[:2] or weak_valid.shape != weak_xy.shape[:2]:
        raise ValueError("candidate validity masks must align with coordinates")
    if weak_weight.shape != weak_valid.shape or raw_xy.shape[0] != weak_xy.shape[0]:
        raise ValueError("weak labels must share a frame axis")
    if identity.shape != (raw_xy.shape[0], 2) or not np.isfinite(identity).all():
        raise ValueError("identity_xy_m must be finite [frames,2]")

    frames, raw_count = raw_valid.shape
    candidate_xy = np.concatenate((identity[:, None, :], raw_xy), axis=1)
    candidate_valid = np.concatenate((np.ones((frames, 1), dtype=np.bool_), raw_valid), axis=1)
    target_weight = np.zeros((frames, raw_count + 1), dtype=np.float32)
    for frame in range(frames):
        observed = np.flatnonzero(raw_valid[frame] & np.isfinite(raw_xy[frame]).all(axis=1))
        for member in np.flatnonzero(weak_valid[frame] & np.isfinite(weak_xy[frame]).all(axis=1)):
            weight = float(weak_weight[frame, member])
            if weight <= 0.0 or not np.isfinite(weight):
                continue
            if observed.size:
                distance = np.linalg.norm(raw_xy[frame, observed] - weak_xy[frame, member], axis=1)
                local = int(distance.argmin())
                if float(distance[local]) <= association_radius_m:
                    target_weight[frame, int(observed[local]) + 1] += weight
                    continue
            if float(np.linalg.norm(identity[frame] - weak_xy[frame, member])) <= association_radius_m:
                target_weight[frame, 0] += weight
    mass = target_weight.sum(axis=1, keepdims=True)
    target_weight = np.divide(target_weight, mass, out=np.zeros_like(target_weight), where=mass > 0.0)
    return candidate_xy.astype(np.float32), candidate_valid, target_weight.astype(np.float32)


def augment_identity_candidate_evidence(
    *,
    raw_candidate_xy_m: np.ndarray,
    raw_candidate_valid: np.ndarray,
    raw_score: np.ndarray,
    ra_mti_agreement: np.ndarray,
    background_risk: np.ndarray,
    temporal_persistence: np.ndarray,
    identity_xy_m: np.ndarray,
    identity_match_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    """Prepend a frozen identity point without modifying measured evidence.

    The identity action is a detector fallback rather than a raw peak.  It may
    borrow local radar evidence only when a measured raw candidate is
    physically co-located, otherwise it receives conservative neutral values.
    All nonzero slots are copied bit-for-bit from the raw candidate bank.
    """

    if identity_match_radius_m <= 0.0:
        raise ValueError("identity_match_radius_m must be positive")
    raw_xy = _as_xy(raw_candidate_xy_m, "raw_candidate_xy_m")
    valid = np.asarray(raw_candidate_valid, dtype=np.bool_)
    identity = np.asarray(identity_xy_m, dtype=np.float32)
    fields = {
        "raw_score": np.asarray(raw_score, dtype=np.float32),
        "ra_mti_agreement": np.asarray(ra_mti_agreement, dtype=np.float32),
        "background_risk": np.asarray(background_risk, dtype=np.float32),
        "temporal_persistence": np.asarray(temporal_persistence, dtype=np.float32),
    }
    if valid.shape != raw_xy.shape[:2] or identity.shape != (raw_xy.shape[0], 2) or not np.isfinite(identity).all():
        raise ValueError("identity and raw candidate coordinates must align and be finite")
    if any(value.shape != valid.shape for value in fields.values()):
        raise ValueError("raw candidate evidence must align with raw candidate validity")

    frame_count, candidate_count = valid.shape
    candidate_xy = np.concatenate((identity[:, None, :], raw_xy), axis=1).astype(np.float32)
    candidate_valid = np.concatenate((np.ones((frame_count, 1), dtype=np.bool_), valid), axis=1)
    defaults = {
        "raw_score": -12.0,
        "ra_mti_agreement": 0.0,
        "background_risk": 1.0,
        "temporal_persistence": 0.0,
    }
    augmented: dict[str, np.ndarray] = {}
    for name, value in fields.items():
        output = np.full((frame_count, candidate_count + 1), defaults[name], dtype=np.float32)
        output[:, 1:] = value
        augmented[name] = output
    for frame in range(frame_count):
        observed = np.flatnonzero(valid[frame] & np.isfinite(raw_xy[frame]).all(axis=1))
        if observed.size == 0:
            continue
        distance = np.linalg.norm(raw_xy[frame, observed] - identity[frame], axis=1)
        nearest = int(observed[int(distance.argmin())])
        if float(distance.min()) <= float(identity_match_radius_m):
            for name, value in fields.items():
                augmented[name][frame, 0] = value[frame, nearest]
    return candidate_xy, candidate_valid, augmented


def validate_pca_cache_contract(payload: Mapping[str, np.ndarray], *, require_train_targets: bool) -> None:
    """Reject label-tainted, free-coordinate, or malformed PCA caches."""

    if str(np.asarray(payload.get("schema_version", "")).item()) != PCA_RUNTIME_SCHEMA:
        raise ValueError("unsupported PCA cache schema")
    for key in (
        "target_final_bev_read",
        "development_labels_read",
        "locked_test_read",
        "right_rgb_read",
        "manual_ra_anchor_at_label_stage",
    ):
        if bool(np.asarray(payload.get(key, True)).item()):
            raise ValueError("PCA cache contains forbidden provenance")
    candidate_xy = _as_xy(np.asarray(payload["candidate_xy_m"]), "candidate_xy_m")
    candidate_valid = np.asarray(payload["candidate_valid"], dtype=np.bool_)
    if candidate_valid.shape != candidate_xy.shape[:2] or not candidate_valid[:, 0].all():
        raise ValueError("candidate zero must be a valid identity action in every frame")
    identity_index = int(np.asarray(payload.get("identity_candidate_index", -1)).item())
    if identity_index != 0:
        raise ValueError("candidate zero must be the only identity action")
    if not np.isfinite(candidate_xy[:, 0]).all():
        raise ValueError("identity candidate must have finite coordinates")
    if "candidate_patch" in payload:
        patch = np.asarray(payload["candidate_patch"], dtype=np.float32)
        if patch.shape != (*candidate_xy.shape[:2], 2, 9, 9):
            raise ValueError("candidate_patch must be [frames,candidates,2,9,9]")
        if not np.isfinite(patch).all():
            raise ValueError("candidate_patch must be finite")
    if require_train_targets:
        target = np.asarray(payload.get("target_weight"), dtype=np.float32)
        sample_weight = np.asarray(payload.get("sample_weight"), dtype=np.float32)
        if target.shape != candidate_valid.shape or sample_weight.shape != (candidate_xy.shape[0],):
            raise ValueError("PCA train target arrays do not align with candidates")
        if np.any(target < 0.0) or np.any((sample_weight > 0.0) & (target.sum(axis=1) <= 0.0)):
            raise ValueError("PCA train target is not a valid measured-candidate distribution")


def _masked_zscore(value: np.ndarray, valid: np.ndarray) -> np.ndarray:
    finite = valid & np.isfinite(value)
    safe = np.where(finite, value, np.nan)
    mean = np.nanmean(safe, axis=1, keepdims=True)
    scale = np.nanstd(safe, axis=1, keepdims=True)
    mean = np.nan_to_num(mean, nan=0.0)
    scale = np.nan_to_num(scale, nan=1.0).clip(min=1.0e-3)
    return np.where(finite, (value - mean) / scale, 0.0).astype(np.float32)


def build_pca_radar_tokens(
    *,
    raw_score: np.ndarray,
    cora0_score: np.ndarray,
    se1_score: np.ndarray,
    se2_score: np.ndarray,
    ra_mti_agreement: np.ndarray,
    background_risk: np.ndarray,
    temporal_persistence: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build deployment-safe PCA tokens from candidate-local radar evidence.

    The returned tensors intentionally contain no R11 target weight, visual
    bearing, depth, or Final-BEV value.  Per-frame standardization avoids
    transferring a raw gain scale from one commissioned site to another.
    """

    xy = _as_xy(candidate_xy_m, "candidate_xy_m")
    valid = np.asarray(candidate_valid, dtype=np.bool_)
    arrays = tuple(np.asarray(value, dtype=np.float32) for value in (
        raw_score, cora0_score, se1_score, se2_score, ra_mti_agreement, background_risk, temporal_persistence
    ))
    if valid.shape != xy.shape[:2] or any(value.shape != valid.shape for value in arrays):
        raise ValueError("PCA candidate evidence must share [frames,candidates]")
    if not valid[:, 0].all() or not np.isfinite(xy[:, 0]).all():
        raise ValueError("candidate zero must be finite and valid")
    raw, cora0, se1, se2, agreement, risk, persistence = arrays
    raw_z = _masked_zscore(raw, valid)
    cora0_z = _masked_zscore(cora0, valid)
    se1_z = _masked_zscore(se1, valid)
    se2_z = _masked_zscore(se2, valid)
    agreement = np.where(valid, np.clip(np.nan_to_num(agreement, nan=0.0), 0.0, 1.0), 0.0)
    background_safe = np.where(valid, 1.0 - np.clip(np.nan_to_num(risk, nan=1.0), 0.0, 1.0), 0.0)
    persistence = np.where(valid, np.clip(np.nan_to_num(persistence, nan=0.0), 0.0, 1.0), 0.0)
    x_coord = np.where(valid, np.nan_to_num(xy[..., 0], nan=0.0) / 10.0, 0.0)
    y_coord = np.where(valid, np.nan_to_num(xy[..., 1], nan=0.0) / 25.0, 0.0)
    token = np.stack((raw_z, cora0_z, se1_z, se2_z, agreement, background_safe, persistence, x_coord), axis=-1)
    token *= valid[..., None]
    unary = (0.24 * raw_z + 0.14 * cora0_z + 0.17 * se1_z + 0.25 * se2_z + 0.08 * agreement + 0.06 * background_safe + 0.06 * persistence).astype(np.float32)
    unary = np.where(valid, unary, -20.0).astype(np.float32)

    def top_gap(value: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        safe = np.where(valid, value, -np.inf)
        ordered = np.sort(safe, axis=1)
        first = np.nan_to_num(ordered[:, -1], neginf=0.0)
        second = np.nan_to_num(ordered[:, -2] if ordered.shape[1] > 1 else ordered[:, -1], neginf=0.0)
        return first.astype(np.float32), second.astype(np.float32)

    raw_top1, raw_top2 = top_gap(raw_z)
    se2_top1, se2_top2 = top_gap(se2_z)
    global_state = np.stack(
        (
            raw_top1,
            raw_top1 - raw_top2,
            se2_top1,
            se2_top1 - se2_top2,
            (agreement * valid).sum(axis=1) / np.maximum(valid.sum(axis=1), 1),
            (background_safe * valid).sum(axis=1) / np.maximum(valid.sum(axis=1), 1),
            (persistence * valid).sum(axis=1) / np.maximum(valid.sum(axis=1), 1),
            (y_coord * valid).sum(axis=1) / np.maximum(valid.sum(axis=1), 1),
        ),
        axis=-1,
    ).astype(np.float32)
    return token.astype(np.float32), unary, global_state


class R11PhysicalCandidateAssociationExpert(nn.Module):
    """Causal physical candidate scorer with an exact candidate-zero fallback."""

    def __init__(
        self,
        *,
        candidate_count: int,
        token_dim: int = 8,
        hidden_dim: int = 96,
        maximum_step_m: float = 0.30,
        transition_scale_m: float = 0.12,
        use_candidate_patches: bool = False,
        use_factor_graph: bool = False,
        force_measured_candidates: bool = False,
    ) -> None:
        super().__init__()
        if candidate_count < 2 or token_dim < 1 or hidden_dim < 8:
            raise ValueError("invalid PCA dimensions")
        if maximum_step_m <= 0.0 or transition_scale_m <= 0.0:
            raise ValueError("PCA transition scales must be positive")
        self.candidate_count = int(candidate_count)
        self.token_dim = int(token_dim)
        self.maximum_step_m = float(maximum_step_m)
        self.transition_scale_m = float(transition_scale_m)
        self.use_candidate_patches = bool(use_candidate_patches)
        self.use_factor_graph = bool(use_factor_graph)
        self.force_measured_candidates = bool(force_measured_candidates)
        heads = 4 if hidden_dim % 4 == 0 else 1
        self.type_embedding = nn.Embedding(candidate_count, 8)
        self.token_encoder = nn.Sequential(
            nn.Linear(token_dim + 11, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
        )
        patch_hidden = max(hidden_dim // 2, 16)
        self.patch_encoder = (
            nn.Sequential(
                nn.Conv2d(2, patch_hidden, kernel_size=3, padding=1),
                nn.SiLU(inplace=True),
                nn.Conv2d(patch_hidden, patch_hidden, kernel_size=3, padding=1),
                nn.SiLU(inplace=True),
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
                nn.Linear(patch_hidden, hidden_dim),
                nn.SiLU(inplace=True),
            )
            if self.use_candidate_patches
            else None
        )
        # Current/previous candidate features are paired only across measured,
        # physically reachable nodes. Candidate zero remains a separate exact
        # identity action and never participates in learned graph transitions.
        self.edge_factor = (
            nn.Sequential(
                nn.Linear(7, hidden_dim // 2),
                nn.SiLU(inplace=True),
                nn.Linear(hidden_dim // 2, 1),
            )
            if self.use_factor_graph
            else None
        )
        self.candidate_attention = nn.MultiheadAttention(hidden_dim, heads, batch_first=True)
        self.candidate_norm = nn.LayerNorm(hidden_dim)
        self.state_cell = nn.GRUCell(hidden_dim + 8, hidden_dim)
        self.candidate_head = nn.Linear(hidden_dim, 1)
        self.benefit_head = nn.Sequential(
            nn.Linear(hidden_dim + 4, hidden_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )
        nn.init.zeros_(self.candidate_head.weight)
        nn.init.zeros_(self.candidate_head.bias)
        nn.init.zeros_(self.benefit_head[-1].weight)
        nn.init.zeros_(self.benefit_head[-1].bias)
        if self.edge_factor is not None:
            nn.init.zeros_(self.edge_factor[-1].weight)
            nn.init.zeros_(self.edge_factor[-1].bias)

    def _validate(
        self,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
        candidate_patch: Tensor | None,
    ) -> tuple[int, int, int]:
        if candidate_token.ndim != 4 or candidate_token.shape[-1] != self.token_dim:
            raise ValueError("candidate_token must be [batch,time,candidates,token_dim]")
        batch, steps, candidates = candidate_token.shape[:3]
        if candidates != self.candidate_count:
            raise ValueError("candidate count mismatch")
        if candidate_xy_m.shape != (batch, steps, candidates, 2):
            raise ValueError("candidate_xy_m must align with candidate_token")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [batch,time,candidates]")
        if candidate_unary_logits.shape != (batch, steps, candidates):
            raise ValueError("candidate_unary_logits must align with candidates")
        if global_state.shape != (batch, steps, 8):
            raise ValueError("global_state must be [batch,time,8]")
        if self.use_candidate_patches:
            if candidate_patch is None:
                raise ValueError("candidate patches are required in echo-morphology mode")
            if candidate_patch.shape != (batch, steps, candidates, 2, 9, 9):
                raise ValueError("candidate patches must be [batch,time,candidates,2,9,9]")
        if not bool(candidate_valid[..., 0].all()) or not bool(torch.isfinite(candidate_xy_m[..., 0, :]).all()):
            raise ValueError("candidate zero must remain finite and valid")
        return batch, steps, candidates

    def forward(
        self,
        *,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
        candidate_patch: Tensor | None = None,
    ) -> dict[str, Tensor]:
        batch, steps, candidates = self._validate(
            candidate_token, candidate_xy_m, candidate_valid, candidate_unary_logits, global_state, candidate_patch
        )
        valid = candidate_valid & torch.isfinite(candidate_xy_m).all(dim=-1)
        association_valid = valid.clone()
        if self.force_measured_candidates:
            association_valid[..., 0] = False
            # The exact identity action remains available solely when the raw
            # frame contains no measured candidate at all.
            no_measured = ~association_valid.any(dim=-1)
            association_valid[..., 0] = no_measured
        type_id = torch.arange(candidates, device=candidate_token.device).view(1, 1, candidates)
        type_embedding = self.type_embedding(type_id.expand(batch, steps, -1))
        delta_zero = candidate_xy_m - candidate_xy_m[..., :1, :]
        geometry = torch.cat((delta_zero / 4.0, torch.linalg.vector_norm(delta_zero, dim=-1, keepdim=True) / 4.0), dim=-1)
        token = self.token_encoder(torch.cat((candidate_token.float(), geometry.float(), type_embedding), dim=-1))
        if self.patch_encoder is not None:
            assert candidate_patch is not None
            patch_state = self.patch_encoder(
                candidate_patch.float().reshape(batch * steps * candidates, 2, 9, 9)
            ).reshape(batch, steps, candidates, -1)
            token = token + patch_state * valid[..., None].to(patch_state.dtype)
        flat = token.reshape(batch * steps, candidates, -1)
        flat_valid = association_valid.reshape(batch * steps, candidates)
        attended, _ = self.candidate_attention(flat, flat, flat, key_padding_mask=~flat_valid, need_weights=False)
        token = self.candidate_norm(flat + attended).reshape(batch, steps, candidates, -1)

        state = torch.zeros(batch, token.shape[-1], device=token.device, dtype=token.dtype)
        previous_log_probability: Tensor | None = None
        previous_xy: Tensor | None = None
        previous_valid: Tensor | None = None
        previous_evidence: Tensor | None = None
        logits_history: list[Tensor] = []
        reachable_history: list[Tensor] = []
        state_history: list[Tensor] = []
        for step in range(steps):
            pooled = (token[:, step] * association_valid[:, step, :, None]).sum(dim=1)
            pooled = pooled / association_valid[:, step].sum(dim=1, keepdim=True).clamp_min(1)
            state = self.state_cell(torch.cat((pooled, global_state[:, step].float()), dim=-1), state)
            unary = candidate_unary_logits[:, step].float() + self.candidate_head(token[:, step] + state[:, None, :]).squeeze(-1)
            unary = unary.masked_fill(~association_valid[:, step], -torch.inf)
            if previous_log_probability is None:
                logits = unary
                reachable = association_valid[:, step]
            else:
                current_xy = candidate_xy_m[:, step].float()
                distance = torch.cdist(current_xy, previous_xy.float())
                edge = association_valid[:, step, :, None] & previous_valid[:, None, :] & distance.le(self.maximum_step_m)
                transition = previous_log_probability[:, None, :] - distance / self.transition_scale_m
                if self.edge_factor is not None:
                    assert previous_evidence is not None
                    delta = current_xy[:, :, None, :] - previous_xy[:, None, :, :].float()
                    current_evidence = candidate_token[:, step, :, :2].float()[:, :, None, :].expand(-1, -1, candidates, -1)
                    prior_evidence = previous_evidence[:, None, :, :].expand(-1, candidates, -1, -1)
                    edge_feature = torch.cat(
                        (
                            delta / self.maximum_step_m,
                            distance[..., None] / self.transition_scale_m,
                            current_evidence,
                            prior_evidence,
                        ),
                        dim=-1,
                    )
                    learned_edge = self.edge_factor(edge_feature).squeeze(-1)
                    observed = torch.ones((1, candidates, candidates), dtype=torch.bool, device=token.device)
                    observed[:, 0, :] = False
                    observed[:, :, 0] = False
                    edge = edge & observed
                    transition = transition + learned_edge * edge.to(learned_edge.dtype)
                inherited = transition.masked_fill(~edge, -torch.inf).logsumexp(dim=-1)
                reachable = edge.any(dim=-1)
                # Candidate zero is an exact detector fallback, not a synthetic path.
                logits = unary + 0.35 * torch.where(reachable, inherited, torch.zeros_like(inherited))
                logits[:, 0] = unary[:, 0]
                logits = logits.masked_fill(~association_valid[:, step], -torch.inf)
            probability = functional.softmax(logits, dim=-1)
            previous_log_probability = probability.clamp_min(1.0e-8).log()
            previous_xy = candidate_xy_m[:, step]
            previous_valid = association_valid[:, step]
            previous_evidence = candidate_token[:, step, :, :2].float()
            logits_history.append(logits)
            reachable_history.append(reachable)
            state_history.append(state)
        logits = torch.stack(logits_history, dim=1)
        probability = functional.softmax(logits, dim=-1)
        selected = probability.argmax(dim=-1)
        rows = torch.arange(batch, device=token.device)[:, None]
        times = torch.arange(steps, device=token.device)[None, :]
        proposal = candidate_xy_m[rows, times, selected]
        sorted_probability = probability.topk(k=min(2, candidates), dim=-1).values
        margin = sorted_probability[..., 0] - sorted_probability[..., 1] if candidates > 1 else sorted_probability[..., 0]
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1) / np.log(float(candidates))
        non_identity = 1.0 - probability[..., 0]
        benefit_feature = torch.cat((torch.stack(state_history, dim=1), entropy[..., None], margin[..., None], non_identity[..., None], global_state[..., 2:3].float()), dim=-1)
        benefit_logit = self.benefit_head(benefit_feature).squeeze(-1)
        return {
            "candidate_logits": logits,
            "candidate_probability": probability,
            "selected_candidate_index": selected,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "posterior_entropy": entropy,
            "posterior_margin": margin,
            "non_identity_probability": non_identity,
            "reachable": torch.stack(reachable_history, dim=1),
        }

    @staticmethod
    def select_with_identity(output: Mapping[str, Tensor], candidate_xy_m: Tensor, *, threshold: float) -> Tensor:
        """Return a measured proposal only when the learned gate accepts it."""

        if not 0.0 <= threshold <= 1.0:
            raise ValueError("threshold must lie in [0,1]")
        selected = output["selected_candidate_index"]
        proposal = output["proposal_xy_m"]
        benefit = output["benefit_probability"]
        identity = candidate_xy_m[..., 0, :]
        accepted = benefit.ge(float(threshold)) & selected.ne(0) & torch.isfinite(proposal).all(dim=-1)
        return torch.where(accepted[..., None], proposal, identity)
