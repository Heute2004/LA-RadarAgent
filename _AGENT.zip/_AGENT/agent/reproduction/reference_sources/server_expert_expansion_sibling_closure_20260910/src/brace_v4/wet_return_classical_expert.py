"""Data-efficient candidate ranking and causal association for wet returns."""

from __future__ import annotations

from collections.abc import Mapping

import numpy as np


def restrict_candidates_to_parent_radius(
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    *,
    maximum_parent_radius_m: float,
) -> np.ndarray:
    """Admit only local physical corrections while preserving exact identity."""

    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("candidate coordinates and validity must align")
    if xy.shape[1] < 1 or maximum_parent_radius_m <= 0.0:
        raise ValueError("identity candidate and a positive parent radius are required")
    if not valid[:, 0].all():
        raise ValueError("candidate zero must remain the exact identity action")
    distance = np.linalg.norm(xy - xy[:, :1], axis=-1)
    admitted = valid & (distance <= float(maximum_parent_radius_m))
    admitted[:, 0] = True
    return admitted


def set_mass_gate_outcomes(
    selected_index: np.ndarray,
    allowed_weight: np.ndarray,
    sample_weight: np.ndarray,
) -> dict[str, np.ndarray]:
    """Derive correction outcomes from train-only set-valued radar supervision."""

    selected = np.asarray(selected_index, dtype=np.int64)
    allowed = np.asarray(allowed_weight, dtype=np.float32)
    weight = np.asarray(sample_weight, dtype=np.float32)
    if allowed.ndim != 2 or selected.shape != (allowed.shape[0],) or weight.shape != selected.shape:
        raise ValueError("selected indices and set-mass supervision must align")
    if np.any(selected < 0) or np.any(selected >= allowed.shape[1]):
        raise ValueError("selected candidate index is out of range")
    if np.any(allowed < 0.0) or np.any(weight < 0.0):
        raise ValueError("set-mass supervision must be non-negative")
    frame = np.arange(selected.size)
    active = (weight > 0.0) & (allowed.sum(axis=1) > 0.0)
    parent_supported = active & (allowed[:, 0] > 0.0)
    proposal_supported = active & (allowed[frame, selected] > 0.0)
    intervention = selected != 0
    benefit = intervention & proposal_supported & ~parent_supported
    harm = intervention & parent_supported & ~proposal_supported
    return {
        "active": active,
        "parent_supported": parent_supported,
        "proposal_supported": proposal_supported,
        "benefit": benefit,
        "harm": harm,
    }


def select_set_mass_gate_threshold(
    benefit_probability: np.ndarray,
    selected_index: np.ndarray,
    allowed_weight: np.ndarray,
    sample_weight: np.ndarray,
    *,
    harm_budget: float,
    minimum_coverage: float,
) -> tuple[float, dict[str, float]]:
    """Select a conservative Train-internal gate without point targets."""

    probability = np.asarray(benefit_probability, dtype=np.float64)
    selected = np.asarray(selected_index, dtype=np.int64)
    weight = np.asarray(sample_weight, dtype=np.float64)
    if probability.shape != selected.shape or not np.isfinite(probability).all():
        raise ValueError("gate probability must be finite and align with selected candidates")
    if not 0.0 <= harm_budget <= 1.0 or not 0.0 <= minimum_coverage <= 1.0:
        raise ValueError("gate budgets must lie in [0,1]")
    outcomes = set_mass_gate_outcomes(selected, allowed_weight, weight)
    active = outcomes["active"]
    active_mass = float(weight[active].sum())
    if active_mass <= 0.0:
        raise ValueError("gate calibration requires active set-mass supervision")

    baseline = outcomes["parent_supported"].astype(np.float64)
    thresholds = sorted({float(value) for value in probability[active & (selected != 0)]}, reverse=True)
    best: tuple[tuple[float, float, float, float], float, dict[str, float]] | None = None
    for threshold in thresholds:
        accept = active & (selected != 0) & (probability >= threshold)
        accepted_mass = float(weight[accept].sum())
        coverage = accepted_mass / active_mass
        if coverage + 1.0e-12 < minimum_coverage:
            continue
        harm_mass = float(weight[accept & outcomes["harm"]].sum())
        harm_rate = harm_mass / max(accepted_mass, 1.0e-12)
        if harm_rate > harm_budget + 1.0e-12:
            continue
        final_supported = np.where(
            accept,
            outcomes["proposal_supported"],
            outcomes["parent_supported"],
        ).astype(np.float64)
        gain = float(np.sum(weight * (final_supported - baseline)) / active_mass)
        report = {
            "threshold": threshold,
            "coverage": coverage,
            "harm_rate": harm_rate,
            "weighted_set_hit_gain": gain,
        }
        key = (gain, -harm_rate, -coverage, threshold)
        if best is None or key > best[0]:
            best = (key, threshold, report)
    if best is None:
        return 1.1, {
            "threshold": 1.1,
            "coverage": 0.0,
            "harm_rate": 0.0,
            "weighted_set_hit_gain": 0.0,
        }
    return best[1], best[2]


def route_candidate_training_rows(
    candidate_feature: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    allowed_weight: np.ndarray,
    sample_weight: np.ndarray,
    *,
    maximum_parent_radius_m: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Flatten local candidates into radar set-mass ranking examples."""

    feature = np.asarray(candidate_feature, dtype=np.float32)
    allowed = np.asarray(allowed_weight, dtype=np.float32)
    frame_weight = np.asarray(sample_weight, dtype=np.float32)
    admitted = restrict_candidates_to_parent_radius(
        candidate_xy_m,
        candidate_valid,
        maximum_parent_radius_m=maximum_parent_radius_m,
    )
    if feature.ndim != 3 or feature.shape[:2] != admitted.shape:
        raise ValueError("candidate features must align with admitted candidates")
    if allowed.shape != admitted.shape or frame_weight.shape != (admitted.shape[0],):
        raise ValueError("set-mass supervision must align with candidates")
    active = (frame_weight > 0.0) & (allowed.sum(axis=1) > 0.0)
    keep = admitted & active[:, None]
    if not keep.any():
        raise ValueError("candidate ranker has no active local supervision")
    labels = (allowed[keep] > 0.0).astype(np.int8)
    if np.unique(labels).size < 2:
        raise ValueError("candidate ranker requires supported and unsupported examples")
    per_candidate = frame_weight[:, None] / np.maximum(admitted.sum(axis=1, keepdims=True), 1)
    normalized_allowed = allowed / np.maximum(allowed.sum(axis=1, keepdims=True), 1.0e-8)
    weights = per_candidate * np.where(allowed > 0.0, 1.0 + 19.0 * normalized_allowed, 1.0)
    return feature[keep], labels, weights[keep].astype(np.float32)


def route_gate_features(
    candidate_feature: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_probability: np.ndarray,
    selected_index: np.ndarray,
) -> np.ndarray:
    """Describe proposal-vs-identity evidence for a conservative benefit gate."""

    feature = np.asarray(candidate_feature, dtype=np.float32)
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    probability = np.asarray(candidate_probability, dtype=np.float32)
    selected = np.asarray(selected_index, dtype=np.int64)
    if feature.ndim != 3 or xy.shape != (*feature.shape[:2], 2):
        raise ValueError("gate candidate features and coordinates must align")
    if probability.shape != feature.shape[:2] or selected.shape != (feature.shape[0],):
        raise ValueError("gate probabilities and selected indices must align")
    if np.any(selected < 0) or np.any(selected >= feature.shape[1]):
        raise ValueError("gate selected index is out of range")
    frame = np.arange(selected.size)
    selected_feature = feature[frame, selected]
    parent_feature = feature[:, 0]
    selected_probability = probability[frame, selected]
    parent_probability = probability[:, 0]
    ordered = np.sort(probability, axis=1)
    margin = ordered[:, -1] - ordered[:, -2] if probability.shape[1] > 1 else ordered[:, -1]
    normalized = probability / np.maximum(probability.sum(axis=1, keepdims=True), 1.0e-8)
    entropy = -(normalized * np.log(np.maximum(normalized, 1.0e-8))).sum(axis=1)
    displacement = xy[frame, selected] - xy[:, 0]
    distance = np.linalg.norm(displacement, axis=1)
    temporal_step = np.zeros(selected.size, dtype=np.float32)
    if selected.size > 1:
        temporal_step[1:] = np.linalg.norm(
            xy[frame[1:], selected[1:]] - xy[frame[:-1], selected[:-1]],
            axis=1,
        )
    output = np.concatenate(
        (
            selected_feature,
            parent_feature,
            selected_feature - parent_feature,
            selected_probability[:, None],
            parent_probability[:, None],
            margin[:, None],
            entropy[:, None],
            displacement,
            distance[:, None],
            temporal_step[:, None],
        ),
        axis=1,
    ).astype(np.float32)
    return np.nan_to_num(output, nan=0.0, posinf=8.0, neginf=-8.0)


def build_candidate_features(record: Mapping[str, np.ndarray]) -> np.ndarray:
    """Build per-measured-candidate features without visual or label inputs."""

    token = np.asarray(record["candidate_token"], dtype=np.float32)[:, 1:]
    xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)
    unary = np.asarray(record["candidate_unary_logits"], dtype=np.float32)[:, 1:]
    global_state = np.asarray(record["global_state"], dtype=np.float32)
    valid = np.asarray(record["candidate_valid"], dtype=bool)[:, 1:]
    if token.ndim != 3 or token.shape[-1] != 8:
        raise ValueError("candidate_token must contain eight admitted evidence features")
    if xy.shape[:2] != (token.shape[0], token.shape[1] + 1) or xy.shape[-1] != 2:
        raise ValueError("candidate geometry does not align with measured tokens")
    if unary.shape != token.shape[:2] or valid.shape != token.shape[:2]:
        raise ValueError("candidate evidence arrays must share [time,physical_candidate]")
    if global_state.shape != (token.shape[0], 8):
        raise ValueError("global_state must be [time,8]")

    parent = xy[:, :1]
    physical_xy = xy[:, 1:]
    delta = physical_xy - parent
    distance = np.linalg.norm(delta, axis=-1, keepdims=True)
    rank = np.linspace(0.0, 1.0, token.shape[1], dtype=np.float32)
    rank = np.broadcast_to(rank[None, :, None], (*token.shape[:2], 1))
    geometry = np.concatenate(
        (
            physical_xy[..., 0:1] / 10.0,
            physical_xy[..., 1:2] / 25.0,
            delta[..., 0:1] / 2.0,
            delta[..., 1:2] / 2.0,
            distance / 2.0,
            rank,
        ),
        axis=-1,
    )
    broadcast_global = np.broadcast_to(
        global_state[:, None, :], (*token.shape[:2], global_state.shape[-1])
    )

    parts = [token, unary[..., None], geometry, broadcast_global]
    if "candidate_patch" in record:
        patch = np.asarray(record["candidate_patch"], dtype=np.float32)[:, 1:]
        if patch.shape[:3] != (*token.shape[:2], 2) or patch.shape[-2:] != (9, 9):
            raise ValueError("candidate_patch must be [time,identity+physical,2,9,9]")
        flat = patch.reshape(*patch.shape[:3], -1)
        center = patch[..., 4, 4]
        patch_feature = np.concatenate(
            (
                flat.mean(axis=-1),
                flat.std(axis=-1),
                flat.max(axis=-1),
                np.quantile(flat, 0.90, axis=-1),
                center,
            ),
            axis=-1,
        )
        parts.append(patch_feature.astype(np.float32))
    output = np.concatenate(parts, axis=-1).astype(np.float32)
    output = np.nan_to_num(output, nan=0.0, posinf=8.0, neginf=-8.0)
    output *= valid[..., None]
    return output


def causal_candidate_track(
    candidate_score: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    *,
    maximum_step_m: float,
    transition_scale_m: float,
) -> np.ndarray:
    """Greedy causal association with a hard human-motion step constraint."""

    score = np.asarray(candidate_score, dtype=np.float32)
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    if score.shape != valid.shape or xy.shape != (*score.shape, 2):
        raise ValueError("causal candidate arrays must align")
    if maximum_step_m <= 0.0 or transition_scale_m <= 0.0:
        raise ValueError("causal association scales must be positive")
    if not valid.any(axis=1).all():
        raise ValueError("every frame must contain at least one physical candidate")

    selected = np.zeros(score.shape[0], dtype=np.int64)
    first_score = np.where(valid[0], score[0], -np.inf)
    selected[0] = int(np.argmax(first_score))
    for frame in range(1, score.shape[0]):
        distance = np.linalg.norm(xy[frame] - xy[frame - 1, selected[frame - 1]], axis=-1)
        reachable = valid[frame] & (distance <= float(maximum_step_m))
        if reachable.any():
            objective = score[frame] - distance / float(transition_scale_m)
            objective = np.where(reachable, objective, -np.inf)
            selected[frame] = int(np.argmax(objective))
        else:
            nearest = np.where(valid[frame], distance, np.inf)
            selected[frame] = int(np.argmin(nearest))
    return selected
