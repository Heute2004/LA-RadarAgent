"""Offline R8 candidate-attribution primitives for the two outdoor routes.

The modules deliberately score only current measured RA/RA-MTI candidates.
They provide an offline teacher, never a free-coordinate regressor.  Candidate
selection is admissible only after a full-episode forward/reverse agreement.
"""

from __future__ import annotations

from typing import NamedTuple

import numpy as np
import torch
from torch import Tensor, nn


class PathDecode(NamedTuple):
    """Finite candidate paths and per-frame consensus diagnostics."""

    paths: np.ndarray
    path_scores: np.ndarray
    forward_path: np.ndarray
    reverse_path: np.ndarray
    posterior_mass: np.ndarray
    posterior_margin: np.ndarray
    continuous: np.ndarray
    segment_start: np.ndarray


def _masked_softmax(values: np.ndarray, valid: np.ndarray) -> np.ndarray:
    safe = np.where(valid, np.asarray(values, dtype=np.float64), -np.inf)
    maximum = np.max(safe, axis=1, keepdims=True)
    shifted = np.where(np.isfinite(safe), safe - maximum, -np.inf)
    probability = np.exp(shifted)
    probability[~valid] = 0.0
    return (probability / np.maximum(probability.sum(axis=1, keepdims=True), 1.0e-12)).astype(np.float32)


def partial_label_em_responsibility(unary: np.ndarray, allowed: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """E-step responsibility constrained to the R8 candidate member set.

    Frames with no allowed candidate are invalid protocol inputs.  The function
    has no coordinates by design: it cannot convert a set-valued label into a
    fabricated point target.
    """

    score = np.asarray(unary, dtype=np.float32)
    member = np.asarray(allowed, dtype=bool)
    available = np.asarray(valid, dtype=bool)
    if score.ndim != 2 or member.shape != score.shape or available.shape != score.shape:
        raise ValueError("unary, allowed and valid must be aligned [frames,candidates]")
    constrained = member & available & np.isfinite(score)
    if not constrained.any(axis=1).all():
        raise ValueError("every supervised frame requires one valid allowed candidate")
    return _masked_softmax(score, constrained)


def _viterbi_path(unary: np.ndarray, xy: np.ndarray, valid: np.ndarray, *, max_step_m: float) -> tuple[np.ndarray, float]:
    """Decode one highest-score physically reachable path."""

    frames, count = unary.shape
    score = np.where(valid & np.isfinite(unary), unary.astype(np.float64), -np.inf)
    dynamic = np.full((frames, count), -np.inf, dtype=np.float64)
    parent = np.full((frames, count), -1, dtype=np.int64)
    dynamic[0] = score[0]
    for frame in range(1, frames):
        distance = np.linalg.norm(xy[frame - 1, :, None, :] - xy[frame, None, :, :], axis=-1)
        reachable = valid[frame - 1, :, None] & valid[frame, None, :] & (distance <= float(max_step_m) + 1.0e-7)
        joint = dynamic[frame - 1, :, None] + np.where(reachable, 0.0, -np.inf)
        parent[frame] = joint.argmax(axis=0)
        dynamic[frame] = score[frame] + joint.max(axis=0)
    if not np.isfinite(dynamic[-1]).any():
        raise ValueError("no physically reachable candidate path")
    path = np.empty(frames, dtype=np.int64)
    path[-1] = int(dynamic[-1].argmax())
    for frame in range(frames - 1, 0, -1):
        path[frame - 1] = parent[frame, path[frame]]
    return path, float(dynamic[-1, path[-1]])


def _maximal_reachable_segments(xy: np.ndarray, valid: np.ndarray, *, max_step_m: float) -> list[tuple[int, int]]:
    """Partition a timeline whenever no candidate can extend its live path."""

    frames = valid.shape[0]
    start = 0
    reachable_from_start = valid[0].copy()
    segments: list[tuple[int, int]] = []
    for frame in range(1, frames):
        distance = np.linalg.norm(xy[frame - 1, :, None, :] - xy[frame, None, :, :], axis=-1)
        edge = (
            reachable_from_start[:, None]
            & valid[frame, None, :]
            & (distance <= float(max_step_m) + 1.0e-7)
        )
        next_reachable = edge.any(axis=0)
        if next_reachable.any():
            reachable_from_start = next_reachable
            continue
        segments.append((start, frame))
        start = frame
        reachable_from_start = valid[frame].copy()
    segments.append((start, frames))
    return segments


def decode_diverse_physical_paths(
    unary: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    *,
    beam_width: int,
    max_step_m: float,
    stable_step_m: float | None = None,
    diversity_penalty: float = 1.25,
) -> PathDecode:
    """Decode a small diverse family of whole-episode physical hypotheses.

    The primary forward and reverse paths are decoded independently.  Extra
    paths use deterministic node suppression, so a bright but disconnected
    response cannot take over an already physical branch.
    """

    score = np.asarray(unary, dtype=np.float32)
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    if score.ndim != 2 or xy.shape != (*score.shape, 2) or valid.shape != score.shape:
        raise ValueError("candidate tensors must be [frames,candidates] and [frames,candidates,2]")
    if beam_width < 1 or max_step_m <= 0.0:
        raise ValueError("beam_width and max_step_m must be positive")
    if stable_step_m is not None and (stable_step_m <= 0.0 or stable_step_m > max_step_m):
        raise ValueError("stable_step_m must be positive and no larger than max_step_m")
    valid &= np.isfinite(xy).all(axis=-1) & np.isfinite(score)
    if not valid.any(axis=1).all():
        raise ValueError("every frame requires one finite observed candidate")

    segments = _maximal_reachable_segments(xy, valid, max_step_m=max_step_m)
    forward = np.empty(score.shape[0], dtype=np.int64)
    reverse = np.empty_like(forward)
    paths = np.empty((int(beam_width), score.shape[0]), dtype=np.int64)
    path_scores = np.zeros(int(beam_width), dtype=np.float64)
    segment_start = np.zeros(score.shape[0], dtype=bool)
    for start, stop in segments:
        segment_start[start] = True
        local_score = score[start:stop]
        local_xy = xy[start:stop]
        local_valid = valid[start:stop]
        forward_path, _ = _viterbi_path(local_score, local_xy, local_valid, max_step_m=max_step_m)
        reverse_reversed, _ = _viterbi_path(
            local_score[::-1], local_xy[::-1], local_valid[::-1], max_step_m=max_step_m
        )
        forward[start:stop] = forward_path
        reverse[start:stop] = reverse_reversed[::-1]
        work = local_score.astype(np.float64, copy=True)
        for beam in range(int(beam_width)):
            path, total = _viterbi_path(work, local_xy, local_valid, max_step_m=max_step_m)
            paths[beam, start:stop] = path
            path_scores[beam] += total
            work[np.arange(stop - start), path] -= float(diversity_penalty)

    probability = _masked_softmax(score, valid)
    sorted_probability = np.sort(probability, axis=1)
    mass = probability[np.arange(score.shape[0]), forward]
    second = sorted_probability[:, -2] if score.shape[1] > 1 else np.zeros(score.shape[0], dtype=np.float32)
    margin = np.maximum(mass - second, 0.0).astype(np.float32)
    continuous = np.ones(score.shape[0], dtype=bool)
    continuity_limit = float(max_step_m if stable_step_m is None else stable_step_m)
    for start, stop in segments:
        if stop - start == 1:
            continuous[start] = False
            continue
        current = xy[np.arange(start + 1, stop), forward[start + 1 : stop]]
        previous = xy[np.arange(start, stop - 1), forward[start : stop - 1]]
        steps = np.linalg.norm(current - previous, axis=-1)
        continuous[start + 1 : stop] = steps <= continuity_limit + 1.0e-7
        continuous[start] = bool(continuous[start + 1]) if start == 0 else False
    return PathDecode(
        paths=paths.astype(np.int64),
        path_scores=path_scores.astype(np.float32),
        forward_path=forward,
        reverse_path=reverse,
        posterior_mass=mass.astype(np.float32),
        posterior_margin=margin,
        continuous=continuous,
        segment_start=segment_start,
    )


def accept_consensus_path(decode: PathDecode, *, min_mass: float, min_margin: float) -> np.ndarray:
    """Accept only physically continuous forward/reverse-consensus frames."""

    if not 0.0 <= min_mass <= 1.0 or min_margin < 0.0:
        raise ValueError("invalid consensus thresholds")
    return (
        (decode.forward_path == decode.reverse_path)
        & decode.continuous
        & ~decode.segment_start
        & (decode.posterior_mass >= float(min_mass))
        & (decode.posterior_margin >= float(min_margin))
    )


def calibrate_set_supported_gate(
    *,
    posterior_mass: np.ndarray,
    posterior_margin: np.ndarray,
    continuous: np.ndarray,
    forward_reverse_agree: np.ndarray,
    set_supported: np.ndarray,
    sample_weight: np.ndarray,
    min_set_support_precision: float,
    min_coverage: float,
) -> dict[str, np.ndarray | float]:
    """Calibrate a candidate gate using only held-back training set membership.

    ``set_supported`` means the decoder's *measured* candidate belongs to the
    immutable, set-valued R8 weak supervisor.  It is deliberately not a point
    coordinate or a Development correctness signal.  The returned thresholds
    maximise weighted coverage subject to a predeclared teacher-set-support
    budget; if that budget cannot be met, the safe result rejects every frame.
    """

    mass = np.asarray(posterior_mass, dtype=np.float32).reshape(-1)
    margin = np.asarray(posterior_margin, dtype=np.float32).reshape(-1)
    continuous_mask = np.asarray(continuous, dtype=bool).reshape(-1)
    agreement_mask = np.asarray(forward_reverse_agree, dtype=bool).reshape(-1)
    supported = np.asarray(set_supported, dtype=bool).reshape(-1)
    weight = np.asarray(sample_weight, dtype=np.float32).reshape(-1)
    length = mass.size
    if any(value.size != length for value in (margin, continuous_mask, agreement_mask, supported, weight)):
        raise ValueError("gate calibration tensors must have equal length")
    if not 0.0 < float(min_set_support_precision) <= 1.0 or not 0.0 <= float(min_coverage) <= 1.0:
        raise ValueError("invalid set-support or coverage budget")

    eligible = (
        np.isfinite(mass)
        & np.isfinite(margin)
        & continuous_mask
        & agreement_mask
        & (weight > 0.0)
    )
    total_weight = float(weight[eligible].sum())
    empty = np.zeros(length, dtype=bool)
    if total_weight <= 0.0:
        return {
            "accepted": empty,
            "min_mass": float("inf"),
            "min_margin": float("inf"),
            "coverage": 0.0,
            "set_support_precision": 0.0,
        }

    # Exact observed values keep this deterministic and avoid using any target
    # coordinate to choose a probability threshold.
    mass_grid = np.unique(mass[eligible])
    margin_grid = np.unique(margin[eligible])
    best: tuple[float, float, float, float, np.ndarray] | None = None
    for mass_threshold in mass_grid:
        for margin_threshold in margin_grid:
            accepted = eligible & (mass >= mass_threshold) & (margin >= margin_threshold)
            accepted_weight = float(weight[accepted].sum())
            if accepted_weight <= 0.0:
                continue
            coverage = accepted_weight / total_weight
            support_precision = float(weight[accepted & supported].sum()) / accepted_weight
            if coverage + 1.0e-12 < float(min_coverage) or support_precision + 1.0e-12 < float(min_set_support_precision):
                continue
            candidate = (coverage, support_precision, -float(mass_threshold), -float(margin_threshold), accepted)
            if best is None or candidate[:4] > best[:4]:
                best = candidate
    if best is None:
        return {
            "accepted": empty,
            "min_mass": float("inf"),
            "min_margin": float("inf"),
            "coverage": 0.0,
            "set_support_precision": 0.0,
        }
    coverage, precision, neg_mass, neg_margin, accepted = best
    return {
        "accepted": np.asarray(accepted, dtype=bool),
        "min_mass": -neg_mass,
        "min_margin": -neg_margin,
        "coverage": coverage,
        "set_support_precision": precision,
    }


def freeze_physical_candidate_prediction(
    *,
    candidate_logits: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    beam_width: int,
    max_step_m: float,
    stable_step_m: float,
    min_mass: float,
    min_margin: float,
) -> dict[str, np.ndarray]:
    """Freeze an offline teacher result without emitting any free coordinate.

    The returned position is a direct lookup from the current-frame measured
    candidate bank.  R8 set membership, visual evidence, depth and evaluation
    coordinates are deliberately absent from the serializable result.
    """

    score = np.asarray(candidate_logits, dtype=np.float32)
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool) & np.isfinite(xy).all(axis=-1) & np.isfinite(score)
    if score.ndim != 2 or xy.shape != (*score.shape, 2) or valid.shape != score.shape:
        raise ValueError("candidate tensors must be [frames,candidates] and [frames,candidates,2]")
    frames = score.shape[0]
    selected = np.full(frames, -1, dtype=np.int16)
    selected_xy = np.full((frames, 2), np.nan, dtype=np.float32)
    forward = np.full(frames, -1, dtype=np.int16)
    reverse = np.full(frames, -1, dtype=np.int16)
    mass = np.zeros(frames, dtype=np.float32)
    margin = np.zeros(frames, dtype=np.float32)
    accepted = np.zeros(frames, dtype=bool)
    continuous = np.zeros(frames, dtype=bool)
    segment_start = np.zeros(frames, dtype=bool)
    path_scores = np.zeros(int(beam_width), dtype=np.float32)
    active = valid.any(axis=1)
    begin = 0
    while begin < frames:
        while begin < frames and not active[begin]:
            begin += 1
        if begin == frames:
            break
        end = begin + 1
        while end < frames and active[end]:
            end += 1
        decode = decode_diverse_physical_paths(
            score[begin:end],
            xy[begin:end],
            valid[begin:end],
            beam_width=beam_width,
            max_step_m=max_step_m,
            stable_step_m=stable_step_m,
        )
        local_selected = decode.forward_path.astype(np.int16)
        rows = np.arange(begin, end)
        selected[begin:end] = local_selected
        selected_xy[begin:end] = xy[rows, local_selected]
        forward[begin:end] = decode.forward_path.astype(np.int16)
        reverse[begin:end] = decode.reverse_path.astype(np.int16)
        mass[begin:end] = decode.posterior_mass.astype(np.float32)
        margin[begin:end] = decode.posterior_margin.astype(np.float32)
        continuous[begin:end] = decode.continuous.astype(bool)
        segment_start[begin:end] = decode.segment_start.astype(bool)
        accepted[begin:end] = accept_consensus_path(decode, min_mass=min_mass, min_margin=min_margin)
        path_scores += decode.path_scores.astype(np.float32)
        begin = end
    return {
        "selected_candidate_index": selected,
        "selected_candidate_xy_m": selected_xy,
        "forward_path": forward,
        "reverse_path": reverse,
        "posterior_mass": mass,
        "posterior_margin": margin,
        "accepted": accepted,
        "continuous": continuous,
        "segment_start": segment_start,
        "path_scores": path_scores,
    }


def combine_frozen_unary(base_unary: Tensor, residual_logits: Tensor, candidate_valid: Tensor) -> Tensor:
    """Add a residual ranker to frozen radar unary evidence without moving peaks."""

    if base_unary.shape != residual_logits.shape or candidate_valid.shape != base_unary.shape:
        raise ValueError("base, residual and valid tensors must be aligned [batch,time,candidates]")
    if candidate_valid.dtype is not torch.bool:
        raise ValueError("candidate_valid must be boolean")
    return (base_unary.float() + residual_logits.float()).masked_fill(~candidate_valid, -torch.inf)


def partial_label_objective(
    candidate_logits: Tensor,
    allowed_mask: Tensor,
    candidate_valid: Tensor,
    sample_weight: Tensor,
    *,
    allowed_weight: Tensor | None = None,
) -> dict[str, Tensor]:
    """Set mass plus frozen within-set evidence weighting for R8 labels."""

    if candidate_logits.ndim != 3 or allowed_mask.shape != candidate_logits.shape or candidate_valid.shape != candidate_logits.shape:
        raise ValueError("candidate logits and masks must be aligned [batch,time,candidates]")
    if sample_weight.shape != candidate_logits.shape[:2]:
        raise ValueError("sample_weight must be [batch,time]")
    valid = candidate_valid.bool()
    allowed = allowed_mask.bool() & valid
    supported = allowed.any(dim=-1) & sample_weight.gt(0.0)
    if not bool(supported.any()):
        raise ValueError("batch has no R8-supported partial-label frame")
    safe = candidate_logits.float().masked_fill(~valid, -torch.inf)
    inside = safe.masked_fill(~allowed, -torch.inf)
    # Frames without a trusted R8 member are explicitly unsupervised.  Do not
    # let their undefined ``logsumexp(-inf)`` enter the arithmetic graph and
    # rely on a later zero weight to hide it.
    inside_for_loss = torch.where(supported.unsqueeze(-1), inside, torch.zeros_like(inside))
    set_nll = torch.where(
        supported,
        torch.logsumexp(safe, dim=-1) - torch.logsumexp(inside_for_loss, dim=-1),
        torch.zeros_like(sample_weight, dtype=safe.dtype),
    )
    if allowed_weight is None:
        responsibility = torch.softmax(inside_for_loss, dim=-1).detach()
    else:
        if allowed_weight.shape != candidate_logits.shape:
            raise ValueError("allowed_weight must align with candidate logits")
        frozen_weight = allowed_weight.float().clamp_min(0.0) * allowed.to(candidate_logits.dtype)
        normalized_weight = frozen_weight / frozen_weight.sum(dim=-1, keepdim=True).clamp_min(1.0e-8)
        # Degenerate set weights are legal but should not fabricate a preferred
        # member.  Fall back to a detached in-set posterior for those rows.
        fallback = torch.softmax(inside_for_loss, dim=-1).detach()
        responsibility = torch.where(frozen_weight.sum(dim=-1, keepdim=True).gt(0.0), normalized_weight, fallback).detach()
    # No R8 member means no supervision.  In particular, do not let the
    # fallback distribution assign mass to a masked candidate whose log-score
    # is -inf and then rely on a zero frame weight to cancel it later.
    responsibility = torch.where(supported.unsqueeze(-1), responsibility, torch.zeros_like(responsibility))
    log_probability = torch.log_softmax(safe, dim=-1)
    # Invalid candidates carry -inf logits.  Multiplying those by a zero
    # responsibility is mathematically zero but numerically NaN, so make the
    # support restriction explicit before summation.
    em_terms = torch.where(responsibility.gt(0.0), responsibility * log_probability, torch.zeros_like(log_probability))
    em_ce = -em_terms.sum(dim=-1)
    weight = sample_weight.float().clamp_min(0.0) * supported.to(sample_weight.dtype)
    loss = (weight * (set_nll + 0.25 * em_ce)).sum() / weight.sum().clamp_min(1.0e-8)
    return {
        "loss": loss,
        "set_nll": (weight * set_nll).sum() / weight.sum().clamp_min(1.0e-8),
        "em_ce": (weight * em_ce).sum() / weight.sum().clamp_min(1.0e-8),
        "supported_frames": supported.sum(),
    }


class _CandidateTemporalScorer(nn.Module):
    """Shared bidirectional candidate scorer with a zero-initialized residual."""

    def __init__(self, feature_dim: int, *, patch_encoder: nn.Module | None = None) -> None:
        super().__init__()
        if feature_dim <= 0:
            raise ValueError("feature_dim must be positive")
        self.feature_dim = int(feature_dim)
        self.patch_encoder = patch_encoder
        patch_dim = 32 if patch_encoder is not None else 0
        hidden = 96
        self.candidate_encoder = nn.Sequential(
            nn.LayerNorm(feature_dim + patch_dim), nn.Linear(feature_dim + patch_dim, hidden), nn.GELU(), nn.Linear(hidden, hidden), nn.GELU()
        )
        self.set_attention = nn.MultiheadAttention(hidden, num_heads=4, batch_first=True)
        self.temporal = nn.GRU(hidden, hidden // 2, batch_first=True, bidirectional=True)
        self.score_head = nn.Sequential(nn.LayerNorm(hidden), nn.Linear(hidden, hidden), nn.GELU(), nn.Linear(hidden, 1))
        nn.init.zeros_(self.score_head[-1].weight)
        nn.init.zeros_(self.score_head[-1].bias)

    def _score(self, feature: Tensor, valid: Tensor, patch: Tensor | None = None) -> Tensor:
        if feature.ndim != 4 or feature.shape[-1] != self.feature_dim:
            raise ValueError("candidate feature must be [batch,time,candidates,feature_dim]")
        if valid.shape != feature.shape[:3] or valid.dtype is not torch.bool or not bool(valid.any(dim=-1).all()):
            raise ValueError("candidate validity must be nonempty bool [batch,time,candidates]")
        pieces = [feature.float()]
        if self.patch_encoder is not None:
            if patch is None or patch.shape[:4] != (*feature.shape[:3], 2) or patch.shape[-2:] != (9, 9):
                raise ValueError("wet scorer requires [batch,time,candidates,2,9,9] RA/RA-MTI patches")
            encoded_patch = self.patch_encoder(patch.reshape(-1, 2, 9, 9).float()).reshape(*feature.shape[:3], -1)
            pieces.append(encoded_patch)
        encoded = self.candidate_encoder(torch.cat(pieces, dim=-1))
        batch, time, count, hidden = encoded.shape
        flat = encoded.reshape(batch * time, count, hidden)
        flat_valid = valid.reshape(batch * time, count)
        attended, _ = self.set_attention(flat, flat, flat, key_padding_mask=~flat_valid, need_weights=False)
        encoded = (flat + attended).reshape(batch, time, count, hidden)
        weight = valid.to(encoded.dtype).unsqueeze(-1)
        context = (encoded * weight).sum(dim=2) / weight.sum(dim=2).clamp_min(1.0)
        temporal, _ = self.temporal(context)
        # ``temporal`` is shared scene context, while ``encoded`` retains the
        # physical identity of every observed candidate.  Scoring their sum is
        # crucial: averaging candidate tokens and scoring only the context
        # would add exactly the same residual to every candidate and make any
        # partial-label ranking loss ineffective.
        candidate_context = encoded + temporal.unsqueeze(2).expand(-1, -1, count, -1)
        logits = self.score_head(candidate_context).squeeze(-1)
        return logits.masked_fill(~valid, -torch.inf)


class MHPCDryScorer(_CandidateTemporalScorer):
    """Dry-route scalar candidate morphology and branch-consensus scorer."""

    def __init__(self, feature_dim: int) -> None:
        super().__init__(feature_dim)

    def forward(self, candidate_feature: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        return {"candidate_logits": self._score(candidate_feature, candidate_valid)}


class WTTIWetScorer(_CandidateTemporalScorer):
    """Wet-route scorer with local non-coherent RA/RA-MTI response tubes."""

    def __init__(self, feature_dim: int) -> None:
        patch_encoder = nn.Sequential(
            nn.Conv2d(2, 24, kernel_size=3, padding=1), nn.GELU(),
            nn.Conv2d(24, 32, kernel_size=3, padding=1), nn.GELU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(32, 32), nn.GELU(),
        )
        super().__init__(feature_dim, patch_encoder=patch_encoder)

    def forward(self, candidate_feature: Tensor, candidate_valid: Tensor, candidate_patch: Tensor) -> dict[str, Tensor]:
        return {"candidate_logits": self._score(candidate_feature, candidate_valid, candidate_patch)}
