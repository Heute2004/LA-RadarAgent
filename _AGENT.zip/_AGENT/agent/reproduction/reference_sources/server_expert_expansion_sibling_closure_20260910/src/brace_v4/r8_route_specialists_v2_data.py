"""Read-only R8 V3 route-specialist episode loading.

This module sits at the data boundary.  It strips the old identity pseudo
candidate, validates parent provenance, and exposes only radar-derived values
plus the already frozen set-valued R8 supervision.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Mapping

import numpy as np

from .r8_outdoor_set_experts import build_radar_only_candidate_features
from .self_evolution_data import RadarSequenceFrames


FORBIDDEN_PARENT_FLAGS = (
    "target_final_bev_read",
    "development_read",
    "locked_test_read",
    "right_rgb_read",
    "manual_ra_anchor_at_label_stage",
)


@dataclass(frozen=True)
class R8RouteEpisode:
    sequence: str
    route: str
    frame_id: np.ndarray
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_feature: np.ndarray
    candidate_unary: np.ndarray
    base_xy_m: np.ndarray
    allowed_mask: np.ndarray | None
    allowed_weight: np.ndarray | None
    sample_weight: np.ndarray | None
    candidate_patch: np.ndarray | None = None


def _load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {key: np.asarray(archive[key]).copy() for key in archive.files}


def _scalar_text(record: Mapping[str, np.ndarray], key: str) -> str:
    if key not in record:
        raise ValueError(f"archive is missing {key}")
    return str(np.asarray(record[key]).item()).strip().lower()


def _scalar_bool(record: Mapping[str, np.ndarray], key: str) -> bool:
    return bool(np.asarray(record[key]).item())


def _physical_runtime_view(runtime: Mapping[str, np.ndarray]) -> dict[str, np.ndarray]:
    required = (
        "candidate_xy_m", "candidate_valid", "raw_candidate_score", "source_candidate_score",
        "adapted_candidate_score", "candidate_ra_mti_agreement", "candidate_background_risk",
        "candidate_temporal_persistence", "base_xy_m",
    )
    missing = [key for key in required if key not in runtime]
    if missing:
        raise ValueError(f"runtime archive is missing radar fields: {missing}")
    xy = np.asarray(runtime["candidate_xy_m"], dtype=np.float32)
    valid = np.asarray(runtime["candidate_valid"], dtype=bool)
    base = np.asarray(runtime["base_xy_m"], dtype=np.float32)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2] or base.shape != (xy.shape[0], 2):
        raise ValueError("runtime candidate geometry is malformed")
    identity_inserted = _scalar_bool(runtime, "identity_base_inserted") if "identity_base_inserted" in runtime else False
    offset = 1 if identity_inserted else 0
    result: dict[str, np.ndarray] = {
        "candidate_xy_m": xy[:, offset:].copy(),
        "candidate_valid": valid[:, offset:].copy(),
        "base_xy_m": base.copy(),
    }
    for key in required[2:-1]:
        value = np.asarray(runtime[key], dtype=np.float32)
        if value.shape != valid.shape:
            raise ValueError(f"runtime {key} does not align with candidate geometry")
        result[key] = value[:, offset:].copy()
    # A current-parent cache may already contain patches sampled at exactly the
    # same candidate locations.  Reusing them prevents a second coordinate to
    # polar-bin conversion from quietly changing the WTTI observation.  Older
    # runtimes omit this optional field and continue through the legacy reader.
    if "candidate_patch" in runtime:
        patch = np.asarray(runtime["candidate_patch"], dtype=np.float32)
        expected = (*valid.shape, 2, 9, 9)
        if patch.shape != expected:
            raise ValueError("runtime candidate_patch must be [frames,candidates,2,9,9]")
        if not np.isfinite(patch).all():
            raise ValueError("runtime candidate_patch must be finite")
        result["candidate_patch"] = patch[:, offset:].copy()
    return result


def _align_runtime_to_r8(runtime: dict[str, np.ndarray], r8: Mapping[str, np.ndarray]) -> dict[str, np.ndarray]:
    r8_xy = np.asarray(r8["candidate_xy_m"], dtype=np.float32)
    r8_valid = np.asarray(r8["candidate_valid"], dtype=bool)
    if runtime["candidate_xy_m"].shape != r8_xy.shape or not np.allclose(runtime["candidate_xy_m"], r8_xy, atol=1e-6, rtol=0.0, equal_nan=True):
        raise ValueError("runtime/R8 physical candidate geometry mismatch")
    if r8_valid.shape != runtime["candidate_valid"].shape:
        raise ValueError("runtime/R8 candidate validity mismatch")
    if np.any(r8_valid & ~runtime["candidate_valid"]):
        raise ValueError("R8 activates a candidate absent from the radar runtime")
    output = dict(runtime)
    output["candidate_valid"] = runtime["candidate_valid"] & r8_valid
    distance = np.linalg.norm(output["candidate_xy_m"] - output["base_xy_m"][:, None, :], axis=-1)
    distance = np.where(output["candidate_valid"], distance, np.inf)
    if not np.isfinite(distance).any(axis=1).all():
        raise ValueError("R8 validity removes every observed physical candidate")
    output["base_index"] = distance.argmin(axis=1).astype(np.int64)
    return output


def load_route_episode(runtime_path: Path, r8_path: Path, *, route: str) -> R8RouteEpisode:
    """Load a V2 radar runtime and immutable R8 V3 set archive without labels."""

    runtime = _load_npz(Path(runtime_path))
    r8 = _load_npz(Path(r8_path))
    normalized_route = str(route).strip().lower()
    if _scalar_text(runtime, "route") != normalized_route or _scalar_text(r8, "route") != normalized_route:
        raise ValueError("runtime/R8 route does not match requested route")
    if _scalar_text(runtime, "sequence") != _scalar_text(r8, "sequence"):
        raise ValueError("runtime/R8 sequence mismatch")
    if not np.array_equal(runtime["frame_id"], r8["frame_id"]):
        raise ValueError("runtime/R8 frame timeline mismatch")
    for key in FORBIDDEN_PARENT_FLAGS:
        if key not in r8 or _scalar_bool(r8, key):
            raise ValueError(f"R8 parent has forbidden provenance: {key}")
    if bool(np.asarray(r8.get("point_target_emitted", False)).item()):
        raise ValueError("R8 point targets are forbidden; V2 requires set-valued supervision")

    physical = _align_runtime_to_r8(_physical_runtime_view(runtime), r8)
    features = build_radar_only_candidate_features(physical)
    allowed = np.asarray(r8["candidate_set_mask"], dtype=bool) & physical["candidate_valid"]
    allowed_weight = np.asarray(r8["candidate_set_weight"], dtype=np.float32)
    sample_weight = np.asarray(r8["sample_weight"], dtype=np.float32)
    radar_valid = np.asarray(r8["radar_training_valid"], dtype=bool)
    if allowed_weight.shape != allowed.shape or sample_weight.shape != (allowed.shape[0],) or radar_valid.shape != sample_weight.shape:
        raise ValueError("R8 supervision tensors do not align with physical candidates")
    allowed_weight = np.where(allowed, allowed_weight, 0.0)
    allowed_weight /= np.maximum(allowed_weight.sum(axis=1, keepdims=True), 1.0e-8)
    # Raw96 transfer deliberately leaves a frame unlabeled when its immutable
    # R8 set has no physical match.  Preserve that frame for recurrent context
    # while assigning zero position-supervision weight; never manufacture a
    # replacement point target merely to satisfy the loader.
    sample_weight = np.where(radar_valid & allowed.any(axis=1), sample_weight, 0.0).astype(np.float32)
    return R8RouteEpisode(
        sequence=_scalar_text(r8, "sequence"),
        route=normalized_route,
        frame_id=np.asarray(r8["frame_id"], dtype=np.int16),
        candidate_xy_m=physical["candidate_xy_m"].astype(np.float32),
        candidate_valid=physical["candidate_valid"].astype(bool),
        candidate_feature=features.candidate_token.astype(np.float32),
        candidate_unary=features.candidate_unary_logits.astype(np.float32),
        base_xy_m=physical["base_xy_m"].astype(np.float32),
        allowed_mask=allowed.astype(bool),
        allowed_weight=allowed_weight.astype(np.float32),
        sample_weight=sample_weight,
        candidate_patch=physical.get("candidate_patch"),
    )


def load_runtime_episode(runtime_path: Path, *, route: str) -> R8RouteEpisode:
    """Load radar-only inference inputs without opening an R8 teacher archive."""

    runtime = _load_npz(Path(runtime_path))
    normalized_route = str(route).strip().lower()
    if _scalar_text(runtime, "route") != normalized_route:
        raise ValueError("runtime route does not match requested route")
    physical = _physical_runtime_view(runtime)
    valid = np.asarray(physical["candidate_valid"], dtype=bool)
    distance = np.linalg.norm(physical["candidate_xy_m"] - physical["base_xy_m"][:, None, :], axis=-1)
    distance = np.where(valid, distance, np.inf)
    if not np.isfinite(distance).any(axis=1).all():
        raise ValueError("runtime has no observed physical candidate in a frame")
    physical["base_index"] = distance.argmin(axis=1).astype(np.int64)
    features = build_radar_only_candidate_features(physical)
    return R8RouteEpisode(
        sequence=_scalar_text(runtime, "sequence"),
        route=normalized_route,
        frame_id=np.asarray(runtime["frame_id"], dtype=np.int16),
        candidate_xy_m=physical["candidate_xy_m"].astype(np.float32),
        candidate_valid=valid,
        candidate_feature=features.candidate_token.astype(np.float32),
        candidate_unary=features.candidate_unary_logits.astype(np.float32),
        base_xy_m=physical["base_xy_m"].astype(np.float32),
        allowed_mask=None,
        allowed_weight=None,
        sample_weight=None,
        candidate_patch=physical.get("candidate_patch"),
    )


def append_identity_fallback_action(episode: R8RouteEpisode, *, support_radius_m: float) -> R8RouteEpisode:
    """Append one explicit, coordinate-preserving CORA fallback action.

    The extra action is the frozen base coordinate itself, never an invented
    radar peak.  During train-only R8 supervision it is eligible only when an
    existing allowed *physical* candidate lies within ``support_radius_m`` of
    the base.  At inference it remains a legitimate identity action but has no
    teacher mask.  The last token dimension marks it so a scorer cannot confuse
    fallback with a measured RA-MTI response.
    """

    if support_radius_m <= 0.0:
        raise ValueError("support_radius_m must be positive")
    distance = np.linalg.norm(episode.candidate_xy_m - episode.base_xy_m[:, None, :], axis=-1)
    nearest = np.where(episode.candidate_valid, distance, np.inf).argmin(axis=1)
    rows = np.arange(episode.candidate_valid.shape[0])
    nearest_feature = episode.candidate_feature[rows, nearest]
    physical_feature = np.concatenate(
        (episode.candidate_feature, np.zeros((*episode.candidate_feature.shape[:2], 1), dtype=np.float32)), axis=-1
    )
    identity_feature = np.concatenate(
        (nearest_feature, np.ones((nearest_feature.shape[0], 1), dtype=np.float32)), axis=-1
    )
    physical_unary = np.where(episode.candidate_valid, episode.candidate_unary, -np.inf)
    identity_unary = np.max(physical_unary, axis=1, keepdims=True).astype(np.float32)
    allowed = None
    allowed_weight = None
    sample_weight = episode.sample_weight
    if episode.allowed_mask is not None:
        if episode.allowed_weight is None or episode.sample_weight is None:
            raise ValueError("R8 episode has incomplete frozen set supervision")
        base_supported = (episode.allowed_mask & (distance <= float(support_radius_m) + 1.0e-7)).any(axis=1)
        allowed = np.concatenate((episode.allowed_mask, base_supported[:, None]), axis=1)
        local_weight = np.where(
            episode.allowed_mask & (distance <= float(support_radius_m) + 1.0e-7),
            episode.allowed_weight,
            0.0,
        ).sum(axis=1, keepdims=True)
        allowed_weight = np.concatenate((episode.allowed_weight, local_weight.astype(np.float32)), axis=1)
        allowed_weight = np.where(allowed, allowed_weight, 0.0).astype(np.float32)
        allowed_weight /= np.maximum(allowed_weight.sum(axis=1, keepdims=True), 1.0e-8)
        sample_weight = np.where(allowed.any(axis=1), episode.sample_weight, 0.0).astype(np.float32)
    patch = None
    if episode.candidate_patch is not None:
        patch = np.concatenate((episode.candidate_patch, episode.candidate_patch[rows, nearest, None]), axis=1)
    return replace(
        episode,
        candidate_xy_m=np.concatenate((episode.candidate_xy_m, episode.base_xy_m[:, None, :]), axis=1).astype(np.float32),
        candidate_valid=np.concatenate((episode.candidate_valid, np.ones((episode.candidate_valid.shape[0], 1), dtype=bool)), axis=1),
        candidate_feature=np.concatenate((physical_feature, identity_feature[:, None, :]), axis=1).astype(np.float32),
        candidate_unary=np.concatenate((episode.candidate_unary, identity_unary), axis=1).astype(np.float32),
        allowed_mask=None if allowed is None else allowed.astype(bool),
        allowed_weight=None if allowed_weight is None else allowed_weight.astype(np.float32),
        sample_weight=sample_weight,
        candidate_patch=patch,
    )


def restrict_to_base_trust_region(episode: R8RouteEpisode, *, radius_m: float) -> R8RouteEpisode:
    """Keep only measured candidates locally reachable from frozen CORA.

    A route specialist has no target coordinate available for validating a
    long jump.  This trust region therefore constrains all selectable physical
    candidates around the frozen detector, while always retaining its nearest
    observed radar candidate for a well-defined identity comparison.  Frames
    whose R8 set has no in-region member are unsupervised rather than forced
    onto a distant false branch.
    """

    if radius_m <= 0.0:
        raise ValueError("radius_m must be positive")
    distance = np.linalg.norm(episode.candidate_xy_m - episode.base_xy_m[:, None, :], axis=-1)
    valid = episode.candidate_valid & (distance <= float(radius_m) + 1.0e-7)
    nearest = np.where(episode.candidate_valid, distance, np.inf).argmin(axis=1)
    valid[np.arange(valid.shape[0]), nearest] = True
    allowed = None
    allowed_weight = None
    sample_weight = None
    if episode.allowed_mask is not None:
        allowed = episode.allowed_mask & valid
        if episode.allowed_weight is None or episode.sample_weight is None:
            raise ValueError("R8 episode has incomplete frozen set supervision")
        allowed_weight = np.where(allowed, episode.allowed_weight, 0.0).astype(np.float32)
        allowed_weight /= np.maximum(allowed_weight.sum(axis=1, keepdims=True), 1.0e-8)
        sample_weight = np.where(allowed.any(axis=1), episode.sample_weight, 0.0).astype(np.float32)
    patch = None
    if episode.candidate_patch is not None:
        patch = np.where(valid[:, :, None, None, None], episode.candidate_patch, 0.0).astype(np.float32)
    return replace(
        episode,
        candidate_valid=valid.astype(bool),
        allowed_mask=allowed,
        allowed_weight=allowed_weight,
        sample_weight=sample_weight,
        candidate_patch=patch,
    )


def attach_observed_raw_patches(
    episode: R8RouteEpisode,
    *,
    data_root: Path,
    episode_record: Mapping[str, object],
    radius: int = 4,
) -> R8RouteEpisode:
    """Attach same-frame normalized RA/RA-MTI patches around observed peaks.

    This is intentionally a local raw-radar feature operation.  It never loads
    commissioned background statistics, camera values, depth, or labels.
    """

    if radius < 0:
        raise ValueError("patch radius must be nonnegative")
    if episode.candidate_patch is not None:
        return episode
    source = RadarSequenceFrames.create(data_root, dict(episode_record))
    if tuple(episode.frame_id.astype(int).tolist()) != source.frame_ids:
        raise ValueError("raw radar/R8 timeline mismatch")
    patch_size = 2 * radius + 1
    output = np.zeros((*episode.candidate_valid.shape, 2, patch_size, patch_size), dtype=np.float32)
    range_resolution = 23.4 / 128.0
    for row, frame_id in enumerate(episode.frame_id.astype(int)):
        frame = source.read_normalized(int(frame_id)).numpy()
        padded = np.pad(frame, ((0, 0), (radius, radius), (radius, radius)), mode="constant")
        for candidate in np.flatnonzero(episode.candidate_valid[row]):
            x_m, y_m = episode.candidate_xy_m[row, candidate]
            distance = max(float(np.hypot(x_m, y_m)), 1.0e-6)
            range_bin = int(np.clip(np.rint(distance / range_resolution), 0, 127))
            azimuth_bin = int(np.clip(np.rint(((x_m / distance) + 1.0) * 64.0), 0, 127))
            output[row, candidate] = padded[:, range_bin : range_bin + patch_size, azimuth_bin : azimuth_bin + patch_size]
    return replace(episode, candidate_patch=output)
