"""Candidate-level weak supervision and safe CORA expert primitives.

The visual branch is allowed to select an existing radar candidate, but it
cannot synthesize a free BEV coordinate or alter radar range.  New experts are
identity initialized and therefore leave candidate zero (the CORA proposal)
unchanged until a shadow-validation stage explicitly enables them.
"""

from __future__ import annotations

import math
from typing import Any

import torch
from torch import Tensor, nn
from torch.nn import functional as functional


def nms_topk_bev_candidates(
    probability: Tensor,
    *,
    top_k: int,
    radius_cells: int,
) -> tuple[Tensor, Tensor]:
    """Extract spatially distinct BEV maxima as ``(row, column)`` indices."""

    if probability.ndim != 4 or probability.shape[1] != 1:
        raise ValueError("probability must have shape [B,1,H,W]")
    if top_k < 1:
        raise ValueError("top_k must be positive")
    if radius_cells < 0:
        raise ValueError("radius_cells must be non-negative")

    kernel = 2 * int(radius_cells) + 1
    pooled = functional.max_pool2d(probability, kernel_size=kernel, stride=1, padding=radius_cells)
    maxima = probability.eq(pooled)
    suppressed = probability.masked_fill(~maxima, -torch.inf)
    flat = suppressed.flatten(2).squeeze(1)
    available = min(int(top_k), flat.shape[1])
    scores, flat_indices = flat.topk(available, dim=1)
    width = probability.shape[-1]
    rows = torch.div(flat_indices, width, rounding_mode="floor")
    columns = flat_indices.remainder(width)
    indices = torch.stack((rows, columns), dim=-1)

    if available < top_k:
        pad_count = int(top_k) - available
        indices = functional.pad(indices, (0, 0, 0, pad_count))
        scores = functional.pad(scores, (0, pad_count), value=-torch.inf)
    return indices, scores


def visual_bearing_polar_peaks(
    polar_power: Tensor,
    *,
    visual_theta: Tensor,
    visual_reliability: Tensor,
    top_k: int,
    azimuth_half_width_bins: int = 2,
    range_nms_radius_bins: int = 3,
    minimum_visual_reliability: float = 0.55,
) -> tuple[Tensor, Tensor, Tensor]:
    """Extract causal raw-polar peaks inside a reliable visual bearing band.

    The visual branch constrains *only* azimuth.  Range is always selected
    from the current RA/RA-MTI response, so no image-derived range or free BEV
    coordinate can enter the weak target.  Returned indices use the native
    ``[range_bin, azimuth_bin]`` convention.
    """

    if polar_power.ndim != 4 or polar_power.shape[1] != 2:
        raise ValueError("polar_power must have shape [B,2,range,azimuth]")
    if top_k < 1:
        raise ValueError("top_k must be positive")
    if azimuth_half_width_bins < 0 or range_nms_radius_bins < 0:
        raise ValueError("NMS radii must be non-negative")

    batch, _, range_bins, azimuth_bins = polar_power.shape
    theta = visual_theta.reshape(batch).to(device=polar_power.device, dtype=polar_power.dtype)
    reliability = visual_reliability.reshape(batch).to(device=polar_power.device, dtype=polar_power.dtype)
    accepted = torch.isfinite(theta) & torch.isfinite(reliability) & reliability.ge(float(minimum_visual_reliability))

    # Both RA and RA-MTI must support a candidate; their equal-weight mean
    # keeps static and moving evidence available without introducing a
    # hand-designed range estimate.
    response = polar_power.mean(dim=1)
    center = torch.round((torch.sin(theta) + 1.0) * (azimuth_bins / 2.0)).long().clamp(0, azimuth_bins - 1)
    azimuth_axis = torch.arange(azimuth_bins, device=polar_power.device)[None, :]
    allowed_azimuth = (azimuth_axis - center[:, None]).abs().le(int(azimuth_half_width_bins))
    band = response.masked_fill(~allowed_azimuth[:, None, :], -torch.inf)
    range_scores, range_azimuth = band.max(dim=-1)

    indices = torch.zeros((batch, top_k, 2), dtype=torch.long, device=polar_power.device)
    scores = torch.full((batch, top_k), -torch.inf, dtype=polar_power.dtype, device=polar_power.device)
    remaining = range_scores.clone()
    for rank in range(top_k):
        peak_score, range_index = remaining.max(dim=1)
        azimuth_index = range_azimuth.gather(1, range_index[:, None]).squeeze(1)
        indices[:, rank, 0] = range_index
        indices[:, rank, 1] = azimuth_index
        scores[:, rank] = peak_score
        for offset in range(-int(range_nms_radius_bins), int(range_nms_radius_bins) + 1):
            masked_index = (range_index + offset).clamp(0, range_bins - 1)
            remaining.scatter_(1, masked_index[:, None], -torch.inf)

    # Invalid visual observations cannot create a radar weak label.  Their
    # placeholder indices are deterministic and are ignored by the caller.
    indices = torch.where(accepted[:, None, None], indices, torch.zeros_like(indices))
    scores = torch.where(accepted[:, None], scores, torch.full_like(scores, -torch.inf))
    return indices, scores, accepted


def v21_raw_polar_label_allowed(
    *,
    visual_polar_mode: Tensor,
    require_visual: bool,
) -> Tensor:
    """Gate V2.1 coordinate weak labels to raw RA visual-band candidates.

    CORA remains an inference fallback, but it is not a V2.1 weak-label
    source.  Therefore a frame without a reliable raw-polar visual-band
    candidate must abstain rather than reusing candidate zero from CORA.
    """

    if visual_polar_mode.ndim != 1:
        raise ValueError("visual_polar_mode must be one-dimensional [B]")
    if not require_visual:
        return torch.ones_like(visual_polar_mode, dtype=torch.bool)
    return visual_polar_mode.to(dtype=torch.bool)


def select_visual_temporal_pseudolabel(
    candidates_xy: Tensor,
    radar_scores: Tensor,
    *,
    visual_theta: Tensor,
    visual_reliability: Tensor,
    previous_xy: Tensor,
    minimum_visual_reliability: float = 0.55,
    maximum_angle_error_rad: float = math.radians(12.0),
    maximum_step_m: float = 1.25,
    angle_scale_rad: float = math.radians(4.0),
    temporal_scale_m: float = 0.6,
) -> tuple[Tensor, Tensor, dict[str, Tensor]]:
    """Choose one radar candidate using visual bearing and causal continuity.

    Candidate zero is the frozen CORA fallback.  Invalid or unreliable visual
    evidence causes abstention and therefore returns candidate zero.
    """

    if candidates_xy.ndim != 3 or candidates_xy.shape[-1] != 2:
        raise ValueError("candidates_xy must have shape [B,K,2]")
    if radar_scores.shape != candidates_xy.shape[:2]:
        raise ValueError("radar_scores must have shape [B,K]")
    batch_size = candidates_xy.shape[0]
    theta = visual_theta.reshape(batch_size, 1).to(candidates_xy)
    reliability = visual_reliability.reshape(batch_size).to(candidates_xy)
    previous = previous_xy.reshape(batch_size, 1, 2).to(candidates_xy)

    candidate_theta = torch.atan2(candidates_xy[..., 0], candidates_xy[..., 1].clamp_min(1e-3))
    angle_difference = torch.atan2(
        torch.sin(candidate_theta - theta),
        torch.cos(candidate_theta - theta),
    ).abs()
    step_distance = torch.linalg.vector_norm(candidates_xy - previous, dim=-1)

    finite_scores = torch.where(torch.isfinite(radar_scores), radar_scores, torch.full_like(radar_scores, -1e6))
    score_min = finite_scores.amin(dim=1, keepdim=True)
    score_span = (finite_scores.amax(dim=1, keepdim=True) - score_min).clamp_min(1e-6)
    normalized_radar = (finite_scores - score_min) / score_span
    compatibility = (
        0.20 * normalized_radar
        - angle_difference / max(float(angle_scale_rad), 1e-6)
        - 0.25 * step_distance / max(float(temporal_scale_m), 1e-6)
    )
    selected = compatibility.argmax(dim=1)
    gather_index = selected[:, None]
    selected_angle = angle_difference.gather(1, gather_index).squeeze(1)
    selected_step = step_distance.gather(1, gather_index).squeeze(1)
    selected_score = radar_scores.gather(1, gather_index).squeeze(1)

    accepted = (
        torch.isfinite(theta.squeeze(1))
        & torch.isfinite(reliability)
        & torch.isfinite(selected_score)
        & reliability.ge(float(minimum_visual_reliability))
        & selected_angle.le(float(maximum_angle_error_rad))
        & selected_step.le(float(maximum_step_m))
    )
    fallback = torch.zeros_like(selected)
    selected = torch.where(accepted, selected, fallback)
    diagnostics = {
        "candidate_angle_error_rad": angle_difference,
        "candidate_step_m": step_distance,
        "compatibility": compatibility,
        "selected_angle_error_rad": selected_angle,
        "selected_step_m": selected_step,
        "selected_radar_score": selected_score,
    }
    return selected, accepted, diagnostics


def select_visual_polar_temporal_pseudolabel(
    candidates_xy: Tensor,
    polar_scores: Tensor,
    *,
    candidate_background_risk: Tensor,
    candidate_ra_mti_agreement: Tensor | None = None,
    previous_xy: Tensor,
    predicted_xy: Tensor,
    maximum_background_risk: float = 0.13,
    maximum_range_innovation_m: float = 1.0,
    maximum_lateral_step_m: float = 0.30,
    minimum_polar_score: float | None = None,
    minimum_ra_mti_agreement: float | None = None,
) -> tuple[Tensor, Tensor, dict[str, Tensor]]:
    """Choose a VAST-constrained raw-polar peak from candidates ``1..K-1``.

    Candidate zero is the frozen CORA BEV output and is deliberately excluded:
    when reliable visual bearing is available, the weak target must represent a
    genuine in-band radar response rather than another confirmation of the
    base detector.  Range and lateral continuity are both imposed.  The
    lateral gate prevents a transient visual-bearing error from moving the
    raw-polar teacher onto a distant azimuth branch.
    """

    if candidates_xy.ndim != 3 or candidates_xy.shape[-1] != 2:
        raise ValueError("candidates_xy must have shape [B,K,2]")
    if polar_scores.shape != candidates_xy.shape[:2] or candidate_background_risk.shape != polar_scores.shape:
        raise ValueError("polar scores and background risk must match [B,K]")
    if candidate_ra_mti_agreement is not None and candidate_ra_mti_agreement.shape != polar_scores.shape:
        raise ValueError("candidate_ra_mti_agreement must match [B,K]")
    if candidates_xy.shape[1] < 2:
        raise ValueError("visual polar selection requires base plus one polar candidate")

    previous = previous_xy.reshape(candidates_xy.shape[0], 2).to(candidates_xy)
    predicted = predicted_xy.reshape(candidates_xy.shape[0], 2).to(candidates_xy)
    previous_range = previous[..., 1:2]
    predicted_range = predicted[..., 1:2]
    ranges = candidates_xy[..., 1]
    innovation = (ranges - predicted_range).abs()
    step = (ranges - previous_range).abs()
    lateral_step = (candidates_xy[..., 0] - previous[..., 0:1]).abs()
    lateral_innovation = (candidates_xy[..., 0] - predicted[..., 0:1]).abs()
    candidate_mask = torch.arange(candidates_xy.shape[1], device=candidates_xy.device)[None, :].ge(1)
    valid = (
        candidate_mask
        & torch.isfinite(polar_scores)
        & candidate_background_risk.to(candidates_xy).le(float(maximum_background_risk))
        & innovation.le(float(maximum_range_innovation_m))
        & lateral_step.le(float(maximum_lateral_step_m))
    )
    if minimum_polar_score is not None:
        valid = valid & polar_scores.ge(float(minimum_polar_score))
    if minimum_ra_mti_agreement is not None:
        if candidate_ra_mti_agreement is None:
            raise ValueError("candidate_ra_mti_agreement is required when its minimum is set")
        valid = valid & candidate_ra_mti_agreement.to(candidates_xy).ge(float(minimum_ra_mti_agreement))
    finite = torch.where(torch.isfinite(polar_scores), polar_scores, torch.full_like(polar_scores, -1e6))
    polar_min = finite[:, 1:].amin(dim=1, keepdim=True)
    polar_span = (finite[:, 1:].amax(dim=1, keepdim=True) - polar_min).clamp_min(1e-6)
    normalized_score = (finite - polar_min) / polar_span
    compatibility = normalized_score - 0.35 * innovation / max(float(maximum_range_innovation_m), 1e-6)
    selected = compatibility.masked_fill(~valid, -torch.inf).argmax(dim=1)
    accepted = valid.any(dim=1)
    selected = torch.where(accepted, selected, torch.zeros_like(selected))
    gather = selected[:, None]
    return selected, accepted, {
        "candidate_range_innovation_m": innovation,
        "candidate_range_step_m": step,
        "candidate_lateral_innovation_m": lateral_innovation,
        "candidate_lateral_step_m": lateral_step,
        "candidate_valid": valid,
        "selected_range_innovation_m": innovation.gather(1, gather).squeeze(1),
        "selected_range_step_m": step.gather(1, gather).squeeze(1),
        "selected_lateral_innovation_m": lateral_innovation.gather(1, gather).squeeze(1),
        "selected_lateral_step_m": lateral_step.gather(1, gather).squeeze(1),
        "selected_background_risk": candidate_background_risk.to(candidates_xy).gather(1, gather).squeeze(1),
        "selected_ra_mti_agreement": (
            candidate_ra_mti_agreement.to(candidates_xy).gather(1, gather).squeeze(1)
            if candidate_ra_mti_agreement is not None
            else torch.full_like(innovation.gather(1, gather).squeeze(1), float("nan"))
        ),
        "selected_compatibility": compatibility.gather(1, gather).squeeze(1),
        "valid_candidate_count": valid.sum(dim=1),
    }


def candidate_temporal_persistence(
    current_xy: Tensor,
    history_xy: Tensor,
    *,
    distance_scale_m: float = 0.6,
) -> Tensor:
    """Score how consistently each current candidate appears in causal history.

    ``history_xy`` contains only frames preceding ``current_xy``.  For every
    current candidate, the nearest candidate in each past frame contributes an
    exponentially decayed match score.  No future frame or target coordinate
    is required.
    """

    if current_xy.ndim != 2 or current_xy.shape[-1] != 2:
        raise ValueError("current_xy must have shape [K,2]")
    if history_xy.ndim != 3 or history_xy.shape[-1] != 2:
        raise ValueError("history_xy must have shape [T,K,2]")
    if distance_scale_m <= 0.0:
        raise ValueError("distance_scale_m must be positive")
    if history_xy.shape[0] == 0:
        return torch.zeros(current_xy.shape[0], device=current_xy.device, dtype=current_xy.dtype)

    history = history_xy.to(device=current_xy.device, dtype=current_xy.dtype)
    distances = torch.linalg.vector_norm(
        current_xy[None, :, None, :] - history[:, None, :, :],
        dim=-1,
    )
    nearest = distances.amin(dim=-1)
    normalized = nearest / float(distance_scale_m)
    return torch.exp(-0.5 * normalized.square()).mean(dim=0)


def ra_mti_candidate_agreement(sampled_ra_mti: Tensor, *, difference_scale: float = 1.0) -> Tensor:
    """Return a bounded agreement score for sampled normalized RA/RA-MTI."""

    if sampled_ra_mti.ndim != 3 or sampled_ra_mti.shape[-1] != 2:
        raise ValueError("sampled_ra_mti must have shape [B,K,2]")
    if difference_scale <= 0.0:
        raise ValueError("difference_scale must be positive")
    difference = (sampled_ra_mti[..., 0] - sampled_ra_mti[..., 1]).abs()
    normalized = difference / float(difference_scale)
    return torch.exp(-0.5 * normalized.square())


def select_radar_temporal_pseudolabel(
    candidates_xy: Tensor,
    radar_scores: Tensor,
    *,
    candidate_ra_mti_agreement: Tensor,
    candidate_background_risk: Tensor,
    candidate_persistence: Tensor,
    previous_xy: Tensor,
    predicted_xy: Tensor,
    minimum_radar_score: float = 0.14,
    minimum_ra_mti_agreement: float = 0.05,
    maximum_background_risk: float = 0.13,
    minimum_persistence: float = 0.25,
    maximum_step_m: float = 1.0,
    maximum_prediction_error_m: float = 0.8,
    maximum_lateral_step_m: float | None = 0.30,
    candidate_coordinate_allowed: Tensor | None = None,
) -> tuple[Tensor, Tensor, dict[str, Tensor]]:
    """Select a causal radar candidate when visual weak labels are unavailable.

    Candidate zero remains the frozen CORA fallback.  A candidate must be
    supported by radar score, RA/RA-MTI agreement, commissioned-background
    safety, causal persistence and a bounded motion innovation.  The function
    abstains instead of manufacturing a free coordinate when no candidate
    satisfies all gates.
    """

    if candidates_xy.ndim != 3 or candidates_xy.shape[-1] != 2:
        raise ValueError("candidates_xy must have shape [B,K,2]")
    expected = candidates_xy.shape[:2]
    evidence = {
        "radar_scores": radar_scores,
        "candidate_ra_mti_agreement": candidate_ra_mti_agreement,
        "candidate_background_risk": candidate_background_risk,
        "candidate_persistence": candidate_persistence,
    }
    for name, value in evidence.items():
        if value.shape != expected:
            raise ValueError(f"{name} must have shape [B,K]")
    if candidate_coordinate_allowed is not None and candidate_coordinate_allowed.shape != expected:
        raise ValueError("candidate_coordinate_allowed must have shape [B,K]")

    batch_size = candidates_xy.shape[0]
    previous = previous_xy.reshape(batch_size, 1, 2).to(candidates_xy)
    predicted = predicted_xy.reshape(batch_size, 1, 2).to(candidates_xy)
    agreement = candidate_ra_mti_agreement.to(candidates_xy).clamp(0.0, 1.0)
    background_risk = candidate_background_risk.to(candidates_xy).clamp(0.0, 1.0)
    persistence = candidate_persistence.to(candidates_xy).clamp(0.0, 1.0)
    scores = radar_scores.to(candidates_xy)

    finite_scores = torch.where(torch.isfinite(scores), scores, torch.full_like(scores, -1e6))
    score_min = finite_scores.amin(dim=1, keepdim=True)
    score_span = (finite_scores.amax(dim=1, keepdim=True) - score_min).clamp_min(1e-6)
    normalized_radar = (finite_scores - score_min) / score_span
    step_distance = torch.linalg.vector_norm(candidates_xy - previous, dim=-1)
    prediction_error = torch.linalg.vector_norm(candidates_xy - predicted, dim=-1)

    lateral_step = (candidates_xy[..., 0] - previous[..., 0]).abs()
    valid = (
        torch.isfinite(scores)
        & scores.ge(float(minimum_radar_score))
        & agreement.ge(float(minimum_ra_mti_agreement))
        & background_risk.le(float(maximum_background_risk))
        & persistence.ge(float(minimum_persistence))
        & step_distance.le(float(maximum_step_m))
        & prediction_error.le(float(maximum_prediction_error_m))
    )
    if maximum_lateral_step_m is not None:
        if maximum_lateral_step_m <= 0.0:
            raise ValueError("maximum_lateral_step_m must be positive when supplied")
        valid = valid & lateral_step.le(float(maximum_lateral_step_m))
    if candidate_coordinate_allowed is not None:
        valid = valid & candidate_coordinate_allowed.to(device=candidates_xy.device, dtype=torch.bool)
    compatibility = (
        0.45 * normalized_radar
        + 0.20 * agreement
        + 0.20 * persistence
        + 0.15 * (1.0 - background_risk)
        - 0.20 * step_distance / max(float(maximum_step_m), 1e-6)
        - 0.20 * prediction_error / max(float(maximum_prediction_error_m), 1e-6)
    )
    masked_compatibility = compatibility.masked_fill(~valid, -torch.inf)
    selected = masked_compatibility.argmax(dim=1)
    valid_count = valid.sum(dim=1)
    accepted = valid_count.gt(0)
    selected = torch.where(accepted, selected, torch.zeros_like(selected))
    gather = selected[:, None]
    diagnostics = {
        "candidate_step_m": step_distance,
        "candidate_prediction_error_m": prediction_error,
        "candidate_compatibility": compatibility,
        "candidate_valid": valid,
        "valid_candidate_count": valid_count,
        "selected_step_m": step_distance.gather(1, gather).squeeze(1),
        "selected_prediction_error_m": prediction_error.gather(1, gather).squeeze(1),
        "selected_lateral_step_m": lateral_step.gather(1, gather).squeeze(1),
        "selected_radar_score": scores.gather(1, gather).squeeze(1),
        "selected_ra_mti_agreement": agreement.gather(1, gather).squeeze(1),
        "selected_background_risk": background_risk.gather(1, gather).squeeze(1),
        "selected_persistence": persistence.gather(1, gather).squeeze(1),
        "selected_compatibility": compatibility.gather(1, gather).squeeze(1),
    }
    return selected, accepted, diagnostics


def select_condition_aware_pseudolabel(
    candidates_xy: Tensor,
    radar_scores: Tensor,
    *,
    visual_theta: Tensor,
    visual_reliability: Tensor,
    visual_presence_accepted: Tensor,
    candidate_ra_mti_agreement: Tensor,
    candidate_background_risk: Tensor,
    candidate_persistence: Tensor,
    previous_xy: Tensor,
    predicted_xy: Tensor,
    minimum_visual_reliability: float = 0.55,
    maximum_background_risk: float = 0.13,
) -> tuple[Tensor, Tensor, dict[str, Tensor]]:
    """Route weak supervision between visual-bearing and radar-only modes.

    Reliable visual evidence may select an existing radar candidate.  Missing
    or degraded visual evidence activates the causal radar-only selector.  A
    reliable but geometrically inconsistent visual observation causes
    abstention rather than silently reinforcing a conflicting radar branch.
    """

    batch_size = candidates_xy.shape[0]
    theta = visual_theta.reshape(batch_size).to(candidates_xy)
    reliability = visual_reliability.reshape(batch_size).to(candidates_xy)
    presence = visual_presence_accepted.reshape(batch_size).to(device=candidates_xy.device, dtype=torch.bool)
    visual_available = (
        presence
        & torch.isfinite(theta)
        & torch.isfinite(reliability)
        & reliability.ge(float(minimum_visual_reliability))
    )

    visual_selected, visual_accepted, visual_diagnostics = select_visual_temporal_pseudolabel(
        candidates_xy,
        radar_scores,
        visual_theta=theta[:, None],
        visual_reliability=reliability[:, None],
        previous_xy=previous_xy,
        minimum_visual_reliability=minimum_visual_reliability,
    )
    selected_visual_risk = candidate_background_risk.to(candidates_xy).gather(
        1, visual_selected[:, None]
    ).squeeze(1)
    visual_accepted = visual_accepted & selected_visual_risk.le(float(maximum_background_risk))
    visual_selected = torch.where(visual_accepted, visual_selected, torch.zeros_like(visual_selected))

    radar_selected, radar_accepted, radar_diagnostics = select_radar_temporal_pseudolabel(
        candidates_xy,
        radar_scores,
        candidate_ra_mti_agreement=candidate_ra_mti_agreement,
        candidate_background_risk=candidate_background_risk,
        candidate_persistence=candidate_persistence,
        previous_xy=previous_xy,
        predicted_xy=predicted_xy,
        maximum_background_risk=maximum_background_risk,
    )
    selected = torch.where(visual_available, visual_selected, radar_selected)
    accepted = torch.where(visual_available, visual_accepted, radar_accepted)
    selected = torch.where(accepted, selected, torch.zeros_like(selected))
    visual_used = visual_available & visual_accepted
    pseudo_source_id = torch.where(
        accepted,
        visual_used.to(dtype=torch.long),
        torch.full_like(selected, -1),
    )
    diagnostics = {
        "visual_available": visual_available,
        "visual_weak_label_used": visual_used,
        "pseudo_source_id": pseudo_source_id,
        "selected_background_risk": candidate_background_risk.to(candidates_xy).gather(
            1, selected[:, None]
        ).squeeze(1),
        "selected_angle_error_rad": visual_diagnostics["selected_angle_error_rad"],
        "selected_step_m": torch.where(
            visual_available,
            visual_diagnostics["selected_step_m"],
            radar_diagnostics["selected_step_m"],
        ),
        "selected_prediction_error_m": radar_diagnostics["selected_prediction_error_m"],
        "selected_persistence": radar_diagnostics["selected_persistence"],
        "selected_ra_mti_agreement": radar_diagnostics["selected_ra_mti_agreement"],
        "valid_radar_candidate_count": radar_diagnostics["valid_candidate_count"],
    }
    return selected, accepted, diagnostics


class CORACandidateExpert(nn.Module):
    """Small route expert with an exact identity initialization."""

    def __init__(self, *, token_dim: int, hidden_dim: int, top_k: int, attention_heads: int = 4) -> None:
        super().__init__()
        if token_dim < 1 or hidden_dim < 1 or top_k < 1:
            raise ValueError("token_dim, hidden_dim and top_k must be positive")
        if hidden_dim % attention_heads:
            raise ValueError("hidden_dim must be divisible by attention_heads")
        self.top_k = int(top_k)
        self.token_projection = nn.Sequential(
            nn.LayerNorm(token_dim),
            nn.Linear(token_dim, hidden_dim),
            nn.GELU(),
        )
        self.candidate_attention = nn.MultiheadAttention(
            embed_dim=hidden_dim,
            num_heads=attention_heads,
            batch_first=True,
        )
        self.residual_score = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        self.acceptance_head = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        self.identity_gate = nn.Parameter(torch.zeros(()))

    def forward(self, tokens: Tensor, base_scores: Tensor) -> dict[str, Tensor]:
        if tokens.ndim != 3 or tokens.shape[1] != self.top_k:
            raise ValueError(f"tokens must have shape [B,{self.top_k},D]")
        if base_scores.shape != tokens.shape[:2]:
            raise ValueError("base_scores must have shape [B,K]")
        embedded = self.token_projection(tokens)
        attended, _ = self.candidate_attention(embedded, embedded, embedded, need_weights=False)
        residual_scores = self.residual_score(attended).squeeze(-1)
        raw_acceptance = torch.sigmoid(self.acceptance_head(attended[:, 0]).squeeze(-1))
        gate = self.identity_gate.clamp(0.0, 1.0)
        acceptance = gate * raw_acceptance
        candidate_logits = base_scores + gate * residual_scores
        learned_index = candidate_logits.argmax(dim=1)
        selected_index = torch.where(acceptance.gt(0.0), learned_index, torch.zeros_like(learned_index))
        return {
            "candidate_logits": candidate_logits,
            "residual_scores": residual_scores,
            "selected_index": selected_index,
            "acceptance": acceptance,
            "identity_gate": gate.expand(tokens.shape[0]),
        }


def candidate_correctness_target(shadow_logits: Tensor, target_index: Tensor) -> tuple[Tensor, Tensor]:
    """Return the trainable gate target for a proposed non-base candidate.

    The gate is useful only when the frozen candidate branch proposes a
    non-base option.  A positive target therefore means that this exact
    intervention matches the label-free teacher target; seed availability
    alone is deliberately insufficient.
    """

    if shadow_logits.ndim != 2 or target_index.shape != (shadow_logits.shape[0],):
        raise ValueError("shadow_logits must be [B,K] and target_index must be [B]")
    learned_index = shadow_logits.argmax(dim=1)
    intervention = learned_index.ne(0)
    correctness = intervention & learned_index.eq(target_index)
    return correctness.to(dtype=shadow_logits.dtype), intervention


class CORARouteExpert(nn.Module):
    """Heterogeneous candidate scorer instantiated from the V4 expert library.

    ``shadow_logits`` are optimized in isolation.  The deployed outputs remain
    candidate zero until :meth:`promote` is called by the deterministic Safety
    Executor after label-free shadow validation.
    """

    _KINDS = {
        "local_refiner",
        "candidate_disambiguator",
        "path_integrator",
        "multi_hypothesis",
        "risk_recovery",
    }

    def __init__(
        self,
        *,
        kind: str,
        token_dim: int,
        hidden_dim: int,
        top_k: int,
        attention_heads: int = 4,
        independent_acceptance: bool = False,
        correctness_gate: bool = False,
        candidate_quality_dim: int = 0,
        runtime_quality_dim: int = 0,
        visual_acceptance_guard: bool = False,
    ) -> None:
        super().__init__()
        if kind not in self._KINDS:
            raise ValueError(f"unknown route expert kind: {kind!r}")
        if hidden_dim % attention_heads:
            raise ValueError("hidden_dim must be divisible by attention_heads")
        self.kind = kind
        self.top_k = int(top_k)
        self.independent_acceptance = bool(independent_acceptance)
        self.correctness_gate = bool(correctness_gate)
        self.candidate_quality_dim = int(candidate_quality_dim)
        self.runtime_quality_dim = int(runtime_quality_dim)
        self.visual_acceptance_guard = bool(visual_acceptance_guard)
        self.token_projection = nn.Sequential(nn.LayerNorm(token_dim), nn.Linear(token_dim, hidden_dim), nn.GELU())
        self.temporal = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.candidate_attention = nn.MultiheadAttention(hidden_dim, attention_heads, batch_first=True)
        self.local_fuse = nn.Sequential(
            nn.LayerNorm(hidden_dim * 2),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
        )
        self.score_head = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        self.acceptance_head = nn.Sequential(
            nn.LayerNorm(hidden_dim * 2),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        if self.correctness_gate:
            gate_dim = hidden_dim * 3 + self.candidate_quality_dim * 2 + self.runtime_quality_dim + 3
            self.correctness_gate_head = nn.Sequential(
                nn.LayerNorm(gate_dim),
                nn.Linear(gate_dim, hidden_dim),
                nn.GELU(),
                nn.Linear(hidden_dim, 1),
            )
        self.register_buffer("promotion_gate", torch.zeros(()))

    def promote(self) -> None:
        self.promotion_gate.fill_(1.0)

    def rollback(self) -> None:
        self.promotion_gate.zero_()

    def forward(
        self,
        history_tokens: Tensor,
        base_scores: Tensor,
        candidate_quality: Tensor | None = None,
        runtime_quality: Tensor | None = None,
    ) -> dict[str, Tensor]:
        if history_tokens.ndim != 4 or history_tokens.shape[2] != self.top_k:
            raise ValueError(f"history_tokens must have shape [B,T,{self.top_k},D]")
        if base_scores.shape != (history_tokens.shape[0], self.top_k):
            raise ValueError("base_scores must have shape [B,K]")
        batch, time_steps, candidates, _ = history_tokens.shape
        embedded = self.token_projection(history_tokens)
        current = embedded[:, -1]

        if self.kind in {"path_integrator", "multi_hypothesis", "risk_recovery", "local_refiner"}:
            temporal_input = embedded.permute(0, 2, 1, 3).reshape(batch * candidates, time_steps, -1)
            _, hidden = self.temporal(temporal_input)
            temporal_state = hidden[-1].reshape(batch, candidates, -1)
        else:
            temporal_state = current

        if self.kind in {"candidate_disambiguator", "multi_hypothesis", "risk_recovery"}:
            candidate_state, _ = self.candidate_attention(temporal_state, temporal_state, temporal_state, need_weights=False)
        elif self.kind == "local_refiner":
            base_state = temporal_state[:, 0:1].expand(-1, candidates, -1)
            candidate_state = self.local_fuse(torch.cat((temporal_state, base_state), dim=-1))
        else:
            candidate_state = temporal_state

        residual_scores = self.score_head(candidate_state).squeeze(-1)
        shadow_logits = base_scores + residual_scores
        shadow_probability = torch.softmax(shadow_logits, dim=1)
        confidence = shadow_probability.amax(dim=1)
        learned_index = shadow_logits.argmax(dim=1)
        if self.correctness_gate:
            if candidate_quality is None or candidate_quality.shape != (
                batch,
                candidates,
                self.candidate_quality_dim,
            ):
                raise ValueError("candidate_quality has an incompatible shape")
            if runtime_quality is None or runtime_quality.shape != (batch, self.runtime_quality_dim):
                raise ValueError("runtime_quality has an incompatible shape")
            gather_state = learned_index[:, None, None].expand(-1, 1, candidate_state.shape[-1])
            selected_state = candidate_state.gather(1, gather_state).squeeze(1)
            gather_quality = learned_index[:, None, None].expand(-1, 1, self.candidate_quality_dim)
            selected_quality = candidate_quality.to(candidate_state).gather(1, gather_quality).squeeze(1)
            top_probability = torch.topk(shadow_probability, k=min(2, candidates), dim=1).values
            margin = top_probability[:, 0] - (top_probability[:, 1] if candidates > 1 else 0.0)
            entropy = -(shadow_probability.clamp_min(1e-8) * shadow_probability.clamp_min(1e-8).log()).sum(dim=1)
            probability_quality = torch.stack((confidence, margin, entropy), dim=1)
            gate_feature = torch.cat(
                (
                    candidate_state[:, 0],
                    selected_state,
                    candidate_state.mean(dim=1),
                    candidate_quality[:, 0].to(candidate_state),
                    selected_quality,
                    runtime_quality.to(candidate_state),
                    probability_quality,
                ),
                dim=1,
            )
            acceptance_logit = self.correctness_gate_head(gate_feature).squeeze(-1)
            learned_acceptance = torch.sigmoid(acceptance_logit)
            if self.visual_acceptance_guard:
                learned_acceptance = learned_acceptance * runtime_quality[:, 0].to(learned_acceptance).clamp(0.0, 1.0)
        else:
            acceptance_feature = torch.cat((candidate_state[:, 0], candidate_state.mean(dim=1)), dim=-1)
            acceptance_logit = self.acceptance_head(acceptance_feature).squeeze(-1)
            learned_acceptance = torch.sigmoid(acceptance_logit)
            if self.kind != "risk_recovery" and not self.independent_acceptance:
                learned_acceptance = torch.maximum(learned_acceptance, confidence)

        gate = self.promotion_gate.to(dtype=history_tokens.dtype)
        acceptance = gate * learned_acceptance
        selected_index = torch.where(acceptance.gt(0.0), learned_index, torch.zeros_like(learned_index))
        return {
            "shadow_logits": shadow_logits,
            "shadow_probability": shadow_probability,
            "residual_scores": residual_scores,
            "learned_acceptance": learned_acceptance,
            "acceptance_logit": acceptance_logit,
            "selected_index": selected_index,
            "acceptance": acceptance,
            "identity_gate": gate.expand(batch),
        }


def candidate_batch_to_cpu(output: dict[str, Any]) -> dict[str, Any]:
    """Detach tensor outputs before writing a shadow-training cache."""

    return {
        key: value.detach().cpu() if isinstance(value, Tensor) else value
        for key, value in output.items()
    }
