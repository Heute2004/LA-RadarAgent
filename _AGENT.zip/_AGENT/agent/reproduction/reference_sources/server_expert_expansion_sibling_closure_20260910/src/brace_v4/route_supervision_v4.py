"""Causal track teachers for label-free V4 route supervision.

Every function in this module consumes only the frozen radar base trajectory up
to the current frame.  The resulting tracks may supervise shadow experts, but
Development coordinates must never enter this module or its callers.
"""

from __future__ import annotations

import numpy as np


def _track_xy(values: np.ndarray) -> np.ndarray:
    track = np.asarray(values, dtype=np.float64)
    if track.ndim != 2 or track.shape[1] != 2:
        raise ValueError("track must have shape [N,2]")
    if track.shape[0] == 0:
        raise ValueError("track must not be empty")
    if not np.all(np.isfinite(track)):
        raise ValueError("track must contain only finite coordinates")
    return track


def causal_ema_track(values: np.ndarray, *, alpha: float) -> np.ndarray:
    """Apply an exponential moving average without future-frame access."""

    track = _track_xy(values)
    if not 0.0 < float(alpha) <= 1.0:
        raise ValueError("alpha must be in (0,1]")
    result = np.empty_like(track)
    result[0] = track[0]
    for index in range(1, len(track)):
        result[index] = float(alpha) * track[index] + (1.0 - float(alpha)) * result[index - 1]
    return result.astype(np.float32)


def causal_trailing_median_track(values: np.ndarray, *, window: int) -> np.ndarray:
    """Use a trailing coordinate-wise median over current and past frames."""

    track = _track_xy(values)
    if int(window) < 1:
        raise ValueError("window must be positive")
    result = np.empty_like(track)
    for index in range(len(track)):
        start = max(0, index - int(window) + 1)
        result[index] = np.median(track[start : index + 1], axis=0)
    return result.astype(np.float32)


def bounded_track_correction(
    base_values: np.ndarray,
    proposed_values: np.ndarray,
    *,
    max_correction_m: float,
) -> np.ndarray:
    """Project each proposed correction onto a metric-radius safety ball."""

    base = _track_xy(base_values)
    proposed = _track_xy(proposed_values)
    if proposed.shape != base.shape:
        raise ValueError("base and proposed tracks must have the same shape")
    if float(max_correction_m) <= 0.0:
        raise ValueError("max_correction_m must be positive")
    delta = proposed - base
    norm = np.linalg.norm(delta, axis=1, keepdims=True)
    scale = np.minimum(1.0, float(max_correction_m) / np.maximum(norm, 1e-12))
    return (base + delta * scale).astype(np.float32)


def causal_alpha_beta_track(
    values: np.ndarray,
    *,
    alpha: float,
    beta: float,
    innovation_gate_m: float,
) -> np.ndarray:
    """Run a causal alpha-beta tracker with a norm-bounded innovation update."""

    track = _track_xy(values)
    if not 0.0 < float(alpha) <= 1.0:
        raise ValueError("alpha must be in (0,1]")
    if not 0.0 <= float(beta) <= 1.0:
        raise ValueError("beta must be in [0,1]")
    if float(innovation_gate_m) <= 0.0:
        raise ValueError("innovation_gate_m must be positive")

    result = np.empty_like(track)
    result[0] = track[0]
    velocity = np.zeros(2, dtype=np.float64)
    gate = float(innovation_gate_m)
    for index in range(1, len(track)):
        predicted = result[index - 1] + velocity
        innovation = track[index] - predicted
        norm = float(np.linalg.norm(innovation))
        if norm > gate:
            innovation *= gate / max(norm, 1e-12)
        result[index] = predicted + float(alpha) * innovation
        velocity = velocity + float(beta) * innovation
    return result.astype(np.float32)


def causal_reset_alpha_beta_track(
    values: np.ndarray,
    *,
    alpha: float,
    beta: float,
    innovation_gate_m: float,
    reset_velocity: str = "zero",
) -> np.ndarray:
    """Alpha-beta update that resets to measurement on implausible innovation.

    Resetting prevents a clipped innovation from accumulating a fictitious
    velocity over several frames.  It is still fully causal and preserves a
    hard radar measurement fallback.
    """

    track = _track_xy(values)
    if not 0.0 < float(alpha) <= 1.0:
        raise ValueError("alpha must be in (0,1]")
    if not 0.0 <= float(beta) <= 1.0:
        raise ValueError("beta must be in [0,1]")
    if float(innovation_gate_m) <= 0.0:
        raise ValueError("innovation_gate_m must be positive")
    if reset_velocity not in {"zero", "measurement"}:
        raise ValueError("reset_velocity must be 'zero' or 'measurement'")

    result = np.empty_like(track)
    result[0] = track[0]
    velocity = np.zeros(2, dtype=np.float64)
    for index in range(1, len(track)):
        predicted = result[index - 1] + velocity
        innovation = track[index] - predicted
        if float(np.linalg.norm(innovation)) > float(innovation_gate_m):
            result[index] = track[index]
            velocity = (
                track[index] - track[index - 1]
                if reset_velocity == "measurement"
                else np.zeros(2, dtype=np.float64)
            )
            continue
        result[index] = predicted + float(alpha) * innovation
        velocity = velocity + float(beta) * innovation
    return result.astype(np.float32)


def route_teacher_track(route: str, values: np.ndarray) -> np.ndarray:
    """Apply the frozen initial V4 teacher hypothesis for a scene route."""

    normalized = str(route).strip().lower()
    if normalized == "corner_nlos_ris":
        return bounded_track_correction(
            values,
            causal_ema_track(values, alpha=0.1),
            max_correction_m=0.5,
        )
    if normalized == "open_indoor_los":
        return bounded_track_correction(
            values,
            causal_ema_track(values, alpha=0.5),
            max_correction_m=0.3,
        )
    if normalized == "outdoor_dry_complex":
        return causal_trailing_median_track(values, window=5)
    if normalized == "outdoor_wet_return":
        return causal_reset_alpha_beta_track(
            values,
            alpha=0.7,
            beta=0.1,
            innovation_gate_m=0.3,
            reset_velocity="zero",
        )
    raise ValueError(f"no causal track teacher is defined for route={route!r}")


def hybrid_causal_seed_track(
    route: str,
    base_values: np.ndarray,
    *,
    seed_xy_m: np.ndarray,
    seed_mask: np.ndarray,
    maximum_seed_delta_m: float | None,
) -> tuple[np.ndarray, np.ndarray]:
    """Overlay current-frame high-confidence visual/radar seeds on a causal track.

    Both inputs are label-free runtime evidence.  The optional metric gate is
    measured against the causal radar fallback and therefore cannot read a
    future frame or a human coordinate.
    """

    base = _track_xy(base_values)
    seed = _track_xy(seed_xy_m)
    mask = np.asarray(seed_mask, dtype=np.bool_)
    if seed.shape != base.shape or mask.shape != (len(base),):
        raise ValueError("seed track and mask must match the base track")
    fallback = route_teacher_track(route, base)
    used = mask.copy()
    if maximum_seed_delta_m is not None:
        if float(maximum_seed_delta_m) <= 0.0:
            raise ValueError("maximum_seed_delta_m must be positive")
        used &= np.linalg.norm(seed - fallback, axis=1) <= float(maximum_seed_delta_m)
    hybrid = np.where(used[:, None], seed, fallback)
    return hybrid.astype(np.float32), used
