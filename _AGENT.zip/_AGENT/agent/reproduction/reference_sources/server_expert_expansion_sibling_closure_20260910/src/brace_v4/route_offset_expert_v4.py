"""Continuous causal offset expert for V4 label-free route adaptation."""

from __future__ import annotations

import torch
from torch import Tensor, nn


class CausalOffsetRouteExpert(nn.Module):
    """Predict a bounded metric correction while retaining exact identity.

    The expert reads only causal candidate-token history and the frozen base
    trajectory.  Shadow outputs are always available for audit; deployment
    outputs remain bitwise equal to the base until the Safety Executor calls
    :meth:`promote`.
    """

    def __init__(
        self,
        *,
        token_dim: int,
        hidden_dim: int,
        top_k: int,
        max_offset_m: float,
    ) -> None:
        super().__init__()
        if token_dim < 1 or hidden_dim < 1 or top_k < 1:
            raise ValueError("token_dim, hidden_dim and top_k must be positive")
        if max_offset_m <= 0.0:
            raise ValueError("max_offset_m must be positive")
        self.top_k = int(top_k)
        self.max_offset_m = float(max_offset_m)
        frame_dim = 2 * int(token_dim) + 4
        self.frame_projection = nn.Sequential(
            nn.LayerNorm(frame_dim),
            nn.Linear(frame_dim, hidden_dim),
            nn.GELU(),
        )
        self.temporal = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.offset_head = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 2),
        )
        self.acceptance_head = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim // 2 if hidden_dim >= 2 else 1),
            nn.GELU(),
            nn.Linear(hidden_dim // 2 if hidden_dim >= 2 else 1, 1),
        )
        self.uncertainty_head = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, 2),
        )
        nn.init.zeros_(self.offset_head[-1].weight)
        nn.init.zeros_(self.offset_head[-1].bias)
        self.register_buffer("promotion_gate", torch.zeros(()))

    def promote(self) -> None:
        self.promotion_gate.fill_(1.0)

    def rollback(self) -> None:
        self.promotion_gate.zero_()

    def forward(self, history_tokens: Tensor, history_base_xy: Tensor) -> dict[str, Tensor]:
        if history_tokens.ndim != 4 or history_tokens.shape[2] != self.top_k:
            raise ValueError(f"history_tokens must have shape [B,T,{self.top_k},D]")
        if history_base_xy.shape != history_tokens.shape[:2] + (2,):
            raise ValueError("history_base_xy must have shape [B,T,2]")
        base_token = history_tokens[:, :, 0]
        pooled_token = history_tokens.mean(dim=2)
        normalized_xy = torch.stack(
            (history_base_xy[..., 0] / 10.0, history_base_xy[..., 1] / 23.4),
            dim=-1,
        )
        velocity = torch.diff(history_base_xy, dim=1, prepend=history_base_xy[:, :1])
        normalized_velocity = velocity / 1.0
        frame_feature = torch.cat(
            (base_token, pooled_token, normalized_xy, normalized_velocity),
            dim=-1,
        )
        encoded = self.frame_projection(frame_feature)
        _, state = self.temporal(encoded)
        state = state[-1]

        raw_offset = torch.tanh(self.offset_head(state))
        raw_norm = torch.linalg.vector_norm(raw_offset, dim=-1, keepdim=True).clamp_min(1e-6)
        unit_bounded = raw_offset / torch.maximum(raw_norm, torch.ones_like(raw_norm))
        shadow_offset = self.max_offset_m * unit_bounded
        acceptance = torch.sigmoid(self.acceptance_head(state).squeeze(-1))
        log_std = self.uncertainty_head(state).clamp(-4.0, 2.0)
        covariance = torch.diag_embed(torch.exp(2.0 * log_std))
        base_xy = history_base_xy[:, -1]
        shadow_xy = base_xy + shadow_offset
        gate = self.promotion_gate.to(dtype=base_xy.dtype)
        final_xy = base_xy + gate * acceptance[:, None] * shadow_offset
        return {
            "shadow_offset_xy": shadow_offset,
            "shadow_xy": shadow_xy,
            "learned_acceptance": acceptance,
            "covariance": covariance,
            "final_xy": final_xy,
            "identity_gate": gate.expand(base_xy.shape[0]),
        }
