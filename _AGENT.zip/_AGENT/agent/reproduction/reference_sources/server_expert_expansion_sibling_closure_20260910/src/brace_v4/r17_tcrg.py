"""Causal reachability-graph association over measured radar candidates.

R17 is deliberately a candidate-state model rather than a coordinate regressor.
Candidate zero denotes the frozen CORA-SE2 identity output.  It is evaluated as
an action but is excluded from all graph transitions, so the fallback cannot
silently bridge two unrelated measured peaks.
"""

from __future__ import annotations

import math

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional


R17_ARCHITECTURE = "CORA-SE2-TCRG-PhysicalCandidateAssociationExpert-V1"


def declared_identity_score(record: dict[str, np.ndarray], identity_branch: str) -> np.ndarray:
    """Return the score of the exact branch used as candidate-zero fallback.

    TCRG changes coordinates only. Its AP ranking must therefore inherit the
    declared frozen fallback score, rather than silently using SE2 when the
    identity action is CORA0 or SE1.
    """

    branch = str(identity_branch).strip().lower()
    if branch not in {"cora0", "se1", "se2"}:
        raise ValueError("identity branch is invalid")
    score = np.asarray(record[f"{branch}_peak_score"], dtype=np.float32)
    frame_count = int(np.asarray(record["frame_id"]).size)
    if score.shape != (frame_count,) or not np.isfinite(score).all():
        raise ValueError("identity score must be finite and align with runtime frames")
    return score.copy()


def select_identity_safe_candidates(
    identity_xy_m: np.ndarray,
    proposal_xy_m: np.ndarray,
    selected_candidate_index: np.ndarray,
    benefit_probability: np.ndarray,
    *,
    threshold: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Return exact identity unless a nonzero measured candidate clears the gate."""

    if not 0.0 <= float(threshold) <= 1.0:
        raise ValueError("threshold must lie in [0, 1]")
    identity = np.asarray(identity_xy_m, dtype=np.float32)
    proposal = np.asarray(proposal_xy_m, dtype=np.float32)
    selected = np.asarray(selected_candidate_index, dtype=np.int64).reshape(-1)
    benefit = np.asarray(benefit_probability, dtype=np.float32).reshape(-1)
    if identity.ndim != 2 or identity.shape[1:] != (2,) or proposal.shape != identity.shape:
        raise ValueError("identity and proposal coordinates must be [frames, 2]")
    if selected.shape != benefit.shape or selected.shape != identity.shape[:1]:
        raise ValueError("candidate selection and benefit must share the frame axis")
    accepted = (selected != 0) & np.isfinite(benefit) & (benefit >= float(threshold)) & np.isfinite(proposal).all(axis=1)
    output = identity.copy()
    output[accepted] = proposal[accepted]
    return output, accepted


class CausalReachabilityCandidateGraph(nn.Module):
    """Score current measured candidates using causal, reachable graph state."""

    def __init__(
        self,
        *,
        candidate_count: int,
        token_dim: int = 8,
        hidden_dim: int = 96,
        maximum_step_m: float = 0.30,
        transition_temperature_m: float = 0.08,
    ) -> None:
        super().__init__()
        if candidate_count < 2 or token_dim < 1 or hidden_dim < 8:
            raise ValueError("candidate_count, token_dim, and hidden_dim are invalid")
        if maximum_step_m <= 0.0 or transition_temperature_m <= 0.0:
            raise ValueError("physical transition scales must be positive")
        self.candidate_count = int(candidate_count)
        self.token_dim = int(token_dim)
        self.hidden_dim = int(hidden_dim)
        self.maximum_step_m = float(maximum_step_m)
        self.transition_temperature_m = float(transition_temperature_m)
        attention_heads = 4 if hidden_dim % 4 == 0 else 1
        self.type_embedding = nn.Embedding(candidate_count, 8)
        self.token_encoder = nn.Sequential(
            nn.Linear(token_dim + 12, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.global_projection = nn.Sequential(nn.Linear(8, hidden_dim), nn.SiLU(inplace=True))
        self.candidate_attention = nn.MultiheadAttention(hidden_dim, attention_heads, batch_first=True)
        self.candidate_norm = nn.LayerNorm(hidden_dim)
        self.state_cell = nn.GRUCell(hidden_dim, hidden_dim)
        self.candidate_head = nn.Linear(hidden_dim, 1)
        self.benefit_head = nn.Sequential(
            nn.Linear(hidden_dim + 4, hidden_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )
        nn.init.zeros_(self.candidate_head.weight)
        nn.init.zeros_(self.candidate_head.bias)
        nn.init.zeros_(self.benefit_head[-1].weight)
        nn.init.zeros_(self.benefit_head[-1].bias)

    def _validate(
        self,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
    ) -> tuple[int, int, int]:
        if candidate_token.ndim != 4 or candidate_token.shape[-1] != self.token_dim:
            raise ValueError("candidate_token must be [batch,time,candidates,token_dim]")
        batch, steps, candidates = candidate_token.shape[:3]
        if candidates != self.candidate_count:
            raise ValueError("candidate count does not match model configuration")
        if candidate_xy_m.shape != (batch, steps, candidates, 2):
            raise ValueError("candidate_xy_m must align with candidate_token")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [batch,time,candidates]")
        if candidate_unary_logits.shape != (batch, steps, candidates):
            raise ValueError("candidate_unary_logits must align with candidates")
        if global_state.shape != (batch, steps, 8):
            raise ValueError("global_state must be [batch,time,8]")
        if not bool(candidate_valid[..., 0].all()) or not bool(torch.isfinite(candidate_xy_m[..., 0, :]).all()):
            raise ValueError("candidate zero must remain finite and valid in every frame")
        return batch, steps, candidates

    def _transition(
        self,
        previous_xy_m: Tensor,
        current_xy_m: Tensor,
        previous_hidden: Tensor,
        previous_valid: Tensor,
        current_valid: Tensor,
    ) -> tuple[Tensor, Tensor]:
        """Transport state only across non-identity, physically reachable edges."""

        distance = torch.cdist(current_xy_m.float(), previous_xy_m.float())
        current_measured = current_valid.clone()
        previous_measured = previous_valid.clone()
        current_measured[:, 0] = False
        previous_measured[:, 0] = False
        edge = (
            current_measured[:, :, None]
            & previous_measured[:, None, :]
            & torch.isfinite(distance)
            & (distance <= self.maximum_step_m + 1.0e-9)
        )
        reachable = edge.any(dim=-1)
        transition_logits = (-distance / self.transition_temperature_m).masked_fill(~edge, -1.0e4)
        weight = torch.softmax(transition_logits, dim=-1)
        weight = torch.where(reachable[:, :, None], weight, torch.zeros_like(weight))
        transported = torch.bmm(weight.to(previous_hidden.dtype), previous_hidden)
        return transported, edge

    def forward(
        self,
        *,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
    ) -> dict[str, Tensor]:
        batch, steps, candidates = self._validate(
            candidate_token,
            candidate_xy_m,
            candidate_valid,
            candidate_unary_logits,
            global_state,
        )
        valid = candidate_valid & torch.isfinite(candidate_xy_m).all(dim=-1)
        type_id = torch.arange(candidates, device=candidate_token.device).view(1, 1, candidates)
        type_feature = self.type_embedding(type_id.expand(batch, steps, -1))
        offset = candidate_xy_m - candidate_xy_m[..., :1, :]
        geometry = torch.cat((offset / 4.0, torch.linalg.vector_norm(offset, dim=-1, keepdim=True) / 4.0), dim=-1)
        token = self.token_encoder(torch.cat((candidate_token.float(), candidate_unary_logits[..., None].float(), geometry.float(), type_feature), dim=-1))
        token = token + self.global_projection(global_state.float())[:, :, None, :]
        flat_token = token.reshape(batch * steps, candidates, self.hidden_dim)
        flat_valid = valid.reshape(batch * steps, candidates)
        attended, _ = self.candidate_attention(flat_token, flat_token, flat_token, key_padding_mask=~flat_valid, need_weights=False)
        token = self.candidate_norm(flat_token + attended).reshape(batch, steps, candidates, self.hidden_dim)

        previous_hidden = torch.zeros(batch, candidates, self.hidden_dim, device=token.device, dtype=token.dtype)
        previous_xy = candidate_xy_m[:, 0]
        previous_valid = valid[:, 0]
        hidden_history: list[Tensor] = []
        transition_history: list[Tensor] = []
        for index in range(steps):
            if index == 0:
                transported = torch.zeros_like(previous_hidden)
                transition = torch.zeros(batch, candidates, candidates, device=token.device, dtype=torch.bool)
            else:
                transported, transition = self._transition(
                    previous_xy,
                    candidate_xy_m[:, index],
                    previous_hidden,
                    previous_valid,
                    valid[:, index],
                )
            hidden = self.state_cell(
                token[:, index].reshape(batch * candidates, self.hidden_dim),
                transported.reshape(batch * candidates, self.hidden_dim),
            ).reshape(batch, candidates, self.hidden_dim)
            hidden = hidden.masked_fill(~valid[:, index, :, None], 0.0)
            hidden_history.append(hidden)
            transition_history.append(transition)
            previous_hidden, previous_xy, previous_valid = hidden, candidate_xy_m[:, index], valid[:, index]

        hidden = torch.stack(hidden_history, dim=1)
        candidate_logits = self.candidate_head(hidden).squeeze(-1) + candidate_unary_logits.float()
        candidate_logits = candidate_logits.masked_fill(~valid, -1.0e4)
        probability = torch.softmax(candidate_logits, dim=-1)
        selected = probability.argmax(dim=-1)
        batch_index = torch.arange(batch, device=token.device)[:, None]
        time_index = torch.arange(steps, device=token.device)[None, :]
        proposal = candidate_xy_m[batch_index, time_index, selected]
        selected_state = (probability[..., None] * hidden).sum(dim=2)
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1) / math.log(float(candidates))
        top2 = probability.topk(2, dim=-1).values
        margin = top2[..., 0] - top2[..., 1]
        non_identity = 1.0 - probability[..., 0]
        correction = torch.linalg.vector_norm(proposal - candidate_xy_m[..., 0, :], dim=-1)
        benefit_logit = self.benefit_head(
            torch.cat((selected_state, entropy[..., None], margin[..., None], non_identity[..., None], correction[..., None] / 4.0), dim=-1)
        ).squeeze(-1)
        return {
            "candidate_logits": candidate_logits,
            "candidate_probability": probability,
            "selected_candidate_index": selected,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "transition_valid": torch.stack(transition_history, dim=1),
            "posterior_entropy": entropy,
            "posterior_margin": margin,
        }


def r17_weighted_association_loss(
    output: dict[str, Tensor],
    target_weight: Tensor,
    sample_weight: Tensor,
    *,
    candidate_loss_weight: float = 1.0,
    benefit_loss_weight: float = 0.25,
) -> tuple[Tensor, dict[str, Tensor]]:
    """Train from a measured-candidate teacher without creating new coordinates."""

    logits = output["candidate_logits"]
    if target_weight.shape != logits.shape or sample_weight.shape != logits.shape[:2]:
        raise ValueError("R17 targets must align with candidate logits")
    weight = sample_weight.float().clamp_min(0.0)
    denominator = weight.sum().clamp_min(1.0e-6)
    candidate_nll = -((target_weight.float() * functional.log_softmax(logits, dim=-1)).sum(dim=-1) * weight).sum() / denominator
    target_benefit = (target_weight[..., 1:].sum(dim=-1) > target_weight[..., 0]).float()
    benefit_bce = (functional.binary_cross_entropy_with_logits(output["benefit_logit"], target_benefit, reduction="none") * weight).sum() / denominator
    total = float(candidate_loss_weight) * candidate_nll + float(benefit_loss_weight) * benefit_bce
    return total, {"candidate_nll": candidate_nll.detach(), "benefit_bce": benefit_bce.detach()}
