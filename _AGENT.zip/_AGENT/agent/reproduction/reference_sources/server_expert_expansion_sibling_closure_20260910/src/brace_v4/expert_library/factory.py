"""The only factory exposed to BRACE-V4 for verified CPB-ConvLSTM route experts."""

from __future__ import annotations

from collections.abc import Callable

from torch import nn

from .catalog import card_by_identifier
from .cpb_convlstm.models.convlstm_expert_wrappers import (
    ConvLSTME3RouteExpertBEV,
    ConvLSTMHeterogeneousExpertBEV,
    ConvLSTMPBMHBRStage1BEV,
    ConvLSTMTECSEchoExpertBEV,
)


_FACTORIES: dict[str, Callable[[], nn.Module]] = {
    "clor": ConvLSTMHeterogeneousExpertBEV,
    "tecs": ConvLSTMTECSEchoExpertBEV,
    "ltge": lambda: ConvLSTME3RouteExpertBEV(expert_kind="ltge"),
    "pb_mhbr_stage1": ConvLSTMPBMHBRStage1BEV,
    "gg_srre": lambda: ConvLSTME3RouteExpertBEV(expert_kind="gg_srre"),
}


def build_verified_cpb_expert(identifier: str) -> nn.Module:
    """Build a frozen-backbone CPB expert without exposing legacy DREAM/Mamba wrappers."""
    card = card_by_identifier(identifier)
    if card.status not in {"verified", "identity_only"}:
        raise ValueError(f"{identifier} is research-only and cannot be instantiated")
    try:
        return _FACTORIES[identifier]()
    except KeyError as error:
        raise ValueError(f"No CPB factory registered for {identifier}") from error
