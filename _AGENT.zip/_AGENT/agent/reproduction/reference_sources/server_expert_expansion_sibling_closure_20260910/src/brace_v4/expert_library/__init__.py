"""Semantic registry and CPB-ConvLSTM expert implementations for BRACE-V4."""

from .catalog import RESEARCH_CANDIDATES, VERIFIED_CPB_EXPERTS, VERIFIED_SAFETY_TOOLS, ExpertSemanticCard
from .factory import build_verified_cpb_expert

__all__ = [
    "ExpertSemanticCard",
    "RESEARCH_CANDIDATES",
    "VERIFIED_CPB_EXPERTS",
    "VERIFIED_SAFETY_TOOLS",
    "build_verified_cpb_expert",
]
