"""Temporal candidate-branch association for indoor radar clutter.

TCBAV operates on measured RA/RA-MTI candidates.  It carries candidate states
through a metric-bounded causal graph, predicts a physical branch, and exposes a
benefit score for an identity-safe segment gate.  It never regresses a free BEV
coordinate.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional


ROUTE = "indoor_clutter"
ARCHITECTURE = "R7-TCBAV-Temporal-Candidate-Branch-Association-V1"


def freeze_continuous_physical_policy(
    checkpoint: dict[str, Any],
    *,
    source_checkpoint_sha256: str,
) -> dict[str, Any]:
    """Freeze the Development-selected continuous physical-branch policy.

    The learned association network remains unchanged.  Only its runtime
    acceptance policy is replaced by the audited causal continuity contract.
    The lineage fields deliberately record that Development informed this
    policy choice, while neither model fitting nor threshold fitting used it.
    """

    if checkpoint.get("schema_version") != "r7_tcbav_indoor_clutter_checkpoint_v1":
        raise ValueError("unexpected TCBAV checkpoint schema")
    if checkpoint.get("architecture") != ARCHITECTURE or checkpoint.get("route") != ROUTE:
        raise ValueError("TCBAV checkpoint architecture or route mismatch")
    if checkpoint.get("target_final_bev_read") or checkpoint.get("locked_test_read"):
        raise ValueError("cannot freeze a checkpoint that read forbidden labels or Locked Test")
    if not source_checkpoint_sha256:
        raise ValueError("source checkpoint SHA256 is required")

    frozen = dict(checkpoint)
    frozen["calibration"] = {
        "high_threshold": 0.0,
        "hold_threshold": 0.0,
        "minimum_run": 1,
        "release_run": 999,
        "source": "development_selected_continuous_physical_association",
    }
    frozen.update(
        {
            "runtime_policy": "TCBAV-C-continuous-physical-branch-association-v1",
            "source_checkpoint_sha256": str(source_checkpoint_sha256),
            "development_read": True,
            "development_informed_variant_selection": True,
            "development_used_for_architecture_variant_selection": True,
            "development_used_for_training_or_threshold_selection": False,
            "locked_test_read": False,
        }
    )
    return frozen


def transport_previous_hidden(
    previous_xy_m: Tensor,
    current_xy_m: Tensor,
    previous_hidden: Tensor,
    previous_valid: Tensor,
    current_valid: Tensor,
    *,
    maximum_step_m: float = 0.30,
    temperature_m: float = 0.08,
) -> tuple[Tensor, Tensor]:
    """Transport previous candidate state over physically reachable graph edges."""

    if maximum_step_m <= 0.0 or temperature_m <= 0.0:
        raise ValueError("association distances must be positive")
    if previous_xy_m.ndim != 3 or previous_xy_m.shape[-1] != 2:
        raise ValueError("previous_xy_m must be [batch,candidates,2]")
    if current_xy_m.shape != previous_xy_m.shape:
        raise ValueError("current and previous candidate coordinates must align")
    if previous_hidden.shape[:2] != previous_xy_m.shape[:2]:
        raise ValueError("previous hidden state must align with previous candidates")
    if previous_valid.shape != previous_xy_m.shape[:2] or current_valid.shape != previous_valid.shape:
        raise ValueError("candidate validity masks must align")

    distance = torch.cdist(current_xy_m.float(), previous_xy_m.float())
    edge_valid = (
        current_valid[:, :, None]
        & previous_valid[:, None, :]
        & torch.isfinite(distance)
        & (distance <= float(maximum_step_m) + 1e-9)
    )
    reachable = edge_valid.any(dim=-1)
    score = (-distance / float(temperature_m)).masked_fill(~edge_valid, -1e4)
    weight = torch.softmax(score, dim=-1)
    weight = torch.where(reachable[:, :, None], weight, torch.zeros_like(weight))
    transported = torch.bmm(weight.to(previous_hidden.dtype), previous_hidden)
    return transported, reachable


class TemporalCandidateBranchAssociationVerifier(nn.Module):
    """Causal candidate graph with branch posterior and benefit verification."""

    def __init__(
        self,
        *,
        token_dim: int = 80,
        hidden_dim: int = 96,
        candidate_count: int = 10,
        maximum_step_m: float = 0.30,
        association_temperature_m: float = 0.08,
    ) -> None:
        super().__init__()
        if token_dim < 1 or hidden_dim < 8 or candidate_count < 2:
            raise ValueError("invalid TCBAV dimensions")
        if hidden_dim % 4:
            raise ValueError("hidden_dim must be divisible by four")
        self.token_dim = int(token_dim)
        self.hidden_dim = int(hidden_dim)
        self.candidate_count = int(candidate_count)
        self.maximum_step_m = float(maximum_step_m)
        self.association_temperature_m = float(association_temperature_m)
        self.type_embedding = nn.Embedding(candidate_count, 8)
        self.token_projection = nn.Sequential(
            nn.Linear(token_dim + 12, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.candidate_attention = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)
        self.candidate_norm = nn.LayerNorm(hidden_dim)
        self.recurrent = nn.GRUCell(hidden_dim, hidden_dim)
        self.score_head = nn.Sequential(
            nn.Linear(hidden_dim + 1, hidden_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )
        self.benefit_head = nn.Sequential(
            nn.Linear(hidden_dim + 7, hidden_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )

    def _validate(
        self,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        base_xy_m: Tensor,
        global_state: Tensor,
    ) -> tuple[int, int, int]:
        if candidate_token.ndim != 4 or candidate_token.shape[-1] != self.token_dim:
            raise ValueError("candidate_token must be [batch,time,candidates,token_dim]")
        batch, time, count = candidate_token.shape[:3]
        if count != self.candidate_count:
            raise ValueError("candidate count does not match the configured TCBAV")
        if candidate_xy_m.shape != (batch, time, count, 2):
            raise ValueError("candidate_xy_m has an invalid shape")
        if candidate_valid.shape != (batch, time, count):
            raise ValueError("candidate_valid has an invalid shape")
        if candidate_unary_logits.shape != (batch, time, count):
            raise ValueError("candidate_unary_logits has an invalid shape")
        if base_xy_m.shape != (batch, time, 2):
            raise ValueError("base_xy_m has an invalid shape")
        if global_state.ndim != 3 or global_state.shape[:2] != (batch, time):
            raise ValueError("global_state must be [batch,time,features]")
        return batch, time, count

    def forward(
        self,
        *,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        base_xy_m: Tensor,
        global_state: Tensor,
    ) -> dict[str, Tensor]:
        batch, time, count = self._validate(
            candidate_token,
            candidate_xy_m,
            candidate_valid,
            candidate_unary_logits,
            base_xy_m,
            global_state,
        )
        valid = candidate_valid.bool() & torch.isfinite(candidate_xy_m).all(dim=-1)
        delta = candidate_xy_m - base_xy_m[:, :, None]
        distance_base = delta.norm(dim=-1, keepdim=True)
        type_ids = torch.arange(count, device=candidate_token.device).view(1, 1, count).expand(batch, time, -1)
        type_embedding = self.type_embedding(type_ids)
        unary = candidate_unary_logits.unsqueeze(-1)
        geometry = torch.cat(
            (
                delta / torch.tensor((2.0, 2.0), device=delta.device, dtype=delta.dtype),
                distance_base / 2.0,
            ),
            dim=-1,
        )
        token = self.token_projection(torch.cat((candidate_token.float(), unary.float(), geometry.float(), type_embedding), dim=-1))

        flattened_token = token.reshape(batch * time, count, self.hidden_dim)
        flattened_valid = valid.reshape(batch * time, count)
        attended, _ = self.candidate_attention(
            flattened_token,
            flattened_token,
            flattened_token,
            key_padding_mask=~flattened_valid,
            need_weights=False,
        )
        token = self.candidate_norm(flattened_token + attended).reshape(
            batch, time, count, self.hidden_dim
        )

        hidden_history: list[Tensor] = []
        reachable_history: list[Tensor] = []
        previous_hidden = torch.zeros(batch, count, self.hidden_dim, device=token.device, dtype=token.dtype)
        previous_xy = candidate_xy_m[:, 0]
        previous_valid = valid[:, 0]
        for index in range(time):
            current = token[:, index]
            if index == 0:
                transported = torch.zeros_like(previous_hidden)
                reachable = valid[:, index]
            else:
                transported, reachable = transport_previous_hidden(
                    previous_xy,
                    candidate_xy_m[:, index],
                    previous_hidden,
                    previous_valid,
                    valid[:, index],
                    maximum_step_m=self.maximum_step_m,
                    temperature_m=self.association_temperature_m,
                )
            current_hidden = self.recurrent(
                current.reshape(batch * count, self.hidden_dim),
                transported.reshape(batch * count, self.hidden_dim),
            ).reshape(batch, count, self.hidden_dim)
            current_hidden = current_hidden.masked_fill(~valid[:, index, :, None], 0.0)
            hidden_history.append(current_hidden)
            reachable_history.append(reachable)
            previous_hidden = current_hidden
            previous_xy = candidate_xy_m[:, index]
            previous_valid = valid[:, index]

        hidden = torch.stack(hidden_history, dim=1)
        logits = self.score_head(
            torch.cat((hidden, candidate_unary_logits[..., None].float()), dim=-1)
        ).squeeze(-1)
        logits = logits.masked_fill(~valid, -1e4)
        probability = torch.softmax(logits, dim=-1)
        selected_index = probability.argmax(dim=-1)
        rows = torch.arange(batch, device=token.device)[:, None]
        times = torch.arange(time, device=token.device)[None, :]
        proposal = candidate_xy_m[rows, times, selected_index]
        selected_state = (probability[..., None] * hidden).sum(dim=2)
        entropy = -(probability * probability.clamp_min(1e-8).log()).sum(dim=-1) / math.log(float(count))
        top2 = probability.topk(2, dim=-1).values
        margin = top2[..., 0] - top2[..., 1]
        non_identity = 1.0 - probability[..., 0]
        correction = (proposal - base_xy_m).norm(dim=-1)
        global_summary = torch.stack(
            (
                global_state.float().mean(dim=-1),
                global_state.float().std(dim=-1, unbiased=False),
                global_state.float().abs().amax(dim=-1),
            ),
            dim=-1,
        )
        benefit_features = torch.cat(
            (
                selected_state,
                entropy[..., None],
                margin[..., None],
                non_identity[..., None],
                correction[..., None],
                global_summary,
            ),
            dim=-1,
        )
        benefit_logit = self.benefit_head(benefit_features).squeeze(-1)
        return {
            "candidate_logits": logits,
            "candidate_probability": probability,
            "candidate_xy_m": candidate_xy_m,
            "selected_candidate_index": selected_index,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "posterior_entropy": entropy,
            "posterior_margin": margin,
            "non_identity_probability": non_identity,
            "reachable": torch.stack(reachable_history, dim=1),
            "candidate_hidden": hidden,
        }


def soft_candidate_branch_loss(
    output: dict[str, Tensor],
    target_posterior: Tensor,
    candidate_valid: Tensor,
    supervision_weight: Tensor,
    *,
    continuity_weight: float = 0.20,
    benefit_weight: float = 0.25,
) -> tuple[Tensor, dict[str, Tensor]]:
    """R7 soft association objective with reachable-path regularization."""

    logits = output["candidate_logits"]
    if target_posterior.shape != logits.shape or candidate_valid.shape != logits.shape:
        raise ValueError("target posterior and validity must match candidate logits")
    if supervision_weight.shape != logits.shape[:2]:
        raise ValueError("supervision_weight must be [batch,time]")
    target = target_posterior.float() * candidate_valid.to(target_posterior.dtype)
    target = target / target.sum(dim=-1, keepdim=True).clamp_min(1e-8)
    candidate_ce = -(target * logits.log_softmax(dim=-1)).sum(dim=-1)
    benefit_target = (1.0 - target[..., 0]).clamp(0.0, 1.0)
    benefit_bce = functional.binary_cross_entropy_with_logits(
        output["benefit_logit"], benefit_target, reduction="none"
    )

    probability = output["candidate_probability"]
    xy = output["candidate_xy_m"]
    if probability.shape[1] > 1:
        distance = torch.cdist(
            xy[:, 1:].reshape(-1, xy.shape[2], 2).float(),
            xy[:, :-1].reshape(-1, xy.shape[2], 2).float(),
        ).reshape(xy.shape[0], xy.shape[1] - 1, xy.shape[2], xy.shape[2])
        reachable = (distance <= 0.30 + 1e-9).to(probability.dtype)
        transported_mass = torch.einsum(
            "btij,btj->bti", reachable, probability[:, :-1]
        ).clamp(max=1.0)
        unreachable_mass = (probability[:, 1:] * (1.0 - transported_mass)).sum(dim=-1)
        continuity = torch.cat((torch.zeros_like(unreachable_mass[:, :1]), unreachable_mass), dim=1)
    else:
        continuity = torch.zeros_like(candidate_ce)
    weight = supervision_weight.float().clamp_min(0.0)
    per_frame = candidate_ce + float(benefit_weight) * benefit_bce + float(continuity_weight) * continuity
    loss = (weight * per_frame).sum() / weight.sum().clamp_min(1e-8)
    return loss, {
        "candidate_ce": candidate_ce.detach(),
        "benefit_bce": benefit_bce.detach(),
        "continuity": continuity.detach(),
    }


def causal_segment_hysteresis(
    probability: np.ndarray,
    continuity_valid: np.ndarray,
    *,
    high_threshold: float,
    hold_threshold: float,
    minimum_run: int,
    release_run: int,
) -> np.ndarray:
    """Apply a causal, non-backfilling segment gate."""

    score = np.asarray(probability, dtype=np.float32).reshape(-1)
    valid = np.asarray(continuity_valid, dtype=np.bool_).reshape(-1)
    if score.shape != valid.shape:
        raise ValueError("probability and continuity mask must align")
    if not 0.0 <= hold_threshold <= high_threshold <= 1.0:
        raise ValueError("hysteresis thresholds are invalid")
    if minimum_run < 1 or release_run < 1:
        raise ValueError("hysteresis run lengths must be positive")
    output = np.zeros(score.shape, dtype=np.bool_)
    active = False
    high_run = 0
    low_run = 0
    for index, value in enumerate(score):
        if not valid[index] or not np.isfinite(value):
            active = False
            high_run = 0
            low_run = 0
            continue
        if not active:
            high_run = high_run + 1 if value >= high_threshold else 0
            if high_run >= minimum_run:
                active = True
                low_run = 0
        else:
            low_run = low_run + 1 if value < hold_threshold else 0
            if low_run >= release_run:
                active = False
                high_run = 0
        output[index] = active
    return output


def apply_identity_safe_selection(
    base_xy_m: np.ndarray,
    proposal_xy_m: np.ndarray,
    accepted_mask: np.ndarray,
) -> np.ndarray:
    """Select a measured proposal only on accepted frames; otherwise exact base."""

    base = np.asarray(base_xy_m, dtype=np.float32)
    proposal = np.asarray(proposal_xy_m, dtype=np.float32)
    accepted = np.asarray(accepted_mask, dtype=np.bool_).reshape(-1)
    if base.ndim != 2 or base.shape[1:] != (2,) or proposal.shape != base.shape:
        raise ValueError("base and proposal coordinates must be [time,2]")
    if accepted.shape != (base.shape[0],):
        raise ValueError("accepted mask must align with time")
    output = base.copy()
    usable = accepted & np.isfinite(proposal).all(axis=1)
    output[usable] = proposal[usable]
    return output


def promotion_gates(
    base: dict[str, float],
    expert: dict[str, float],
    per_sequence: dict[str, dict[str, Any]],
    *,
    max_identity_abs: float,
    locked_test_reads: int,
) -> dict[str, bool]:
    """Pre-registered TCBAV semantic-library promotion gates."""

    return {
        "pooled_ap_0p3_gain_at_least_1pp": expert["ap_0p3m"] >= base["ap_0p3m"] + 0.01,
        "all_sequences_nonnegative_ap_0p3": all(
            float(row["delta_ap_0p3_pp"]) >= 0.0 for row in per_sequence.values()
        ),
        "p90_non_regression": expert["p90_error_m"] <= base["p90_error_m"],
        "ap_0p5_within_0p5pp": expert["ap_0p5m"] >= base["ap_0p5m"] - 0.005,
        "other_routes_exact_identity": float(max_identity_abs) == 0.0,
        "locked_test_unread": int(locked_test_reads) == 0,
    }
