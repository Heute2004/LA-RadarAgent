"""Full-resolution RA/RA-MTI experts for daytime wet-return association."""

from __future__ import annotations

import math
from typing import Literal, Mapping

import torch
from torch import Tensor, nn
from torch.nn import functional

from .expert_library.cpb_convlstm.models.common import ConvGRUCell


ModelKind = Literal[
    "transformer",
    "convgru_unet",
    "trod_window",
    "graph_tbd",
    "candidate_graph",
    "gg_srre_recovery",
    "gg_srre_recovery_lite",
]
_RANGE_RESOLUTION_M = 299_792_458.0 * 6.25e6 / (2.0 * 9.994e12 * 512)


def _expand_background(value: Tensor, radar: Tensor, name: str) -> Tensor:
    if value.ndim == 3:
        value = value.unsqueeze(0)
    if value.ndim != 4 or value.shape[1:] != radar.shape[2:]:
        raise ValueError(f"{name} must be [2,H,W] or [B,2,H,W]")
    if value.shape[0] not in (1, radar.shape[0]):
        raise ValueError(f"{name} batch does not match radar")
    return value[:, None].to(device=radar.device, dtype=radar.dtype)


def build_background_aware_channels(
    radar_clip_db: Tensor,
    background_mean_db: Tensor,
    background_std_db: Tensor,
    *,
    z_clip: float = 12.0,
) -> Tensor:
    if radar_clip_db.ndim != 5 or radar_clip_db.shape[2] != 2:
        raise ValueError("radar_clip_db must contain exactly RA/RA-MTI channels")
    if z_clip <= 0.0:
        raise ValueError("z_clip must be positive")
    mean = _expand_background(background_mean_db, radar_clip_db, "background_mean_db")
    std = _expand_background(background_std_db, radar_clip_db, "background_std_db").clamp_min(1.0e-3)
    z = ((radar_clip_db - mean) / std).clamp(-float(z_clip), float(z_clip))
    return torch.cat((z, z.clamp_min(0.0), z.abs()), dim=2)


def _metric_grid(candidate_xy_m: Tensor) -> tuple[Tensor, Tensor]:
    if candidate_xy_m.ndim != 4 or candidate_xy_m.shape[-1] != 2:
        raise ValueError("candidate_xy_m must be [B,T,K,2]")
    x, y = candidate_xy_m.float().unbind(dim=-1)
    radius = torch.sqrt(x.square() + y.square())
    row = radius / _RANGE_RESOLUTION_M
    sine = torch.where(radius > 1.0e-6, x / radius, torch.zeros_like(radius)).clamp(-1.0, 1.0)
    column = (sine + 1.0) * 64.0
    grid_x = 2.0 * column / 127.0 - 1.0
    grid_y = 2.0 * row / 127.0 - 1.0
    grid = torch.stack((grid_x, grid_y), dim=-1)
    in_bounds = (row >= 0.0) & (row <= 127.0) & (column >= 0.0) & (column <= 127.0)
    return grid, in_bounds


def sample_candidate_features(feature: Tensor, candidate_xy_m: Tensor, candidate_valid: Tensor) -> Tensor:
    if feature.ndim != 5:
        raise ValueError("feature must be [B,T,C,H,W]")
    batch, steps, channels, height, width = feature.shape
    if candidate_xy_m.shape[:2] != (batch, steps) or candidate_valid.shape != candidate_xy_m.shape[:3]:
        raise ValueError("candidate arrays do not align with feature sequence")
    grid, in_bounds = _metric_grid(candidate_xy_m)
    finite = torch.isfinite(candidate_xy_m).all(dim=-1)
    valid = candidate_valid.bool() & in_bounds & finite
    safe_grid = torch.where(valid[..., None], grid, torch.zeros_like(grid))
    sampled = functional.grid_sample(
        feature.reshape(batch * steps, channels, height, width),
        safe_grid.reshape(batch * steps, -1, 1, 2),
        mode="bilinear",
        padding_mode="zeros",
        align_corners=True,
    )
    sampled = sampled[:, :, :, 0].transpose(1, 2).reshape(batch, steps, -1, channels)
    return sampled * valid[..., None].to(sampled.dtype)


def set_mass_nll(candidate_logits: Tensor, target_weight: Tensor, sample_weight: Tensor) -> Tensor:
    if candidate_logits.shape != target_weight.shape or sample_weight.shape != candidate_logits.shape[:2]:
        raise ValueError("set-mass tensors do not align")
    if torch.any(target_weight < 0.0) or torch.any(sample_weight < 0.0):
        raise ValueError("set-mass weights must be non-negative")
    usable = sample_weight.float() > 0.0
    if not bool(usable.any()):
        return candidate_logits.sum() * 0.0
    selected_logits = candidate_logits.float()[usable]
    selected_target = target_weight.float()[usable]
    selected_weight = sample_weight.float()[usable]
    log_probability = functional.log_softmax(selected_logits, dim=-1)
    log_target = torch.where(
        selected_target > 0.0,
        selected_target.log(),
        torch.full_like(selected_target, -torch.inf),
    )
    log_mass = torch.logsumexp(log_probability + log_target, dim=-1)
    return -(log_mass * selected_weight).sum() / selected_weight.sum().clamp_min(1.0e-6)


def candidate_equivalent_target_support(
    target_weight: Tensor,
    candidate_xy_m: Tensor,
    *,
    radius_m: float,
) -> Tensor:
    """Return weak-target mass supported near every candidate coordinate."""

    if target_weight.shape != candidate_xy_m.shape[:-1] or candidate_xy_m.shape[-1] != 2:
        raise ValueError("target weights and candidate coordinates do not align")
    if radius_m <= 0.0:
        raise ValueError("radius_m must be positive")
    finite = torch.isfinite(candidate_xy_m).all(dim=-1)
    safe_xy = torch.nan_to_num(candidate_xy_m.float(), nan=0.0, posinf=0.0, neginf=0.0)
    distance = torch.linalg.vector_norm(safe_xy.unsqueeze(-2) - safe_xy.unsqueeze(-3), dim=-1)
    pair_valid = finite.unsqueeze(-1) & finite.unsqueeze(-2)
    equivalent = pair_valid & (distance <= float(radius_m))
    return (equivalent.to(target_weight.dtype) * target_weight.unsqueeze(-2)).sum(dim=-1).clamp(0.0, 1.0)


def local_action_mask(
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    *,
    maximum_correction_m: float,
) -> Tensor:
    """Restrict expert actions to the Fit-pre-registered neighborhood of Identity."""

    if candidate_xy_m.shape != candidate_valid.shape + (2,):
        raise ValueError("candidate coordinates and validity do not align")
    if not math.isfinite(maximum_correction_m) or maximum_correction_m <= 0.0:
        raise ValueError("maximum_correction_m must be finite and positive")
    finite = torch.isfinite(candidate_xy_m).all(dim=-1)
    identity = candidate_xy_m[..., :1, :]
    displacement = torch.linalg.vector_norm(candidate_xy_m.float() - identity.float(), dim=-1)
    valid = candidate_valid.bool() & finite & displacement.le(float(maximum_correction_m))
    valid[..., 0] = candidate_valid[..., 0].bool() & finite[..., 0]
    return valid


def causal_track_filter(
    unary_logits: Tensor,
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    *,
    maximum_step_m: float,
    transition_scale_m: float | Tensor,
    birth_logit: float,
) -> Tensor:
    """Accumulate causal candidate evidence along physically reachable paths."""

    if unary_logits.shape != candidate_valid.shape or candidate_xy_m.shape != unary_logits.shape + (2,):
        raise ValueError("track-filter inputs do not align")
    if maximum_step_m <= 0.0:
        raise ValueError("maximum_step_m must be positive")
    scale = torch.as_tensor(transition_scale_m, dtype=unary_logits.dtype, device=unary_logits.device).clamp_min(1.0e-3)
    valid = candidate_valid.bool() & torch.isfinite(candidate_xy_m).all(dim=-1)
    safe_xy = torch.nan_to_num(candidate_xy_m.float(), nan=0.0, posinf=0.0, neginf=0.0)
    unary = unary_logits.float().masked_fill(~valid, -1.0e4)
    state = unary[:, 0]
    state = state - torch.logsumexp(state, dim=-1, keepdim=True)
    output = [state]
    for step in range(1, unary.shape[1]):
        distance = torch.linalg.vector_norm(safe_xy[:, step - 1, :, None] - safe_xy[:, step, None, :], dim=-1)
        reachable = valid[:, step - 1, :, None] & valid[:, step, None, :] & (distance <= float(maximum_step_m))
        reachable[:, 0, 0] = valid[:, step - 1, 0] & valid[:, step, 0]
        transition = (-distance / scale).masked_fill(~reachable, -1.0e4)
        incoming = (state.unsqueeze(-1) + transition).amax(dim=-2)
        birth = torch.full_like(incoming, float(birth_logit))
        incoming = torch.maximum(incoming, birth)
        state = (unary[:, step] + incoming).masked_fill(~valid[:, step], -1.0e4)
        state = state - torch.logsumexp(state, dim=-1, keepdim=True)
        output.append(state)
    return torch.stack(output, dim=1)


def transition_excess_loss(position_xy_m: Tensor, *, maximum_step_m: float) -> Tensor:
    if position_xy_m.ndim != 3 or position_xy_m.shape[-1] != 2:
        raise ValueError("position_xy_m must be [B,T,2]")
    if maximum_step_m <= 0.0:
        raise ValueError("maximum_step_m must be positive")
    if position_xy_m.shape[1] < 2:
        return position_xy_m.sum() * 0.0
    step = torch.linalg.vector_norm(position_xy_m[:, 1:] - position_xy_m[:, :-1], dim=-1)
    return functional.smooth_l1_loss(step.clamp_min(maximum_step_m), torch.full_like(step, maximum_step_m))


def decode_with_identity(
    output: Mapping[str, Tensor],
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    *,
    threshold: float,
) -> tuple[Tensor, Tensor]:
    if not math.isfinite(threshold) or threshold < 0.0:
        raise ValueError("threshold must be finite and non-negative")
    selected = output["selected_candidate_index"].long()
    proposal = output["proposal_xy_m"]
    benefit = output["benefit_probability"]
    selected_valid = candidate_valid.gather(-1, selected.unsqueeze(-1)).squeeze(-1)
    accepted = benefit.ge(float(threshold)) & selected.ne(0) & selected_valid & torch.isfinite(proposal).all(dim=-1)
    identity = candidate_xy_m[..., 0, :]
    return torch.where(accepted[..., None], proposal, identity), accepted


class _ConvBlock(nn.Sequential):
    def __init__(self, inputs: int, outputs: int, *, stride: int = 1) -> None:
        groups = 8 if outputs % 8 == 0 else 1
        super().__init__(
            nn.Conv2d(inputs, outputs, 3, stride=stride, padding=1, bias=False),
            nn.GroupNorm(groups, outputs),
            nn.SiLU(inplace=True),
            nn.Conv2d(outputs, outputs, 3, padding=1, bias=False),
            nn.GroupNorm(groups, outputs),
            nn.SiLU(inplace=True),
        )


class _FramePyramid(nn.Module):
    def __init__(self, feature_dim: int) -> None:
        super().__init__()
        low = max(feature_dim // 2, 16)
        self.level0 = _ConvBlock(6, low)
        self.level1 = _ConvBlock(low, feature_dim, stride=2)
        self.level2 = _ConvBlock(feature_dim, feature_dim, stride=2)

    def forward(self, value: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        level0 = self.level0(value)
        level1 = self.level1(level0)
        level2 = self.level2(level1)
        return level0, level1, level2


class _CausalTransformerEncoder(nn.Module):
    def __init__(self, dimension: int) -> None:
        super().__init__()
        heads = 4 if dimension % 4 == 0 else 1
        layer = nn.TransformerEncoderLayer(
            d_model=dimension,
            nhead=heads,
            dim_feedforward=dimension * 2,
            dropout=0.0,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)

    def forward(self, tokens: Tensor) -> Tensor:
        steps = tokens.shape[1]
        mask = torch.triu(torch.ones(steps, steps, device=tokens.device, dtype=torch.bool), diagonal=1)
        return self.encoder(tokens, mask=mask)


class _CandidatePosterior(nn.Module):
    def __init__(self, dimension: int, candidate_count: int) -> None:
        super().__init__()
        heads = 4 if dimension % 4 == 0 else 1
        self.type_embedding = nn.Embedding(candidate_count, dimension)
        self.attention = nn.MultiheadAttention(dimension, heads, dropout=0.0, batch_first=True)
        self.norm = nn.LayerNorm(dimension)
        self.head = nn.Linear(dimension, 1)
        self.unary_scale = nn.Parameter(torch.tensor(0.25))
        self.benefit = nn.Sequential(nn.Linear(dimension + 3, dimension), nn.SiLU(), nn.Linear(dimension, 1))

    def forward(
        self,
        token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
    ) -> dict[str, Tensor]:
        batch, steps, candidates, dimension = token.shape
        type_id = torch.arange(candidates, device=token.device).view(1, 1, candidates)
        token = token + self.type_embedding(type_id)
        valid = candidate_valid.bool() & torch.isfinite(candidate_xy_m).all(dim=-1)
        flat = token.reshape(batch * steps, candidates, dimension)
        flat_valid = valid.reshape(batch * steps, candidates)
        attended, _ = self.attention(flat, flat, flat, key_padding_mask=~flat_valid, need_weights=False)
        token = self.norm(flat + attended).reshape(batch, steps, candidates, dimension)
        logits = self.head(token).squeeze(-1) + self.unary_scale * candidate_unary_logits.float()
        logits = logits.masked_fill(~valid, -20.0)
        probability = functional.softmax(logits, dim=-1)
        selected = probability.argmax(dim=-1)
        rows = torch.arange(batch, device=token.device)[:, None]
        times = torch.arange(steps, device=token.device)[None, :]
        proposal = candidate_xy_m[rows, times, selected]
        ordered = probability.topk(k=min(2, candidates), dim=-1).values
        margin = ordered[..., 0] - ordered[..., 1] if candidates > 1 else ordered[..., 0]
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1) / math.log(float(candidates))
        pooled = (token * probability[..., None]).sum(dim=-2)
        benefit_input = torch.cat((pooled, 1.0 - probability[..., :1], margin[..., None], entropy[..., None]), dim=-1)
        benefit_logit = self.benefit(benefit_input).squeeze(-1)
        return {
            "candidate_logits": logits,
            "candidate_probability": probability,
            "selected_candidate_index": selected,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "posterior_margin": margin,
            "posterior_entropy": entropy,
        }


class _GraphTBDPosterior(nn.Module):
    def __init__(self, dimension: int, candidate_count: int, *, use_base_score: bool = False) -> None:
        super().__init__()
        self.use_base_score = bool(use_base_score)
        heads = 4 if dimension % 4 == 0 else 1
        self.type_embedding = nn.Embedding(candidate_count, dimension)
        self.attention = nn.MultiheadAttention(dimension, heads, dropout=0.0, batch_first=True)
        self.norm = nn.LayerNorm(dimension)
        self.unary_head = nn.Linear(dimension, 1)
        self.unary_scale = nn.Parameter(torch.tensor(0.25))
        self.transition_scale_raw = nn.Parameter(torch.tensor(-1.5))
        benefit_inputs = dimension + 4 + int(self.use_base_score)
        self.benefit = nn.Sequential(nn.Linear(benefit_inputs, dimension), nn.SiLU(), nn.Linear(dimension, 1))

    def forward(
        self,
        token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        base_score: Tensor | None = None,
    ) -> dict[str, Tensor]:
        batch, steps, candidates, dimension = token.shape
        type_id = torch.arange(candidates, device=token.device).view(1, 1, candidates)
        token = token + self.type_embedding(type_id)
        valid = candidate_valid.bool() & torch.isfinite(candidate_xy_m).all(dim=-1)
        flat = token.reshape(batch * steps, candidates, dimension)
        flat_valid = valid.reshape(batch * steps, candidates)
        attended, _ = self.attention(flat, flat, flat, key_padding_mask=~flat_valid, need_weights=False)
        token = self.norm(flat + attended).reshape(batch, steps, candidates, dimension)
        unary = self.unary_head(token).squeeze(-1) + self.unary_scale * candidate_unary_logits.float()
        transition_scale = functional.softplus(self.transition_scale_raw) + 0.05
        logits = causal_track_filter(
            unary,
            candidate_xy_m,
            valid,
            maximum_step_m=0.35,
            transition_scale_m=transition_scale,
            birth_logit=-4.0,
        )
        probability = functional.softmax(logits, dim=-1)
        selected = probability.argmax(dim=-1)
        rows = torch.arange(batch, device=token.device)[:, None]
        times = torch.arange(steps, device=token.device)[None, :]
        proposal = candidate_xy_m[rows, times, selected]
        ordered = probability.topk(k=min(2, candidates), dim=-1).values
        margin = ordered[..., 0] - ordered[..., 1] if candidates > 1 else ordered[..., 0]
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1) / math.log(float(candidates))
        pooled = (token * probability[..., None]).sum(dim=-2)
        displacement = torch.linalg.vector_norm(proposal - candidate_xy_m[..., 0, :], dim=-1)
        benefit_parts = [pooled, 1.0 - probability[..., :1], margin[..., None], entropy[..., None], displacement[..., None]]
        if self.use_base_score:
            if base_score is None or base_score.shape != probability.shape[:2]:
                raise ValueError("base_score must align with the candidate sequence")
            benefit_parts.append(base_score.float().clamp(0.0, 1.0)[..., None])
        benefit_input = torch.cat(benefit_parts, dim=-1)
        benefit_logit = self.benefit(benefit_input).squeeze(-1)
        return {
            "candidate_logits": logits,
            "candidate_probability": probability,
            "selected_candidate_index": selected,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "posterior_margin": margin,
            "posterior_entropy": entropy,
        }


class _GGSRRERecoveryPosterior(nn.Module):
    """Predict a bounded local recovery centre, then execute a measured peak.

    Sparse weak supervision is substantially easier to learn as a local metric
    correction than as a 97-way candidate identity.  The continuous centre is
    used only to score current-frame physical radar candidates; runtime output
    remains one measured candidate or the exact frozen identity fallback.
    """

    def __init__(
        self,
        dimension: int,
        candidate_count: int,
        *,
        maximum_correction_m: float,
    ) -> None:
        super().__init__()
        if maximum_correction_m <= 0.0:
            raise ValueError("maximum_correction_m must be positive")
        heads = 4 if dimension % 4 == 0 else 1
        self.maximum_correction_m = float(maximum_correction_m)
        self.type_embedding = nn.Embedding(candidate_count, dimension)
        self.attention = nn.MultiheadAttention(dimension, heads, dropout=0.0, batch_first=True)
        self.norm = nn.LayerNorm(dimension)
        self.candidate_residual = nn.Linear(dimension, 1)
        self.unary_scale = nn.Parameter(torch.tensor(0.10))
        self.temporal = nn.GRU(dimension * 2, dimension, batch_first=True)
        self.offset_head = nn.Sequential(
            nn.Linear(dimension * 2, dimension),
            nn.SiLU(),
            nn.Linear(dimension, 2),
        )
        self.scale_head = nn.Linear(dimension, 1)
        self.benefit = nn.Sequential(
            nn.Linear(dimension + 3, dimension),
            nn.SiLU(),
            nn.Linear(dimension, 1),
        )
        nn.init.zeros_(self.offset_head[-1].weight)
        nn.init.zeros_(self.offset_head[-1].bias)
        nn.init.zeros_(self.benefit[-1].weight)
        nn.init.zeros_(self.benefit[-1].bias)

    def forward(
        self,
        token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
    ) -> dict[str, Tensor]:
        batch, steps, candidates, dimension = token.shape
        type_id = torch.arange(candidates, device=token.device).view(1, 1, candidates)
        token = token + self.type_embedding(type_id)
        valid = candidate_valid.bool() & torch.isfinite(candidate_xy_m).all(dim=-1)
        flat = token.reshape(batch * steps, candidates, dimension)
        flat_valid = valid.reshape(batch * steps, candidates)
        attended, _ = self.attention(flat, flat, flat, key_padding_mask=~flat_valid, need_weights=False)
        token = self.norm(flat + attended).reshape(batch, steps, candidates, dimension)

        evidence_logits = candidate_unary_logits.float().masked_fill(~valid, -20.0)
        evidence_probability = functional.softmax(evidence_logits, dim=-1)
        evidence = (token * evidence_probability[..., None]).sum(dim=-2)
        identity_token = token[..., 0, :]
        temporal_state, _ = self.temporal(torch.cat((identity_token, evidence), dim=-1))
        recovery_state = torch.cat((temporal_state, identity_token), dim=-1)
        offset = self.maximum_correction_m * torch.tanh(self.offset_head(recovery_state))
        identity_xy = candidate_xy_m[..., 0, :].float()
        recovery_center = identity_xy + offset

        safe_xy = torch.nan_to_num(candidate_xy_m.float(), nan=0.0, posinf=0.0, neginf=0.0)
        distance = torch.linalg.vector_norm(safe_xy - recovery_center[..., None, :], dim=-1)
        metric_scale = functional.softplus(self.scale_head(temporal_state)).squeeze(-1) + 0.08
        metric_logit = -0.5 * (distance / metric_scale[..., None]).square()
        residual = self.candidate_residual(token).squeeze(-1)
        logits = metric_logit + residual + self.unary_scale * candidate_unary_logits.float()
        logits = logits.masked_fill(~valid, -20.0)
        probability = functional.softmax(logits, dim=-1)
        selected = probability.argmax(dim=-1)
        rows = torch.arange(batch, device=token.device)[:, None]
        times = torch.arange(steps, device=token.device)[None, :]
        proposal = candidate_xy_m[rows, times, selected]

        ordered = probability.topk(k=min(2, candidates), dim=-1).values
        margin = ordered[..., 0] - ordered[..., 1] if candidates > 1 else ordered[..., 0]
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1) / math.log(float(candidates))
        displacement = torch.linalg.vector_norm(recovery_center - identity_xy, dim=-1)
        benefit_input = torch.cat(
            (temporal_state, displacement[..., None], margin[..., None], entropy[..., None]), dim=-1
        )
        benefit_logit = self.benefit(benefit_input).squeeze(-1)
        return {
            "candidate_logits": logits,
            "candidate_probability": probability,
            "selected_candidate_index": selected,
            "proposal_xy_m": proposal,
            "recovery_center_xy_m": recovery_center,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "posterior_margin": margin,
            "posterior_entropy": entropy,
        }


class _TransformerFeatures(nn.Module):
    def __init__(self, feature_dim: int) -> None:
        super().__init__()
        self.pyramid = _FramePyramid(feature_dim)
        low = max(feature_dim // 2, 16)
        self.project = nn.Sequential(nn.Linear(low + feature_dim * 2, feature_dim), nn.LayerNorm(feature_dim), nn.SiLU())
        self.temporal = _CausalTransformerEncoder(feature_dim)

    def forward(self, channels: Tensor, xy: Tensor, valid: Tensor) -> Tensor:
        batch, steps = channels.shape[:2]
        levels = self.pyramid(channels.reshape(batch * steps, 6, 128, 128))
        levels = tuple(level.reshape(batch, steps, level.shape[1], level.shape[2], level.shape[3]) for level in levels)
        sampled = torch.cat([sample_candidate_features(level, xy, valid) for level in levels], dim=-1)
        token = self.project(sampled)
        candidates = token.shape[2]
        temporal = self.temporal(token.permute(0, 2, 1, 3).reshape(batch * candidates, steps, -1))
        return temporal.reshape(batch, candidates, steps, -1).permute(0, 2, 1, 3)


class _CandidateOnlyFeatures(nn.Module):
    """Encode measured candidate evidence without duplicating the frozen radar backbone."""

    def __init__(self, feature_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(
            nn.Linear(11, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.SiLU(),
            nn.Linear(feature_dim, feature_dim),
        )

    def forward(self, channels: Tensor, xy: Tensor, valid: Tensor) -> Tensor:
        local = sample_candidate_features(channels, xy, valid)
        identity = xy[..., :1, :]
        delta = torch.nan_to_num((xy.float() - identity.float()) / 1.60, nan=0.0)
        displacement = torch.linalg.vector_norm(delta, dim=-1, keepdim=True)
        absolute = torch.nan_to_num(xy.float(), nan=0.0) / xy.new_tensor((20.0, 25.0))
        return self.project(torch.cat((local.float(), delta, displacement, absolute), dim=-1))


class _ConvGRUUNetFeatures(nn.Module):
    def __init__(self, feature_dim: int) -> None:
        super().__init__()
        self.pyramid = _FramePyramid(feature_dim)
        low = max(feature_dim // 2, 16)
        self.recurrent1 = ConvGRUCell(feature_dim, feature_dim)
        self.recurrent2 = ConvGRUCell(feature_dim, feature_dim)
        self.decode = _ConvBlock(low + feature_dim * 2, feature_dim)
        self.project = nn.Sequential(nn.Linear(feature_dim * 3, feature_dim), nn.LayerNorm(feature_dim), nn.SiLU())

    def forward(self, channels: Tensor, xy: Tensor, valid: Tensor) -> Tensor:
        batch, steps = channels.shape[:2]
        levels = self.pyramid(channels.reshape(batch * steps, 6, 128, 128))
        level0, level1, level2 = (
            level.reshape(batch, steps, level.shape[1], level.shape[2], level.shape[3]) for level in levels
        )
        hidden1 = hidden2 = None
        outputs = []
        recurrent1 = []
        recurrent2 = []
        for step in range(steps):
            hidden1 = self.recurrent1(level1[:, step], hidden1)
            hidden2 = self.recurrent2(level2[:, step], hidden2)
            up1 = functional.interpolate(hidden1, size=(128, 128), mode="bilinear", align_corners=False)
            up2 = functional.interpolate(hidden2, size=(128, 128), mode="bilinear", align_corners=False)
            outputs.append(self.decode(torch.cat((level0[:, step], up1, up2), dim=1)))
            recurrent1.append(hidden1)
            recurrent2.append(hidden2)
        decoded = torch.stack(outputs, dim=1)
        h1 = torch.stack(recurrent1, dim=1)
        h2 = torch.stack(recurrent2, dim=1)
        sampled = torch.cat(
            (
                sample_candidate_features(decoded, xy, valid),
                sample_candidate_features(h1, xy, valid),
                sample_candidate_features(h2, xy, valid),
            ),
            dim=-1,
        )
        return self.project(sampled)


class _CausalTemporalBranch(nn.Module):
    def __init__(self, channels: int, kernel: int) -> None:
        super().__init__()
        self.kernel = kernel
        self.conv = nn.Conv3d(channels, channels, (kernel, 3, 3), padding=(0, 1, 1), groups=channels, bias=False)
        self.mix = nn.Conv3d(channels, channels, 1, bias=False)

    def forward(self, value: Tensor) -> Tensor:
        value = functional.pad(value, (0, 0, 0, 0, self.kernel - 1, 0))
        return functional.silu(self.mix(self.conv(value)))


class _TRODWindowFeatures(nn.Module):
    def __init__(self, feature_dim: int) -> None:
        super().__init__()
        self.pyramid = _FramePyramid(feature_dim)
        self.branches = nn.ModuleList([_CausalTemporalBranch(feature_dim, kernel) for kernel in (3, 5, 7)])
        self.fuse = nn.Sequential(nn.Conv3d(feature_dim * 3, feature_dim, 1, bias=False), nn.SiLU())
        self.project = nn.Sequential(nn.Linear(feature_dim * 2, feature_dim), nn.LayerNorm(feature_dim), nn.SiLU())
        self.temporal = _CausalTransformerEncoder(feature_dim)

    def forward(self, channels: Tensor, xy: Tensor, valid: Tensor) -> Tensor:
        batch, steps = channels.shape[:2]
        _, level1, level2 = self.pyramid(channels.reshape(batch * steps, 6, 128, 128))
        level1 = level1.reshape(batch, steps, level1.shape[1], level1.shape[2], level1.shape[3])
        level2 = level2.reshape(batch, steps, level2.shape[1], level2.shape[2], level2.shape[3])
        temporal = level2.permute(0, 2, 1, 3, 4)
        temporal = self.fuse(torch.cat([branch(temporal) for branch in self.branches], dim=1)).permute(0, 2, 1, 3, 4)
        sampled = torch.cat((sample_candidate_features(level1, xy, valid), sample_candidate_features(temporal, xy, valid)), dim=-1)
        token = self.project(sampled)
        candidates = token.shape[2]
        token = self.temporal(token.permute(0, 2, 1, 3).reshape(batch * candidates, steps, -1))
        return token.reshape(batch, candidates, steps, -1).permute(0, 2, 1, 3)


class FullRAWetExpert(nn.Module):
    def __init__(
        self,
        *,
        model_kind: ModelKind,
        candidate_count: int = 97,
        feature_dim: int = 64,
        maximum_correction_m: float | None = None,
    ) -> None:
        super().__init__()
        if candidate_count < 2 or feature_dim < 16:
            raise ValueError("invalid full-RA wet expert dimensions")
        builders = {
            "transformer": _TransformerFeatures,
            "convgru_unet": _ConvGRUUNetFeatures,
            "trod_window": _TRODWindowFeatures,
            "graph_tbd": _TransformerFeatures,
            "candidate_graph": _CandidateOnlyFeatures,
            "gg_srre_recovery": _ConvGRUUNetFeatures,
            "gg_srre_recovery_lite": _CandidateOnlyFeatures,
        }
        if model_kind not in builders:
            raise ValueError(f"unknown full-RA wet expert kind: {model_kind}")
        self.model_kind = model_kind
        self.candidate_count = int(candidate_count)
        self.requires_base_score = model_kind == "candidate_graph"
        if model_kind in {"gg_srre_recovery", "gg_srre_recovery_lite"} and maximum_correction_m is None:
            maximum_correction_m = 0.60
        self.maximum_correction_m = None if maximum_correction_m is None else float(maximum_correction_m)
        self.features = builders[model_kind](feature_dim)
        if model_kind in {"gg_srre_recovery", "gg_srre_recovery_lite"}:
            assert self.maximum_correction_m is not None
            self.posterior = _GGSRRERecoveryPosterior(
                feature_dim,
                candidate_count,
                maximum_correction_m=self.maximum_correction_m,
            )
        elif model_kind in {"graph_tbd", "candidate_graph"}:
            self.posterior = _GraphTBDPosterior(
                feature_dim,
                candidate_count,
                use_base_score=self.requires_base_score,
            )
        else:
            self.posterior = _CandidatePosterior(feature_dim, candidate_count)

    def forward(
        self,
        *,
        radar_clip_db: Tensor,
        background_mean_db: Tensor,
        background_std_db: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        base_score: Tensor | None = None,
    ) -> dict[str, Tensor]:
        if radar_clip_db.ndim != 5 or radar_clip_db.shape[2:] != (2, 128, 128):
            raise ValueError("radar input must be [B,T,2,128,128] RA/RA-MTI only")
        batch, steps = radar_clip_db.shape[:2]
        if candidate_xy_m.shape != (batch, steps, self.candidate_count, 2):
            raise ValueError("candidate_xy_m does not match the configured candidate count")
        if candidate_valid.shape != (batch, steps, self.candidate_count) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [B,T,K]")
        if candidate_unary_logits.shape != candidate_valid.shape:
            raise ValueError("candidate_unary_logits must align with candidates")
        if self.requires_base_score and (base_score is None or base_score.shape != (batch, steps)):
            raise ValueError("base_score must be [B,T] for candidate_graph")
        if not bool(candidate_valid[..., 0].all()) or not bool(torch.isfinite(candidate_xy_m[..., 0, :]).all()):
            raise ValueError("candidate zero must remain finite and valid")
        if self.maximum_correction_m is not None:
            candidate_valid = local_action_mask(
                candidate_xy_m,
                candidate_valid,
                maximum_correction_m=self.maximum_correction_m,
            )
        channels = build_background_aware_channels(radar_clip_db, background_mean_db, background_std_db)
        token = self.features(channels, candidate_xy_m, candidate_valid)
        if isinstance(self.posterior, _GraphTBDPosterior):
            output = self.posterior(
                token,
                candidate_xy_m,
                candidate_valid,
                candidate_unary_logits,
                base_score=base_score,
            )
        else:
            output = self.posterior(token, candidate_xy_m, candidate_valid, candidate_unary_logits)
        output["action_valid"] = candidate_valid
        return output
