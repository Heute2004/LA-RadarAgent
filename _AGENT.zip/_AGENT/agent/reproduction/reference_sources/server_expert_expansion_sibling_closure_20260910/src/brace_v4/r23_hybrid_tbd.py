"""Hybrid low/high-threshold existence primitives over measured candidates.

This module deliberately has no coordinate regressor. Candidate zero is an
exact frozen identity action, while nonzero candidates can be born only from
high-threshold evidence or sustained by a reachable low-threshold path.
"""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional


R23_ARCHITECTURE = "CORA-HybridTBD-DTT-ExistenceManager-V1"


def hybrid_existence_update(
    *,
    previous_xy_m: Tensor,
    current_xy_m: Tensor,
    previous_existence: Tensor,
    previous_valid: Tensor,
    current_valid: Tensor,
    high_confirmation: Tensor,
    low_support: Tensor,
    maximum_step_m: float,
) -> tuple[Tensor, Tensor]:
    """Update a finite candidate-existence state without an identity bridge."""

    if maximum_step_m <= 0.0:
        raise ValueError("maximum_step_m must be positive")
    if previous_xy_m.ndim != 3 or previous_xy_m.shape[-1] != 2 or current_xy_m.shape != previous_xy_m.shape:
        raise ValueError("candidate coordinates must be aligned [batch,candidates,2]")
    batch, candidates = previous_xy_m.shape[:2]
    expected = (batch, candidates)
    if any(value.shape != expected for value in (previous_existence, previous_valid, current_valid, high_confirmation, low_support)):
        raise ValueError("candidate state tensors must align with coordinates")
    if previous_valid.dtype is not torch.bool or current_valid.dtype is not torch.bool:
        raise ValueError("candidate validity must be boolean")
    if not bool(previous_valid[:, 0].all()) or not bool(current_valid[:, 0].all()):
        raise ValueError("candidate zero must remain valid")

    distance = torch.cdist(current_xy_m.float(), previous_xy_m.float())
    current_measured = current_valid.clone()
    previous_measured = previous_valid.clone()
    current_measured[:, 0] = False
    previous_measured[:, 0] = False
    transition = (
        current_measured[:, :, None]
        & previous_measured[:, None, :]
        & torch.isfinite(distance)
        & (distance <= float(maximum_step_m) + 1.0e-9)
    )
    reachable_previous = torch.where(
        transition,
        previous_existence[:, None, :].clamp(0.0, 1.0),
        torch.zeros_like(distance),
    ).amax(dim=-1)
    sustained = low_support.clamp(0.0, 1.0) * reachable_previous
    born = high_confirmation.clamp(0.0, 1.0)
    existence = torch.maximum(born, sustained) * current_measured.to(dtype=born.dtype)
    return existence, transition


class HybridTBDExistenceCandidateManager(nn.Module):
    """Causal high-birth/low-continuation manager over physical candidates."""

    architecture = R23_ARCHITECTURE

    def __init__(
        self,
        *,
        candidate_count: int,
        token_dim: int = 8,
        hidden_dim: int = 96,
        maximum_step_m: float = 0.30,
    ) -> None:
        super().__init__()
        if candidate_count < 2 or token_dim < 1 or hidden_dim < 8 or maximum_step_m <= 0.0:
            raise ValueError("invalid Hybrid-TBD manager dimensions")
        self.candidate_count = int(candidate_count)
        self.token_dim = int(token_dim)
        self.hidden_dim = int(hidden_dim)
        self.maximum_step_m = float(maximum_step_m)
        self.type_embedding = nn.Embedding(candidate_count, 8)
        self.token_encoder = nn.Sequential(
            nn.Linear(token_dim + 1 + 3 + 8 + 8, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(inplace=True),
        )
        self.high_head = nn.Linear(hidden_dim, 1)
        self.low_head = nn.Linear(hidden_dim, 1)
        self.candidate_head = nn.Linear(hidden_dim, 1)
        self.benefit_head = nn.Sequential(
            nn.Linear(hidden_dim + 4, hidden_dim // 2),
            nn.SiLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1),
        )
        nn.init.zeros_(self.candidate_head.weight)
        nn.init.zeros_(self.candidate_head.bias)
        nn.init.zeros_(self.benefit_head[-1].weight)
        nn.init.zeros_(self.benefit_head[-1].bias)

    def _validate(
        self,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
    ) -> tuple[int, int, int]:
        if candidate_token.ndim != 4 or candidate_token.shape[-1] != self.token_dim:
            raise ValueError("candidate_token must be [batch,time,candidates,token_dim]")
        batch, steps, candidates = candidate_token.shape[:3]
        if candidates != self.candidate_count:
            raise ValueError("candidate count does not match model configuration")
        if candidate_xy_m.shape != (batch, steps, candidates, 2):
            raise ValueError("candidate_xy_m must align with candidate_token")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be boolean [batch,time,candidates]")
        if candidate_unary_logits.shape != (batch, steps, candidates):
            raise ValueError("candidate_unary_logits must align with candidate_token")
        if global_state.shape != (batch, steps, 8):
            raise ValueError("global_state must be [batch,time,8]")
        if not bool(candidate_valid[..., 0].all()) or not bool(torch.isfinite(candidate_xy_m[..., 0, :]).all()):
            raise ValueError("candidate zero must remain finite and valid")
        return batch, steps, candidates

    def forward(
        self,
        *,
        candidate_token: Tensor,
        candidate_xy_m: Tensor,
        candidate_valid: Tensor,
        candidate_unary_logits: Tensor,
        global_state: Tensor,
    ) -> dict[str, Tensor]:
        batch, steps, candidates = self._validate(
            candidate_token,
            candidate_xy_m,
            candidate_valid,
            candidate_unary_logits,
            global_state,
        )
        valid = candidate_valid & torch.isfinite(candidate_xy_m).all(dim=-1)
        identity_xy = candidate_xy_m[..., :1, :]
        offset = candidate_xy_m - identity_xy
        geometry = torch.cat((offset / 4.0, torch.linalg.vector_norm(offset, dim=-1, keepdim=True) / 4.0), dim=-1)
        type_id = torch.arange(candidates, device=candidate_token.device).view(1, 1, candidates)
        type_feature = self.type_embedding(type_id.expand(batch, steps, -1))
        global_feature = global_state.float()[:, :, None, :].expand(-1, -1, candidates, -1)
        hidden = self.token_encoder(
            torch.cat((candidate_token.float(), candidate_unary_logits[..., None].float(), geometry.float(), type_feature, global_feature), dim=-1)
        )

        previous_xy = candidate_xy_m[:, 0]
        previous_valid = valid[:, 0]
        previous_existence = torch.zeros(batch, candidates, dtype=hidden.dtype, device=hidden.device)
        existence_history: list[Tensor] = []
        transition_history: list[Tensor] = []
        for index in range(steps):
            high = torch.sigmoid(self.high_head(hidden[:, index]).squeeze(-1) + 0.5 * candidate_unary_logits[:, index].float())
            low = torch.sigmoid(self.low_head(hidden[:, index]).squeeze(-1) + 0.25 * candidate_unary_logits[:, index].float())
            if index == 0:
                transition = torch.zeros(batch, candidates, candidates, dtype=torch.bool, device=hidden.device)
                existence = high * valid[:, index].to(dtype=high.dtype)
                existence[:, 0] = 0.0
            else:
                existence, transition = hybrid_existence_update(
                    previous_xy_m=previous_xy,
                    current_xy_m=candidate_xy_m[:, index],
                    previous_existence=previous_existence,
                    previous_valid=previous_valid,
                    current_valid=valid[:, index],
                    high_confirmation=high,
                    low_support=low,
                    maximum_step_m=self.maximum_step_m,
                )
            existence_history.append(existence)
            transition_history.append(transition)
            previous_xy = candidate_xy_m[:, index]
            previous_valid = valid[:, index]
            previous_existence = existence

        existence_probability = torch.stack(existence_history, dim=1)
        raw_logits = candidate_unary_logits.float() + self.candidate_head(hidden).squeeze(-1)
        non_identity_bonus = torch.log(existence_probability.clamp_min(1.0e-4))
        candidate_logits = raw_logits + non_identity_bonus
        candidate_logits[..., 0] = raw_logits[..., 0]
        candidate_logits = candidate_logits.masked_fill(~valid, -1.0e4)
        probability = torch.softmax(candidate_logits, dim=-1)
        selected = probability.argmax(dim=-1)
        batch_index = torch.arange(batch, device=hidden.device)[:, None]
        time_index = torch.arange(steps, device=hidden.device)[None, :]
        proposal = candidate_xy_m[batch_index, time_index, selected]
        selected_hidden = (probability[..., None] * hidden).sum(dim=2)
        entropy = -(probability * probability.clamp_min(1.0e-8).log()).sum(dim=-1) / torch.log(torch.tensor(float(candidates), device=hidden.device))
        top2 = probability.topk(2, dim=-1).values
        margin = top2[..., 0] - top2[..., 1]
        non_identity = 1.0 - probability[..., 0]
        correction = torch.linalg.vector_norm(proposal - identity_xy.squeeze(2), dim=-1)
        benefit_logit = self.benefit_head(
            torch.cat((selected_hidden, entropy[..., None], margin[..., None], non_identity[..., None], correction[..., None] / 4.0), dim=-1)
        ).squeeze(-1)
        return {
            "candidate_logits": candidate_logits,
            "candidate_probability": probability,
            "selected_candidate_index": selected,
            "proposal_xy_m": proposal,
            "benefit_logit": benefit_logit,
            "benefit_probability": torch.sigmoid(benefit_logit),
            "existence_probability": existence_probability,
            "transition_valid": torch.stack(transition_history, dim=1),
        }


def r23_weighted_association_loss(
    output: dict[str, Tensor],
    target_weight: Tensor,
    sample_weight: Tensor,
    *,
    candidate_loss_weight: float = 1.0,
    benefit_loss_weight: float = 0.25,
) -> tuple[Tensor, dict[str, Tensor]]:
    """Set-valued measured-candidate loss shared with the R16 teacher contract."""

    logits = output["candidate_logits"]
    if target_weight.shape != logits.shape or sample_weight.shape != logits.shape[:2]:
        raise ValueError("R23 targets must align with candidate logits")
    weight = sample_weight.float().clamp_min(0.0)
    denominator = weight.sum().clamp_min(1.0e-6)
    candidate_nll = -((target_weight.float() * functional.log_softmax(logits, dim=-1)).sum(dim=-1) * weight).sum() / denominator
    target_benefit = (target_weight[..., 1:].sum(dim=-1) > target_weight[..., 0]).float()
    benefit_bce = (functional.binary_cross_entropy_with_logits(output["benefit_logit"], target_benefit, reduction="none") * weight).sum() / denominator
    total = float(candidate_loss_weight) * candidate_nll + float(benefit_loss_weight) * benefit_bce
    return total, {"candidate_nll": candidate_nll.detach(), "benefit_bce": benefit_bce.detach()}
