"""Train-only calibration helpers for physical-candidate association experts."""

from __future__ import annotations

import numpy as np

MINIMUM_PCA_CALIBRATION_COVERAGE = 0.02


def summarize_fixed_gate(
    *,
    benefit_probability: np.ndarray,
    selected_candidate_index: np.ndarray,
    target_weight: np.ndarray,
    sample_weight: np.ndarray,
    threshold: float,
) -> dict[str, float | int]:
    """Summarize a frozen gate using only set-valued R11 supervision."""

    benefit = np.asarray(benefit_probability, dtype=np.float32).reshape(-1)
    selected = np.asarray(selected_candidate_index, dtype=np.int64).reshape(-1)
    target = np.asarray(target_weight, dtype=np.float32)
    weight = np.asarray(sample_weight, dtype=np.float32).reshape(-1)
    if not 0.0 <= float(threshold) <= 1.0:
        raise ValueError("threshold must lie in [0,1]")
    if target.ndim != 2 or target.shape[0] != benefit.size or selected.shape != benefit.shape or weight.shape != benefit.shape:
        raise ValueError("PCA fixed-gate arrays must share a frame axis")
    if np.any(selected < 0) or np.any(selected >= target.shape[1]) or np.any(weight < 0.0):
        raise ValueError("invalid selected candidate or sample weight")
    active = (weight > 0.0) & np.isfinite(benefit)
    accepted = active & (selected != 0) & (benefit >= float(threshold))
    total_weight = max(float(weight[active].sum()), 1.0e-8)
    accepted_weight = float(weight[accepted].sum())
    base_support = target[:, 0]
    selected_support = target[np.arange(target.shape[0]), selected]
    delta = selected_support - base_support
    chosen_support = np.where(accepted, selected_support, base_support)
    return {
        "accepted_frames": int(accepted.sum()),
        "coverage": float(accepted_weight / total_weight),
        "harm_rate": float(weight[accepted & (delta < -1.0e-6)].sum() / max(accepted_weight, 1.0e-8)),
        "conditional_support_gain": float((weight[accepted] * delta[accepted]).sum() / max(accepted_weight, 1.0e-8)),
        "set_support": float((weight[active] * chosen_support[active]).sum() / total_weight),
    }


def should_enter_stage_b(gate: dict[str, float | int]) -> bool:
    """Allow retraining only when Stage A can plausibly meet the 2 pp goal.

    An intervention cannot improve an event-level AP by more than its own
    accepted-frame coverage.  The 2% floor therefore follows directly from
    the frozen route acceptance target, without looking at Development.
    """

    return (
        int(gate.get("accepted_frames", 0)) > 0
        and float(gate.get("coverage", 0.0)) >= MINIMUM_PCA_CALIBRATION_COVERAGE
        and float(gate.get("conditional_support_gain", 0.0)) > 1.0e-6
        and float(gate.get("threshold", 1.0)) < 1.0
    )


def select_finalization_stage(gate: dict[str, float | int]) -> str:
    """Preserve a calibrated Stage-A model instead of shifting its gate scale."""

    return "A_FINAL" if should_enter_stage_b(gate) else "NO_GO"


def is_deployable_pca_stage(stage: object) -> bool:
    """Only a calibrated Stage-A final or legacy frozen Stage-B may run."""

    return str(stage) in {"A_FINAL", "B"}


def select_safe_gate_threshold(
    *,
    benefit_probability: np.ndarray,
    selected_candidate_index: np.ndarray,
    target_weight: np.ndarray,
    sample_weight: np.ndarray,
    harm_budget: float,
) -> dict[str, float | int]:
    """Choose a Train-calibrated intervention threshold from set-valued support.

    A selected measured candidate is harmful when it receives less immutable
    R11 support than the identity slot for the same frame.  The threshold is
    chosen without any coordinate label: among thresholds satisfying the harm
    budget, prefer the largest conditional support gain and then coverage.
    If no intervention is safe, the returned threshold is ``1.0``.
    """

    benefit = np.asarray(benefit_probability, dtype=np.float32).reshape(-1)
    selected = np.asarray(selected_candidate_index, dtype=np.int64).reshape(-1)
    target = np.asarray(target_weight, dtype=np.float32)
    weight = np.asarray(sample_weight, dtype=np.float32).reshape(-1)
    if not 0.0 <= harm_budget < 1.0:
        raise ValueError("harm_budget must lie in [0,1)")
    if target.ndim != 2 or target.shape[0] != benefit.size or selected.shape != benefit.shape or weight.shape != benefit.shape:
        raise ValueError("PCA calibration arrays must share a frame axis")
    if np.any(selected < 0) or np.any(selected >= target.shape[1]) or np.any(weight < 0.0):
        raise ValueError("invalid selected candidate or sample weight")

    active = (weight > 0.0) & np.isfinite(benefit)
    base_support = target[:, 0]
    selected_support = target[np.arange(target.shape[0]), selected]
    thresholds = sorted({float(value) for value in benefit[active] if 0.0 <= value <= 1.0}, reverse=True)
    best: dict[str, float | int] | None = None
    for threshold in thresholds:
        accepted = active & (selected != 0) & (benefit >= threshold)
        accepted_weight = float(weight[accepted].sum())
        if accepted_weight <= 0.0:
            continue
        delta = selected_support - base_support
        harm_rate = float(weight[accepted & (delta < -1.0e-6)].sum() / accepted_weight)
        if harm_rate > harm_budget:
            continue
        conditional_gain = float((weight[accepted] * delta[accepted]).sum() / accepted_weight)
        # A gate is a rescue mechanism, not a tie-breaker: zero-support
        # changes are indistinguishable from identity under set supervision.
        if conditional_gain <= 1.0e-6:
            continue
        candidate = {
            "threshold": round(float(threshold), 6),
            "accepted_frames": int(accepted.sum()),
            "accepted_weight": accepted_weight,
            "coverage": float(accepted_weight / max(float(weight[active].sum()), 1.0e-8)),
            "harm_rate": harm_rate,
            "conditional_support_gain": conditional_gain,
        }
        if best is None or (candidate["conditional_support_gain"], candidate["coverage"]) > (best["conditional_support_gain"], best["coverage"]):
            best = candidate
    if best is not None:
        return best
    return {
        "threshold": 1.0,
        "accepted_frames": 0,
        "accepted_weight": 0.0,
        "coverage": 0.0,
        "harm_rate": 0.0,
        "conditional_support_gain": 0.0,
    }
