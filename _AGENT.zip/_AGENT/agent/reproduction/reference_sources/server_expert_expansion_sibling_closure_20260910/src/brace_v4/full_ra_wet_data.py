"""Data and provenance contract for the full-resolution wet-return experts."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset


FULL_RA_CACHE_SCHEMA = "full_ra_wet_cache_v1"
FULL_RA_PROTOCOL_SCHEMA = "full_ra_wet_expert_protocol_v1"
_FORBIDDEN_FLAGS = (
    "target_final_bev_read",
    "development_labels_read",
    "locked_test_read",
    "right_rgb_read",
    "manual_ra_anchor_at_label_stage",
    "depth_read",
    "rd_read",
)


@dataclass(frozen=True)
class FullRAWetProtocol:
    window_frames: int
    fit_sequences: tuple[str, ...]
    calibration_sequences: tuple[str, ...]
    development_sequences: tuple[str, ...]
    identity_only_sequences: tuple[str, ...]
    runtime_modalities: tuple[str, ...]


def _sequence_tuple(payload: Mapping[str, object], key: str) -> tuple[str, ...]:
    values = payload.get(key)
    if not isinstance(values, list) or not values or not all(isinstance(value, str) for value in values):
        raise ValueError(f"{key} must be a non-empty sequence list")
    result = tuple(values)
    if len(set(result)) != len(result):
        raise ValueError(f"{key} contains duplicate sequences")
    return result


def load_full_ra_wet_protocol(path: str | Path) -> FullRAWetProtocol:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema_version") != FULL_RA_PROTOCOL_SCHEMA:
        raise ValueError("unsupported full-RA wet protocol schema")
    if bool(payload.get("locked_test_open", True)):
        raise ValueError("Locked Test must remain closed")
    modalities = tuple(payload.get("runtime_modalities", ()))
    if modalities != ("RA", "RA-MTI"):
        raise ValueError("runtime modalities must be exactly RA and RA-MTI")
    window = int(payload.get("window_frames", 0))
    if window < 2:
        raise ValueError("window_frames must be at least two")
    protocol = FullRAWetProtocol(
        window_frames=window,
        fit_sequences=_sequence_tuple(payload, "fit_sequences"),
        calibration_sequences=_sequence_tuple(payload, "calibration_sequences"),
        development_sequences=_sequence_tuple(payload, "development_sequences"),
        identity_only_sequences=_sequence_tuple(payload, "identity_only_sequences"),
        runtime_modalities=modalities,
    )
    groups = (
        protocol.fit_sequences,
        protocol.calibration_sequences,
        protocol.development_sequences,
        protocol.identity_only_sequences,
    )
    flattened = [sequence for group in groups for sequence in group]
    if len(set(flattened)) != len(flattened):
        raise ValueError("protocol sequence partitions must be disjoint")
    return protocol


def causal_window_indices(*, frame_count: int, window_frames: int) -> np.ndarray:
    if frame_count < 1 or window_frames < 1:
        raise ValueError("frame_count and window_frames must be positive")
    current = np.arange(frame_count, dtype=np.int64)[:, None]
    offset = np.arange(window_frames - 1, -1, -1, dtype=np.int64)[None, :]
    return np.maximum(current - offset, 0)


def load_rainy_day_background(path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    with np.load(Path(path), allow_pickle=False) as archive:
        required = ("RA_mean_db", "RA_std_db", "RA-MIT_mean_db", "RA-MIT_std_db")
        if any(key not in archive for key in required):
            raise ValueError("background archive is missing RA/RA-MTI statistics")
        mean = np.stack((archive["RA_mean_db"], archive["RA-MIT_mean_db"]), axis=0).astype(np.float32)
        std = np.stack((archive["RA_std_db"], archive["RA-MIT_std_db"]), axis=0).astype(np.float32)
    if mean.shape != (2, 128, 128) or std.shape != mean.shape:
        raise ValueError("background RA/RA-MTI statistics must be [2,128,128]")
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std <= 0.0):
        raise ValueError("background statistics must be finite with positive standard deviation")
    return mean, std


def validate_full_ra_cache(payload: Mapping[str, np.ndarray], *, require_targets: bool) -> None:
    schema = str(np.asarray(payload.get("schema_version", "")).item())
    if schema != FULL_RA_CACHE_SCHEMA:
        raise ValueError("unsupported full-RA cache schema")
    for key in _FORBIDDEN_FLAGS:
        if bool(np.asarray(payload.get(key, True)).item()):
            raise ValueError("full-RA cache contains forbidden provenance")
    route = str(np.asarray(payload.get("route", "")).item())
    if route != "outdoor_wet_return":
        raise ValueError("full-RA wet cache must contain the wet-return route")
    radar = np.asarray(payload.get("radar_frame_db"))
    frame_id = np.asarray(payload.get("frame_id"))
    coordinate = np.asarray(payload.get("candidate_xy_m"), dtype=np.float32)
    valid = np.asarray(payload.get("candidate_valid"), dtype=np.bool_)
    if radar.ndim != 4 or radar.shape[1:] != (2, 128, 128):
        raise ValueError("radar_frame_db must be [frames,2,128,128]")
    frames = radar.shape[0]
    if frame_id.shape != (frames,) or coordinate.ndim != 3 or coordinate.shape[0] != frames or coordinate.shape[-1] != 2:
        raise ValueError("full-RA cache frame arrays do not align")
    if valid.shape != coordinate.shape[:2]:
        raise ValueError("candidate_valid does not align with candidate coordinates")
    identity_index = int(np.asarray(payload.get("identity_candidate_index", -1)).item())
    if identity_index != 0 or not valid[:, 0].all() or not np.isfinite(coordinate[:, 0]).all():
        raise ValueError("candidate zero must be the finite valid identity action")
    if not np.isfinite(radar).all():
        raise ValueError("radar frames must be finite")
    if require_targets:
        target = np.asarray(payload.get("target_weight"), dtype=np.float32)
        weight = np.asarray(payload.get("sample_weight"), dtype=np.float32)
        if target.shape != valid.shape or weight.shape != (frames,):
            raise ValueError("training targets do not align with candidates")
        if np.any(target < 0.0) or np.any(weight < 0.0):
            raise ValueError("training weights must be non-negative")
        mass = target.sum(axis=1)
        supervised = weight > 0.0
        if np.any(supervised & ~np.isclose(mass, 1.0, atol=1.0e-4)):
            raise ValueError("supervised target distributions must be normalized")
        if np.any((~valid) & (target > 0.0)):
            raise ValueError("target mass cannot be assigned to invalid candidates")


def load_full_ra_cache(path: str | Path, *, require_targets: bool) -> dict[str, np.ndarray]:
    with np.load(Path(path), allow_pickle=False) as archive:
        payload = {key: archive[key].copy() for key in archive.files}
    validate_full_ra_cache(payload, require_targets=require_targets)
    return payload


class FullRASequenceWindowDataset(Dataset[dict[str, Tensor]]):
    """Expose one causal window per frame from one immutable sequence cache."""

    def __init__(
        self,
        payload: Mapping[str, np.ndarray],
        background_mean_db: np.ndarray,
        background_std_db: np.ndarray,
        *,
        window_frames: int,
        require_targets: bool,
    ) -> None:
        validate_full_ra_cache(payload, require_targets=require_targets)
        self.radar = torch.from_numpy(np.asarray(payload["radar_frame_db"], dtype=np.float32))
        self.candidate_xy = torch.from_numpy(np.asarray(payload["candidate_xy_m"], dtype=np.float32))
        self.candidate_valid = torch.from_numpy(np.asarray(payload["candidate_valid"], dtype=np.bool_))
        self.candidate_unary = torch.from_numpy(np.asarray(payload["candidate_unary_logits"], dtype=np.float32))
        self.base_score = torch.from_numpy(np.asarray(payload["se2_peak_score"], dtype=np.float32))
        self.frame_id = torch.from_numpy(np.asarray(payload["frame_id"], dtype=np.int64))
        self.background_mean = torch.from_numpy(np.asarray(background_mean_db, dtype=np.float32))
        self.background_std = torch.from_numpy(np.asarray(background_std_db, dtype=np.float32))
        self.window_index = torch.from_numpy(
            causal_window_indices(frame_count=len(self.frame_id), window_frames=window_frames)
        )
        if require_targets:
            self.target_weight = torch.from_numpy(np.asarray(payload["target_weight"], dtype=np.float32))
            self.sample_weight = torch.from_numpy(np.asarray(payload["sample_weight"], dtype=np.float32))
        else:
            candidates = self.candidate_xy.shape[1]
            self.target_weight = torch.zeros(len(self.frame_id), candidates, dtype=torch.float32)
            self.sample_weight = torch.zeros(len(self.frame_id), dtype=torch.float32)

    def __len__(self) -> int:
        return int(self.frame_id.numel())

    def __getitem__(self, index: int) -> dict[str, Tensor]:
        window = self.window_index[index]
        target = torch.zeros((len(window), self.target_weight.shape[1]), dtype=torch.float32)
        weight = torch.zeros(len(window), dtype=torch.float32)
        target[-1] = self.target_weight[index]
        weight[-1] = self.sample_weight[index]
        return {
            "radar_clip_db": self.radar[window],
            "background_mean_db": self.background_mean,
            "background_std_db": self.background_std,
            "candidate_xy_m": self.candidate_xy[window],
            "candidate_valid": self.candidate_valid[window],
            "candidate_unary_logits": self.candidate_unary[window],
            "base_score": self.base_score[window],
            "target_weight": target,
            "sample_weight": weight,
            "frame_id": self.frame_id[index],
            "frame_index": torch.tensor(index, dtype=torch.int64),
        }
