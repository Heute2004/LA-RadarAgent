#!/usr/bin/env python3
"""Train one full-resolution RA/RA-MTI wet-return expert."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import ConcatDataset, DataLoader

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.full_ra_wet_data import (
    FullRASequenceWindowDataset,
    load_full_ra_cache,
    load_full_ra_wet_protocol,
)
from brace_v4.full_ra_wet_expert import (
    FullRAWetExpert,
    candidate_equivalent_target_support,
    set_mass_nll,
    transition_excess_loss,
)


CHECKPOINT_SCHEMA = "full_ra_wet_expert_checkpoint_v1"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def mask_targets_to_action_space(
    target_weight: Tensor,
    sample_weight: Tensor,
    action_valid: Tensor | None,
) -> tuple[Tensor, Tensor]:
    """Drop weak targets that the registered expert action space cannot execute."""

    if action_valid is None:
        return target_weight.float(), sample_weight.float()
    if action_valid.shape != target_weight.shape:
        raise ValueError("action_valid must align with target_weight")
    masked_target = target_weight.float() * action_valid.to(target_weight.dtype)
    target_mass = masked_target.sum(dim=-1, keepdim=True)
    masked_target = torch.where(
        target_mass > 0.0,
        masked_target / target_mass.clamp_min(1.0e-8),
        torch.zeros_like(masked_target),
    )
    masked_weight = sample_weight.float() * target_mass.squeeze(-1).gt(0.0).to(sample_weight.dtype)
    return masked_target, masked_weight


def full_ra_training_loss(
    output: dict[str, Tensor],
    target_weight: Tensor,
    sample_weight: Tensor,
    candidate_xy_m: Tensor,
    *,
    candidate_loss_weight: float = 1.0,
    benefit_loss_weight: float = 0.25,
    transition_loss_weight: float = 0.03,
    coordinate_loss_weight: float = 0.75,
    maximum_step_m: float = 0.30,
    identity_equivalence_radius_m: float = 0.20,
) -> tuple[Tensor, dict[str, float]]:
    target_weight, sample_weight = mask_targets_to_action_space(
        target_weight,
        sample_weight,
        output.get("action_valid"),
    )
    candidate_nll = set_mass_nll(output["candidate_logits"], target_weight, sample_weight)
    equivalent_support = candidate_equivalent_target_support(
        target_weight,
        candidate_xy_m,
        radius_m=identity_equivalence_radius_m,
    )
    benefit_target = (1.0 - equivalent_support[..., 0]).clamp(0.0, 1.0)
    benefit_raw = torch.nn.functional.binary_cross_entropy_with_logits(
        output["benefit_logit"].float(), benefit_target.float(), reduction="none"
    )
    denominator = sample_weight.float().sum().clamp_min(1.0e-6)
    benefit_bce = (benefit_raw * sample_weight.float()).sum() / denominator
    coordinate = torch.nan_to_num(candidate_xy_m.float(), nan=0.0)
    expected_xy = (output["candidate_probability"].float()[..., None] * coordinate).sum(dim=-2)
    transition = transition_excess_loss(expected_xy, maximum_step_m=maximum_step_m)
    active = sample_weight.float().sum().gt(0.0).to(transition.dtype)
    transition = transition * active
    coordinate_loss = candidate_nll * 0.0
    recovery_center = output.get("recovery_center_xy_m")
    if recovery_center is not None:
        if recovery_center.shape != candidate_xy_m.shape[:2] + (2,):
            raise ValueError("recovery_center_xy_m must be [B,T,2]")
        target_mass = target_weight.float().sum(dim=-1)
        target_xy = (
            target_weight.float()[..., None] * torch.nan_to_num(candidate_xy_m.float(), nan=0.0)
        ).sum(dim=-2) / target_mass.clamp_min(1.0e-8)[..., None]
        usable = (sample_weight.float() > 0.0) & (target_mass > 0.0)
        if bool(usable.any()):
            per_frame = torch.nn.functional.smooth_l1_loss(
                recovery_center.float(), target_xy, reduction="none"
            ).sum(dim=-1)
            coordinate_loss = (
                per_frame[usable] * sample_weight.float()[usable]
            ).sum() / sample_weight.float()[usable].sum().clamp_min(1.0e-6)
    loss = (
        candidate_loss_weight * candidate_nll
        + benefit_loss_weight * benefit_bce
        + transition_loss_weight * transition
        + coordinate_loss_weight * coordinate_loss
    )
    return loss, {
        "set_mass_nll": float(candidate_nll.detach().cpu()),
        "benefit_bce": float(benefit_bce.detach().cpu()),
        "transition_loss": float(transition.detach().cpu()),
        "coordinate_loss": float(coordinate_loss.detach().cpu()),
        "loss": float(loss.detach().cpu()),
    }


def _background(cache_dir: Path) -> tuple[np.ndarray, np.ndarray]:
    with np.load(cache_dir / "background_stats.npz", allow_pickle=False) as archive:
        mean = archive["mean_db"].astype(np.float32)
        std = archive["std_db"].astype(np.float32)
    return mean, std


def _dataset(cache_dir: Path, sequences: tuple[str, ...], window: int, *, require_targets: bool):
    mean, std = _background(cache_dir)
    datasets = [
        FullRASequenceWindowDataset(
            load_full_ra_cache(cache_dir / f"{sequence}.npz", require_targets=require_targets),
            mean,
            std,
            window_frames=window,
            require_targets=require_targets,
        )
        for sequence in sequences
    ]
    return ConcatDataset(datasets), datasets


def _move(batch: dict[str, Tensor], device: torch.device) -> dict[str, Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


def _forward(model: FullRAWetExpert, batch: dict[str, Tensor]) -> dict[str, Tensor]:
    return model(
        radar_clip_db=batch["radar_clip_db"],
        background_mean_db=batch["background_mean_db"],
        background_std_db=batch["background_std_db"],
        candidate_xy_m=batch["candidate_xy_m"],
        candidate_valid=batch["candidate_valid"],
        candidate_unary_logits=batch["candidate_unary_logits"],
        base_score=batch["base_score"],
    )


@torch.inference_mode()
def collect_calibration(
    model: FullRAWetExpert,
    loader: DataLoader,
    device: torch.device,
    *,
    identity_equivalence_radius_m: float,
) -> dict[str, np.ndarray]:
    model.eval()
    collected: dict[str, list[np.ndarray]] = {
        "selected": [],
        "benefit": [],
        "identity_support": [],
        "selected_support": [],
        "weight": [],
        "candidate_nll": [],
    }
    for raw in loader:
        batch = _move(raw, device)
        output = _forward(model, batch)
        last_logits = output["candidate_logits"][:, -1:]
        last_target = batch["target_weight"][:, -1:]
        last_weight = batch["sample_weight"][:, -1:]
        last_xy = batch["candidate_xy_m"][:, -1:]
        last_action_valid = output.get("action_valid")
        if last_action_valid is not None:
            last_action_valid = last_action_valid[:, -1:]
        last_target, last_weight = mask_targets_to_action_space(last_target, last_weight, last_action_valid)
        nll = set_mass_nll(last_logits, last_target, last_weight)
        selected = output["selected_candidate_index"][:, -1]
        support = candidate_equivalent_target_support(
            last_target,
            last_xy,
            radius_m=identity_equivalence_radius_m,
        )
        selected_support = support[:, 0].gather(1, selected[:, None])[:, 0]
        collected["selected"].append(selected.cpu().numpy())
        collected["benefit"].append(output["benefit_probability"][:, -1].cpu().numpy())
        collected["identity_support"].append(support[:, 0, 0].cpu().numpy())
        collected["selected_support"].append(selected_support.cpu().numpy())
        collected["weight"].append(last_weight[:, 0].cpu().numpy())
        collected["candidate_nll"].append(np.asarray([float(nll.cpu())], dtype=np.float32))
    return {key: np.concatenate(value) for key, value in collected.items()}


def calibrate_threshold(prediction: dict[str, np.ndarray], *, harm_budget: float) -> dict[str, float]:
    selected = prediction["selected"].astype(np.int64)
    benefit = prediction["benefit"].astype(np.float64)
    identity_support = prediction["identity_support"].astype(np.float64)
    selected_support = prediction["selected_support"].astype(np.float64)
    weight = prediction["weight"].astype(np.float64)
    usable = weight > 0.0
    if not np.any(usable):
        raise ValueError("calibration split has no supervised weak-label frames")
    best = {"threshold": 1.1, "weak_support": float(np.average(identity_support[usable], weights=weight[usable])), "weak_harm": 0.0, "coverage": 0.0}
    for threshold in np.linspace(0.0, 1.0, 101):
        accepted = usable & (benefit >= threshold) & (selected != 0)
        final_support = np.where(accepted, selected_support, identity_support)
        harm = accepted & (selected_support + 1.0e-8 < identity_support)
        weak_harm = float(weight[harm].sum() / max(weight[usable].sum(), 1.0e-8))
        support = float(np.average(final_support[usable], weights=weight[usable]))
        coverage = float(weight[accepted].sum() / max(weight[usable].sum(), 1.0e-8))
        better = support > best["weak_support"] + 1.0e-9
        tied_support = abs(support - best["weak_support"]) <= 1.0e-9
        safer = weak_harm < best["weak_harm"] - 1.0e-9
        tied_harm = abs(weak_harm - best["weak_harm"]) <= 1.0e-9
        more_conservative = coverage < best["coverage"] - 1.0e-9
        if weak_harm <= harm_budget and (better or (tied_support and (safer or (tied_harm and more_conservative)))):
            best = {"threshold": float(threshold), "weak_support": support, "weak_harm": weak_harm, "coverage": coverage}
    return best


def cpu_state(model: torch.nn.Module) -> dict[str, Tensor]:
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--model-kind",
        choices=(
            "transformer",
            "convgru_unet",
            "trod_window",
            "graph_tbd",
            "candidate_graph",
            "gg_srre_recovery",
            "gg_srre_recovery_lite",
        ),
        required=True,
    )
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "FULL_RA_WET_EXPERT_PROTOCOL.json")
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--feature-dim", type=int, default=64)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"training output is not empty: {args.output_dir}")
    protocol = load_full_ra_wet_protocol(args.protocol)
    raw_protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    train_cfg = raw_protocol["training"]
    seed_everything(int(train_cfg["seed"]))
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("full-RA expert training requires CUDA")
    fit, fit_parts = _dataset(args.cache_dir, protocol.fit_sequences, protocol.window_frames, require_targets=True)
    calibration, calibration_parts = _dataset(
        args.cache_dir, protocol.calibration_sequences, protocol.window_frames, require_targets=True
    )
    candidate_count = int(fit_parts[0].candidate_xy.shape[1])
    if any(int(dataset.candidate_xy.shape[1]) != candidate_count for dataset in fit_parts + calibration_parts):
        raise ValueError("full-RA caches disagree on candidate count")
    train_loader = DataLoader(
        fit,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.workers > 0,
    )
    calibration_loader = DataLoader(
        calibration,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.workers > 0,
    )
    model = FullRAWetExpert(
        model_kind=args.model_kind,
        candidate_count=candidate_count,
        feature_dim=args.feature_dim,
        maximum_correction_m=float(train_cfg["maximum_correction_m"]),
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=float(train_cfg["learning_rate"]), weight_decay=float(train_cfg["weight_decay"])
    )
    scaler = torch.cuda.amp.GradScaler(enabled=device.type == "cuda")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    contract = {
        "schema_version": CHECKPOINT_SCHEMA,
        "model_kind": args.model_kind,
        "candidate_count": candidate_count,
        "feature_dim": args.feature_dim,
        "maximum_correction_m": float(train_cfg["maximum_correction_m"]),
        "fit_sequences": list(protocol.fit_sequences),
        "calibration_sequences": list(protocol.calibration_sequences),
        "identity_only_sequences": list(protocol.identity_only_sequences),
        "protocol_sha256": sha256(args.protocol),
        "cache_manifest_sha256": sha256(args.cache_dir / "CACHE_MANIFEST.json"),
        "runtime_modalities": ["RA", "RA-MTI"],
        "target_final_bev_read": False,
        "development_read": False,
        "locked_test_read": False,
        "depth_read": False,
        "rd_read": False,
        "right_rgb_read": False,
        "manual_ra_anchor_at_label_stage": False,
        "model_future_frame_input": False,
        "night_policy": "exact identity fallback",
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "identity_equivalence_radius_m": float(train_cfg["identity_equivalence_radius_m"]),
    }
    (args.output_dir / "run_contract.json").write_text(json.dumps(contract, indent=2) + "\n", encoding="utf-8")
    history: list[dict[str, float | int]] = []
    best_state = None
    best_gate = None
    best_support = -np.inf
    best_nll = np.inf
    best_epoch = 0
    stale = 0
    for epoch in range(1, int(train_cfg["epochs"]) + 1):
        model.train()
        totals = {
            "loss": 0.0,
            "set_mass_nll": 0.0,
            "benefit_bce": 0.0,
            "transition_loss": 0.0,
            "coordinate_loss": 0.0,
        }
        steps = 0
        for raw in train_loader:
            batch = _move(raw, device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"):
                output = _forward(model, batch)
                loss, detail = full_ra_training_loss(
                    output,
                    batch["target_weight"],
                    batch["sample_weight"],
                    batch["candidate_xy_m"],
                    candidate_loss_weight=float(train_cfg["candidate_loss_weight"]),
                    benefit_loss_weight=float(train_cfg["benefit_loss_weight"]),
                    transition_loss_weight=float(train_cfg["transition_loss_weight"]),
                    coordinate_loss_weight=float(train_cfg.get("coordinate_loss_weight", 0.75)),
                    maximum_step_m=float(train_cfg["maximum_step_m"]),
                    identity_equivalence_radius_m=float(train_cfg["identity_equivalence_radius_m"]),
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            for key in totals:
                totals[key] += detail[key]
            steps += 1
        prediction = collect_calibration(
            model,
            calibration_loader,
            device,
            identity_equivalence_radius_m=float(train_cfg["identity_equivalence_radius_m"]),
        )
        gate = calibrate_threshold(prediction, harm_budget=float(train_cfg["weak_harm_budget"]))
        calibration_nll = float(np.mean(prediction["candidate_nll"]))
        row = {
            "epoch": epoch,
            **{key: value / max(steps, 1) for key, value in totals.items()},
            "calibration_candidate_nll": calibration_nll,
            **gate,
        }
        history.append(row)
        better = (gate["weak_support"] > best_support + 1.0e-7) or (
            abs(gate["weak_support"] - best_support) <= 1.0e-7 and calibration_nll < best_nll
        )
        if better:
            best_state = cpu_state(model)
            best_gate = gate
            best_support = float(gate["weak_support"])
            best_nll = calibration_nll
            best_epoch = epoch
            stale = 0
        else:
            stale += 1
        print(json.dumps(row), flush=True)
        if stale >= int(train_cfg["patience"]):
            break
    if best_state is None or best_gate is None:
        raise RuntimeError("training did not produce a checkpoint")
    checkpoint = contract | {
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "selected_epoch": best_epoch,
        "gate": best_gate,
        "model_state": best_state,
    }
    checkpoint_path = args.output_dir / "FULL_RA_WET_EXPERT_FINAL.pt"
    torch.save(checkpoint, checkpoint_path)
    (args.output_dir / "history.json").write_text(json.dumps(history, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "TRAINING_COMPLETE.json").write_text(
        json.dumps(
            {
                "schema_version": "full_ra_wet_training_complete_v1",
                "model_kind": args.model_kind,
                "selected_epoch": best_epoch,
                "gate": best_gate,
                "checkpoint": checkpoint_path.name,
                "checkpoint_sha256": sha256(checkpoint_path),
                "development_read": False,
                "locked_test_read": False,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
