#!/usr/bin/env python3
"""Train one daytime wet-return physical-candidate association expert."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor
from torch.nn import functional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.r11_physical_candidate_association import validate_pca_cache_contract
from brace_v4.wet_return_candidate_association import (
    WetReturnCandidateAssociationExpert,
    map_offline_teacher_to_physical_candidates,
    physical_only_targets,
    validate_daytime_wet_split,
)


CHECKPOINT_SCHEMA = "brace_v4_wrca_checkpoint_v1"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument(
        "--protocol",
        type=Path,
        default=ROOT / "configs" / "WRCA_DAYTIME_PROTOCOL_V1.json",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--supervision-root",
        type=Path,
        help="Offline daytime teacher predictions used only to rank measured candidates.",
    )
    parser.add_argument("--maximum-teacher-mapping-error-m", type=float, default=0.30)
    parser.add_argument("--teacher-target-sigma-m", type=float, default=0.12)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def load_protocol(path: Path, variant: str) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "brace_v4_wrca_daytime_protocol_v1":
        raise ValueError("unsupported WRCA protocol")
    if payload.get("route") != "outdoor_wet_return":
        raise ValueError("WRCA protocol route mismatch")
    if bool(payload.get("identity_in_physical_candidate_softmax", True)):
        raise ValueError("WRCA must exclude identity from physical association")
    forbidden = (
        "locked_test_read",
        "development_labels_read_during_training",
        "target_final_bev_read_during_training",
        "depth_read",
        "right_rgb_read",
        "manual_ra_anchor_at_label_stage",
        "model_future_frame_input",
    )
    if any(bool(payload.get(key, True)) for key in forbidden):
        raise ValueError("WRCA protocol permits a forbidden read")
    if variant not in payload.get("variants", {}):
        raise ValueError(f"unknown WRCA variant: {variant}")
    validate_daytime_wet_split(
        fit_sequences=payload["fit_sequences"],
        calibration_sequences=payload["calibration_sequences"],
        development_sequences=payload["development_sequences"],
    )
    return payload


def load_record(cache_dir: Path, sequence: str) -> dict[str, np.ndarray]:
    path = cache_dir / f"{sequence}.npz"
    if not path.is_file():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        record = {key: archive[key].copy() for key in archive.files}
    validate_pca_cache_contract(record, require_train_targets=True)
    if str(np.asarray(record["sequence"]).item()) != sequence:
        raise ValueError("WRCA cache sequence mismatch")
    if str(np.asarray(record["route"]).item()) != "outdoor_wet_return":
        raise ValueError("WRCA cache route mismatch")
    return record


def load_teacher_record(supervision_root: Path, sequence: str) -> dict[str, np.ndarray]:
    path = supervision_root / f"{sequence}.npz"
    if not path.is_file():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        teacher = {key: archive[key].copy() for key in archive.files}
    required = {
        "sequence",
        "frame_id",
        "selected_candidate_xy_m",
        "sample_weight",
        "training_mask",
        "radar_training_valid",
        "visual_measurement_supported",
    }
    missing = sorted(required - set(teacher))
    if missing:
        raise ValueError(f"offline teacher is missing fields: {missing}")
    return teacher


def apply_offline_supervision(
    records: list[dict[str, np.ndarray]],
    *,
    supervision_root: Path,
    allowed_sequences: list[str],
    maximum_mapping_error_m: float,
    target_sigma_m: float,
) -> tuple[list[dict[str, np.ndarray]], list[dict[str, float | int | str]]]:
    mapped_records: list[dict[str, np.ndarray]] = []
    audits: list[dict[str, float | int | str]] = []
    for record in records:
        sequence = str(np.asarray(record["sequence"]).item())
        teacher = load_teacher_record(supervision_root, sequence)
        mapped, audit = map_offline_teacher_to_physical_candidates(
            record,
            teacher,
            allowed_sequences=allowed_sequences,
            maximum_mapping_error_m=maximum_mapping_error_m,
            target_sigma_m=target_sigma_m,
        )
        mapped_records.append(mapped)
        audits.append(audit)
    return mapped_records, audits


def record_tensors(record: dict[str, np.ndarray], device: torch.device) -> dict[str, Tensor]:
    values = {
        "candidate_token": torch.from_numpy(np.asarray(record["candidate_token"][:, 1:], dtype=np.float32)).unsqueeze(0).to(device),
        "candidate_xy_m": torch.from_numpy(np.asarray(record["candidate_xy_m"][:, 1:], dtype=np.float32)).unsqueeze(0).to(device),
        "candidate_valid": torch.from_numpy(np.asarray(record["candidate_valid"][:, 1:], dtype=bool)).unsqueeze(0).to(device),
        "candidate_unary_logits": torch.from_numpy(np.asarray(record["candidate_unary_logits"][:, 1:], dtype=np.float32)).unsqueeze(0).to(device),
        "global_state": torch.from_numpy(np.asarray(record["global_state"], dtype=np.float32)).unsqueeze(0).to(device),
        "parent_xy_m": torch.from_numpy(np.asarray(record["candidate_xy_m"][:, 0], dtype=np.float32)).unsqueeze(0).to(device),
        "full_target_weight": torch.from_numpy(np.asarray(record["target_weight"], dtype=np.float32)).unsqueeze(0).to(device),
        "sample_weight": torch.from_numpy(np.asarray(record["sample_weight"], dtype=np.float32)).unsqueeze(0).to(device),
    }
    if "candidate_patch" in record:
        values["candidate_patch"] = torch.from_numpy(
            np.asarray(record["candidate_patch"][:, 1:], dtype=np.float32)
        ).unsqueeze(0).to(device)
    return values


def model_forward(
    model: WetReturnCandidateAssociationExpert,
    tensors: dict[str, Tensor],
) -> dict[str, Tensor]:
    return model(
        candidate_token=tensors["candidate_token"],
        candidate_xy_m=tensors["candidate_xy_m"],
        candidate_valid=tensors["candidate_valid"],
        candidate_unary_logits=tensors["candidate_unary_logits"],
        global_state=tensors["global_state"],
        parent_xy_m=tensors["parent_xy_m"],
        candidate_patch=tensors.get("candidate_patch"),
    )


def weighted_loss(
    output: dict[str, Tensor],
    tensors: dict[str, Tensor],
    *,
    candidate_loss_weight: float,
    benefit_loss_weight: float,
) -> tuple[Tensor, dict[str, float]]:
    physical_target, association_weight, _ = physical_only_targets(
        tensors["full_target_weight"], tensors["sample_weight"]
    )
    candidate_denominator = association_weight.sum().clamp_min(1.0e-6)
    candidate_nll = -(
        (physical_target * functional.log_softmax(output["physical_candidate_logits"], dim=-1)).sum(dim=-1)
        * association_weight
    ).sum() / candidate_denominator

    selected_full = output["selected_physical_index"] + 1
    selected_support = tensors["full_target_weight"].gather(-1, selected_full[..., None]).squeeze(-1)
    identity_support = tensors["full_target_weight"][..., 0]
    benefit_target = (selected_support > identity_support).float()
    benefit_weight = tensors["sample_weight"]
    benefit_denominator = benefit_weight.sum().clamp_min(1.0e-6)
    benefit_bce = (
        functional.binary_cross_entropy_with_logits(
            output["benefit_logit"], benefit_target, reduction="none"
        )
        * benefit_weight
    ).sum() / benefit_denominator
    total = float(candidate_loss_weight) * candidate_nll + float(benefit_loss_weight) * benefit_bce
    return total, {
        "candidate_nll": float(candidate_nll.detach().cpu()),
        "benefit_bce": float(benefit_bce.detach().cpu()),
    }


def select_train_internal_gate(
    *,
    benefit_probability: np.ndarray,
    selected_full_index: np.ndarray,
    target_weight: np.ndarray,
    sample_weight: np.ndarray,
    harm_budget: float,
    minimum_coverage: float,
) -> dict[str, float | int]:
    benefit = np.asarray(benefit_probability, dtype=np.float32).reshape(-1)
    selected = np.asarray(selected_full_index, dtype=np.int64).reshape(-1)
    target = np.asarray(target_weight, dtype=np.float32)
    weight = np.asarray(sample_weight, dtype=np.float32).reshape(-1)
    active = (weight > 0.0) & np.isfinite(benefit)
    total_weight = max(float(weight[active].sum()), 1.0e-8)
    base_support = target[:, 0]
    selected_support = target[np.arange(target.shape[0]), selected]
    delta = selected_support - base_support
    best: dict[str, float | int] | None = None
    thresholds = sorted({float(value) for value in benefit[active]}, reverse=True)
    for threshold in thresholds:
        accepted = active & (benefit >= threshold)
        accepted_weight = float(weight[accepted].sum())
        if accepted_weight <= 0.0:
            continue
        coverage = accepted_weight / total_weight
        if coverage < float(minimum_coverage):
            continue
        harm_rate = float(weight[accepted & (delta < -1.0e-6)].sum() / accepted_weight)
        if harm_rate > float(harm_budget):
            continue
        overall_gain = float((weight[accepted] * delta[accepted]).sum() / total_weight)
        if overall_gain <= 1.0e-6:
            continue
        conditional_gain = float((weight[accepted] * delta[accepted]).sum() / accepted_weight)
        candidate = {
            "threshold": round(threshold, 6),
            "accepted_frames": int(accepted.sum()),
            "coverage": coverage,
            "harm_rate": harm_rate,
            "conditional_support_gain": conditional_gain,
            "overall_support_gain": overall_gain,
        }
        if best is None or (overall_gain, coverage, conditional_gain) > (
            float(best["overall_support_gain"]),
            float(best["coverage"]),
            float(best["conditional_support_gain"]),
        ):
            best = candidate
    if best is not None:
        return best
    return {
        "threshold": 1.0,
        "accepted_frames": 0,
        "coverage": 0.0,
        "harm_rate": 0.0,
        "conditional_support_gain": 0.0,
        "overall_support_gain": 0.0,
    }


@torch.inference_mode()
def collect_predictions(
    model: WetReturnCandidateAssociationExpert,
    records: list[dict[str, np.ndarray]],
    device: torch.device,
) -> dict[str, np.ndarray]:
    result: dict[str, list[np.ndarray]] = {
        "benefit_probability": [],
        "selected_full_index": [],
        "target_weight": [],
        "sample_weight": [],
    }
    model.eval()
    for record in records:
        tensors = record_tensors(record, device)
        output = model_forward(model, tensors)
        result["benefit_probability"].append(output["benefit_probability"].squeeze(0).cpu().numpy())
        result["selected_full_index"].append((output["selected_physical_index"] + 1).squeeze(0).cpu().numpy())
        result["target_weight"].append(tensors["full_target_weight"].squeeze(0).cpu().numpy())
        result["sample_weight"].append(tensors["sample_weight"].squeeze(0).cpu().numpy())
    return {key: np.concatenate(value, axis=0) for key, value in result.items()}


def train_one_epoch(
    model: WetReturnCandidateAssociationExpert,
    records: list[dict[str, np.ndarray]],
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    *,
    candidate_loss_weight: float,
    benefit_loss_weight: float,
) -> dict[str, float]:
    model.train()
    total = {"loss": 0.0, "candidate_nll": 0.0, "benefit_bce": 0.0}
    for index in np.random.permutation(len(records)):
        tensors = record_tensors(records[int(index)], device)
        output = model_forward(model, tensors)
        loss, detail = weighted_loss(
            output,
            tensors,
            candidate_loss_weight=candidate_loss_weight,
            benefit_loss_weight=benefit_loss_weight,
        )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        total["loss"] += float(loss.detach().cpu())
        total["candidate_nll"] += detail["candidate_nll"]
        total["benefit_bce"] += detail["benefit_bce"]
    return {key: value / len(records) for key, value in total.items()}


def cpu_state_dict(model: torch.nn.Module) -> dict[str, Tensor]:
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def main() -> None:
    args = parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"WRCA output directory is not empty: {args.output_dir}")
    protocol = load_protocol(args.protocol, args.variant)
    training = dict(protocol["training"])
    variant = dict(protocol["variants"][args.variant])
    seed_everything(int(training["seed"]))
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("WRCA training requires CUDA")

    manifest_candidates = (
        args.cache_dir / "R16_NSCAN_TRAIN_MANIFEST.json",
        args.cache_dir / "PCA_TRAIN_MANIFEST.json",
    )
    manifest_path = next((path for path in manifest_candidates if path.is_file()), None)
    if manifest_path is None:
        raise FileNotFoundError(f"missing WRCA cache manifest in {args.cache_dir}")
    fit_records = [load_record(args.cache_dir, sequence) for sequence in protocol["fit_sequences"]]
    calibration_records = [load_record(args.cache_dir, sequence) for sequence in protocol["calibration_sequences"]]
    supervision_audit: dict[str, list[dict[str, float | int | str]]] | None = None
    supervision_manifest_path: Path | None = None
    if args.supervision_root is not None:
        allowed_sequences = list(protocol["fit_sequences"]) + list(protocol["calibration_sequences"])
        fit_records, fit_audit = apply_offline_supervision(
            fit_records,
            supervision_root=args.supervision_root,
            allowed_sequences=allowed_sequences,
            maximum_mapping_error_m=float(args.maximum_teacher_mapping_error_m),
            target_sigma_m=float(args.teacher_target_sigma_m),
        )
        calibration_records, calibration_audit = apply_offline_supervision(
            calibration_records,
            supervision_root=args.supervision_root,
            allowed_sequences=allowed_sequences,
            maximum_mapping_error_m=float(args.maximum_teacher_mapping_error_m),
            target_sigma_m=float(args.teacher_target_sigma_m),
        )
        supervision_audit = {"fit": fit_audit, "calibration": calibration_audit}
        candidate_manifest = args.supervision_root / "PREDICTION_MANIFEST.json"
        supervision_manifest_path = candidate_manifest if candidate_manifest.is_file() else None
    physical_count = int(fit_records[0]["candidate_xy_m"].shape[1] - 1)
    if physical_count < 2:
        raise ValueError("WRCA cache has too few measured candidates")

    model = WetReturnCandidateAssociationExpert(
        candidate_count=physical_count,
        hidden_dim=int(variant["hidden_dim"]),
        maximum_step_m=float(variant["maximum_step_m"]),
        transition_scale_m=float(variant["transition_scale_m"]),
        use_candidate_patches=bool(variant["use_candidate_patches"]),
        use_existence_state=bool(variant["use_existence_state"]),
        background_emphasis=float(variant["background_emphasis"]),
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(training["learning_rate"]),
        weight_decay=float(training["weight_decay"]),
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    contract = {
        "schema_version": CHECKPOINT_SCHEMA,
        "architecture": "WetReturnCandidateAssociationExpert",
        "variant": args.variant,
        "route": "outdoor_wet_return",
        "physical_candidate_count": physical_count,
        "variant_config": variant,
        "protocol_sha256": sha256(args.protocol),
        "cache_manifest_sha256": sha256(manifest_path),
        "supervision": "offline_daytime_visual_radar_candidate_teacher" if args.supervision_root is not None else "embedded_cache_weak_set",
        "supervision_root": str(args.supervision_root) if args.supervision_root is not None else None,
        "supervision_manifest_sha256": sha256(supervision_manifest_path) if supervision_manifest_path is not None else None,
        "maximum_teacher_mapping_error_m": float(args.maximum_teacher_mapping_error_m) if args.supervision_root is not None else None,
        "teacher_target_sigma_m": float(args.teacher_target_sigma_m) if args.supervision_root is not None else None,
        "supervision_audit": supervision_audit,
        "fit_sequences": list(protocol["fit_sequences"]),
        "calibration_sequences": list(protocol["calibration_sequences"]),
        "development_sequences": list(protocol["development_sequences"]),
        "identity_in_physical_candidate_softmax": False,
        "nighttime_wet_read": False,
        "development_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
        "depth_read": False,
        "right_rgb_read": False,
        "manual_ra_anchor_at_label_stage": False,
        "model_future_frame_input": False,
    }
    (args.output_dir / "run_contract.json").write_text(
        json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    best_state: dict[str, Tensor] | None = None
    best_gate: dict[str, float | int] | None = None
    best_gain = -np.inf
    best_loss = np.inf
    stale = 0
    history: list[dict[str, float | int]] = []
    for epoch in range(1, int(training["epochs"]) + 1):
        train_stat = train_one_epoch(
            model,
            fit_records,
            optimizer,
            device,
            candidate_loss_weight=float(training["candidate_loss_weight"]),
            benefit_loss_weight=float(training["benefit_loss_weight"]),
        )
        prediction = collect_predictions(model, calibration_records, device)
        gate = select_train_internal_gate(
            benefit_probability=prediction["benefit_probability"],
            selected_full_index=prediction["selected_full_index"],
            target_weight=prediction["target_weight"],
            sample_weight=prediction["sample_weight"],
            harm_budget=float(variant["harm_budget"]),
            minimum_coverage=float(training["minimum_gate_coverage"]),
        )
        row = {"epoch": epoch, **train_stat, **gate}
        history.append(row)
        gain = float(gate["overall_support_gain"])
        better = gain > best_gain + 1.0e-8 or (
            abs(gain - best_gain) <= 1.0e-8 and train_stat["loss"] < best_loss
        )
        if better:
            best_state = cpu_state_dict(model)
            best_gate = gate
            best_gain = gain
            best_loss = train_stat["loss"]
            stale = 0
        else:
            stale += 1
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if stale >= int(training["patience"]):
            break

    if best_state is None or best_gate is None:
        raise RuntimeError("WRCA did not produce a checkpoint")
    checkpoint_path = args.output_dir / "WRCA_FINAL.pt"
    torch.save(
        contract
        | {
            "stage": "TRAIN_INTERNAL_CALIBRATED",
            "gate": best_gate,
            "model_state": best_state,
        },
        checkpoint_path,
    )
    report = {
        "schema_version": "brace_v4_wrca_training_complete_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "variant": args.variant,
        "checkpoint": str(checkpoint_path),
        "checkpoint_sha256": sha256(checkpoint_path),
        "gate": best_gate,
        "development_read": False,
        "nighttime_wet_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "history.json").write_text(
        json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (args.output_dir / "training_complete.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
