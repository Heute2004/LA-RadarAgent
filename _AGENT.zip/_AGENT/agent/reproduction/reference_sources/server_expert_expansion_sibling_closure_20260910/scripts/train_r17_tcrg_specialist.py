#!/usr/bin/env python3
"""Train R17 causal reachability-graph specialists from the immutable R16 cache."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.pca_training import select_finalization_stage, select_safe_gate_threshold
from brace_v4.r11_physical_candidate_association import PCA_RUNTIME_SCHEMA, validate_pca_cache_contract
from brace_v4.r17_tcrg import R17_ARCHITECTURE, CausalReachabilityCandidateGraph, r17_weighted_association_loss


CHECKPOINT_SCHEMA = "brace_v4_r17_tcrg_specialist_checkpoint_v1"
FORBIDDEN = (
    "target_final_bev_read_train",
    "development_read_during_training",
    "locked_test_read",
    "depth_read",
    "right_rgb_read",
    "manual_ra_anchor_at_label_stage",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("indoor_clutter", "outdoor_dry_complex", "outdoor_wet_return"), required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "R17_TCRG_SPECIALISTS_PROTOCOL_V1.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--identity-branch", choices=("cora0", "se1", "se2"), default="se2")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--seed-override", type=int, default=None, help="Independent ensemble seed; the immutable protocol is otherwise unchanged.")
    return parser.parse_args()


def require_protocol(path: Path, route: str) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "brace_v4_r17_tcrg_specialist_protocol_v1" or payload.get("architecture") != R17_ARCHITECTURE:
        raise ValueError("unsupported R17 protocol")
    if int(payload.get("clip_length", 0)) != 16 or bool(payload.get("model_future_frame_input", True)):
        raise ValueError("R17 runtime must consume causal 16-frame radar evidence")
    if not bool(payload.get("teacher_future_frame_input_only", False)):
        raise ValueError("R17 requires an offline-only fixed-lag teacher")
    if any(bool(payload.get(key, True)) for key in FORBIDDEN):
        raise ValueError("R17 protocol permits a forbidden read")
    if not all(bool(payload.get(key, False)) for key in ("cora0_frozen", "se1_frozen", "se2_frozen", "preserve_stage_a_calibration")):
        raise ValueError("R17 must freeze upstream CORA models and preserve calibration")
    if bool(payload.get("stage_b_retrain_all_route_r11", True)):
        raise ValueError("R17 forbids post-calibration full-route retraining")
    profile = payload.get("routes", {}).get(route)
    if not isinstance(profile, dict) or not profile.get("fit_sequences") or not profile.get("calibration_sequences"):
        raise ValueError(f"R17 route profile is incomplete: {route}")
    return profile


def load_record(cache_dir: Path, sequence: str, route: str, identity_branch: str) -> dict[str, np.ndarray]:
    path = cache_dir / f"{sequence}.npz"
    if not path.is_file():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        record = {key: archive[key].copy() for key in archive.files}
    validate_pca_cache_contract(record, require_train_targets=True)
    if str(np.asarray(record["schema_version"]).item()) != PCA_RUNTIME_SCHEMA:
        raise ValueError("R17 expects the PCA runtime-cache schema")
    if str(np.asarray(record["sequence"]).item()) != sequence or str(np.asarray(record["route"]).item()) != route:
        raise ValueError("R17 cache sequence/route mismatch")
    requested_branch = str(identity_branch).strip().lower()
    if "identity_branch" in record:
        cache_branch = str(np.asarray(record["identity_branch"]).item()).strip().lower()
        if cache_branch != requested_branch:
            raise ValueError("R17 cache identity branch does not match the requested fallback")
    else:
        # R22's first cache build predates the scalar provenance field.  Admit
        # it only after verifying the actual candidate-zero coordinates.
        expected_identity = np.asarray(record[f"{requested_branch}_peak_xy_m"], dtype=np.float32)
        if not np.array_equal(np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 0], expected_identity):
            raise ValueError("legacy R17 cache candidate-zero does not match the requested fallback")
    if str(np.asarray(record.get("r16_teacher_schema", "")).item()) != "brace_v4_r16_nscan_path_teacher_v1":
        raise ValueError("R17 accepts only the immutable R16 N-scan training cache")
    agreement = np.asarray(record.get("r16_teacher_agreement"), dtype=bool)
    sample_weight = np.asarray(record["sample_weight"], dtype=np.float32)
    target = np.asarray(record["target_weight"], dtype=np.float32)
    if agreement.shape != sample_weight.shape or target.shape[0] != sample_weight.size:
        raise ValueError("R17 teacher fields do not align")
    if np.any((sample_weight > 0.0) & ~agreement):
        raise ValueError("R17 positive supervision requires bidirectional R16 agreement")
    return record


def tensors_for(record: dict[str, np.ndarray], device: torch.device) -> dict[str, Tensor]:
    return {
        "candidate_token": torch.from_numpy(np.asarray(record["candidate_token"], dtype=np.float32)).unsqueeze(0).to(device),
        "candidate_xy_m": torch.from_numpy(np.asarray(record["candidate_xy_m"], dtype=np.float32)).unsqueeze(0).to(device),
        "candidate_valid": torch.from_numpy(np.asarray(record["candidate_valid"], dtype=bool)).unsqueeze(0).to(device),
        "candidate_unary_logits": torch.from_numpy(np.asarray(record["candidate_unary_logits"], dtype=np.float32)).unsqueeze(0).to(device),
        "global_state": torch.from_numpy(np.asarray(record["global_state"], dtype=np.float32)).unsqueeze(0).to(device),
        "target_weight": torch.from_numpy(np.asarray(record["target_weight"], dtype=np.float32)).unsqueeze(0).to(device),
        "sample_weight": torch.from_numpy(np.asarray(record["sample_weight"], dtype=np.float32)).unsqueeze(0).to(device),
    }


def model_forward(model: CausalReachabilityCandidateGraph, tensors: dict[str, Tensor]) -> dict[str, Tensor]:
    return model(**{key: tensors[key] for key in ("candidate_token", "candidate_xy_m", "candidate_valid", "candidate_unary_logits", "global_state")})


@torch.no_grad()
def collect_predictions(model: CausalReachabilityCandidateGraph, records: list[dict[str, np.ndarray]], device: torch.device) -> dict[str, np.ndarray]:
    aggregate: dict[str, list[np.ndarray]] = {key: [] for key in ("benefit_probability", "selected_candidate_index", "target_weight", "sample_weight", "candidate_nll")}
    model.eval()
    for record in records:
        tensors = tensors_for(record, device)
        output = model_forward(model, tensors)
        _, detail = r17_weighted_association_loss(output, tensors["target_weight"], tensors["sample_weight"], candidate_loss_weight=1.0, benefit_loss_weight=0.0)
        aggregate["benefit_probability"].append(output["benefit_probability"].squeeze(0).cpu().numpy())
        aggregate["selected_candidate_index"].append(output["selected_candidate_index"].squeeze(0).cpu().numpy())
        aggregate["target_weight"].append(tensors["target_weight"].squeeze(0).cpu().numpy())
        aggregate["sample_weight"].append(tensors["sample_weight"].squeeze(0).cpu().numpy())
        aggregate["candidate_nll"].append(np.asarray([float(detail["candidate_nll"].cpu())], dtype=np.float32))
    return {key: np.concatenate(value) for key, value in aggregate.items()}


def train_epoch(
    model: CausalReachabilityCandidateGraph,
    records: list[dict[str, np.ndarray]],
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    *,
    candidate_loss_weight: float,
    benefit_loss_weight: float,
) -> dict[str, float]:
    model.train()
    totals = {"loss": 0.0, "candidate_nll": 0.0, "benefit_bce": 0.0}
    for index in np.random.permutation(len(records)):
        tensors = tensors_for(records[int(index)], device)
        output = model_forward(model, tensors)
        loss, detail = r17_weighted_association_loss(
            output,
            tensors["target_weight"],
            tensors["sample_weight"],
            candidate_loss_weight=candidate_loss_weight,
            benefit_loss_weight=benefit_loss_weight,
        )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        totals["loss"] += float(loss.detach().cpu())
        totals["candidate_nll"] += float(detail["candidate_nll"].cpu())
        totals["benefit_bce"] += float(detail["benefit_bce"].cpu())
    return {key: value / max(len(records), 1) for key, value in totals.items()}


def cpu_state_dict(model: torch.nn.Module) -> dict[str, Tensor]:
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def support_after_gate(prediction: dict[str, np.ndarray], threshold: float) -> float:
    benefit = prediction["benefit_probability"]
    selected = prediction["selected_candidate_index"]
    target = prediction["target_weight"]
    weight = prediction["sample_weight"]
    accepted = (benefit >= float(threshold)) & (selected != 0) & (weight > 0.0)
    chosen = np.where(accepted, selected, 0)
    support = target[np.arange(target.shape[0]), chosen]
    return float((support * weight).sum() / max(float(weight.sum()), 1.0e-8))


def main() -> None:
    args = parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    if not (args.cache_dir / "R16_NSCAN_TRAIN_MANIFEST.json").is_file():
        raise FileNotFoundError("R17 requires R16_NSCAN_TRAIN_MANIFEST.json")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("R17 training requires CUDA")
    profile = require_protocol(args.protocol, args.route)
    identity_branch = str(args.identity_branch).strip().lower()
    training = dict(profile["training"])
    effective_seed = int(training["seed"]) if args.seed_override is None else int(args.seed_override)
    seed_everything(effective_seed)
    fit_sequences = tuple(profile["fit_sequences"])
    calibration_sequences = tuple(profile["calibration_sequences"])
    fit_records = [load_record(args.cache_dir, sequence, args.route, identity_branch) for sequence in fit_sequences]
    calibration_records = [load_record(args.cache_dir, sequence, args.route, identity_branch) for sequence in calibration_sequences]
    candidate_count = int(fit_records[0]["candidate_xy_m"].shape[1])
    if any(int(record["candidate_xy_m"].shape[1]) != candidate_count for record in fit_records + calibration_records):
        raise ValueError("R17 caches do not share a candidate count")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    contract = {
        "schema_version": CHECKPOINT_SCHEMA,
        "architecture": R17_ARCHITECTURE,
        "route": args.route,
        "protocol_sha256": sha256(args.protocol),
        "cache_manifest_sha256": sha256(args.cache_dir / "R16_NSCAN_TRAIN_MANIFEST.json"),
        "fit_sequences": list(fit_sequences),
        "calibration_sequences": list(calibration_sequences),
        "candidate_count": candidate_count,
        "identity_branch": identity_branch,
        "identity_branch_validation": "metadata_or_exact_candidate_zero_coordinate_match",
        "effective_seed": effective_seed,
        "target_final_bev_read": False,
        "development_read": False,
        "locked_test_read": False,
        "depth_read": False,
        "right_rgb_read": False,
        "manual_ra_anchor_at_label_stage": False,
        "model_future_frame_input": False,
        "teacher_future_frame_input_only": True,
        "identity_transition_disabled": True,
        "non_route_behavior": f"exact frozen {identity_branch.upper()} identity",
    }
    (args.output_dir / "run_contract.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    model = CausalReachabilityCandidateGraph(candidate_count=candidate_count).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(training["learning_rate"]), weight_decay=float(training["weight_decay"]))
    best_state: dict[str, Tensor] | None = None
    best_gate: dict[str, float | int] | None = None
    best_support, best_nll, stale, selected_epoch = -np.inf, np.inf, 0, 0
    history: list[dict[str, float | int]] = []
    for epoch in range(1, int(training["epochs"]) + 1):
        train = train_epoch(model, fit_records, optimizer, device, candidate_loss_weight=float(training["candidate_loss_weight"]), benefit_loss_weight=float(training["benefit_loss_weight"]))
        prediction = collect_predictions(model, calibration_records, device)
        gate = select_safe_gate_threshold(
            benefit_probability=prediction["benefit_probability"],
            selected_candidate_index=prediction["selected_candidate_index"],
            target_weight=prediction["target_weight"],
            sample_weight=prediction["sample_weight"],
            harm_budget=float(training["harm_budget"]),
        )
        support = support_after_gate(prediction, float(gate["threshold"]))
        nll = float(prediction["candidate_nll"].mean())
        row = {"epoch": epoch, **train, "calibration_set_support": support, "calibration_candidate_nll": nll, **gate}
        history.append(row)
        better = (support > best_support + 1.0e-7) or (abs(support - best_support) <= 1.0e-7 and nll < best_nll)
        if better:
            best_state, best_gate, best_support, best_nll, stale, selected_epoch = cpu_state_dict(model), gate, support, nll, 0, epoch
        else:
            stale += 1
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if stale >= int(training["patience"]):
            break
    if best_state is None or best_gate is None:
        raise RuntimeError("R17 did not produce a checkpoint")
    finalization = select_finalization_stage(best_gate)
    history_path = args.output_dir / "history.json"
    history_path.write_text(json.dumps({"stage_a": history}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if finalization != "A_FINAL":
        report = contract | {
            "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "selected_stage_a_epoch": selected_epoch,
            "stage_a_gate": best_gate,
            "stage_a_calibration_set_support": best_support,
            "decision": "NO_GO_IDENTITY_ONLY",
            "development_read": False,
            "locked_test_read": False,
        }
        (args.output_dir / "training_no_go.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return
    final_path = args.output_dir / "TCRG_SPECIALIST_FINAL.pt"
    torch.save(contract | {"stage": "A_FINAL", "selected_stage_a_epoch": selected_epoch, "gate": best_gate, "model_state": best_state}, final_path)
    report = contract | {
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "selected_stage_a_epoch": selected_epoch,
        "stage_a_gate": best_gate,
        "stage_a_calibration_set_support": best_support,
        "final_checkpoint": str(final_path),
        "final_checkpoint_sha256": sha256(final_path),
        "development_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "training_complete.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
