"""Fit a second-stage correctness gate for a frozen V4 candidate expert."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as functional
from torch.utils.data import DataLoader, Subset

from brace_v4.self_evolution_candidates import CORARouteExpert, candidate_correctness_target
from brace_v4.self_evolution_data import CandidateCacheDataset


HISTORY_LENGTH = {
    "corner_nlos_ris": 16,
    "indoor_clutter": 6,
    "open_indoor_los": 4,
    "outdoor_dry_complex": 8,
    "outdoor_wet_return": 8,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def move(batch: dict[str, object], device: torch.device) -> dict[str, object]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def forward(model: CORARouteExpert, batch: dict[str, object]) -> dict[str, torch.Tensor]:
    return model(
        batch["history_tokens"],
        batch["base_scores"],
        batch["candidate_quality"],
        batch["runtime_quality"],
    )


def gate_loss(
    output: dict[str, torch.Tensor],
    target_index: torch.Tensor,
    pseudo_accepted: torch.Tensor,
) -> torch.Tensor:
    accepted = pseudo_accepted.to(dtype=torch.bool)
    if not bool(accepted.any()):
        return output["acceptance_logit"].sum() * 0.0
    target, intervention = candidate_correctness_target(
        output["shadow_logits"].detach()[accepted],
        target_index[accepted],
    )
    if not bool(intervention.any()):
        return output["acceptance_logit"].sum() * 0.0
    gate_target = target[intervention]
    positives = gate_target.sum()
    negatives = gate_target.numel() - positives
    positive_weight = (negatives / positives.clamp_min(1.0)).clamp(1.0, 12.0)
    return functional.binary_cross_entropy_with_logits(
        output["acceptance_logit"][accepted][intervention],
        gate_target,
        pos_weight=positive_weight,
    )


def collect(
    model: CORARouteExpert,
    loader: DataLoader,
    device: torch.device,
) -> dict[str, np.ndarray | float]:
    model.eval()
    targets: list[np.ndarray] = []
    accepted: list[np.ndarray] = []
    logits: list[np.ndarray] = []
    acceptance: list[np.ndarray] = []
    losses: list[float] = []
    with torch.inference_mode():
        for raw_batch in loader:
            batch = move(raw_batch, device)
            output = forward(model, batch)
            losses.append(float(gate_loss(output, batch["target_index"], batch["pseudo_accepted"])))
            targets.append(batch["target_index"].cpu().numpy())
            accepted.append(batch["pseudo_accepted"].cpu().numpy())
            logits.append(output["shadow_logits"].cpu().numpy())
            acceptance.append(output["learned_acceptance"].cpu().numpy())
    return {
        "loss": float(np.mean(losses)),
        "target": np.concatenate(targets),
        "pseudo_accepted": np.concatenate(accepted),
        "shadow_logits": np.concatenate(logits),
        "acceptance": np.concatenate(acceptance),
    }


def calibrate(values: dict[str, np.ndarray | float]) -> dict[str, object]:
    accepted = np.asarray(values["pseudo_accepted"], dtype=bool)
    if not np.any(accepted):
        raise ValueError("gate calibration has no Tier-A/B coordinate labels")
    target = np.asarray(values["target"])[accepted]
    logits = np.asarray(values["shadow_logits"])[accepted]
    shifted = logits - logits.max(axis=1, keepdims=True)
    probability = np.exp(shifted) / np.exp(shifted).sum(axis=1, keepdims=True)
    learned = probability.argmax(axis=1)
    confidence = probability.max(axis=1)
    acceptance = np.asarray(values["acceptance"])[accepted]
    baseline_accuracy = float(np.mean(target == 0))
    best: dict[str, object] | None = None
    for acceptance_threshold in np.linspace(0.02, 0.98, 49):
        for confidence_threshold in np.linspace(0.20, 0.98, 40):
            intervene = (learned != 0) & (acceptance >= acceptance_threshold) & (confidence >= confidence_threshold)
            final = np.where(intervene, learned, 0)
            accuracy = float(np.mean(final == target))
            harm = float(np.mean((target == 0) & (final != 0)))
            recall = float(np.mean(final[target != 0] == target[target != 0])) if np.any(target != 0) else 0.0
            candidate = {
                "acceptance_threshold": float(acceptance_threshold),
                "confidence_threshold": float(confidence_threshold),
                "pseudo_accuracy": accuracy,
                "pseudo_gain": accuracy - baseline_accuracy,
                "harm_rate": harm,
                "intervention_rate": float(intervene.mean()),
                "nonbase_correction_recall": recall,
            }
            if harm <= 0.01 and (
                best is None
                or (accuracy, recall, -harm) > (
                    best["pseudo_accuracy"],
                    best["nonbase_correction_recall"],
                    -best["harm_rate"],
                )
            ):
                best = candidate
    if best is None:
        best = {
            "acceptance_threshold": 1.0,
            "confidence_threshold": 1.0,
            "pseudo_accuracy": baseline_accuracy,
            "pseudo_gain": 0.0,
            "harm_rate": 0.0,
            "intervention_rate": 0.0,
            "nonbase_correction_recall": 0.0,
        }
    best["base_pseudo_accuracy"] = baseline_accuracy
    best["eligible_for_shadow_canary"] = bool(
        best["pseudo_gain"] >= 0.005
        and best["intervention_rate"] >= 0.005
        and best["harm_rate"] <= 0.01
    )
    return best


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--route", choices=tuple(HISTORY_LENGTH), required=True)
    parser.add_argument("--candidate-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=8e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--shadow-strategy", choices=("tail", "interleaved"), default="tail")
    parser.add_argument("--shadow-stride", type=int, default=5)
    parser.add_argument("--shadow-offset", type=int, default=None)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dataset = CandidateCacheDataset(
        args.cache_dir,
        args.route,
        "shadow",
        history_length=HISTORY_LENGTH[args.route],
        shadow_strategy=args.shadow_strategy,
        shadow_stride=args.shadow_stride,
        shadow_offset=args.shadow_offset,
    )
    gate_train = Subset(dataset, list(range(0, len(dataset), 2)))
    gate_calibration = Subset(dataset, list(range(1, len(dataset), 2)))
    train_loader = DataLoader(gate_train, batch_size=args.batch_size, shuffle=True, num_workers=0)
    calibration_loader = DataLoader(gate_calibration, batch_size=args.batch_size, shuffle=False, num_workers=0)

    source = torch.load(args.candidate_checkpoint, map_location="cpu", weights_only=False)
    source_kwargs = dict(source["model_kwargs"])
    model_kwargs = {
        **source_kwargs,
        "independent_acceptance": True,
        "correctness_gate": True,
        "candidate_quality_dim": 3,
        "runtime_quality_dim": 6,
        "visual_acceptance_guard": True,
    }
    model = CORARouteExpert(**model_kwargs).to(device)
    incompatible = model.load_state_dict(source["model_state"], strict=False)
    if incompatible.unexpected_keys or any(
        not key.startswith("correctness_gate_head.") for key in incompatible.missing_keys
    ):
        raise RuntimeError(f"candidate checkpoint is incompatible: {incompatible}")
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for parameter in model.correctness_gate_head.parameters():
        parameter.requires_grad_(True)
    optimizer = torch.optim.AdamW(
        model.correctness_gate_head.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    config = {
        "schema_version": "brace_v4_candidate_correctness_gate_training_v1",
        "route": args.route,
        "candidate_checkpoint": str(args.candidate_checkpoint),
        "candidate_checkpoint_sha256": sha256(args.candidate_checkpoint),
        "gate_target": "frozen_candidate_prediction_matches_label_free_teacher_nonbase_target",
        "gate_train_partition": "alternating half of Train-internal shadow frames",
        "gate_calibration_partition": "disjoint alternating half of Train-internal shadow frames",
        "shadow_strategy": args.shadow_strategy,
        "shadow_stride": args.shadow_stride,
        "shadow_offset": args.shadow_offset,
        "visual_acceptance_guard": True,
        "human_coordinate_read": False,
        "final_bev_read": False,
        "depth_read": False,
        "locked_test_read": False,
        "arguments": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (args.output_dir / "run_config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    best_state: dict[str, torch.Tensor] | None = None
    best_loss = float("inf")
    stale = 0
    history: list[dict[str, float | int]] = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        train_losses: list[float] = []
        for raw_batch in train_loader:
            batch = move(raw_batch, device)
            optimizer.zero_grad(set_to_none=True)
            output = forward(model, batch)
            loss = gate_loss(output, batch["target_index"], batch["pseudo_accepted"])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.correctness_gate_head.parameters(), 5.0)
            optimizer.step()
            train_losses.append(float(loss.detach()))
        calibration_values = collect(model, calibration_loader, device)
        record = {
            "epoch": epoch,
            "train_gate_loss": float(np.mean(train_losses)),
            "calibration_gate_loss": float(calibration_values["loss"]),
        }
        history.append(record)
        print(json.dumps(record), flush=True)
        if record["calibration_gate_loss"] < best_loss - 1e-5:
            best_loss = record["calibration_gate_loss"]
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= args.patience:
            break
    if best_state is None:
        raise RuntimeError("correctness gate did not produce a checkpoint")
    model.load_state_dict(best_state, strict=True)
    calibration_values = collect(model, calibration_loader, device)
    calibration = calibrate(calibration_values)
    model.rollback()
    checkpoint = {
        "schema_version": "brace_v4_correctness_gated_route_expert_checkpoint_v1",
        "route": args.route,
        "expert_kind": source["expert_kind"],
        "model_kwargs": model_kwargs,
        "model_state": model.state_dict(),
        "calibration": calibration,
        "shadow_canary_eligible": bool(calibration["eligible_for_shadow_canary"]),
        "deployment_gate": "identity_locked",
        "candidate_checkpoint_sha256": sha256(args.candidate_checkpoint),
        "human_coordinate_read": False,
        "final_bev_read": False,
        "locked_test_read": False,
    }
    torch.save(checkpoint, args.output_dir / "best.pt")
    complete = {
        "schema_version": "brace_v4_correctness_gated_route_expert_complete_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "epochs": len(history),
        "gate_training_samples": len(gate_train),
        "gate_calibration_samples": len(gate_calibration),
        "calibration": calibration,
        "checkpoint_sha256": sha256(args.output_dir / "best.pt"),
        "locked_test_read": False,
    }
    (args.output_dir / "history.json").write_text(
        json.dumps(history, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (args.output_dir / "training_complete.json").write_text(
        json.dumps(complete, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(complete, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
