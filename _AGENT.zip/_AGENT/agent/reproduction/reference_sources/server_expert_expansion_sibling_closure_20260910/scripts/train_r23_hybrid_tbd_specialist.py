#!/usr/bin/env python3
"""Train a Hybrid TBD/DTT existence specialist from immutable R16 cache."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
for entry in (ROOT / "src", ROOT / "scripts"):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

from brace_v4.pca_training import select_finalization_stage, select_safe_gate_threshold
from brace_v4.r23_hybrid_tbd import R23_ARCHITECTURE, HybridTBDExistenceCandidateManager, r23_weighted_association_loss
from train_r17_tcrg_specialist import cpu_state_dict, load_record, seed_everything, sha256, tensors_for


CHECKPOINT_SCHEMA = "brace_v4_r23_hybrid_tbd_checkpoint_v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "R23_HYBRID_TBD_WET_GROUND_PROTOCOL_V1.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def load_protocol(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != "brace_v4_r23_hybrid_tbd_protocol_v1" or payload.get("architecture") != R23_ARCHITECTURE:
        raise ValueError("unsupported R23 protocol")
    if payload.get("runtime_route") != "outdoor_wet_return" or payload.get("identity_branch") != "cora0":
        raise ValueError("R23 wet-ground identity contract is invalid")
    if any(not bool(payload.get("forbidden_reads", {}).get(key)) for key in ("target_final_bev", "development_during_training", "locked_test", "depth", "right_rgb", "manual_ra_anchor")):
        raise ValueError("R23 protocol allows a forbidden read")
    return payload


def forward(model: HybridTBDExistenceCandidateManager, values: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return model(**{key: values[key] for key in ("candidate_token", "candidate_xy_m", "candidate_valid", "candidate_unary_logits", "global_state")})


@torch.no_grad()
def collect(model: HybridTBDExistenceCandidateManager, records: list[dict[str, np.ndarray]], device: torch.device) -> dict[str, np.ndarray]:
    result = {key: [] for key in ("benefit_probability", "selected_candidate_index", "target_weight", "sample_weight", "candidate_nll")}
    model.eval()
    for record in records:
        values = tensors_for(record, device)
        output = forward(model, values)
        _, detail = r23_weighted_association_loss(output, values["target_weight"], values["sample_weight"], benefit_loss_weight=0.0)
        result["benefit_probability"].append(output["benefit_probability"].squeeze(0).cpu().numpy())
        result["selected_candidate_index"].append(output["selected_candidate_index"].squeeze(0).cpu().numpy())
        result["target_weight"].append(values["target_weight"].squeeze(0).cpu().numpy())
        result["sample_weight"].append(values["sample_weight"].squeeze(0).cpu().numpy())
        result["candidate_nll"].append(np.asarray([float(detail["candidate_nll"].cpu())], dtype=np.float32))
    return {key: np.concatenate(value) for key, value in result.items()}


def support_after_gate(prediction: dict[str, np.ndarray], threshold: float) -> float:
    selected = prediction["selected_candidate_index"]
    active = prediction["sample_weight"] > 0.0
    accepted = active & (selected != 0) & (prediction["benefit_probability"] >= float(threshold))
    chosen = np.where(accepted, selected, 0)
    support = prediction["target_weight"][np.arange(chosen.size), chosen]
    return float((support * prediction["sample_weight"]).sum() / max(float(prediction["sample_weight"][active].sum()), 1.0e-8))


def main() -> None:
    args = parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    if not (args.cache_dir / "R16_NSCAN_TRAIN_MANIFEST.json").is_file():
        raise FileNotFoundError("R23 requires immutable R16 train cache")
    protocol = load_protocol(args.protocol)
    training = dict(protocol["training"])
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("R23 requires CUDA")
    seed_everything(int(training["seed"]))
    fit = [load_record(args.cache_dir, sequence, "outdoor_wet_return", "cora0") for sequence in protocol["fit_sequences"]]
    calibration = [load_record(args.cache_dir, sequence, "outdoor_wet_return", "cora0") for sequence in protocol["calibration_sequences"]]
    candidates = int(fit[0]["candidate_xy_m"].shape[1])
    model = HybridTBDExistenceCandidateManager(candidate_count=candidates, maximum_step_m=float(training["maximum_step_m"])).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(training["learning_rate"]), weight_decay=float(training["weight_decay"]))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    contract = {
        "schema_version": CHECKPOINT_SCHEMA,
        "architecture": R23_ARCHITECTURE,
        "protocol_sha256": sha256(args.protocol),
        "cache_manifest_sha256": sha256(args.cache_dir / "R16_NSCAN_TRAIN_MANIFEST.json"),
        "route": "outdoor_wet_return",
        "logical_route": "wet_ground",
        "identity_branch": "cora0",
        "fit_sequences": list(protocol["fit_sequences"]),
        "calibration_sequences": list(protocol["calibration_sequences"]),
        "candidate_count": candidates,
        "target_final_bev_read": False,
        "development_read": False,
        "locked_test_read": False,
        "depth_read": False,
        "right_rgb_read": False,
        "manual_ra_anchor_at_label_stage": False,
        "model_future_frame_input": False,
        "teacher_future_frame_input_only": True,
        "identity_transition_disabled": True,
        "non_route_behavior": "exact frozen CORA0 identity"
    }
    (args.output_dir / "run_contract.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    best_state, best_gate, best_support, best_nll, stale, selected_epoch = None, None, -np.inf, np.inf, 0, 0
    history: list[dict[str, float | int]] = []
    for epoch in range(1, int(training["epochs"]) + 1):
        model.train()
        losses = []
        for index in np.random.permutation(len(fit)):
            values = tensors_for(fit[int(index)], device)
            output = forward(model, values)
            loss, detail = r23_weighted_association_loss(output, values["target_weight"], values["sample_weight"], candidate_loss_weight=float(training["candidate_loss_weight"]), benefit_loss_weight=float(training["benefit_loss_weight"]))
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append((float(loss.detach().cpu()), float(detail["candidate_nll"].cpu()), float(detail["benefit_bce"].cpu())))
        prediction = collect(model, calibration, device)
        gate = select_safe_gate_threshold(benefit_probability=prediction["benefit_probability"], selected_candidate_index=prediction["selected_candidate_index"], target_weight=prediction["target_weight"], sample_weight=prediction["sample_weight"], harm_budget=float(training["harm_budget"]))
        support = support_after_gate(prediction, float(gate["threshold"]))
        nll = float(prediction["candidate_nll"].mean())
        row = {"epoch": epoch, "loss": float(np.mean([item[0] for item in losses])), "candidate_nll": float(np.mean([item[1] for item in losses])), "benefit_bce": float(np.mean([item[2] for item in losses])), "calibration_set_support": support, "calibration_candidate_nll": nll, **gate}
        history.append(row)
        better = support > best_support + 1.0e-7 or (abs(support - best_support) <= 1.0e-7 and nll < best_nll)
        if better:
            best_state, best_gate, best_support, best_nll, stale, selected_epoch = cpu_state_dict(model), gate, support, nll, 0, epoch
        else:
            stale += 1
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if stale >= int(training["patience"]):
            break
    if best_state is None or best_gate is None:
        raise RuntimeError("R23 did not produce a valid model")
    (args.output_dir / "history.json").write_text(json.dumps({"stage_a": history}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report = contract | {"completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "selected_stage_a_epoch": selected_epoch, "stage_a_gate": best_gate, "stage_a_calibration_set_support": best_support, "development_read": False, "locked_test_read": False}
    if select_finalization_stage(best_gate) != "A_FINAL":
        report["decision"] = "NO_GO_IDENTITY_ONLY"
        (args.output_dir / "training_no_go.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False))
        return
    checkpoint = args.output_dir / "HYBRID_TBD_SPECIALIST_FINAL.pt"
    torch.save(contract | {"stage": "A_FINAL", "selected_stage_a_epoch": selected_epoch, "gate": best_gate, "model_state": best_state}, checkpoint)
    report["final_checkpoint"] = str(checkpoint)
    report["final_checkpoint_sha256"] = sha256(checkpoint)
    (args.output_dir / "training_complete.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
