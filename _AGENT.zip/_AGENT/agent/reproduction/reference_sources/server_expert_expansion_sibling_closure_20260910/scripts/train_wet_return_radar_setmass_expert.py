#!/usr/bin/env python3
"""Train a pure-radar wet-return candidate ranker from R11 set-mass support."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.route_specialists_se2_cache import training_cache_route_for_specialist
from brace_v4.route_specialists_se2_cache_data import RouteRuntimeEpisode, load_route_runtime_episode
from brace_v4.route_specialists_se2_contract import load_route_specialist_protocol
from brace_v4.wet_return_classical_expert import (
    causal_candidate_track,
    restrict_candidates_to_parent_radius,
    route_candidate_training_rows,
    route_gate_features,
    select_set_mass_gate_threshold,
    set_mass_gate_outcomes,
)


VARIANTS: dict[str, dict[str, float | int]] = {
    "wet_setmass_tbd_r04_strict": {
        "maximum_parent_radius_m": 0.40, "maximum_step_m": 0.25,
        "transition_scale_m": 0.10, "harm_budget": 0.02, "minimum_coverage": 0.02,
        "max_leaf_nodes": 31, "min_samples_leaf": 20, "max_iter": 220,
    },
    "wet_setmass_tbd_r06_strict": {
        "maximum_parent_radius_m": 0.60, "maximum_step_m": 0.30,
        "transition_scale_m": 0.12, "harm_budget": 0.03, "minimum_coverage": 0.03,
        "max_leaf_nodes": 31, "min_samples_leaf": 20, "max_iter": 240,
    },
    "wet_setmass_tbd_r06_balanced": {
        "maximum_parent_radius_m": 0.60, "maximum_step_m": 0.40,
        "transition_scale_m": 0.16, "harm_budget": 0.05, "minimum_coverage": 0.05,
        "max_leaf_nodes": 63, "min_samples_leaf": 16, "max_iter": 280,
    },
    "wet_setmass_tbd_r08_strict": {
        "maximum_parent_radius_m": 0.80, "maximum_step_m": 0.40,
        "transition_scale_m": 0.15, "harm_budget": 0.03, "minimum_coverage": 0.03,
        "max_leaf_nodes": 31, "min_samples_leaf": 24, "max_iter": 260,
    },
    "wet_setmass_tbd_r08_balanced": {
        "maximum_parent_radius_m": 0.80, "maximum_step_m": 0.50,
        "transition_scale_m": 0.20, "harm_budget": 0.06, "minimum_coverage": 0.05,
        "max_leaf_nodes": 63, "min_samples_leaf": 16, "max_iter": 300,
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_episodes(root: Path, sequences: list[str]) -> list[RouteRuntimeEpisode]:
    expected = training_cache_route_for_specialist("rain_or_wet_ground")
    episodes = [load_route_runtime_episode(root / f"{sequence}.npz", expected_split="train") for sequence in sequences]
    mismatched = [(item.sequence, item.route) for item in episodes if item.route != expected]
    if mismatched:
        raise ValueError(f"wet-return runtime route mismatch: {mismatched}")
    if any(not item.r11_set_mass_attached for item in episodes):
        raise ValueError("wet-return ranker requires R11 set-mass support")
    return episodes


def fit_ranker(
    episodes: list[RouteRuntimeEpisode],
    config: dict[str, Any],
    seed: int,
) -> HistGradientBoostingClassifier:
    rows: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    weights: list[np.ndarray] = []
    for episode in episodes:
        x, y, w = route_candidate_training_rows(
            episode.candidate_feature,
            episode.candidate_xy_m,
            episode.candidate_valid,
            episode.allowed_weight,
            episode.sample_weight,
            maximum_parent_radius_m=float(config["maximum_parent_radius_m"]),
        )
        rows.append(x)
        labels.append(y)
        weights.append(w)
    model = HistGradientBoostingClassifier(
        learning_rate=0.05,
        max_iter=int(config["max_iter"]),
        max_leaf_nodes=int(config["max_leaf_nodes"]),
        min_samples_leaf=int(config["min_samples_leaf"]),
        l2_regularization=2.0,
        early_stopping=False,
        random_state=seed,
    )
    model.fit(np.concatenate(rows), np.concatenate(labels), sample_weight=np.concatenate(weights))
    return model


def rank_candidates(
    model: HistGradientBoostingClassifier,
    episode: RouteRuntimeEpisode,
    config: dict[str, Any],
) -> tuple[np.ndarray, np.ndarray]:
    admitted = restrict_candidates_to_parent_radius(
        episode.candidate_xy_m,
        episode.candidate_valid,
        maximum_parent_radius_m=float(config["maximum_parent_radius_m"]),
    )
    probability = np.zeros(admitted.shape, dtype=np.float32)
    probability[admitted] = model.predict_proba(episode.candidate_feature[admitted])[:, 1].astype(np.float32)
    return probability, admitted


def proposal_indices(
    probability: np.ndarray,
    admitted: np.ndarray,
    episode: RouteRuntimeEpisode,
    config: dict[str, Any],
) -> np.ndarray:
    return causal_candidate_track(
        np.log(np.maximum(probability, 1.0e-7)),
        episode.candidate_xy_m,
        admitted,
        maximum_step_m=float(config["maximum_step_m"]),
        transition_scale_m=float(config["transition_scale_m"]),
    )


def fit_gate(
    ranker: HistGradientBoostingClassifier,
    episodes: list[RouteRuntimeEpisode],
    config: dict[str, Any],
    seed: int,
) -> tuple[Any, float, dict[str, float]]:
    feature_parts: list[np.ndarray] = []
    label_parts: list[np.ndarray] = []
    weight_parts: list[np.ndarray] = []
    episode_rows: list[tuple[RouteRuntimeEpisode, np.ndarray, np.ndarray, np.ndarray]] = []
    for episode in episodes:
        probability, admitted = rank_candidates(ranker, episode, config)
        selected = proposal_indices(probability, admitted, episode, config)
        outcomes = set_mass_gate_outcomes(selected, episode.allowed_weight, episode.sample_weight)
        active = outcomes["active"] & (selected != 0)
        if active.any():
            feature_parts.append(route_gate_features(
                episode.candidate_feature, episode.candidate_xy_m, probability, selected
            )[active])
            label_parts.append(outcomes["benefit"][active].astype(np.int8))
            weight_parts.append(episode.sample_weight[active].astype(np.float32))
        episode_rows.append((episode, probability, admitted, selected))
    if not feature_parts:
        gate: Any = DummyClassifier(strategy="constant", constant=0)
        gate.fit(np.zeros((1, 38), dtype=np.float32), np.zeros(1, dtype=np.int8))
        return gate, 1.1, {"threshold": 1.1, "coverage": 0.0, "harm_rate": 0.0, "weighted_set_hit_gain": 0.0}
    x = np.concatenate(feature_parts)
    y = np.concatenate(label_parts)
    weight = np.concatenate(weight_parts)
    if np.unique(y).size < 2:
        gate = DummyClassifier(strategy="constant", constant=int(y[0]))
        gate.fit(x[:1], y[:1])
    else:
        gate = HistGradientBoostingClassifier(
            learning_rate=0.04,
            max_iter=160,
            max_leaf_nodes=9,
            min_samples_leaf=max(12, int(config["min_samples_leaf"]) // 2),
            l2_regularization=3.0,
            early_stopping=False,
            random_state=seed + 1,
        )
        positive = y.astype(bool)
        positive_scale = max(float((~positive).sum()) / max(float(positive.sum()), 1.0), 1.0)
        gate.fit(x, y, sample_weight=weight * np.where(positive, positive_scale, 1.0))

    probability_parts: list[np.ndarray] = []
    selected_parts: list[np.ndarray] = []
    allowed_parts: list[np.ndarray] = []
    sample_parts: list[np.ndarray] = []
    for episode, candidate_probability, _, selected in episode_rows:
        gate_x = route_gate_features(
            episode.candidate_feature, episode.candidate_xy_m, candidate_probability, selected
        )
        classes = np.asarray(gate.classes_, dtype=np.int64)
        raw = gate.predict_proba(gate_x)
        positive_column = np.flatnonzero(classes == 1)
        benefit_probability = (
            raw[:, int(positive_column[0])].astype(np.float32)
            if positive_column.size else np.zeros(selected.size, dtype=np.float32)
        )
        probability_parts.append(benefit_probability)
        selected_parts.append(selected)
        allowed_parts.append(episode.allowed_weight)
        sample_parts.append(episode.sample_weight)
    threshold, report = select_set_mass_gate_threshold(
        np.concatenate(probability_parts),
        np.concatenate(selected_parts),
        np.concatenate(allowed_parts),
        np.concatenate(sample_parts),
        harm_budget=float(config["harm_budget"]),
        minimum_coverage=float(config["minimum_coverage"]),
    )
    return gate, threshold, report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=tuple(VARIANTS), required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "CORA_SE2_ROUTE_SPECIALISTS_PROTOCOL_V1.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=3407)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)

    protocol = load_route_specialist_protocol(args.protocol)
    pool = protocol["training_pools"]["outdoor_wet"]
    fit_sequences = [str(value).strip().lower() for value in pool["fit_sequences"]]
    calibration_sequences = [str(value).strip().lower() for value in pool["calibration_sequences"]]
    fit = load_episodes(args.runtime_root, fit_sequences)
    calibration = load_episodes(args.runtime_root, calibration_sequences)
    config = dict(VARIANTS[args.variant])
    ranker = fit_ranker(fit, config, args.seed)
    gate, threshold, gate_audit = fit_gate(ranker, calibration, config, args.seed)

    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint = args.output_dir / "best.joblib"
    joblib.dump({
        "schema_version": "brace_v4_wet_radar_setmass_tbd_expert_v1",
        "variant": args.variant,
        "ranker": ranker,
        "gate": gate,
        "threshold": threshold,
        "config": config,
    }, checkpoint)
    contract = {
        "schema_version": "brace_v4_wet_radar_setmass_tbd_training_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "variant": args.variant,
        "architecture": "RadarSetMassRanker+CausalTrackBeforeDetect+BenefitGate",
        "route": "rain_or_wet_ground",
        "fit_sequences": fit_sequences,
        "calibration_sequences": calibration_sequences,
        "supervision": "train_only_R11_radar_candidate_set_mass",
        "gate_audit": gate_audit,
        "checkpoint": checkpoint.name,
        "checkpoint_sha256": sha256(checkpoint),
        "runtime_visual_input": False,
        "model_distillation": False,
        "depth_read": False,
        "development_labels_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "run_contract.json").write_text(
        json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"variant": args.variant, "threshold": threshold, "gate_audit": gate_audit}, ensure_ascii=False))


if __name__ == "__main__":
    main()
