#!/usr/bin/env python3
"""Train dry/wet radar-only shadow experts from frozen R8 candidate sets."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import DataLoader, Dataset

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.r8_outdoor_set_experts import (
    R8OutdoorSetExpert,
    R8RouteSplit,
    build_radar_only_candidate_features,
    candidate_set_mass_loss,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_npz(path: Path) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as payload:
        return {key: np.asarray(payload[key]) for key in payload.files}


class R8WindowDataset(Dataset[dict[str, Tensor]]):
    def __init__(
        self,
        radar_runtime_root: Path,
        r8_root: Path,
        sequences: tuple[str, ...],
        *,
        route: str,
        window: int,
        stride: int,
    ) -> None:
        if window < 2 or stride < 1:
            raise ValueError("window must be >=2 and stride must be positive")
        self.records: dict[str, dict[str, np.ndarray]] = {}
        self.windows: list[tuple[str, int, int]] = []
        for sequence in sequences:
            runtime = load_npz(radar_runtime_root / f"{sequence}.npz")
            r8 = load_npz(r8_root / f"{sequence}.npz")
            if str(r8["route"].item()) != route or str(runtime["route"].item()) != route:
                raise ValueError(f"route mismatch for {sequence}")
            if not np.array_equal(runtime["frame_id"], r8["frame_id"]):
                raise ValueError(f"radar runtime/R8 timeline mismatch for {sequence}")
            r8_candidate_valid = np.asarray(r8["candidate_valid"], dtype=np.bool_)
            identity_inserted = bool(np.asarray(runtime.get("identity_base_inserted", False)).item())
            if identity_inserted:
                if runtime["candidate_xy_m"].shape[1] != r8["candidate_xy_m"].shape[1] + 1:
                    raise ValueError(f"exact identity candidate count mismatch for {sequence}")
                if not np.allclose(runtime["candidate_xy_m"][:, 1:], r8["candidate_xy_m"], equal_nan=True):
                    raise ValueError(f"radar runtime/R8 candidate geometry mismatch for {sequence}")
                candidate_valid = np.asarray(runtime["candidate_valid"], dtype=np.bool_)
            else:
                candidate_valid = r8_candidate_valid
                if not np.allclose(runtime["candidate_xy_m"], r8["candidate_xy_m"], equal_nan=True):
                    raise ValueError(f"radar runtime/R8 candidate geometry mismatch for {sequence}")
                runtime["candidate_valid"] = candidate_valid
            features = build_radar_only_candidate_features(runtime)
            r8_positive = np.asarray(r8["candidate_set_mask"], dtype=np.bool_) & r8_candidate_valid
            # Raw96 preserves the normalized teacher-set mass directly.  The
            # older R8 cache only has nomination counts, whose squared form
            # was the historical consensus prior.  Both remain Train-only.
            if "candidate_set_weight" in r8:
                target_weight = np.asarray(r8["candidate_set_weight"], dtype=np.float32) * r8_positive
            elif "nomination_count" in r8:
                nomination = np.asarray(r8["nomination_count"], dtype=np.float32) * r8_positive
                target_weight = nomination * nomination
            else:
                raise KeyError(f"R8 archive has neither candidate_set_weight nor nomination_count: {sequence}")
            if identity_inserted:
                distance = np.linalg.norm(
                    runtime["candidate_xy_m"][:, 0, None, :] - r8["candidate_xy_m"], axis=-1
                )
                identity_positive = np.any(r8_positive & (distance <= 0.30 + 1e-6), axis=1)
                identity_target_weight = np.where(
                    identity_positive, np.max(target_weight, axis=1), 0.0
                ).astype(np.float32)
                positive = np.concatenate((identity_positive[:, None], r8_positive), axis=1)
                target_weight = np.concatenate((identity_target_weight[:, None], target_weight), axis=1)
            else:
                positive = r8_positive
            weight = np.asarray(r8["sample_weight"], dtype=np.float32)
            weight *= np.asarray(r8["radar_training_valid"], dtype=np.float32)
            if np.any((weight > 0) & ~positive.any(axis=1)):
                raise ValueError(f"supervised R8 frame lacks a positive candidate: {sequence}")
            target_distribution = target_weight
            target_distribution /= np.maximum(target_distribution.sum(axis=1, keepdims=True), 1.0)
            self.records[sequence] = {
                "candidate_token": features.candidate_token,
                "candidate_unary_logits": features.candidate_unary_logits,
                "base_index": features.base_index,
                "base_xy_m": features.base_xy_m,
                "global_state": features.global_state,
                "candidate_xy_m": np.asarray(
                    runtime["candidate_xy_m"] if identity_inserted else r8["candidate_xy_m"],
                    dtype=np.float32,
                ),
                "candidate_valid": candidate_valid,
                "positive_mask": positive,
                "target_distribution": target_distribution.astype(np.float32),
                "supervision_weight": weight,
            }
            frames = len(weight)
            starts = list(range(0, max(frames - window + 1, 1), stride))
            final_start = max(frames - window, 0)
            if not starts or starts[-1] != final_start:
                starts.append(final_start)
            self.windows.extend((sequence, start, min(start + window, frames)) for start in starts)

    def __len__(self) -> int:
        return len(self.windows)

    def __getitem__(self, index: int) -> dict[str, Tensor]:
        sequence, start, stop = self.windows[index]
        record = self.records[sequence]
        return {
            "candidate_token": torch.from_numpy(record["candidate_token"][start:stop]),
            "candidate_unary_logits": torch.from_numpy(record["candidate_unary_logits"][start:stop]),
            "base_index": torch.from_numpy(record["base_index"][start:stop]),
            "base_xy_m": torch.from_numpy(record["base_xy_m"][start:stop]),
            "global_state": torch.from_numpy(record["global_state"][start:stop]),
            "candidate_xy_m": torch.from_numpy(record["candidate_xy_m"][start:stop]),
            "candidate_valid": torch.from_numpy(record["candidate_valid"][start:stop]),
            "positive_mask": torch.from_numpy(record["positive_mask"][start:stop]),
            "target_distribution": torch.from_numpy(record["target_distribution"][start:stop]),
            "supervision_weight": torch.from_numpy(record["supervision_weight"][start:stop]),
        }


def move(batch: dict[str, Tensor], device: torch.device) -> dict[str, Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


def forward(model: R8OutdoorSetExpert, batch: dict[str, Tensor]) -> dict[str, Tensor]:
    return model(
        candidate_token=batch["candidate_token"],
        candidate_xy_m=batch["candidate_xy_m"],
        candidate_valid=batch["candidate_valid"],
        candidate_unary_logits=batch["candidate_unary_logits"],
        base_xy_m=batch["base_xy_m"],
        global_state=batch["global_state"],
    )


@torch.inference_mode()
def collect(model: R8OutdoorSetExpert, loader: DataLoader, device: torch.device) -> dict[str, np.ndarray]:
    model.eval()
    output_values: dict[str, list[np.ndarray]] = {
        key: [] for key in ("set_nll", "selected", "base", "positive", "target", "benefit", "weight")
    }
    for raw in loader:
        batch = move(raw, device)
        output = forward(model, batch)
        _, metrics = candidate_set_mass_loss(
            output,
            batch["positive_mask"],
            batch["candidate_valid"],
            batch["supervision_weight"],
            batch["base_index"],
            target_distribution=batch["target_distribution"],
        )
        output_values["set_nll"].append(metrics["set_nll"].cpu().numpy().reshape(-1))
        output_values["selected"].append(output["selected_candidate_index"].cpu().numpy().reshape(-1))
        output_values["base"].append(batch["base_index"].cpu().numpy().reshape(-1))
        output_values["positive"].append(batch["positive_mask"].cpu().numpy().reshape(-1, batch["positive_mask"].shape[-1]))
        output_values["target"].append(batch["target_distribution"].cpu().numpy().reshape(-1, batch["target_distribution"].shape[-1]))
        output_values["benefit"].append(torch.sigmoid(output["benefit_logit"]).cpu().numpy().reshape(-1))
        output_values["weight"].append(batch["supervision_weight"].cpu().numpy().reshape(-1))
    return {key: np.concatenate(value, axis=0) for key, value in output_values.items()}


def calibrate(values: dict[str, np.ndarray], *, harm_budget: float) -> dict[str, float | bool]:
    valid = values["weight"] > 0
    positive = values["positive"][valid].astype(bool)
    target = values["target"][valid].astype(np.float64)
    selected = values["selected"][valid].astype(np.int64)
    base = values["base"][valid].astype(np.int64)
    benefit = values["benefit"][valid]
    rows = np.arange(len(selected))
    base_hit = positive[rows, base]
    maximum_target = target.max(axis=1)
    consensus_top = target >= (maximum_target[:, None] - 1e-12)
    base_top = consensus_top[rows, base]
    best = None
    for threshold in np.linspace(0.0, 1.0, 101):
        intervene = (selected != base) & (benefit >= threshold)
        final = np.where(intervene, selected, base)
        final_hit = positive[rows, final]
        final_top = consensus_top[rows, final]
        harm = np.mean(base_top & ~final_top)
        final_consensus = target[rows, final]
        base_consensus = target[rows, base]
        candidate = {
            "acceptance_threshold": float(threshold),
            "set_hit_rate": float(np.mean(final_hit)),
            "base_set_hit_rate": float(np.mean(base_hit)),
            "set_hit_gain": float(np.mean(final_hit) - np.mean(base_hit)),
            "consensus_top_hit_rate": float(np.mean(final_top)),
            "base_consensus_top_hit_rate": float(np.mean(base_top)),
            "consensus_score": float(np.mean(final_consensus)),
            "base_consensus_score": float(np.mean(base_consensus)),
            "consensus_score_gain": float(np.mean(final_consensus - base_consensus)),
            "harm_rate": float(harm),
            "intervention_rate": float(np.mean(intervene)),
            "mean_set_nll": float(np.mean(values["set_nll"][valid])),
        }
        if harm <= harm_budget and (
            best is None
            or (candidate["consensus_top_hit_rate"], candidate["consensus_score"], -candidate["harm_rate"])
            > (best["consensus_top_hit_rate"], best["consensus_score"], -best["harm_rate"])
        ):
            best = candidate
    if best is None:
        raise RuntimeError("no identity-safe calibration threshold")
    best["shadow_canary_ready"] = bool(best["consensus_score_gain"] > 0 and best["harm_rate"] <= harm_budget)
    return best


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("outdoor_dry_complex", "outdoor_wet_return"), required=True)
    parser.add_argument("--radar-runtime-root", type=Path, required=True)
    parser.add_argument("--r8-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--window", type=int, default=50)
    parser.add_argument("--stride", type=int, default=50)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--maximum-correction-m", type=float, default=0.30)
    parser.add_argument("--run-id", choices=("r8", "r12"), default="r8")
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.maximum_correction_m <= 0.0:
        raise ValueError("maximum-correction-m must be positive")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device(args.device)
    split = R8RouteSplit.for_route(args.route)
    fit_set = R8WindowDataset(args.radar_runtime_root, args.r8_root, split.fit, route=args.route, window=args.window, stride=args.stride)
    calibration_set = R8WindowDataset(
        args.radar_runtime_root, args.r8_root, split.calibration, route=args.route, window=args.window, stride=args.window
    )
    fit_loader = DataLoader(fit_set, batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=device.type == "cuda")
    calibration_loader = DataLoader(
        calibration_set, batch_size=args.batch_size, shuffle=False, num_workers=0, pin_memory=device.type == "cuda"
    )
    sample = fit_set[0]
    candidate_count = int(sample["candidate_xy_m"].shape[1])
    exact_identity_contract = bool(candidate_count >= 2 and torch.all(sample["base_index"] == 0))
    model_kwargs = {
        "route": args.route,
        "candidate_count": candidate_count,
        "token_dim": int(sample["candidate_token"].shape[2]),
        "hidden_dim": 96,
        "maximum_step_m": 0.30,
        "maximum_correction_m": float(args.maximum_correction_m),
    }
    model = R8OutdoorSetExpert(
        **model_kwargs,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    harm_budget = 0.01 if args.route == "outdoor_dry_complex" else 0.005
    best_state = None
    best_key = None
    stale = 0
    history = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for raw in fit_loader:
            batch = move(raw, device)
            optimizer.zero_grad(set_to_none=True)
            output = forward(model, batch)
            loss, _ = candidate_set_mass_loss(
                output,
                batch["positive_mask"],
                batch["candidate_valid"],
                batch["supervision_weight"],
                batch["base_index"],
                target_distribution=batch["target_distribution"],
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        calibration = calibrate(collect(model, calibration_loader, device), harm_budget=harm_budget)
        row = {"epoch": epoch, "train_loss": float(np.mean(losses)), "learning_rate": scheduler.get_last_lr()[0], **calibration}
        history.append(row)
        print(json.dumps(row), flush=True)
        key = (
            float(calibration["consensus_top_hit_rate"]),
            float(calibration["consensus_score"]),
            -float(calibration["mean_set_nll"]),
        )
        if best_key is None or key > best_key:
            best_key = key
            best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= args.patience:
            break
    if best_state is None:
        raise RuntimeError("R8 outdoor expert produced no checkpoint")
    model.load_state_dict(best_state, strict=True)
    calibration = calibrate(collect(model, calibration_loader, device), harm_budget=harm_budget)
    schema_prefix = "brace_v4_r12_r11_outdoor_shadow_expert" if args.run_id == "r12" else "brace_v4_r8_outdoor_set_expert"
    checkpoint = {
        "schema_version": (
            f"{schema_prefix}_checkpoint_v2_exact_identity"
            if exact_identity_contract else "brace_v4_r8_outdoor_set_expert_checkpoint_v1"
        ),
        "run_id": args.run_id,
        "route": args.route,
        "library_origin": "pb_mhbr_se+probabilistic_branch_posterior" if args.route == "outdoor_dry_complex" else "gg_srre+risk_controlled_candidate_posterior",
        "model_kwargs": model_kwargs,
        "exact_identity_candidate_zero": exact_identity_contract,
        "model_state": model.state_dict(),
        "fit_sequences": split.fit,
        "calibration_sequences": split.calibration,
        "development_sequences_reserved": split.development,
        "calibration": calibration,
        "deployment_gate": "shadow_only_until_postfreeze_development_audit",
        "promotion_forbidden": True,
        "runtime_inputs": [
            "raw_candidate_score", "source_candidate_score", "adapted_candidate_score",
            "candidate_ra_mti_agreement", "candidate_background_risk", "candidate_temporal_persistence",
            "candidate_xy_m", "candidate_valid",
        ],
        "teacher_only_inputs_not_in_runtime": ["visual_bearing", "H_calibrated_depth", f"{args.run_id.upper()}_candidate_set_weight"],
        "forbidden_reads": {"target_final_bev_train": False, "development_train": False, "locked_test": False},
    }
    checkpoint_path = args.output_dir / "best.pt"
    torch.save(checkpoint, checkpoint_path)
    complete = {
        "schema_version": (
            f"{schema_prefix}_training_complete_v2_exact_identity"
            if exact_identity_contract else "brace_v4_r8_outdoor_set_expert_training_complete_v1"
        ),
        "run_id": args.run_id,
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "epochs": len(history),
        "checkpoint_sha256": sha256(checkpoint_path),
        "calibration": calibration,
        "development_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "history.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "training_complete.json").write_text(json.dumps(complete, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(complete, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
