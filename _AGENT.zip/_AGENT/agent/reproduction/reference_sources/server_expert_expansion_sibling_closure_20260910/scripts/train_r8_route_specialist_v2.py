#!/usr/bin/env python3
"""Train an offline R8 partial-label association specialist without Dev labels.

``MHPC-D`` learns dry-route whole-episode branch association from radar-only
candidate evidence.  ``WTTI-W`` adds local RA/RA-MTI tubes for the wet route.
Both consume only immutable R8 *sets*, never a target coordinate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.r8_outdoor_set_experts import R8RouteSplit
from brace_v4.r8_route_specialists_v2 import (
    MHPCDryScorer,
    WTTIWetScorer,
    combine_frozen_unary,
    partial_label_objective,
)
from brace_v4.r8_route_specialists_v2_data import (
    R8RouteEpisode,
    attach_observed_raw_patches,
    append_identity_fallback_action,
    load_route_episode,
    restrict_to_base_trust_region,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def route_parameters(route: str) -> dict[str, float | int]:
    if route == "outdoor_dry_complex":
        return {
            "beam_width": 3,
            "max_step_m": 0.60,
            "stable_step_m": 0.30,
            "min_mass": 0.70,
            "min_margin": 0.15,
            "base_trust_radius_m": 0.60,
        }
    if route == "outdoor_wet_return":
        return {
            "beam_width": 4,
            "max_step_m": 0.60,
            "stable_step_m": 0.30,
            "min_mass": 0.70,
            "min_margin": 0.15,
            "base_trust_radius_m": 0.60,
        }
    raise ValueError(f"unsupported route: {route}")


def load_record_index(path: Path) -> dict[str, dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = {str(record["sequence"]).strip().lower(): dict(record) for record in payload["records"]}
    if not records:
        raise ValueError("split manifest has no episode records")
    return records


def full_route_development_sequences(records: dict[str, dict[str, Any]], route: str) -> tuple[str, ...]:
    """Return every canonical Development episode for a route, in timeline order."""

    selected = [
        sequence for sequence, record in records.items()
        if str(record.get("v3_split", "")).strip().lower() == "development"
        and str(record.get("radar_context", ""))
        and route == (
            "outdoor_dry_complex"
            if str(record.get("weather", "")).strip().lower() == "dry"
            else "outdoor_wet_return"
            if str(record.get("scene_geometry", "")).strip().lower() in {"open_outdoor", "complex_outdoor"}
            else ""
        )
    ]
    return tuple(sorted(selected, key=lambda value: int(value.split("_")[-1])))


def load_episodes(
    *,
    route: str,
    sequences: tuple[str, ...],
    runtime_root: Path,
    r8_root: Path,
    data_root: Path,
    records: dict[str, dict[str, Any]],
    trust_radius_m: float,
    identity_action: bool,
    identity_support_radius_m: float,
) -> list[R8RouteEpisode]:
    episodes: list[R8RouteEpisode] = []
    for sequence in sequences:
        episode = load_route_episode(runtime_root / f"{sequence}.npz", r8_root / f"{sequence}.npz", route=route)
        episode = restrict_to_base_trust_region(episode, radius_m=trust_radius_m)
        if identity_action:
            episode = append_identity_fallback_action(episode, support_radius_m=identity_support_radius_m)
        if route == "outdoor_wet_return":
            if sequence not in records:
                raise ValueError(f"missing source record for wet sequence {sequence}")
            episode = attach_observed_raw_patches(
                episode,
                data_root=data_root,
                episode_record=records[sequence],
            )
        episodes.append(episode)
    return episodes


def to_batch(episode: R8RouteEpisode, device: torch.device) -> dict[str, Tensor]:
    if episode.allowed_mask is None or episode.sample_weight is None:
        raise ValueError("training requires frozen R8 set-valued supervision")
    result = {
        "feature": torch.as_tensor(episode.candidate_feature, dtype=torch.float32, device=device).unsqueeze(0),
        "unary": torch.as_tensor(episode.candidate_unary, dtype=torch.float32, device=device).unsqueeze(0),
        "valid": torch.as_tensor(episode.candidate_valid, dtype=torch.bool, device=device).unsqueeze(0),
        "allowed": torch.as_tensor(episode.allowed_mask, dtype=torch.bool, device=device).unsqueeze(0),
        "allowed_weight": torch.as_tensor(episode.allowed_weight, dtype=torch.float32, device=device).unsqueeze(0),
        "weight": torch.as_tensor(episode.sample_weight, dtype=torch.float32, device=device).unsqueeze(0),
    }
    if episode.candidate_patch is not None:
        result["patch"] = torch.as_tensor(episode.candidate_patch, dtype=torch.float32, device=device).unsqueeze(0)
    return result


def model_output(model: torch.nn.Module, batch: dict[str, Tensor], route: str) -> Tensor:
    if route == "outdoor_wet_return":
        return model(batch["feature"], batch["valid"], batch["patch"])["candidate_logits"]
    return model(batch["feature"], batch["valid"])["candidate_logits"]


def episode_loss(model: torch.nn.Module, batch: dict[str, Tensor], route: str) -> tuple[Tensor, dict[str, float]]:
    residual = model_output(model, batch, route)
    logits = combine_frozen_unary(batch["unary"], residual, batch["valid"])
    objective = partial_label_objective(
        logits,
        batch["allowed"],
        batch["valid"],
        batch["weight"],
        allowed_weight=batch["allowed_weight"],
    )
    regularizer = residual.masked_select(batch["valid"]).square().mean()
    total = objective["loss"] + 1.0e-3 * regularizer
    return total, {
        "loss": float(total.detach()),
        "set_nll": float(objective["set_nll"].detach()),
        "em_ce": float(objective["em_ce"].detach()),
        "residual_l2": float(regularizer.detach()),
    }


@torch.inference_mode()
def evaluate_loss(model: torch.nn.Module, episodes: list[R8RouteEpisode], device: torch.device, route: str) -> dict[str, float]:
    model.eval()
    values: list[dict[str, float]] = []
    for episode in episodes:
        _, metrics = episode_loss(model, to_batch(episode, device), route)
        values.append(metrics)
    return {key: float(np.mean([row[key] for row in values])) for key in values[0]}


def make_model(route: str, feature_dim: int) -> torch.nn.Module:
    return WTTIWetScorer(feature_dim) if route == "outdoor_wet_return" else MHPCDryScorer(feature_dim)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("outdoor_dry_complex", "outdoor_wet_return"), required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--r8-root", type=Path, required=True)
    parser.add_argument("--split-manifest", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=12)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--development-scope", choices=("historical", "full_route"), default="historical")
    parser.add_argument("--fit-sequences", nargs="+", default=None, help="Explicit train-only fit episodes.")
    parser.add_argument("--calibration-sequences", nargs="+", default=None, help="Explicit train-only calibration episodes.")
    parser.add_argument("--development-sequences", nargs="+", default=None, help="Explicit reserved Development episodes.")
    parser.add_argument("--base-trust-radius-m", type=float, default=None)
    parser.add_argument("--identity-action", action="store_true", help="append exact frozen-CORA fallback as a trainable action")
    parser.add_argument("--identity-support-radius-m", type=float, default=0.20)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.epochs < 1 or args.patience < 1:
        raise ValueError("epochs and patience must be positive")
    if args.identity_support_radius_m <= 0.0:
        raise ValueError("identity support radius must be positive")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device(args.device)
    split = R8RouteSplit.for_route(args.route)
    explicit_fit = None if args.fit_sequences is None else tuple(str(value).strip().lower() for value in args.fit_sequences)
    explicit_calibration = None if args.calibration_sequences is None else tuple(str(value).strip().lower() for value in args.calibration_sequences)
    explicit_development = None if args.development_sequences is None else tuple(str(value).strip().lower() for value in args.development_sequences)
    if (explicit_fit is None) != (explicit_calibration is None):
        raise ValueError("fit-sequences and calibration-sequences must be provided together")
    if explicit_fit is not None and (not explicit_fit or not explicit_calibration):
        raise ValueError("explicit fit and calibration sequences must be nonempty")
    if any(not value.startswith("seq_") for value in (*(() if explicit_fit is None else explicit_fit), *(() if explicit_calibration is None else explicit_calibration), *(() if explicit_development is None else explicit_development))):
        raise ValueError("explicit sequences must use canonical seq_XXX names")
    parameters = route_parameters(args.route)
    if args.base_trust_radius_m is not None:
        if args.base_trust_radius_m <= 0.0:
            raise ValueError("base trust radius must be positive")
        parameters["base_trust_radius_m"] = float(args.base_trust_radius_m)
    parameters["identity_action"] = bool(args.identity_action)
    parameters["identity_support_radius_m"] = float(args.identity_support_radius_m)
    records = load_record_index(args.split_manifest)
    development_sequences = explicit_development or (
        full_route_development_sequences(records, args.route)
        if args.development_scope == "full_route"
        else split.development
    )
    if not development_sequences:
        raise ValueError("requested Development scope contains no route sequences")
    fit = load_episodes(
        route=args.route,
        sequences=split.fit if explicit_fit is None else explicit_fit,
        runtime_root=args.runtime_root,
        r8_root=args.r8_root,
        data_root=args.data_root,
        records=records,
        trust_radius_m=float(parameters["base_trust_radius_m"]),
        identity_action=bool(args.identity_action),
        identity_support_radius_m=float(args.identity_support_radius_m),
    )
    calibration = load_episodes(
        route=args.route,
        sequences=split.calibration if explicit_calibration is None else explicit_calibration,
        runtime_root=args.runtime_root,
        r8_root=args.r8_root,
        data_root=args.data_root,
        records=records,
        trust_radius_m=float(parameters["base_trust_radius_m"]),
        identity_action=bool(args.identity_action),
        identity_support_radius_m=float(args.identity_support_radius_m),
    )
    feature_dim = int(fit[0].candidate_feature.shape[-1])
    if any(episode.candidate_feature.shape[-1] != feature_dim for episode in [*fit, *calibration]):
        raise ValueError("candidate feature dimensions differ across route episodes")
    model = make_model(args.route, feature_dim).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    history: list[dict[str, float | int]] = []
    best_key: float | None = None
    best_state: dict[str, Tensor] | None = None
    stale = 0

    for epoch in range(1, args.epochs + 1):
        model.train()
        order = list(range(len(fit)))
        random.shuffle(order)
        train_rows: list[dict[str, float]] = []
        for index in order:
            optimizer.zero_grad(set_to_none=True)
            loss, metrics = episode_loss(model, to_batch(fit[index], device), args.route)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()
            train_rows.append(metrics)
        scheduler.step()
        calibration_metrics = evaluate_loss(model, calibration, device, args.route)
        train_loss = float(np.mean([row["loss"] for row in train_rows]))
        row: dict[str, float | int] = {
            "epoch": epoch,
            "train_loss": train_loss,
            "calibration_loss": calibration_metrics["loss"],
            "calibration_set_nll": calibration_metrics["set_nll"],
            "learning_rate": float(scheduler.get_last_lr()[0]),
        }
        history.append(row)
        print(json.dumps(row), flush=True)
        key = float(calibration_metrics["loss"])
        if best_key is None or key < best_key - 1.0e-8:
            best_key = key
            best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= args.patience:
            break
    if best_state is None:
        raise RuntimeError("training did not produce a checkpoint")

    model.load_state_dict(best_state, strict=True)
    model.eval()
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "brace_v4_r8_route_specialist_v2",
        "specialist": ("IC-MHPA-D" if args.identity_action and args.route == "outdoor_dry_complex" else "MHPC-D") if args.route == "outdoor_dry_complex" else "WTTI-W",
        "route": args.route,
        "model_kwargs": {"feature_dim": feature_dim},
        "model_state": model.state_dict(),
        "fit_sequences": split.fit if explicit_fit is None else explicit_fit,
        "calibration_sequences": split.calibration if explicit_calibration is None else explicit_calibration,
        "development_sequences_reserved": development_sequences,
        "parameters": parameters,
        "selection_metric": "train_only_r8_set_valued_calibration_loss",
        "forbidden_reads": {
            "target_final_bev_train": False,
            "development_train": False,
            "locked_test": False,
            "rgb": False,
            "depth": False,
            "right_rgb": False,
            "manual_ra_anchor": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    contract = {
        "schema_version": "brace_v4_r8_route_specialist_v2_training_contract",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "specialist": checkpoint["specialist"],
        "fit_sequences": list(split.fit if explicit_fit is None else explicit_fit),
        "calibration_sequences": list(split.calibration if explicit_calibration is None else explicit_calibration),
        "reserved_development_sequences": list(development_sequences),
        "development_scope": args.development_scope,
        "checkpoint_sha256": sha256(checkpoint_path),
        "best_calibration_loss": best_key,
        "epochs_completed": len(history),
        "runtime_inputs": [
            "candidate_xy_m", "candidate_valid", "raw_candidate_score", "source_candidate_score",
            "adapted_candidate_score", "candidate_ra_mti_agreement", "candidate_background_risk",
            "candidate_temporal_persistence",
            *( ["exact_frozen_CORA_identity_action"] if args.identity_action else [] ),
            *( ["same_frame_ra_ra_mti_candidate_patches"] if args.route == "outdoor_wet_return" else [] ),
        ],
        "teacher_inputs_only": ["R8_candidate_set_mask", "R8_candidate_set_weight", "R8_sample_weight"],
        "forbidden_reads": checkpoint["forbidden_reads"],
        "development_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "training_contract.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "history.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(contract, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
