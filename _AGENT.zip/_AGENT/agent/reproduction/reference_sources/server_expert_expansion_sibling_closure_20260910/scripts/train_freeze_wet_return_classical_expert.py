#!/usr/bin/env python3
"""Train and freeze a data-efficient daytime wet-return candidate expert."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.r11_physical_candidate_association import validate_pca_cache_contract
from brace_v4.wet_return_candidate_association import (
    map_offline_teacher_to_physical_candidates,
    validate_daytime_wet_split,
)
from brace_v4.wet_return_classical_expert import (
    build_candidate_features,
    causal_candidate_track,
)


VARIANTS: dict[str, dict[str, float | int | bool]] = {
    "wrca_graph": {"max_iter": 180, "max_leaf_nodes": 31, "min_samples_leaf": 24, "maximum_step_m": 0.35, "transition_scale_m": 0.14, "harm_budget": 0.08},
    "wrca_tbd": {"max_iter": 240, "max_leaf_nodes": 63, "min_samples_leaf": 20, "maximum_step_m": 0.45, "transition_scale_m": 0.18, "harm_budget": 0.08},
    "wrca_bg": {"max_iter": 220, "max_leaf_nodes": 31, "min_samples_leaf": 30, "maximum_step_m": 0.35, "transition_scale_m": 0.14, "harm_budget": 0.07},
    "wrca_risk": {"max_iter": 180, "max_leaf_nodes": 15, "min_samples_leaf": 36, "maximum_step_m": 0.30, "transition_scale_m": 0.12, "harm_budget": 0.04},
    "wrca_hybrid": {"max_iter": 260, "max_leaf_nodes": 63, "min_samples_leaf": 24, "maximum_step_m": 0.40, "transition_scale_m": 0.15, "harm_budget": 0.06},
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=tuple(VARIANTS), required=True)
    parser.add_argument("--train-cache", type=Path, required=True)
    parser.add_argument("--development-runtime", type=Path, required=True)
    parser.add_argument("--supervision-root", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=3407)
    return parser.parse_args()


def load_npz(path: Path) -> dict[str, np.ndarray]:
    if not path.is_file():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key].copy() for key in archive.files}


def load_cache(root: Path, sequence: str, *, require_targets: bool) -> dict[str, np.ndarray]:
    record = load_npz(root / f"{sequence}.npz")
    validate_pca_cache_contract(record, require_train_targets=require_targets)
    if str(np.asarray(record["sequence"]).item()) != sequence:
        raise ValueError("classical wet-return cache sequence mismatch")
    if str(np.asarray(record["route"]).item()) != "outdoor_wet_return":
        raise ValueError("classical wet-return cache route mismatch")
    return record


def load_supervised_record(
    cache_root: Path,
    supervision_root: Path,
    sequence: str,
    *,
    allowed_sequences: list[str],
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray], dict[str, Any]]:
    record = load_cache(cache_root, sequence, require_targets=True)
    teacher = load_npz(supervision_root / f"{sequence}.npz")
    mapped, audit = map_offline_teacher_to_physical_candidates(
        record,
        teacher,
        allowed_sequences=allowed_sequences,
        maximum_mapping_error_m=0.30,
        target_sigma_m=0.12,
    )
    return mapped, teacher, audit


def candidate_training_rows(records: list[dict[str, np.ndarray]]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    features: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    weights: list[np.ndarray] = []
    for record in records:
        candidate_feature = build_candidate_features(record)
        valid = np.asarray(record["candidate_valid"], dtype=bool)[:, 1:]
        active = np.asarray(record["sample_weight"], dtype=np.float32) > 0.0
        target = np.asarray(record["target_weight"], dtype=np.float32)[:, 1:]
        target_index = np.argmax(target, axis=1)
        for frame in np.flatnonzero(active):
            keep = valid[frame]
            frame_label = np.zeros(int(keep.sum()), dtype=np.int8)
            valid_indices = np.flatnonzero(keep)
            match = np.flatnonzero(valid_indices == target_index[frame])
            if match.size != 1:
                continue
            frame_label[int(match[0])] = 1
            frame_weight = np.full(frame_label.shape, float(record["sample_weight"][frame]), dtype=np.float32)
            frame_weight[frame_label == 1] *= 28.0
            features.append(candidate_feature[frame, keep])
            labels.append(frame_label)
            weights.append(frame_weight)
    if not features:
        raise RuntimeError("classical wet-return ranker has no supervised candidates")
    return np.concatenate(features), np.concatenate(labels), np.concatenate(weights)


def fit_ranker(records: list[dict[str, np.ndarray]], config: dict[str, Any], seed: int) -> HistGradientBoostingClassifier:
    features, labels, weights = candidate_training_rows(records)
    model = HistGradientBoostingClassifier(
        learning_rate=0.05,
        max_iter=int(config["max_iter"]),
        max_leaf_nodes=int(config["max_leaf_nodes"]),
        min_samples_leaf=int(config["min_samples_leaf"]),
        l2_regularization=1.0,
        early_stopping=False,
        random_state=seed,
    )
    model.fit(features, labels, sample_weight=weights)
    return model


def rank_candidates(model: HistGradientBoostingClassifier, record: dict[str, np.ndarray]) -> np.ndarray:
    features = build_candidate_features(record)
    valid = np.asarray(record["candidate_valid"], dtype=bool)[:, 1:]
    probability = np.zeros(valid.shape, dtype=np.float32)
    probability[valid] = model.predict_proba(features[valid])[:, 1].astype(np.float32)
    return probability


def proposal_indices(
    probability: np.ndarray,
    record: dict[str, np.ndarray],
    config: dict[str, Any],
) -> np.ndarray:
    return causal_candidate_track(
        np.log(np.maximum(probability, 1.0e-7)),
        np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 1:],
        np.asarray(record["candidate_valid"], dtype=bool)[:, 1:],
        maximum_step_m=float(config["maximum_step_m"]),
        transition_scale_m=float(config["transition_scale_m"]),
    )


def gate_features(
    probability: np.ndarray,
    selected: np.ndarray,
    record: dict[str, np.ndarray],
) -> np.ndarray:
    frame = np.arange(probability.shape[0])
    selected_probability = probability[frame, selected]
    ordered = np.sort(probability, axis=1)
    margin = ordered[:, -1] - ordered[:, -2]
    normalized = probability / np.maximum(probability.sum(axis=1, keepdims=True), 1.0e-8)
    entropy = -(normalized * np.log(np.maximum(normalized, 1.0e-8))).sum(axis=1)
    physical_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 1:]
    parent_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 0]
    proposal_xy = physical_xy[frame, selected]
    displacement = proposal_xy - parent_xy
    proposal_token = np.asarray(record["candidate_token"], dtype=np.float32)[:, 1:][frame, selected]
    parent_token = np.asarray(record["candidate_token"], dtype=np.float32)[:, 0]
    global_state = np.asarray(record["global_state"], dtype=np.float32)
    return np.concatenate(
        (
            selected_probability[:, None],
            margin[:, None],
            entropy[:, None],
            displacement,
            np.linalg.norm(displacement, axis=1, keepdims=True),
            proposal_token,
            parent_token,
            global_state,
        ),
        axis=1,
    ).astype(np.float32)


def fit_gate(
    ranker: HistGradientBoostingClassifier,
    records: list[dict[str, np.ndarray]],
    teachers: list[dict[str, np.ndarray]],
    config: dict[str, Any],
    seed: int,
) -> tuple[HistGradientBoostingClassifier, float, dict[str, Any]]:
    feature_rows: list[np.ndarray] = []
    label_rows: list[np.ndarray] = []
    weight_rows: list[np.ndarray] = []
    calibration_rows: list[tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = []
    for record, teacher in zip(records, teachers, strict=True):
        probability = rank_candidates(ranker, record)
        selected = proposal_indices(probability, record, config)
        frame = np.arange(selected.size)
        proposal_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 1:][frame, selected]
        parent_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 0]
        target_xy = np.asarray(teacher["selected_candidate_xy_m"], dtype=np.float32)
        active = np.asarray(record["sample_weight"], dtype=np.float32) > 0.0
        proposal_error = np.linalg.norm(proposal_xy - target_xy, axis=1)
        parent_error = np.linalg.norm(parent_xy - target_xy, axis=1)
        benefit = proposal_error + 0.03 < parent_error
        feature_rows.append(gate_features(probability, selected, record)[active])
        label_rows.append(benefit[active].astype(np.int8))
        weight_rows.append(np.asarray(record["sample_weight"], dtype=np.float32)[active])
        calibration_rows.append((proposal_error, parent_error, active, np.asarray(record["sample_weight"], dtype=np.float32)))

    x = np.concatenate(feature_rows)
    y = np.concatenate(label_rows)
    weight = np.concatenate(weight_rows)
    if np.unique(y).size < 2:
        raise RuntimeError("classical wet-return gate requires both benefit classes")
    gate = HistGradientBoostingClassifier(
        learning_rate=0.04,
        max_iter=140,
        max_leaf_nodes=9,
        min_samples_leaf=24,
        l2_regularization=2.0,
        early_stopping=False,
        random_state=seed + 1,
    )
    class_balance = np.where(y == 1, max(float((y == 0).sum()) / max(float((y == 1).sum()), 1.0), 1.0), 1.0)
    gate.fit(x, y, sample_weight=weight * class_balance)

    probability_rows: list[np.ndarray] = []
    for record in records:
        candidate_probability = rank_candidates(ranker, record)
        selected = proposal_indices(candidate_probability, record, config)
        probability_rows.append(gate.predict_proba(gate_features(candidate_probability, selected, record))[:, 1])
    benefit_probability = np.concatenate(probability_rows)
    proposal_error = np.concatenate([row[0] for row in calibration_rows])
    parent_error = np.concatenate([row[1] for row in calibration_rows])
    active = np.concatenate([row[2] for row in calibration_rows])
    frame_weight = np.concatenate([row[3] for row in calibration_rows])

    best: dict[str, Any] | None = None
    thresholds = sorted({float(value) for value in benefit_probability[active]}, reverse=True)
    thresholds.append(0.0)
    baseline_hit = parent_error <= 0.30
    for threshold in thresholds:
        accept = active & (benefit_probability >= threshold)
        coverage = float(frame_weight[accept].sum() / max(frame_weight[active].sum(), 1.0e-8))
        if coverage < 0.05:
            continue
        harm = accept & (proposal_error > parent_error + 0.05)
        harm_rate = float(frame_weight[harm].sum() / max(frame_weight[accept].sum(), 1.0e-8))
        if harm_rate > float(config["harm_budget"]):
            continue
        final_error = np.where(accept, proposal_error, parent_error)
        gain = float(np.average((final_error <= 0.30).astype(np.float32) - baseline_hit.astype(np.float32), weights=np.maximum(frame_weight, 1.0e-8)))
        candidate = {"threshold": threshold, "coverage": coverage, "harm_rate": harm_rate, "pseudo_hit_0p30_gain": gain}
        if best is None or (gain, coverage) > (best["pseudo_hit_0p30_gain"], best["coverage"]):
            best = candidate
    if best is None:
        best = {"threshold": 1.1, "coverage": 0.0, "harm_rate": 0.0, "pseudo_hit_0p30_gain": 0.0}
    return gate, float(best["threshold"]), best


def freeze_development(
    *,
    ranker: HistGradientBoostingClassifier,
    gate: HistGradientBoostingClassifier,
    threshold: float,
    config: dict[str, Any],
    runtime_root: Path,
    sequences: list[str],
    output_dir: Path,
    variant: str,
    checkpoint_path: Path,
) -> None:
    aggregate: dict[str, list[np.ndarray]] = {key: [] for key in (
        "sequence", "frame_id", "cora0_xy_m", "cora0_score", "se1_xy_m", "se1_score",
        "se2_xy_m", "se2_score", "wrca_xy_m", "wrca_score", "selected_physical_index",
        "benefit_probability", "physical_candidate_probability", "intervened",
    )}
    hashes: dict[str, str] = {}
    for sequence in sequences:
        path = runtime_root / f"{sequence}.npz"
        record = load_cache(runtime_root, sequence, require_targets=False)
        candidate_probability = rank_candidates(ranker, record)
        selected = proposal_indices(candidate_probability, record, config)
        frame = np.arange(selected.size)
        physical_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 1:]
        proposal_xy = physical_xy[frame, selected]
        benefit_probability = gate.predict_proba(gate_features(candidate_probability, selected, record))[:, 1].astype(np.float32)
        intervened = benefit_probability >= threshold
        parent_xy = np.asarray(record["candidate_xy_m"], dtype=np.float32)[:, 0]
        final_xy = np.where(intervened[:, None], proposal_xy, parent_xy).astype(np.float32)
        frames = int(np.asarray(record["frame_id"]).size)
        aggregate["sequence"].append(np.full(frames, sequence))
        for key in ("frame_id", "cora0_peak_xy_m", "cora0_peak_score", "se1_peak_xy_m", "se1_peak_score", "se2_peak_xy_m", "se2_peak_score"):
            aggregate[key.replace("_peak", "")].append(np.asarray(record[key]))
        aggregate["wrca_xy_m"].append(final_xy)
        aggregate["wrca_score"].append(np.asarray(record["se2_peak_score"], dtype=np.float32))
        aggregate["selected_physical_index"].append(selected.astype(np.int16))
        aggregate["benefit_probability"].append(benefit_probability)
        aggregate["physical_candidate_probability"].append(candidate_probability.astype(np.float32))
        aggregate["intervened"].append(intervened.astype(np.bool_))
        hashes[sequence] = sha256(path)

    output_dir.mkdir(parents=True, exist_ok=True)
    prediction_path = output_dir / "wrca_daytime_development_predictions.npz"
    np.savez_compressed(prediction_path, **{key: np.concatenate(value, axis=0) for key, value in aggregate.items()})
    freeze = {
        "schema_version": "brace_v4_wrca_prediction_freeze_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "variant": variant,
        "route": "outdoor_wet_return",
        "development_sequences": sequences,
        "nighttime_sequences_read": [],
        "checkpoint": {"path": str(checkpoint_path), "sha256": sha256(checkpoint_path)},
        "gate": {"threshold": threshold},
        "runtime_sha256": hashes,
        "prediction_file": {"path": prediction_path.name, "sha256": sha256(prediction_path)},
        "development_labels_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }
    (output_dir / "PREDICTION_FREEZE.json").write_text(json.dumps(freeze, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    validate_daytime_wet_split(
        fit_sequences=protocol["fit_sequences"],
        calibration_sequences=protocol["calibration_sequences"],
        development_sequences=protocol["development_sequences"],
    )
    allowed = list(protocol["fit_sequences"]) + list(protocol["calibration_sequences"])
    fit_rows = [load_supervised_record(args.train_cache, args.supervision_root, sequence, allowed_sequences=allowed) for sequence in protocol["fit_sequences"]]
    calibration_rows = [load_supervised_record(args.train_cache, args.supervision_root, sequence, allowed_sequences=allowed) for sequence in protocol["calibration_sequences"]]
    fit_records = [row[0] for row in fit_rows]
    calibration_records = [row[0] for row in calibration_rows]
    calibration_teachers = [row[1] for row in calibration_rows]
    config = dict(VARIANTS[args.variant])
    ranker = fit_ranker(fit_records, config, args.seed)
    gate, threshold, gate_audit = fit_gate(ranker, calibration_records, calibration_teachers, config, args.seed)

    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "classical_wet_return_expert.joblib"
    joblib.dump({"ranker": ranker, "gate": gate, "threshold": threshold, "config": config}, checkpoint_path)
    contract = {
        "schema_version": "brace_v4_classical_wet_return_expert_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "variant": args.variant,
        "architecture": "GradientBoostedCandidateRanker+CausalTrackBeforeDetect+BenefitGate",
        "route": "outdoor_wet_return",
        "fit_sequences": list(protocol["fit_sequences"]),
        "calibration_sequences": list(protocol["calibration_sequences"]),
        "development_sequences": list(protocol["development_sequences"]),
        "supervision": "offline_daytime_visual_radar_candidate_teacher",
        "fit_mapping_audit": [row[2] for row in fit_rows],
        "calibration_mapping_audit": [row[2] for row in calibration_rows],
        "gate_audit": gate_audit,
        "checkpoint_sha256": sha256(checkpoint_path),
        "nighttime_wet_read": False,
        "development_labels_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
        "depth_read": False,
        "right_rgb_read": False,
        "model_future_frame_input": False,
    }
    (args.output_dir / "run_contract.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    freeze_development(
        ranker=ranker,
        gate=gate,
        threshold=threshold,
        config=config,
        runtime_root=args.development_runtime,
        sequences=list(protocol["development_sequences"]),
        output_dir=args.output_dir,
        variant=args.variant,
        checkpoint_path=checkpoint_path,
    )
    print(json.dumps({"variant": args.variant, "threshold": threshold, "gate_audit": gate_audit}, ensure_ascii=False))


if __name__ == "__main__":
    main()
