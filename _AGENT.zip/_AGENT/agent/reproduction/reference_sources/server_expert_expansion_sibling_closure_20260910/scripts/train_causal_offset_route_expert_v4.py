#!/usr/bin/env python3
"""Train a V4 continuous route expert from causal label-free track teachers."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as functional
from torch.utils.data import DataLoader

from brace_v4.route_offset_data_v4 import CausalTeacherOffsetDataset
from brace_v4.route_offset_expert_v4 import CausalOffsetRouteExpert


ROUTE_CONFIG = {
    "corner_nlos_ris": {"hidden_dim": 96, "history_length": 16, "max_offset_m": 0.50},
    "open_indoor_los": {"hidden_dim": 64, "history_length": 8, "max_offset_m": 0.30},
    "outdoor_dry_complex": {"hidden_dim": 96, "history_length": 8, "max_offset_m": 2.00},
    "outdoor_wet_return": {"hidden_dim": 96, "history_length": 8, "max_offset_m": 0.50},
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def move(batch: dict[str, object], device: torch.device) -> dict[str, object]:
    return {
        key: value.to(device, non_blocking=True) if isinstance(value, torch.Tensor) else value
        for key, value in batch.items()
    }


def batch_loss(output: dict[str, torch.Tensor], batch: dict[str, object]) -> torch.Tensor:
    target = batch["target_offset_xy"]
    weight = batch["sample_weight"]
    error = output["shadow_offset_xy"] - target
    regression = functional.smooth_l1_loss(
        output["shadow_offset_xy"],
        target,
        beta=0.05,
        reduction="none",
    ).mean(dim=-1)
    variance = torch.diagonal(output["covariance"], dim1=-2, dim2=-1).clamp_min(1e-5)
    nll = 0.5 * (error.square() / variance + variance.log()).mean(dim=-1)
    acceptance = functional.binary_cross_entropy(
        output["learned_acceptance"],
        batch["target_acceptance"],
        reduction="none",
    )
    total = regression + 0.02 * nll + 0.10 * acceptance + 0.002 * output["shadow_offset_xy"].square().sum(dim=-1)
    return (weight * total).sum() / weight.sum().clamp_min(1.0)


def collect(
    model: CausalOffsetRouteExpert,
    loader: DataLoader,
    device: torch.device,
) -> dict[str, np.ndarray | float]:
    model.eval()
    losses: list[float] = []
    targets: list[np.ndarray] = []
    offsets: list[np.ndarray] = []
    acceptance: list[np.ndarray] = []
    valid: list[np.ndarray] = []
    with torch.inference_mode():
        for batch in loader:
            batch = move(batch, device)
            output = model(batch["history_tokens"], batch["history_base_xy"])
            losses.append(float(batch_loss(output, batch).cpu()))
            targets.append(batch["target_offset_xy"].cpu().numpy())
            offsets.append(output["shadow_offset_xy"].cpu().numpy())
            acceptance.append(output["learned_acceptance"].cpu().numpy())
            valid.append(batch["radar_training_valid"].cpu().numpy())
    return {
        "loss": float(np.mean(losses)),
        "target_offset": np.concatenate(targets),
        "predicted_offset": np.concatenate(offsets),
        "acceptance": np.concatenate(acceptance),
        "valid": np.concatenate(valid),
    }


def calibrate(values: dict[str, np.ndarray | float]) -> dict[str, object]:
    target = np.asarray(values["target_offset"])
    predicted = np.asarray(values["predicted_offset"])
    acceptance = np.asarray(values["acceptance"])
    valid = np.asarray(values["valid"], dtype=np.bool_)
    target = target[valid]
    predicted = predicted[valid]
    acceptance = acceptance[valid]
    base_error = np.linalg.norm(target, axis=1)
    best: dict[str, object] | None = None
    for threshold in np.linspace(0.20, 0.90, 29):
        intervene = acceptance >= threshold
        final_offset = np.where(intervene[:, None], acceptance[:, None] * predicted, 0.0)
        expert_error = np.linalg.norm(final_offset - target, axis=1)
        harm = float(np.mean(expert_error > base_error + 1e-6))
        candidate = {
            "acceptance_threshold": float(threshold),
            "base_teacher_mae_m": float(np.mean(base_error)),
            "expert_teacher_mae_m": float(np.mean(expert_error)),
            "teacher_mae_gain_m": float(np.mean(base_error) - np.mean(expert_error)),
            "base_teacher_p90_m": float(np.quantile(base_error, 0.90)),
            "expert_teacher_p90_m": float(np.quantile(expert_error, 0.90)),
            "shadow_harm_rate": harm,
            "intervention_rate": float(np.mean(intervene)),
        }
        safe = (
            candidate["teacher_mae_gain_m"] > 0.0
            and candidate["expert_teacher_p90_m"] <= candidate["base_teacher_p90_m"] + 1e-9
            and harm <= 0.20
        )
        if safe and (
            best is None
            or (
                candidate["teacher_mae_gain_m"],
                -candidate["shadow_harm_rate"],
                candidate["intervention_rate"],
            )
            > (
                best["teacher_mae_gain_m"],
                -best["shadow_harm_rate"],
                best["intervention_rate"],
            )
        ):
            best = candidate
    if best is None:
        best = {
            "acceptance_threshold": 1.0,
            "base_teacher_mae_m": float(np.mean(base_error)),
            "expert_teacher_mae_m": float(np.mean(base_error)),
            "teacher_mae_gain_m": 0.0,
            "base_teacher_p90_m": float(np.quantile(base_error, 0.90)),
            "expert_teacher_p90_m": float(np.quantile(base_error, 0.90)),
            "shadow_harm_rate": 0.0,
            "intervention_rate": 0.0,
        }
    best["eligible_for_shadow_canary"] = bool(
        best["teacher_mae_gain_m"] >= 0.003
        and best["intervention_rate"] >= 0.01
        and best["shadow_harm_rate"] <= 0.20
    )
    return best


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--route", choices=tuple(ROUTE_CONFIG), required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=12)
    parser.add_argument("--seed", type=int, default=3407)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    config = ROUTE_CONFIG[args.route]
    train_set = CausalTeacherOffsetDataset(
        args.cache_dir,
        args.route,
        "train",
        history_length=config["history_length"],
    )
    shadow_set = CausalTeacherOffsetDataset(
        args.cache_dir,
        args.route,
        "shadow",
        history_length=config["history_length"],
    )
    train_loader = DataLoader(
        train_set,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    shadow_loader = DataLoader(
        shadow_set,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    sample = train_set[0]
    model_kwargs = {
        "token_dim": int(sample["history_tokens"].shape[-1]),
        "hidden_dim": int(config["hidden_dim"]),
        "top_k": int(sample["history_tokens"].shape[-2]),
        "max_offset_m": float(config["max_offset_m"]),
    }
    model = CausalOffsetRouteExpert(**model_kwargs).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    run_config = {
        "schema_version": "brace_v4_causal_offset_route_training_v1",
        "route": args.route,
        "teacher": "route_specific_current_and_past_frozen_base_track",
        "model_kwargs": model_kwargs,
        "human_coordinate_read": False,
        "final_bev_read": False,
        "depth_read": False,
        "right_rgb_read": False,
        "locked_test_read": False,
        "arguments": {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()},
    }
    (args.output_dir / "run_config.json").write_text(
        json.dumps(run_config, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    history: list[dict[str, object]] = []
    best_state: dict[str, torch.Tensor] | None = None
    best_loss = float("inf")
    stale = 0
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses: list[float] = []
        for batch in train_loader:
            batch = move(batch, device)
            optimizer.zero_grad(set_to_none=True)
            output = model(batch["history_tokens"], batch["history_base_xy"])
            loss = batch_loss(output, batch)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        scheduler.step()
        shadow = collect(model, shadow_loader, device)
        record = {
            "epoch": epoch,
            "train_loss": float(np.mean(losses)),
            "shadow_loss": float(shadow["loss"]),
        }
        history.append(record)
        print(json.dumps(record), flush=True)
        if float(shadow["loss"]) < best_loss - 1e-6:
            best_loss = float(shadow["loss"])
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= args.patience:
            break
    if best_state is None:
        raise RuntimeError("offset expert did not produce a checkpoint")
    model.load_state_dict(best_state, strict=True)
    shadow = collect(model, shadow_loader, device)
    calibration = calibrate(shadow)
    model.rollback()
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "brace_v4_causal_offset_route_checkpoint_v1",
        "route": args.route,
        "model_kwargs": model_kwargs,
        "model_state": model.state_dict(),
        "calibration": calibration,
        "shadow_canary_eligible": bool(calibration["eligible_for_shadow_canary"]),
        "deployment_gate": "identity_locked",
        "human_coordinate_read": False,
        "final_bev_read": False,
        "locked_test_read": False,
    }
    torch.save(checkpoint, checkpoint_path)
    complete = {
        "schema_version": "brace_v4_causal_offset_route_training_complete_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "epochs": len(history),
        "training_samples": len(train_set),
        "shadow_samples": len(shadow_set),
        "calibration": calibration,
        "checkpoint_sha256": sha256(checkpoint_path),
        "deployment_gate": "identity_locked",
        "locked_test_read": False,
    }
    (args.output_dir / "history.json").write_text(
        json.dumps(history, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    (args.output_dir / "training_complete.json").write_text(
        json.dumps(complete, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(complete, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()

