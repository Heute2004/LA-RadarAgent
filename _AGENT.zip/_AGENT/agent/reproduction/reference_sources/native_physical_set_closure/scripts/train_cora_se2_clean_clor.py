#!/usr/bin/env python3
"""Train source-only CLOR tail refinement for the clean CORA-SE1 route."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor
from torch.nn import functional as functional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.route_specialists_se2_cache_data import RouteRuntimeEpisode, load_route_runtime_episode, resolve_source_final_bev_track
from brace_v4.route_specialists_se2_contract import load_route_specialist_protocol
from brace_v4.route_specialists_se2_models import CLORSE2Expert


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = True


def load_source_labels(data_root: Path, sequence: str, frame_ids: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Read labels only from declared source-clean sequences."""

    path = resolve_source_final_bev_track(data_root, sequence)
    rows: dict[int, tuple[float, float, bool]] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            valid = str(row["final_label_valid"]).strip().lower() in {"1", "true", "yes"}
            valid &= str(row.get("first_pass_training_valid", "1")).strip().lower() in {"1", "true", "yes"}
            rows[int(row["frame_id"])] = (float(row["final_radar_x_m"]), float(row["final_radar_y_m"]), valid)
    target = np.full((frame_ids.size, 2), np.nan, dtype=np.float32)
    valid = np.zeros(frame_ids.size, dtype=bool)
    for index, frame_id in enumerate(frame_ids):
        if int(frame_id) not in rows:
            raise ValueError(f"source label timeline mismatch: {sequence} frame={frame_id}")
        x, y, accepted = rows[int(frame_id)]
        target[index] = (x, y)
        valid[index] = accepted
    return target, valid


def to_tensors(episode: RouteRuntimeEpisode, target: np.ndarray, valid: np.ndarray, device: torch.device) -> tuple[Tensor, Tensor, Tensor, Tensor]:
    feature = torch.from_numpy(episode.candidate_feature[:, 0].copy()).unsqueeze(0).to(device)
    base = torch.from_numpy(episode.base_xy_m.copy()).unsqueeze(0).to(device)
    target_tensor = torch.from_numpy(target.copy()).unsqueeze(0).to(device)
    mask = torch.from_numpy((valid & episode.radar_training_valid).copy()).unsqueeze(0).to(device)
    return base, feature, target_tensor, mask


def source_loss(model: CLORSE2Expert, batch: tuple[Tensor, Tensor, Tensor, Tensor]) -> tuple[Tensor, dict[str, float], dict[str, Tensor]]:
    base, feature, target, valid = batch
    output = model(base, feature)
    if not bool(valid.any()):
        raise ValueError("source CLOR episode has no valid supervision")
    proposal_error = torch.linalg.vector_norm(output["proposal_xy"] - target, dim=-1)
    base_error = torch.linalg.vector_norm(base - target, dim=-1)
    huber = functional.smooth_l1_loss(output["proposal_xy"][valid], target[valid])
    variance = output["covariance"].clamp_min(1.0e-3)
    delta = output["proposal_xy"] - target
    nll = (0.5 * (delta.square() / variance + variance.log()).sum(dim=-1))[valid].mean()
    gate_target = (proposal_error + 0.02 < base_error).float()
    gate = functional.binary_cross_entropy(output["acceptance"][valid], gate_target[valid])
    if output["proposal_xy"].shape[1] > 1:
        motion = functional.huber_loss(
            output["proposal_xy"][:, 1:] - output["proposal_xy"][:, :-1],
            target[:, 1:] - target[:, :-1],
        )
    else:
        motion = huber * 0.0
    total = huber + 0.10 * nll + 0.10 * gate + 0.05 * motion
    return total, {
        "loss": float(total.detach()),
        "huber": float(huber.detach()),
        "nll": float(nll.detach()),
        "gate": float(gate.detach()),
        "motion": float(motion.detach()),
    }, output


@torch.inference_mode()
def calibration_score(model: CLORSE2Expert, batch: tuple[Tensor, Tensor, Tensor, Tensor]) -> tuple[dict[str, float], list[tuple[float, float, float]]]:
    _, _, target, valid = batch
    total, metrics, output = source_loss(model, batch)
    base = batch[0]
    values: list[tuple[float, float, float]] = []
    for threshold in np.arange(0.10, 0.91, 0.10):
        prediction = torch.where(output["acceptance"][..., None].ge(float(threshold)), output["proposal_xy"], base)
        error = torch.linalg.vector_norm(prediction - target, dim=-1)[valid]
        values.append((float(threshold), float(torch.quantile(error, 0.90)), float(error.median())))
    metrics["loss"] = float(total.detach())
    return metrics, values


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "CORA_SE2_ROUTE_SPECIALISTS_PROTOCOL_V1.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    protocol = load_route_specialist_protocol(args.protocol)
    route = protocol["routes"]["clean"]
    pool = protocol["training_pools"][route["training_pool"]]
    fit_sequence = str(pool["fit_sequences"][0]).lower()
    calibration_sequence = str(pool["calibration_sequences"][0]).lower()
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("source CLOR training requires CUDA")
    seed_everything(args.seed)
    fit_episode = load_route_runtime_episode(args.runtime_root / f"{fit_sequence}.npz", expected_split="train")
    calibration_episode = load_route_runtime_episode(args.runtime_root / f"{calibration_sequence}.npz", expected_split="train")
    if fit_episode.route != "clean" or calibration_episode.route != "clean":
        raise ValueError("clean route cache mismatch")
    fit = to_tensors(fit_episode, *load_source_labels(args.data_root, fit_sequence, fit_episode.frame_id), device)
    calibration = to_tensors(calibration_episode, *load_source_labels(args.data_root, calibration_sequence, calibration_episode.frame_id), device)
    model = CLORSE2Expert(feature_dim=fit_episode.candidate_feature.shape[-1], hidden_dim=args.hidden_dim).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    best_state: dict[str, Tensor] | None = None
    best_epoch, best_p90, stale = 0, float("inf"), 0
    history: list[dict[str, Any]] = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss, train_metrics, _ = source_loss(model, fit)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        scheduler.step()
        model.eval()
        calibration_metrics, values = calibration_score(model, calibration)
        threshold, p90, median = min(values, key=lambda row: (row[1], row[2], -row[0]))
        row = {"epoch": epoch, "train": train_metrics, "calibration": calibration_metrics, "threshold": threshold, "p90": p90, "median": median}
        history.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
        if p90 < best_p90 - 1.0e-7:
            best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            best_epoch, best_p90, stale = epoch, p90, 0
        else:
            stale += 1
        if stale >= args.patience:
            break
    if best_state is None:
        raise RuntimeError("source CLOR did not produce a checkpoint")
    model.load_state_dict(best_state, strict=True)
    _, thresholds = calibration_score(model.eval(), calibration)
    threshold, p90, median = min(thresholds, key=lambda row: (row[1], row[2], -row[0]))
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "brace_v4_cora_se2_clean_clor_v1",
        "route": "clean",
        "expert_id": route["expert_id"],
        "base_branch": route["base_branch"],
        "model_kwargs": {"feature_dim": fit_episode.candidate_feature.shape[-1], "hidden_dim": args.hidden_dim},
        "model_state": model.state_dict(),
        "fit_sequences": [fit_sequence],
        "calibration_sequences": [calibration_sequence],
        "selected_epoch": best_epoch,
        "acceptance_threshold": threshold,
        "forbidden_target_reads": {"target_final_bev": False, "development": False, "locked_test": False},
        "source_final_bev_read": True,
    }
    torch.save(checkpoint, checkpoint_path)
    report = {
        "schema_version": "brace_v4_cora_se2_clean_clor_training_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_only": True,
        "fit_sequences": [fit_sequence],
        "calibration_sequences": [calibration_sequence],
        "selected_epoch": best_epoch,
        "acceptance_threshold": threshold,
        "calibration_p90_m": p90,
        "calibration_median_m": median,
        "checkpoint_sha256": sha256(checkpoint_path),
        "target_final_bev_read": False,
        "development_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "training_contract.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "history.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
