#!/usr/bin/env python3
"""Train one post-SE2 route specialist from an admitted frozen R31 pool."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.r31_route_specialist_data import R31RouteRuntimeEpisode, load_r31_route_runtime_episode
from brace_v4.route_specialists_se2_contract import load_route_specialist_protocol
from brace_v4.route_specialists_se2_training import select_acceptance_threshold
from scripts.train_cora_se2_route_specialists import seed_everything, sha256, train_stage


_ROUTES = ("cluttered", "cluttered_or_multipath_likely", "rain_or_wet_ground")


def _episodes(root: Path, sequences: list[str], route: str) -> list[R31RouteRuntimeEpisode]:
    episodes = [load_r31_route_runtime_episode(root / f"{sequence}.npz") for sequence in sequences]
    if any(episode.route != route for episode in episodes):
        raise ValueError("R31 route runtime mismatch")
    if any(not episode.r31_set_mass_attached for episode in episodes):
        raise ValueError("R31 supervision is missing")
    return episodes


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=_ROUTES, required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "CORA_SE2_ROUTE_SPECIALISTS_PROTOCOL_V1.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--architecture", choices=("route_default", "path_association"), default="route_default")
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    audit = json.loads(args.audit.read_text(encoding="utf-8"))
    if audit.get("schema_version") != "brace_v4_r31_one_shot_postfreeze_audit_v1":
        raise ValueError("expected the one-shot R31 audit")
    route_audit = audit.get("routes", {}).get(args.route)
    if not isinstance(route_audit, dict) or not bool(route_audit.get("admitted_for_expert_training", False)):
        raise ValueError(f"R31 route was not admitted for expert training: {args.route}")
    protocol = load_route_specialist_protocol(args.protocol)
    route_record = protocol["routes"][args.route]
    pool = protocol["training_pools"][route_record["training_pool"]]
    fit_sequences = [str(value).lower() for value in pool["fit_sequences"]]
    calibration_sequences = [str(value).lower() for value in pool["calibration_sequences"]]
    fit = _episodes(args.runtime_root, fit_sequences, args.route)
    calibration = _episodes(args.runtime_root, calibration_sequences, args.route)
    feature_dim = fit[0].candidate_feature.shape[-1]
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("R31 route-specialist training requires CUDA")
    seed_everything(args.seed)
    best_epoch, history, _state, calibration_metrics, calibration_outputs = train_stage(
        route=args.route,
        episodes=fit,
        calibration=calibration,
        feature_dim=feature_dim,
        hidden_dim=args.hidden_dim,
        epochs=args.epochs,
        patience=args.patience,
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        device=device,
        architecture=args.architecture,
    )
    threshold, threshold_report = select_acceptance_threshold(*calibration_outputs)
    seed_everything(args.seed)
    _, refit_history, final_state, _, _ = train_stage(
        route=args.route,
        episodes=[*fit, *calibration],
        calibration=[*fit, *calibration],
        feature_dim=feature_dim,
        hidden_dim=args.hidden_dim,
        epochs=best_epoch,
        patience=best_epoch + 1,
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        device=device,
        architecture=args.architecture,
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "brace_v4_r31_candidate_route_specialist_v1",
        "route": args.route,
        "expert_id": route_record["expert_id"],
        "architecture": args.architecture,
        "base_branch": route_record["base_branch"],
        "model_kwargs": {"feature_dim": feature_dim, "hidden_dim": args.hidden_dim},
        "model_state": final_state,
        "fit_sequences": fit_sequences,
        "calibration_sequences": calibration_sequences,
        "selected_epoch": best_epoch,
        "acceptance_threshold": threshold,
        "selection_metric": "train_only_r31_set_mass_calibration_loss_then_set_hit",
        "r31_audit_sha256": sha256(args.audit),
        "forbidden_reads": {
            "target_final_bev_training": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
            "post_se2_historical_pseudolabel_read": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    completion = {
        "schema_version": "brace_v4_r31_candidate_route_specialist_training_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "architecture": args.architecture,
        "fit_sequences": fit_sequences,
        "calibration_sequences": calibration_sequences,
        "selected_epoch": best_epoch,
        "acceptance_threshold": threshold,
        "train_calibration": calibration_metrics,
        "threshold_report": threshold_report,
        "checkpoint_sha256": sha256(checkpoint_path),
        "development_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "training_complete.json").write_text(json.dumps(completion, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "history_stage_a.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "history_stage_b.json").write_text(json.dumps(refit_history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(completion, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
