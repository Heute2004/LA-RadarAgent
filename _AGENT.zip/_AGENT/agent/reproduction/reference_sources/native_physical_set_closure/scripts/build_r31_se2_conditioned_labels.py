#!/usr/bin/env python3
"""Build immutable post-SE2 R31 labels from observed RA/RA-MTI peaks."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor, nn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.cora_se2_r11 import CORASe2R11Detector, load_cora, sha256
from brace_v4.cora_se2_r11_data import load_r11_set_manifest
from brace_v4.cora_se2_setmass import CORASe2SetMassAdapter
from brace_v4.r8_raw96_runtime import build_raw96_candidate_evidence, transfer_r8_set_to_raw96
from brace_v4.route_specialists_se2_data import RouteCandidateEpisode, load_r11_candidate_episode
from brace_v4.se2_conditioned_candidate_refinement import (
    R31Config,
    build_conditioned_candidate_labels,
    build_r31_train_records,
    candidate_probability_from_bev_logits,
    validate_crossfit_teacher_contract,
)
from brace_v4.self_evolution_data import RadarSequenceFrames, load_episode_records


_R31_TO_R11_ROUTE = {
    "clean": "open_indoor_los",
    "cluttered": "indoor_clutter",
    "cluttered_or_multipath_likely": "outdoor_dry_complex",
    "rain_or_wet_ground": "outdoor_wet_return",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--split-config", type=Path, default=ROOT / "configs" / "V4_AGENT_EPISODE_SPLIT_V2_STRICT_V3.json")
    parser.add_argument("--r11-cache", type=Path, required=True)
    parser.add_argument("--r31-protocol", type=Path, default=ROOT / "configs" / "R31_SE2_CONDITIONED_PHYSICAL_LABEL_PROTOCOL_V1.json")
    parser.add_argument("--cora0-checkpoint", type=Path, required=True)
    parser.add_argument("--se1-checkpoint", type=Path, required=True)
    parser.add_argument("--parent-se2-checkpoint", type=Path, required=True)
    parser.add_argument("--crossfit-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return payload


def _normalised_sequence(source: RadarSequenceFrames) -> np.ndarray:
    return torch.stack([source.read_normalized(frame) for frame in source.frame_ids], dim=0).numpy().astype(np.float32, copy=False)


def _causal_batch(sequence: np.ndarray, start: int, end: int, *, length: int = 16) -> Tensor:
    clips = []
    for position in range(start, end):
        indices = [max(0, position - length + 1 + offset) for offset in range(length)]
        clips.append(torch.from_numpy(sequence[indices].copy()))
    return torch.stack(clips, dim=0)


@torch.inference_mode()
def _infer_logits(model: nn.Module, radar: np.ndarray, device: torch.device, *, batch_size: int) -> np.ndarray:
    values: list[np.ndarray] = []
    model.eval()
    for start in range(0, len(radar), batch_size):
        clip = _causal_batch(radar, start, min(start + batch_size, len(radar))).to(device)
        output = model(clip)
        values.append(output["logits"][:, 0].float().cpu().numpy())
    return np.concatenate(values, axis=0).astype(np.float32, copy=False)


def _r31_config(protocol: dict[str, Any]) -> R31Config:
    candidate = protocol["candidate_contract"]
    threshold = protocol["tier_thresholds"]
    return R31Config(
        max_step_m=float(candidate["maximum_adjacent_step_m"]),
        teacher_anchor_probability=float(threshold["teacher_anchor_probability"]),
        teacher_anchor_margin=float(threshold["teacher_anchor_margin"]),
        parent_anchor_margin=float(threshold["parent_anchor_margin"]),
        tier_a_probability=float(threshold["tier_a_probability"]),
        tier_a_margin=float(threshold["tier_a_margin"]),
        tier_a_agreement=float(threshold["tier_a_forward_backward_agreement"]),
        tier_b_candidate_mass=float(threshold["tier_b_candidate_mass"]),
        tier_b_agreement=float(threshold["tier_b_forward_backward_agreement"]),
        tier_b_relative_probability=float(threshold["tier_b_relative_probability"]),
        tier_b_max_candidates=int(threshold["tier_b_max_candidates"]),
    )


def _crossfit_teachers(
    crossfit_dir: Path,
    cora0: nn.Module,
    *,
    device: torch.device,
    expected_r11_sha256: str,
    expected_parent_se2_sha256: str,
) -> tuple[dict[str, nn.Module], dict[str, dict[str, Any]], dict[str, str]]:
    models: dict[str, nn.Module] = {}
    contracts: dict[str, dict[str, Any]] = {}
    hashes: dict[str, str] = {}
    manifest = _load_json(crossfit_dir / "CROSSFIT_MANIFEST.json")
    for fold in manifest.get("folds", ()):
        if not isinstance(fold, dict):
            raise ValueError("cross-fit manifest contains an invalid fold")
        fold_id = int(fold["fold_id"])
        path = crossfit_dir / f"fold_{fold_id}" / "CORA_SE2_CROSSFIT.pt"
        payload = torch.load(path, map_location="cpu", weights_only=False)
        if not isinstance(payload, dict):
            raise ValueError(f"invalid cross-fit checkpoint: {path}")
        adapter = CORASe2SetMassAdapter().to(device)
        adapter.load_state_dict(payload["adapter_state"], strict=True)
        detector = CORASe2R11Detector(cora0, adapter).to(device).eval()
        checkpoint_hash = sha256(path)
        for sequence in payload.get("holdout_sequences", ()):
            sequence = str(sequence).strip().lower()
            validate_crossfit_teacher_contract(
                payload,
                inference_sequence=sequence,
                expected_r11_sha256=expected_r11_sha256,
                expected_parent_se2_sha256=expected_parent_se2_sha256,
            )
            if sequence in models:
                raise ValueError(f"sequence appears in multiple cross-fit holdouts: {sequence}")
            models[sequence] = detector
            contracts[sequence] = payload
            hashes[sequence] = checkpoint_hash
    return models, contracts, hashes


def _parent_support(
    episode: RouteCandidateEpisode,
    raw: Any,
    source: RadarSequenceFrames,
) -> tuple[np.ndarray, np.ndarray]:
    if tuple(episode.frame_id.tolist()) != source.frame_ids:
        raise ValueError(f"R11/radar timeline mismatch: {source.sequence}")
    transferred = transfer_r8_set_to_raw96(
        episode.candidate_xy_m,
        episode.candidate_valid,
        episode.allowed_weight > 0.0,
        episode.allowed_weight,
        raw.candidate_xy_m,
        raw.candidate_valid,
        episode.sample_weight * source.training_valid.astype(np.float32),
        radius_m=0.25,
    )
    return transferred.allowed_weight, transferred.sample_weight


def main() -> None:
    args = parse_args()
    if args.batch_size < 1:
        raise ValueError("batch-size must be positive")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    protocol = _load_json(args.r31_protocol)
    if protocol.get("schema_version") != "brace_v4_r31_se2_conditioned_physical_label_protocol_v1":
        raise ValueError("unsupported R31 protocol")
    if protocol.get("direct_lineage") != ["cora0", "cora_se1", "cora_se2", "r31", "route_expert"]:
        raise ValueError("R31 direct lineage was modified")
    forbidden = protocol.get("forbidden_reads")
    if not isinstance(forbidden, dict) or not all(bool(value) for value in forbidden.values()):
        raise ValueError("R31 protocol must explicitly forbid every protected read")

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("R31 label construction requires CUDA")
    r11_manifest = load_r11_set_manifest(args.r11_cache)
    records = build_r31_train_records(r11_manifest)
    records_by_sequence = {record["sequence"]: record for record in load_episode_records(args.split_config, "train")}
    if set(record["sequence"] for record in records) - records_by_sequence.keys():
        raise ValueError("R31 requested a sequence outside Agent Train")
    r11_sha256 = sha256(args.r11_cache / "R11_MANIFEST.json")
    parent_se2_sha256 = sha256(args.parent_se2_checkpoint)
    parent_payload = torch.load(args.parent_se2_checkpoint, map_location="cpu", weights_only=False)
    if not isinstance(parent_payload, dict) or str(parent_payload.get("r11_manifest_sha256", "")) != r11_sha256:
        raise ValueError("R31 parent SE2/R11 hash mismatch")

    cora0 = load_cora(args.cora0_checkpoint, device)
    se1 = load_cora(args.se1_checkpoint, device)
    crossfit, contracts, crossfit_hash = _crossfit_teachers(
        args.crossfit_dir,
        cora0,
        device=device,
        expected_r11_sha256=r11_sha256,
        expected_parent_se2_sha256=parent_se2_sha256,
    )
    if set(crossfit) != set(record["sequence"] for record in records):
        raise ValueError("cross-fit holdouts do not cover the exact R31 Train scope")
    config = _r31_config(protocol)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    rows: list[dict[str, Any]] = []
    teacher_by_route = protocol["route_teacher"]
    for position, record in enumerate(records, start=1):
        sequence = record["sequence"]
        route = record["route"]
        source = RadarSequenceFrames.create(args.data_root, records_by_sequence[sequence])
        radar = _normalised_sequence(source)
        raw = build_raw96_candidate_evidence(radar)
        teacher_kind = str(teacher_by_route[route])
        if teacher_kind == "cora_se1":
            teacher = se1
            teacher_hash = sha256(args.se1_checkpoint)
            teacher_fold = -1
        elif teacher_kind == "cora0":
            teacher = cora0
            teacher_hash = sha256(args.cora0_checkpoint)
            teacher_fold = -1
        elif teacher_kind == "crossfit_cora_se2":
            teacher = crossfit[sequence]
            teacher_hash = crossfit_hash[sequence]
            teacher_fold = int(contracts[sequence]["fold_id"])
        else:
            raise ValueError(f"unsupported R31 route teacher: {teacher_kind}")
        logits = _infer_logits(teacher, radar, device, batch_size=args.batch_size)
        teacher_probability = candidate_probability_from_bev_logits(logits, raw.candidate_xy_m, raw.candidate_valid)
        episode = load_r11_candidate_episode(
            args.r11_cache / f"{sequence}.npz",
            expected_r11_route=_R31_TO_R11_ROUTE[route],
        )
        parent_allowed, parent_sample = _parent_support(episode, raw, source)
        labels = build_conditioned_candidate_labels(
            candidate_xy_m=raw.candidate_xy_m,
            candidate_valid=raw.candidate_valid,
            teacher_probability=teacher_probability,
            raw_score=raw.raw_candidate_score,
            ra_mti_agreement=raw.ra_mti_agreement,
            background_risk=raw.background_risk,
            temporal_persistence=raw.temporal_persistence,
            se2_parent_allowed_weight=parent_allowed,
            se2_parent_sample_weight=parent_sample,
            config=config,
        )
        allowed_weight = labels.allowed_weight.copy()
        sample_weight = labels.sample_weight.copy()
        tier = labels.tier.copy()
        invalid = ~source.training_valid.astype(bool)
        allowed_weight[invalid] = 0.0
        sample_weight[invalid] = 0.0
        tier[invalid] = "tier_c"
        output = args.output_dir / f"{sequence}.npz"
        np.savez_compressed(
            output,
            schema_version=np.asarray("brace_v4_r31_se2_conditioned_physical_labels_v1"),
            sequence=np.asarray(sequence),
            route=np.asarray(route),
            frame_id=np.asarray(source.frame_ids, dtype=np.int64),
            candidate_xy_m=labels.candidate_xy_m,
            candidate_valid=labels.candidate_valid,
            candidate_posterior=labels.candidate_posterior,
            allowed_weight=allowed_weight,
            sample_weight=sample_weight,
            selected_index=labels.selected_index,
            selected_xy_m=labels.selected_xy_m,
            tier=tier,
            identity_mass=labels.identity_mass,
            forward_backward_agreement=labels.forward_backward_agreement,
            posterior_margin=labels.posterior_margin,
            anchor_index=labels.anchor_index,
            teacher_probability=teacher_probability,
            teacher_kind=np.asarray(teacher_kind),
            teacher_fold=np.asarray(teacher_fold, dtype=np.int64),
            teacher_checkpoint_sha256=np.asarray(teacher_hash),
            se2_parent_allowed_weight=parent_allowed,
            se2_parent_sample_weight=parent_sample,
            raw_candidate_score=raw.raw_candidate_score,
            ra_mti_agreement=raw.ra_mti_agreement,
            background_risk=raw.background_risk,
            temporal_persistence=raw.temporal_persistence,
            radar_training_valid=source.training_valid.astype(bool),
            target_final_bev_read=np.asarray(False),
            development_read=np.asarray(False),
            locked_test_read=np.asarray(False),
            depth_read=np.asarray(False),
            right_rgb_read=np.asarray(False),
            manual_ra_anchor_read=np.asarray(False),
            post_se2_historical_pseudolabel_read=np.asarray(False),
        )
        row = {
            "sequence": sequence,
            "route": route,
            "frames": len(source.frame_ids),
            "tier_a_frames": int((tier == "tier_a").sum()),
            "tier_b_frames": int((tier == "tier_b").sum()),
            "tier_c_frames": int((tier == "tier_c").sum()),
            "teacher_kind": teacher_kind,
            "teacher_fold": teacher_fold,
            "teacher_checkpoint_sha256": teacher_hash,
            "archive_sha256": sha256(output),
        }
        rows.append(row)
        print(json.dumps({"progress": f"{position}/{len(records)}", **row}, ensure_ascii=False), flush=True)

    manifest = {
        "schema_version": "brace_v4_r31_se2_conditioned_physical_label_manifest_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "lineage": protocol["direct_lineage"],
        "sequences": rows,
        "r11_manifest_sha256": r11_sha256,
        "parent_se2_checkpoint_sha256": parent_se2_sha256,
        "r31_protocol_sha256": sha256(args.r31_protocol),
        "builder_sha256": sha256(Path(__file__)),
        "core_builder_sha256": sha256(ROOT / "src" / "brace_v4" / "se2_conditioned_candidate_refinement.py"),
        "superseded_for_expert_training": protocol["superseded_for_expert_training"],
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
            "post_se2_historical_pseudolabel_read": False,
        },
    }
    manifest_path = args.output_dir / "R31_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
