#!/usr/bin/env python3
"""Train one non-RIS candidate route specialist without target BEV labels.

This trainer is intentionally limited to the four R11-supervised routes.
``clean`` remains a separate source-supervised tail refiner because it must
never consume target R11 support merely to add a redundant correction.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor, nn
from torch.nn import functional as functional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.route_specialists_se2_cache_data import RouteRuntimeEpisode, load_route_runtime_episode
from brace_v4.route_specialists_se2_cache import training_cache_route_for_specialist
from brace_v4.route_specialists_se2_contract import load_route_specialist_protocol
from brace_v4.route_specialists_se2_models import (
    GBLESE2Expert,
    GGSRRECandidateSE2Expert,
    LTGESE2Expert,
    PathAssociationSE2Expert,
    TECSSE2Expert,
)
from brace_v4.route_specialists_se2_training import (
    candidate_set_mass_loss,
    select_acceptance_threshold,
    split_identity_from_physical_association,
)


_TARGET_ROUTES = (
    "cluttered",
    "cluttered_or_multipath_likely",
    "rain_or_wet_ground",
    "wet_ground",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = True
    torch.set_float32_matmul_precision("high")


def to_tensor(episode: RouteRuntimeEpisode, device: torch.device) -> dict[str, Tensor]:
    return {
        "candidate_xy_m": torch.from_numpy(episode.candidate_xy_m.copy()).unsqueeze(0).to(device),
        "candidate_valid": torch.from_numpy(episode.candidate_valid.copy()).unsqueeze(0).to(device),
        "candidate_feature": torch.from_numpy(episode.candidate_feature.copy()).unsqueeze(0).to(device),
        "allowed_weight": torch.from_numpy(episode.allowed_weight.copy()).unsqueeze(0).to(device),
        "sample_weight": torch.from_numpy(episode.sample_weight.copy()).unsqueeze(0).to(device),
        "radar_training_valid": torch.from_numpy(episode.radar_training_valid.copy()).unsqueeze(0).to(device),
    }


def load_episodes(root: Path, sequences: list[str], route: str) -> list[RouteRuntimeEpisode]:
    episodes = [load_route_runtime_episode(root / f"{sequence}.npz", expected_split="train") for sequence in sequences]
    expected_cache_route = training_cache_route_for_specialist(route)
    if any(episode.route != expected_cache_route for episode in episodes):
        mismatch = [(episode.sequence, episode.route) for episode in episodes if episode.route != expected_cache_route]
        raise ValueError(f"route cache mismatch: {mismatch}")
    if any(not episode.r11_set_mass_attached for episode in episodes):
        raise ValueError("target route trainer requires R11 support attached for every training episode")
    return episodes


def make_model(
    route: str,
    *,
    feature_dim: int,
    hidden_dim: int,
    architecture: str = "route_default",
) -> nn.Module:
    if architecture == "path_association":
        if route not in {"cluttered_or_multipath_likely", "rain_or_wet_ground", "wet_ground"}:
            raise ValueError("path association is reserved for outdoor multipath/weak-return routes")
        return PathAssociationSE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim, max_step_m=0.60)
    if architecture != "route_default":
        raise ValueError(f"unsupported architecture: {architecture}")
    if route == "cluttered":
        return TECSSE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim)
    if route == "cluttered_or_multipath_likely":
        return GBLESE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim, max_step_m=0.45)
    if route == "rain_or_wet_ground":
        return GGSRRECandidateSE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim)
    if route == "wet_ground":
        return LTGESE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim)
    raise ValueError(f"unsupported target route: {route}")


def model_output(model: nn.Module, route: str, values: dict[str, Tensor], *, architecture: str = "route_default") -> dict[str, Tensor]:
    if architecture == "path_association" or route == "cluttered_or_multipath_likely":
        return model(values["candidate_feature"], values["candidate_xy_m"], values["candidate_valid"])
    return model(values["candidate_feature"], values["candidate_valid"])


def _acceptance_loss(output: dict[str, Tensor], values: dict[str, Tensor]) -> Tensor:
    support = values["sample_weight"].gt(0.0) & values["allowed_weight"].sum(dim=-1).gt(0.0)
    support &= values["radar_training_valid"]
    if not bool(support.any()):
        return output["candidate_logits"].sum() * 0.0
    # Acceptance means that a correction away from candidate zero is useful;
    # it is never a person-present label.
    target = values["allowed_weight"][..., 0].lt(0.50)
    probability = output["acceptance"].clamp(1.0e-5, 1.0 - 1.0e-5)
    positive = target[support].float()
    raw = functional.binary_cross_entropy(probability[support], positive, reduction="none")
    positive_mass = positive.mean().clamp_min(0.05)
    balanced = torch.where(positive.bool(), 0.5 / positive_mass, 0.5 / (1.0 - positive_mass).clamp_min(0.05))
    return (raw * balanced).mean()


def _continuity_loss(output: dict[str, Tensor], values: dict[str, Tensor]) -> Tensor:
    logits = output["candidate_logits"]
    posterior = torch.softmax(logits, dim=-1)
    expected_xy = (posterior[..., None] * values["candidate_xy_m"]).sum(dim=2)
    if expected_xy.shape[1] < 2:
        return logits.sum() * 0.0
    step = torch.linalg.vector_norm(expected_xy[:, 1:] - expected_xy[:, :-1], dim=-1)
    valid = values["radar_training_valid"][:, 1:] & values["radar_training_valid"][:, :-1]
    if not bool(valid.any()):
        return logits.sum() * 0.0
    # This is only a physical guard against multi-metre branch jumps; it does
    # not force stationary motion or use a target trajectory.
    return functional.relu(step[valid] - 0.75).square().mean()


def episode_loss(
    model: nn.Module,
    route: str,
    episode: RouteRuntimeEpisode,
    device: torch.device,
    *,
    architecture: str = "route_default",
    association_mode: str = "joint",
) -> tuple[Tensor, dict[str, float]]:
    values = to_tensor(episode, device)
    output = model_output(model, route, values, architecture=architecture)
    association_logits = output["candidate_logits"]
    association_allowed = values["allowed_weight"]
    if association_mode == "physical_only":
        association_logits, association_allowed = split_identity_from_physical_association(
            association_logits,
            association_allowed,
        )
    elif association_mode != "joint":
        raise ValueError(f"unsupported association mode: {association_mode}")
    set_loss = candidate_set_mass_loss(association_logits, association_allowed, values["sample_weight"])
    accept = _acceptance_loss(output, values)
    continuity = _continuity_loss(output, values)
    total = set_loss["loss"] + 0.10 * accept + 0.02 * continuity
    return total, {
        "loss": float(total.detach()),
        "set_mass": float(set_loss["set_mass"]),
        "identity_nll": float(set_loss["identity_nll"]),
        "acceptance_bce": float(accept.detach()),
        "continuity": float(continuity.detach()),
        "supervised_frames": float(set_loss["supervised_frames"]),
    }


@torch.inference_mode()
def evaluate(
    model: nn.Module,
    route: str,
    episodes: list[RouteRuntimeEpisode],
    device: torch.device,
    *,
    architecture: str = "route_default",
    association_mode: str = "joint",
) -> tuple[dict[str, float], tuple[Tensor, Tensor, Tensor, Tensor]]:
    model.eval()
    rows: list[dict[str, float]] = []
    logits: list[Tensor] = []
    acceptance: list[Tensor] = []
    allowed: list[Tensor] = []
    weights: list[Tensor] = []
    for episode in episodes:
        total, metrics = episode_loss(
            model,
            route,
            episode,
            device,
            architecture=architecture,
            association_mode=association_mode,
        )
        rows.append(metrics | {"loss": float(total.detach())})
        values = to_tensor(episode, device)
        output = model_output(model, route, values, architecture=architecture)
        candidate_logits = output["candidate_logits"]
        if association_mode == "physical_only":
            candidate_logits, _ = split_identity_from_physical_association(candidate_logits, values["allowed_weight"])
        logits.append(candidate_logits.cpu())
        acceptance.append(output["acceptance"].cpu())
        allowed.append(values["allowed_weight"].cpu())
        weights.append(values["sample_weight"].cpu())
    summary = {key: float(np.mean([row[key] for row in rows])) for key in rows[0]}
    return summary, (torch.cat(logits, dim=1), torch.cat(acceptance, dim=1), torch.cat(allowed, dim=1), torch.cat(weights, dim=1))


def train_stage(
    *,
    route: str,
    episodes: list[RouteRuntimeEpisode],
    calibration: list[RouteRuntimeEpisode],
    feature_dim: int,
    hidden_dim: int,
    epochs: int,
    patience: int,
    lr: float,
    weight_decay: float,
    device: torch.device,
    architecture: str = "route_default",
    association_mode: str = "joint",
) -> tuple[int, list[dict[str, Any]], dict[str, Tensor], dict[str, float], tuple[Tensor, Tensor, Tensor, Tensor]]:
    model = make_model(route, feature_dim=feature_dim, hidden_dim=hidden_dim, architecture=architecture).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    best_epoch, best_key, stale = 0, float("inf"), 0
    best_state: dict[str, Tensor] | None = None
    best_metrics: dict[str, float] | None = None
    best_outputs: tuple[Tensor, Tensor, Tensor, Tensor] | None = None
    history: list[dict[str, Any]] = []
    for epoch in range(1, epochs + 1):
        model.train()
        ordering = list(episodes)
        random.shuffle(ordering)
        train_rows: list[dict[str, float]] = []
        for episode in ordering:
            optimizer.zero_grad(set_to_none=True)
            total, metrics = episode_loss(
                model,
                route,
                episode,
                device,
                architecture=architecture,
                association_mode=association_mode,
            )
            total.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            train_rows.append(metrics)
        scheduler.step()
        calibration_metrics, calibration_outputs = evaluate(
            model,
            route,
            calibration,
            device,
            architecture=architecture,
            association_mode=association_mode,
        )
        record = {
            "epoch": epoch,
            "train_loss": float(np.mean([row["loss"] for row in train_rows])),
            "calibration": calibration_metrics,
            "learning_rate": float(scheduler.get_last_lr()[0]),
        }
        history.append(record)
        print(json.dumps(record, ensure_ascii=False), flush=True)
        key = calibration_metrics["loss"]
        if key < best_key - 1.0e-8:
            best_epoch, best_key, stale = epoch, key, 0
            best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            best_metrics = calibration_metrics
            best_outputs = calibration_outputs
        else:
            stale += 1
        if stale >= patience:
            break
    if best_state is None or best_metrics is None or best_outputs is None:
        raise RuntimeError("route specialist training did not produce a checkpoint")
    return best_epoch, history, best_state, best_metrics, best_outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=_TARGET_ROUTES, required=True)
    parser.add_argument("--runtime-root", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT / "configs" / "CORA_SE2_ROUTE_SPECIALISTS_PROTOCOL_V1.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--architecture", choices=("route_default", "path_association"), default="route_default")
    parser.add_argument("--association-mode", choices=("joint", "physical_only"), default="joint")
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.epochs < 1 or args.patience < 1 or args.hidden_dim < 4:
        raise ValueError("epochs/patience/hidden-dim must be positive")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"output directory is not empty: {args.output_dir}")
    protocol = load_route_specialist_protocol(args.protocol)
    route_record = protocol["routes"][args.route]
    pool = protocol["training_pools"][route_record["training_pool"]]
    fit_sequences = [str(value).strip().lower() for value in pool["fit_sequences"]]
    calibration_sequences = [str(value).strip().lower() for value in pool["calibration_sequences"]]
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("route-specialist training requires CUDA")
    seed_everything(args.seed)
    fit = load_episodes(args.runtime_root, fit_sequences, args.route)
    calibration = load_episodes(args.runtime_root, calibration_sequences, args.route)
    feature_dim = fit[0].candidate_feature.shape[-1]
    if any(item.candidate_feature.shape[-1] != feature_dim for item in [*fit, *calibration]):
        raise ValueError("runtime feature dimensions differ across episodes")

    best_epoch, history, best_state, calibration_metrics, calibration_outputs = train_stage(
        route=args.route,
        episodes=fit,
        calibration=calibration,
        feature_dim=feature_dim,
        hidden_dim=args.hidden_dim,
        epochs=args.epochs,
        patience=args.patience,
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        device=device,
        architecture=args.architecture,
        association_mode=args.association_mode,
    )
    threshold, threshold_report = select_acceptance_threshold(*calibration_outputs)

    # Refit for the pre-selected epoch on the complete route pool.  This is
    # allowed because the epoch and gate were fixed by the train-only split.
    seed_everything(args.seed)
    all_train = [*fit, *calibration]
    _, final_history, final_state, _, _ = train_stage(
        route=args.route,
        episodes=all_train,
        calibration=all_train,
        feature_dim=feature_dim,
        hidden_dim=args.hidden_dim,
        epochs=best_epoch,
        patience=best_epoch + 1,
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
        device=device,
        architecture=args.architecture,
        association_mode=args.association_mode,
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "brace_v4_cora_se2_candidate_route_specialist_v1",
        "route": args.route,
        "expert_id": route_record["expert_id"],
        "architecture": args.architecture,
        "association_mode": args.association_mode,
        "base_branch": route_record["base_branch"],
        "model_kwargs": {"feature_dim": feature_dim, "hidden_dim": args.hidden_dim},
        "model_state": final_state,
        "fit_sequences": fit_sequences,
        "calibration_sequences": calibration_sequences,
        "selected_epoch": best_epoch,
        "acceptance_threshold": threshold,
        "selection_metric": "train_only_set_mass_calibration_loss_then_set_hit",
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    contract = {
        "schema_version": "brace_v4_cora_se2_candidate_route_specialist_training_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "expert_id": route_record["expert_id"],
        "architecture": args.architecture,
        "fit_sequences": fit_sequences,
        "calibration_sequences": calibration_sequences,
        "development_sequences_reserved": protocol["development_sequences"],
        "locked_test_sequences_reserved": protocol["locked_test_sequences"],
        "selected_epoch": best_epoch,
        "acceptance_threshold": threshold,
        "train_calibration": calibration_metrics,
        "threshold_report": threshold_report,
        "checkpoint_sha256": sha256(checkpoint_path),
        "runtime_inputs": ["raw_RA", "raw_RA_MTI", "observed_candidate_peaks", "causal_peak_persistence", "frozen_CORA_branch"],
        "association_mode": args.association_mode,
        "direct_weak_supervision_inputs_train_only": ["frozen_R11_candidate_set_mass"],
        "forbidden_reads": checkpoint["forbidden_reads"],
        "development_read": False,
        "locked_test_read": False,
    }
    (args.output_dir / "training_contract.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "history_stage_a.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "history_stage_b.json").write_text(json.dumps(final_history, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(contract, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
