"""Validated reader for frozen route-specialist runtime caches."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


RUNTIME_FEATURE_NAMES = (
    "per_frame_peak_score_z",
    "candidate_x_normalized",
    "candidate_y_normalized",
    "ra_mti_agreement",
    "background_safety",
    "causal_peak_persistence",
    "delta_x_to_frozen_base",
    "delta_y_to_frozen_base",
    "frozen_base_score",
    "is_exact_identity_action",
)

_FORBIDDEN_PROVENANCE = (
    "target_final_bev_read",
    "development_label_read",
    "locked_test_read",
    "depth_read",
    "right_rgb_read",
    "manual_ra_anchor_read",
)


def resolve_source_final_bev_track(data_root: str | Path, sequence: str) -> Path:
    """Locate source-only labels across the original and packaged layouts."""

    root = Path(data_root)
    raw_sequence = str(sequence).strip().lower()
    digits = raw_sequence.removeprefix("seq").lstrip("_")
    sequence_names = (raw_sequence, f"seq_{int(digits):03d}") if digits.isdigit() else (raw_sequence,)
    data_roots = (root / "Data_train", root) if root.name.lower() != "data_train" else (root,)
    for data_dir in data_roots:
        for sequence_name in dict.fromkeys(sequence_names):
            sequence_root = data_dir / sequence_name
            for directory in ("BEVFinalLabelsV1", "BEVFinalLabels"):
                candidate = sequence_root / directory / "final_bev_track.csv"
                if candidate.is_file():
                    return candidate
    raise FileNotFoundError(data_roots[0] / sequence_names[-1] / "BEVFinalLabelsV1" / "final_bev_track.csv")


@dataclass(frozen=True)
class RouteRuntimeEpisode:
    sequence: str
    split: str
    route: str
    base_branch: str
    frame_id: np.ndarray
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_feature: np.ndarray
    base_xy_m: np.ndarray
    base_index: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    radar_training_valid: np.ndarray
    r11_set_mass_attached: bool
    runtime_feature_names: tuple[str, ...] = RUNTIME_FEATURE_NAMES

    def __post_init__(self) -> None:
        frames, candidates = self.candidate_valid.shape
        if self.candidate_xy_m.shape != (frames, candidates, 2):
            raise ValueError("candidate_xy_m must be [frames,candidates,2]")
        if self.candidate_feature.shape != (frames, candidates, len(RUNTIME_FEATURE_NAMES)):
            raise ValueError("candidate_feature is not the fixed raw runtime schema")
        if self.base_xy_m.shape != (frames, 2) or self.base_index.shape != (frames,):
            raise ValueError("base coordinate/index must align with frames")
        if self.frame_id.shape != (frames,) or self.allowed_weight.shape != (frames, candidates):
            raise ValueError("frame/R11 support shapes are invalid")
        if self.sample_weight.shape != (frames,) or self.radar_training_valid.shape != (frames,):
            raise ValueError("frame weights must align with runtime")
        if not np.array_equal(self.base_index, np.zeros(frames, dtype=np.int64)):
            raise ValueError("candidate zero must remain the exact frozen-base action")
        if np.any(~np.isfinite(self.base_xy_m)) or np.any(~np.isfinite(self.candidate_xy_m[self.candidate_valid])):
            raise ValueError("runtime physical coordinates must be finite")
        if np.any(self.allowed_weight < 0.0) or np.any(self.sample_weight < 0.0):
            raise ValueError("R11 set-mass weights must be non-negative")


def _scalar_text(archive: np.lib.npyio.NpzFile, key: str) -> str:
    value = np.asarray(archive[key])
    if value.shape != ():
        raise ValueError(f"{key} must be scalar")
    return str(value.item()).strip().lower()


def _scalar_bool(archive: np.lib.npyio.NpzFile, key: str) -> bool:
    value = np.asarray(archive[key])
    if value.shape != ():
        raise ValueError(f"{key} must be scalar")
    return bool(value.item())


def load_route_runtime_episode(path: str | Path, *, expected_split: str) -> RouteRuntimeEpisode:
    """Load one raw runtime cache and reject label-contaminated provenance."""

    source = Path(path)
    with np.load(source, allow_pickle=False) as archive:
        if _scalar_text(archive, "schema_version") != "brace_v4_cora_se2_route_runtime_v1":
            raise ValueError("unsupported route runtime cache schema")
        for key in _FORBIDDEN_PROVENANCE:
            if _scalar_bool(archive, key):
                raise ValueError(f"forbidden provenance flag: {key}")
        split = _scalar_text(archive, "split")
        if split != expected_split.strip().lower():
            raise ValueError(f"runtime split mismatch: expected {expected_split!r}, got {split!r}")
        result = RouteRuntimeEpisode(
            sequence=_scalar_text(archive, "sequence"),
            split=split,
            route=_scalar_text(archive, "route"),
            base_branch=_scalar_text(archive, "base_branch"),
            frame_id=np.asarray(archive["frame_id"], dtype=np.int64).copy(),
            candidate_xy_m=np.asarray(archive["candidate_xy_m"], dtype=np.float32).copy(),
            candidate_valid=np.asarray(archive["candidate_valid"], dtype=bool).copy(),
            candidate_feature=np.asarray(archive["candidate_feature"], dtype=np.float32).copy(),
            base_xy_m=np.asarray(archive["base_xy_m"], dtype=np.float32).copy(),
            base_index=np.asarray(archive["base_index"], dtype=np.int64).copy(),
            allowed_weight=np.asarray(archive["allowed_weight"], dtype=np.float32).copy(),
            sample_weight=np.asarray(archive["sample_weight"], dtype=np.float32).copy(),
            radar_training_valid=np.asarray(archive["radar_training_valid"], dtype=bool).copy(),
            r11_set_mass_attached=_scalar_bool(archive, "r11_set_mass_attached"),
        )
    return result
