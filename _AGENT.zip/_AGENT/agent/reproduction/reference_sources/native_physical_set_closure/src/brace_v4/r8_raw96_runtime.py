"""Raw-RA-MTI candidate contract shared by R8 outdoor specialists.

The original R8 teacher used a broad physical candidate bank while an early
Development runtime accidentally exposed only nine peaks.  This module makes
the candidate generator explicit and reusable: both target-side weak-label
projection and frozen deployment use the same current-frame RA-MTI top-K
peaks.  It intentionally contains no camera, depth, Final-BEV, or manual
anchor input.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .raw_candidate_runtime import build_raw_ra_mti_candidates


@dataclass(frozen=True)
class Raw96CandidateEvidence:
    """Current-frame observed radar candidates plus causal persistence."""

    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    raw_candidate_score: np.ndarray
    ra_mti_agreement: np.ndarray
    background_risk: np.ndarray
    temporal_persistence: np.ndarray
    native_indices: np.ndarray
    candidate_patch: np.ndarray


@dataclass(frozen=True)
class TransferredR8Set:
    """Frozen R8 set membership mapped into the canonical Raw96 pool."""

    allowed_mask: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray


def _validate_radar_frames(radar_frames: np.ndarray) -> np.ndarray:
    frames = np.asarray(radar_frames, dtype=np.float32)
    if frames.ndim != 4 or frames.shape[1:] != (2, 128, 128):
        raise ValueError("radar_frames must be [frames,2,128,128]")
    if frames.shape[0] < 1:
        raise ValueError("at least one radar frame is required")
    return frames


def _causal_persistence(coordinates: np.ndarray, valid: np.ndarray, *, scale_m: float) -> np.ndarray:
    if scale_m <= 0.0:
        raise ValueError("scale_m must be positive")
    output = np.zeros(valid.shape, dtype=np.float32)
    for frame in range(1, valid.shape[0]):
        previous = coordinates[frame - 1, valid[frame - 1]]
        if previous.size == 0:
            continue
        current_indices = np.flatnonzero(valid[frame])
        current = coordinates[frame, current_indices]
        distance = np.linalg.norm(current[:, None, :] - previous[None, :, :], axis=-1).min(axis=1)
        output[frame, current_indices] = np.exp(-distance / float(scale_m)).astype(np.float32)
    return output


def build_raw96_candidate_evidence(
    radar_frames: np.ndarray,
    *,
    top_k: int = 96,
    nms_radius_bins: int = 1,
    persistence_scale_m: float = 0.35,
) -> Raw96CandidateEvidence:
    """Extract the canonical broad RA-MTI peak bank from observed radar frames."""

    frames = _validate_radar_frames(radar_frames)
    if top_k < 1:
        raise ValueError("top_k must be positive")
    coordinate = np.full((frames.shape[0], top_k, 2), np.nan, dtype=np.float32)
    valid = np.zeros((frames.shape[0], top_k), dtype=bool)
    score = np.full((frames.shape[0], top_k), -np.inf, dtype=np.float32)
    agreement = np.zeros((frames.shape[0], top_k), dtype=np.float32)
    background_risk = np.ones((frames.shape[0], top_k), dtype=np.float32)
    native = np.full((frames.shape[0], top_k, 2), -1, dtype=np.int16)
    patch = np.zeros((frames.shape[0], top_k, 2, 9, 9), dtype=np.float32)

    for frame, radar in enumerate(frames):
        extracted = build_raw_ra_mti_candidates(
            radar,
            top_k=top_k,
            nms_radius_bins=nms_radius_bins,
            minimum_score=-np.inf,
        )
        coordinate[frame] = np.asarray(extracted["candidate_xy_m"], dtype=np.float32)
        valid[frame] = np.asarray(extracted["candidate_valid"], dtype=bool)
        score[frame] = np.asarray(extracted["radar_score"], dtype=np.float32)
        agreement[frame] = np.asarray(extracted["candidate_ra_mti_agreement"], dtype=np.float32)
        background_risk[frame] = np.asarray(extracted["candidate_background_risk"], dtype=np.float32)
        native[frame] = np.asarray(extracted["candidate_native_indices"], dtype=np.int16)
        patch[frame] = np.asarray(extracted["candidate_patch"], dtype=np.float32)

    persistence = _causal_persistence(coordinate, valid, scale_m=persistence_scale_m)
    return Raw96CandidateEvidence(
        candidate_xy_m=coordinate,
        candidate_valid=valid,
        raw_candidate_score=score,
        ra_mti_agreement=agreement,
        background_risk=background_risk,
        temporal_persistence=persistence,
        native_indices=native,
        candidate_patch=patch,
    )


def transfer_r8_set_to_raw96(
    source_xy_m: np.ndarray,
    source_valid: np.ndarray,
    source_allowed: np.ndarray,
    source_weight: np.ndarray,
    raw_xy_m: np.ndarray,
    raw_valid: np.ndarray,
    sample_weight: np.ndarray,
    *,
    radius_m: float,
) -> TransferredR8Set:
    """Transfer frozen set membership without turning it into point supervision.

    Every source set member contributes its frozen mass to its nearest
    Raw96 candidate only when that candidate is physically co-located within
    ``radius_m``.  A frame with no such member becomes unsupervised rather than
    forcing a distant branch.
    """

    if radius_m <= 0.0:
        raise ValueError("radius_m must be positive")
    source_xy = np.asarray(source_xy_m, dtype=np.float32)
    source_is_valid = np.asarray(source_valid, dtype=bool)
    source_is_allowed = np.asarray(source_allowed, dtype=bool)
    source_mass = np.asarray(source_weight, dtype=np.float32)
    raw_xy = np.asarray(raw_xy_m, dtype=np.float32)
    raw_is_valid = np.asarray(raw_valid, dtype=bool)
    frame_weight = np.asarray(sample_weight, dtype=np.float32)
    if source_xy.ndim != 3 or source_xy.shape[-1] != 2 or raw_xy.ndim != 3 or raw_xy.shape[-1] != 2:
        raise ValueError("source/raw coordinates must be [frames,candidates,2]")
    if source_is_valid.shape != source_xy.shape[:2] or source_is_allowed.shape != source_is_valid.shape:
        raise ValueError("source masks must match source coordinates")
    if source_mass.shape != source_is_valid.shape or raw_is_valid.shape != raw_xy.shape[:2]:
        raise ValueError("candidate weights or raw validity do not match coordinates")
    if source_xy.shape[0] != raw_xy.shape[0] or frame_weight.shape != (source_xy.shape[0],):
        raise ValueError("all tensors must share the same frame axis")

    allowed = np.zeros(raw_is_valid.shape, dtype=bool)
    weight = np.zeros(raw_is_valid.shape, dtype=np.float32)
    source_member = source_is_valid & source_is_allowed & np.isfinite(source_xy).all(axis=-1) & (source_mass > 0.0)
    for frame in range(source_xy.shape[0]):
        candidates = np.flatnonzero(raw_is_valid[frame] & np.isfinite(raw_xy[frame]).all(axis=-1))
        if candidates.size == 0:
            continue
        for member in np.flatnonzero(source_member[frame]):
            distance = np.linalg.norm(raw_xy[frame, candidates] - source_xy[frame, member], axis=1)
            closest = int(np.argmin(distance))
            if float(distance[closest]) <= float(radius_m):
                target = int(candidates[closest])
                allowed[frame, target] = True
                weight[frame, target] += source_mass[frame, member]
    supported = allowed.any(axis=1)
    weight /= np.maximum(weight.sum(axis=1, keepdims=True), 1.0e-8)
    output_weight = np.where(supported, np.maximum(frame_weight, 0.0), 0.0).astype(np.float32)
    return TransferredR8Set(
        allowed_mask=allowed,
        allowed_weight=weight,
        sample_weight=output_weight,
    )
