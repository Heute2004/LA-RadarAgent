"""Route and cache helpers for the frozen CORA-SE2 specialist protocol."""

from __future__ import annotations

from collections.abc import Mapping


def specialist_route_for_record(record: Mapping[str, object]) -> str:
    """Map immutable ledger fields to one non-RIS specialist route.

    This mapping is an offline dataset partition, not a runtime route label.
    The deployed router may later select among the resulting specialists from
    radar/VLM evidence, but cache construction must use a deterministic
    declared mapping so no evaluation label becomes a route feature.
    """

    geometry = str(record.get("scene_geometry", "")).strip().lower()
    weather = str(record.get("weather", "")).strip().lower()
    if geometry == "open_indoor":
        return "clean"
    if geometry == "cluttered_indoor":
        return "cluttered"
    if geometry in {"complex_outdoor", "open_outdoor"}:
        if weather == "dry":
            return "cluttered_or_multipath_likely"
        if weather == "wet_after_rain":
            return "wet_ground"
        return "rain_or_wet_ground"
    if geometry == "l_corridor":
        raise ValueError("RIS L-corridor is outside the generic non-RIS specialist protocol")
    raise ValueError(f"unsupported specialist route geometry={geometry!r}, weather={weather!r}")


def branch_for_route(protocol: Mapping[str, object], route: str) -> str:
    """Return the frozen CORA branch mandated by the immutable protocol."""

    routes = protocol.get("routes")
    if not isinstance(routes, Mapping) or route not in routes:
        raise ValueError(f"unknown route: {route}")
    record = routes[route]
    if not isinstance(record, Mapping):
        raise ValueError(f"route record is invalid: {route}")
    branch = str(record.get("base_branch", "")).strip().lower()
    if branch not in {"cora0", "cora_se1", "cora_se2"}:
        raise ValueError(f"route {route} has unsupported base branch: {branch!r}")
    return branch


def training_cache_route_for_specialist(route: str) -> str:
    """Return the physical-condition cache reused by one specialist.

    ``wet_ground`` deliberately learns from the declared rain/wet R11 pool:
    its own semantic route remains distinct, while the raw candidate evidence
    is cached under the shared physical weather condition.
    """

    normalized = route.strip().lower()
    if normalized == "wet_ground":
        return "rain_or_wet_ground"
    return normalized
