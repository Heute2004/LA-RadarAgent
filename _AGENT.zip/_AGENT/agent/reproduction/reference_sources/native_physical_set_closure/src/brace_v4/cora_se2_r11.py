"""Frozen inference composition for the R11-trained CORA-SE2 adapter."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import torch
from torch import Tensor, nn

from .cora_se2_setmass import CORASe2SetMassAdapter
from .cora_se2_training import require_se2_checkpoint_contract
from .foundation_models import build_foundation_model


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_cora(path: Path, device: torch.device) -> nn.Module:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict) or payload.get("architecture") != "CORA-BEV-RA-RAMTI-ObservationConvLSTM-Presence-V1":
        raise ValueError(f"not a compatible CORA checkpoint: {path}")
    model = build_foundation_model("cora_bev")
    model.load_state_dict(payload["model_state"], strict=True)
    return model.to(device).eval()


class CORASe2R11Detector(nn.Module):
    """Frozen CORA0 plus the SE2 residual adapter; SE1 is training-only."""

    def __init__(self, cora0: nn.Module, adapter: CORASe2SetMassAdapter) -> None:
        super().__init__()
        self.cora0 = cora0.eval()
        self.adapter = adapter.eval()
        for module in (self.cora0, self.adapter):
            for parameter in module.parameters():
                parameter.requires_grad_(False)

    def forward(self, radar: Tensor) -> dict[str, Tensor]:
        base = self.cora0(radar)
        correction = self.adapter(base["shared_feature"], base["logits"], base["presence_logit"])
        return dict(base) | correction


def load_se2_detector(cora0_path: Path, se1_path: Path, checkpoint_path: Path, device: torch.device) -> tuple[CORASe2R11Detector, dict[str, Any]]:
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict):
        raise ValueError("SE2 checkpoint payload is invalid")
    require_se2_checkpoint_contract(payload)
    if payload["cora0_checkpoint_sha256"] != sha256(cora0_path):
        raise ValueError("SE2/CORA0 checkpoint provenance mismatch")
    if payload["se1_checkpoint_sha256"] != sha256(se1_path):
        raise ValueError("SE2/SE1 checkpoint provenance mismatch")
    adapter = CORASe2SetMassAdapter().to(device)
    adapter.load_state_dict(payload["adapter_state"], strict=True)
    return CORASe2R11Detector(load_cora(cora0_path, device), adapter).to(device).eval(), payload
