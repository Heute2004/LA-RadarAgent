"""Identity-safe CORA-SE2 residual adapter with R11 set-mass supervision."""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from .dream_bev import BEVGeometry, ConvNormAct, ResidualBlock


class CORASe2SetMassAdapter(nn.Module):
    """Bounded residual branch mounted on frozen CORA0 shared BEV features."""

    def __init__(self, *, max_delta_logit: float = 2.0) -> None:
        super().__init__()
        if max_delta_logit <= 0.0:
            raise ValueError("max_delta_logit must be positive")
        self.max_delta_logit = float(max_delta_logit)
        self.encoder = nn.Sequential(ConvNormAct(128, 64), ResidualBlock(64))
        self.delta_head = nn.Conv2d(64, 1, kernel_size=1)
        self.presence_head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, 1))
        self.acceptance_head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, 1))
        nn.init.zeros_(self.delta_head.weight)
        nn.init.zeros_(self.delta_head.bias)
        nn.init.zeros_(self.presence_head[-1].weight)
        nn.init.zeros_(self.presence_head[-1].bias)
        nn.init.zeros_(self.acceptance_head[-1].weight)
        nn.init.zeros_(self.acceptance_head[-1].bias)

    def forward(self, shared_feature: Tensor, base_logits: Tensor, base_presence: Tensor) -> dict[str, Tensor]:
        if shared_feature.ndim != 4 or shared_feature.shape[1:] != (128, 50, 59):
            raise ValueError("shared_feature must be [B,128,50,59]")
        batch = shared_feature.shape[0]
        if base_logits.shape != (batch, 1, 200, 234) or base_presence.shape != (batch, 1):
            raise ValueError("CORA0 output shapes are incompatible with SE2")
        decoded = functional.interpolate(self.encoder(shared_feature), size=(200, 234), mode="bilinear", align_corners=False)
        delta_logits = self.max_delta_logit * torch.tanh(self.delta_head(decoded))
        acceptance = torch.sigmoid(self.acceptance_head(shared_feature))
        presence_delta = self.presence_head(shared_feature)
        return {
            "logits": base_logits + acceptance[:, :, None, None] * delta_logits,
            "presence_logit": base_presence + presence_delta,
            "acceptance": acceptance,
            "delta_logits": delta_logits,
        }


def _candidate_log_mass(
    logits: Tensor,
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    candidate_weight: Tensor,
    *,
    geometry: BEVGeometry,
) -> tuple[Tensor, Tensor]:
    if logits.ndim != 4 or logits.shape[1:] != (1, geometry.x_bins, geometry.y_bins):
        raise ValueError("logits must be [B,1,200,234]")
    if candidate_xy_m.ndim != 3 or candidate_xy_m.shape[-1] != 2:
        raise ValueError("candidate_xy_m must be [B,K,2]")
    if candidate_valid.shape != candidate_xy_m.shape[:2] or candidate_weight.shape != candidate_valid.shape:
        raise ValueError("candidate set arrays have incompatible shapes")
    if candidate_xy_m.shape[0] != logits.shape[0]:
        raise ValueError("candidate batch does not match logits")
    index = geometry.metric_to_index(candidate_xy_m.float())
    valid = candidate_valid.bool() & torch.isfinite(candidate_xy_m).all(dim=-1) & candidate_weight.gt(0.0)
    flat_index = index[..., 0].clamp(0, geometry.x_bins - 1) * geometry.y_bins + index[..., 1].clamp(0, geometry.y_bins - 1)
    candidate_log_probability = torch.log_softmax(logits[:, 0].float().flatten(1), dim=1).gather(1, flat_index.long())
    normalized_weight = candidate_weight.float().clamp_min(0.0) * valid.float()
    normalized_weight = normalized_weight / normalized_weight.sum(dim=1, keepdim=True).clamp_min(1e-8)
    return candidate_log_probability.masked_fill(~valid, float("-inf")), normalized_weight


def se2_setmass_loss(
    logits: Tensor,
    presence_logits: Tensor,
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    candidate_weight: Tensor,
    sample_weight: Tensor,
    se1_logits: Tensor,
    *,
    presence_weight: float = 0.05,
    consistency_weight: float = 0.25,
    geometry: BEVGeometry | None = None,
) -> dict[str, Tensor]:
    """Reward all R11-supported candidate mass, never a pseudo coordinate."""

    if logits.shape != se1_logits.shape:
        raise ValueError("SE1 logits must match SE2 logits")
    if presence_logits.shape != (logits.shape[0], 1):
        raise ValueError("presence_logits must be [B,1]")
    if sample_weight.shape != (logits.shape[0],):
        raise ValueError("sample_weight must be [B]")
    if presence_weight < 0.0 or consistency_weight < 0.0:
        raise ValueError("loss weights must be non-negative")
    geometry = geometry or BEVGeometry()
    candidate_log_probability, normalized_weight = _candidate_log_mass(
        logits, candidate_xy_m, candidate_valid, candidate_weight, geometry=geometry
    )
    raw_weight = sample_weight.float().to(device=logits.device).clamp(0.0, 1.0)
    supervised = raw_weight.gt(0.0) & normalized_weight.sum(dim=1).gt(0.0)
    if bool(supervised.any()):
        set_mass_per = -torch.logsumexp(candidate_log_probability + torch.log(normalized_weight.clamp_min(1e-8)), dim=1)
        weights = raw_weight[supervised].clamp_min(0.05)
        set_mass = (set_mass_per[supervised] * weights).sum() / weights.sum().clamp_min(1e-8)
        presence = functional.binary_cross_entropy_with_logits(
            presence_logits[supervised, 0].float(), torch.ones_like(presence_logits[supervised, 0], dtype=torch.float32)
        )
    else:
        set_mass = logits.sum() * 0.0
        presence = logits.sum() * 0.0
    unsupported = ~supervised
    unsupported_consistency = (
        functional.smooth_l1_loss(logits[unsupported].float(), se1_logits[unsupported].detach().float())
        if bool(unsupported.any())
        else logits.sum() * 0.0
    )
    return {
        "loss": set_mass + float(presence_weight) * presence + float(consistency_weight) * unsupported_consistency,
        "set_mass": set_mass.detach(),
        "presence": presence.detach(),
        "unsupported_consistency": unsupported_consistency.detach(),
        "supervised": supervised.sum().detach(),
    }
