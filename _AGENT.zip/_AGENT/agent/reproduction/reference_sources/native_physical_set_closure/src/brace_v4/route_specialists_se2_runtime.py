"""Radar-only Raw96 candidate runtime for frozen CORA-SE2 route specialists.

The R11 teacher appears only in :func:`attach_r11_set_mass`.  Runtime features
are constructed first from current/casual raw radar measurements and the
frozen base coordinate; no teacher field is included in the deployed feature
tensor.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class RawRouteRuntime:
    """Physical candidates plus candidate zero, the exact frozen-base action."""

    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_feature: np.ndarray
    base_index: np.ndarray
    base_xy_m: np.ndarray


@dataclass(frozen=True)
class R11SetMassSupport:
    """Train-only set-mass attachment, deliberately outside runtime features."""

    allowed_weight: np.ndarray
    sample_weight: np.ndarray


def _require_shape(value: np.ndarray, shape: tuple[int, ...], name: str) -> np.ndarray:
    array = np.asarray(value)
    if array.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {array.shape}")
    return array


def _standardize_per_frame(value: np.ndarray, valid: np.ndarray) -> np.ndarray:
    masked = np.where(valid & np.isfinite(value), value, np.nan)
    mean = np.nanmean(masked, axis=1, keepdims=True)
    scale = np.nanstd(masked, axis=1, keepdims=True)
    mean = np.nan_to_num(mean, nan=0.0)
    scale = np.nan_to_num(scale, nan=1.0).clip(min=1.0e-3)
    return np.where(valid, (np.nan_to_num(value, nan=mean) - mean) / scale, 0.0).astype(np.float32)


def build_raw_route_runtime(
    *,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    radar_score: np.ndarray,
    ra_mti_agreement: np.ndarray,
    background_risk: np.ndarray,
    temporal_persistence: np.ndarray,
    base_xy_m: np.ndarray,
    base_score: np.ndarray,
) -> RawRouteRuntime:
    """Prepend the frozen base coordinate to current-frame measured candidates.

    Candidate zero is the only non-measured action and has exactly the frozen
    CORA coordinate.  All other candidate rows are observed Raw96 peaks.
    """

    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("candidate geometry must be [frames,candidates,2]")
    frames, candidates = valid.shape
    score = _require_shape(np.asarray(radar_score, dtype=np.float32), (frames, candidates), "radar_score")
    agreement = _require_shape(np.asarray(ra_mti_agreement, dtype=np.float32), (frames, candidates), "ra_mti_agreement")
    background = _require_shape(np.asarray(background_risk, dtype=np.float32), (frames, candidates), "background_risk")
    persistence = _require_shape(np.asarray(temporal_persistence, dtype=np.float32), (frames, candidates), "temporal_persistence")
    base_xy = _require_shape(np.asarray(base_xy_m, dtype=np.float32), (frames, 2), "base_xy_m")
    score_base = _require_shape(np.asarray(base_score, dtype=np.float32), (frames,), "base_score")
    if not bool(valid.any(axis=1).all()):
        raise ValueError("each frame requires at least one observed raw candidate")
    if not np.isfinite(xy[valid]).all() or not np.isfinite(base_xy).all() or not np.isfinite(score_base).all():
        raise ValueError("valid raw and frozen-base values must be finite")

    raw_z = _standardize_per_frame(score, valid)
    nearest = np.linalg.norm(xy - base_xy[:, None, :], axis=-1)
    nearest = np.where(valid, nearest, np.inf).argmin(axis=1)
    rows = np.arange(frames)
    delta = xy - base_xy[:, None, :]
    physical_feature = np.stack(
        (
            raw_z,
            np.nan_to_num(xy[..., 0]) / 10.0,
            np.nan_to_num(xy[..., 1]) / 23.4,
            np.clip(agreement, 0.0, 1.0),
            1.0 - np.clip(background, 0.0, 1.0),
            np.clip(persistence, 0.0, 1.0),
            np.nan_to_num(delta[..., 0]) / 10.0,
            np.nan_to_num(delta[..., 1]) / 23.4,
            np.broadcast_to(score_base[:, None], (frames, candidates)),
            np.zeros((frames, candidates), dtype=np.float32),
        ),
        axis=-1,
    ).astype(np.float32)
    physical_feature *= valid[..., None]

    identity_feature = physical_feature[rows, nearest].copy()
    identity_feature[:, 1] = base_xy[:, 0] / 10.0
    identity_feature[:, 2] = base_xy[:, 1] / 23.4
    identity_feature[:, 6:8] = 0.0
    identity_feature[:, 8] = score_base
    identity_feature[:, 9] = 1.0

    return RawRouteRuntime(
        candidate_xy_m=np.concatenate((base_xy[:, None, :], xy), axis=1).astype(np.float32),
        candidate_valid=np.concatenate((np.ones((frames, 1), dtype=bool), valid), axis=1),
        candidate_feature=np.concatenate((identity_feature[:, None, :], physical_feature), axis=1).astype(np.float32),
        base_index=np.zeros(frames, dtype=np.int64),
        base_xy_m=base_xy.copy(),
    )


def attach_r11_set_mass(
    runtime: RawRouteRuntime,
    source_xy_m: np.ndarray,
    source_valid: np.ndarray,
    source_weight: np.ndarray,
    sample_weight: np.ndarray,
    *,
    radius_m: float,
) -> R11SetMassSupport:
    """Map frozen R11 support to observed raw candidates without point labels."""

    if radius_m <= 0.0:
        raise ValueError("radius_m must be positive")
    source_xy = np.asarray(source_xy_m, dtype=np.float32)
    source_is_valid = np.asarray(source_valid, dtype=bool)
    source_mass = np.asarray(source_weight, dtype=np.float32)
    if source_xy.ndim != 3 or source_xy.shape[-1] != 2 or source_is_valid.shape != source_xy.shape[:2] or source_mass.shape != source_is_valid.shape:
        raise ValueError("source R11 tensors must be [frames,candidates,(xy)]")
    frames = runtime.candidate_valid.shape[0]
    if source_xy.shape[0] != frames:
        raise ValueError("R11 support and runtime must share the frame axis")
    frame_weight = _require_shape(np.asarray(sample_weight, dtype=np.float32), (frames,), "sample_weight")
    valid_physical = runtime.candidate_valid[:, 1:]
    physical_xy = runtime.candidate_xy_m[:, 1:]
    allowed = np.zeros(runtime.candidate_valid.shape, dtype=np.float32)
    for frame in range(frames):
        physical_indices = np.flatnonzero(valid_physical[frame])
        if not physical_indices.size:
            continue
        source_indices = np.flatnonzero(source_is_valid[frame] & np.isfinite(source_xy[frame]).all(axis=1) & (source_mass[frame] > 0.0))
        for source_index in source_indices:
            distance = np.linalg.norm(physical_xy[frame, physical_indices] - source_xy[frame, source_index], axis=1)
            local = int(np.argmin(distance))
            if float(distance[local]) <= float(radius_m):
                allowed[frame, int(physical_indices[local]) + 1] += float(source_mass[frame, source_index])

    # The exact identity action is eligible only if an actually observed
    # supported candidate physically agrees with the frozen base coordinate.
    supported_physical = allowed[:, 1:] > 0.0
    base_distance = np.linalg.norm(physical_xy - runtime.base_xy_m[:, None, :], axis=-1)
    identity_supported = np.any(supported_physical & (base_distance <= float(radius_m)), axis=1)
    allowed[:, 0] = np.where(identity_supported, allowed[:, 1:].max(axis=1), 0.0)
    allowed /= np.maximum(allowed.sum(axis=1, keepdims=True), 1.0e-8)
    supported = allowed.sum(axis=1) > 0.0
    return R11SetMassSupport(
        allowed_weight=allowed.astype(np.float32),
        sample_weight=np.where(supported, np.maximum(frame_weight, 0.0), 0.0).astype(np.float32),
    )
