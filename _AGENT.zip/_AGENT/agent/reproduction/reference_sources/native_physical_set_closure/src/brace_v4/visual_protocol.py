"""Frozen visual-data eligibility rules for the V4 experiments.

Visual-degradation sequences remain valuable as system stress cases, but they
are not valid supervision or visual-foundation evaluation evidence.
"""

from __future__ import annotations


VISUAL_DEGRADED_SEQUENCES = frozenset(
    {
        *(f"seq_{value:03d}" for value in range(44, 49)),
        *(f"seq_{value:03d}" for value in range(52, 55)),
        *(f"seq_{value:03d}" for value in range(58, 61)),
        *(f"seq_{value:03d}" for value in range(123, 141)),
    }
)


def is_visual_degraded(sequence: str) -> bool:
    return sequence.strip().lower() in VISUAL_DEGRADED_SEQUENCES


def visual_supervision_sequence_allowed(sequence: str) -> bool:
    """Whether a sequence may contribute visual weak-supervision evidence."""

    return not is_visual_degraded(sequence)
