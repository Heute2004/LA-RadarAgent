"""Post-SE2 R31 runtime support for route-specialist shadow training."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .route_specialists_se2_runtime import RawRouteRuntime


@dataclass(frozen=True)
class R31RuntimeSupport:
    allowed_weight: np.ndarray
    sample_weight: np.ndarray


@dataclass(frozen=True)
class R31RouteRuntimeEpisode:
    sequence: str
    split: str
    route: str
    base_branch: str
    frame_id: np.ndarray
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_feature: np.ndarray
    base_xy_m: np.ndarray
    base_index: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    radar_training_valid: np.ndarray
    r31_set_mass_attached: bool


def attach_r31_support(
    runtime: RawRouteRuntime,
    *,
    r31_candidate_xy_m: np.ndarray,
    r31_candidate_valid: np.ndarray,
    r31_allowed_weight: np.ndarray,
    r31_sample_weight: np.ndarray,
    radius_m: float,
) -> R31RuntimeSupport:
    """Attach frozen R31 mass to the exact rebuilt physical candidate bank."""

    if radius_m <= 0.0:
        raise ValueError("radius_m must be positive")
    xy = np.asarray(r31_candidate_xy_m, dtype=np.float32)
    valid = np.asarray(r31_candidate_valid, dtype=bool)
    allowed = np.asarray(r31_allowed_weight, dtype=np.float32)
    sample = np.asarray(r31_sample_weight, dtype=np.float32)
    physical_xy = runtime.candidate_xy_m[:, 1:]
    physical_valid = runtime.candidate_valid[:, 1:]
    if xy.shape != physical_xy.shape or valid.shape != physical_valid.shape or allowed.shape != valid.shape:
        raise ValueError("R31/runtime candidate bank shapes differ")
    if sample.shape != (len(xy),):
        raise ValueError("R31 sample weight must be [frames]")
    if not np.array_equal(valid, physical_valid):
        raise ValueError("R31/runtime candidate bank validity differs")
    if not np.allclose(xy[valid], physical_xy[valid], atol=1.0e-5, rtol=0.0):
        raise ValueError("R31/runtime candidate bank coordinates differ")
    if np.any(allowed < 0.0) or np.any(sample < 0.0) or np.any(allowed[~valid] != 0.0):
        raise ValueError("R31 support contains invalid mass")

    output = np.zeros(runtime.candidate_valid.shape, dtype=np.float32)
    output[:, 1:] = allowed
    distance = np.linalg.norm(physical_xy - runtime.base_xy_m[:, None, :], axis=-1)
    supported_physical = valid & (allowed > 0.0)
    identity_supported = np.any(supported_physical & (distance <= float(radius_m)), axis=1)
    output[:, 0] = np.where(identity_supported, allowed.max(axis=1), 0.0)
    output /= np.maximum(output.sum(axis=1, keepdims=True), 1.0e-8)
    frame_supported = output.sum(axis=1) > 0.0
    return R31RuntimeSupport(
        allowed_weight=output,
        sample_weight=np.where(frame_supported, sample, 0.0).astype(np.float32),
    )


def _scalar_text(archive: np.lib.npyio.NpzFile, key: str) -> str:
    value = np.asarray(archive[key])
    if value.shape != ():
        raise ValueError(f"{key} must be scalar")
    return str(value.item()).strip().lower()


def _scalar_bool(archive: np.lib.npyio.NpzFile, key: str) -> bool:
    value = np.asarray(archive[key])
    if value.shape != ():
        raise ValueError(f"{key} must be scalar")
    return bool(value.item())


def load_r31_route_runtime_episode(path: str | Path, *, expected_split: str = "train") -> R31RouteRuntimeEpisode:
    """Read an honest R31 runtime and reject protected provenance reads."""

    with np.load(Path(path), allow_pickle=False) as archive:
        if _scalar_text(archive, "schema_version") != "brace_v4_r31_route_runtime_v1":
            raise ValueError("unsupported R31 route runtime schema")
        for key in (
            "target_final_bev_read",
            "development_read",
            "locked_test_read",
            "depth_read",
            "right_rgb_read",
            "manual_ra_anchor_read",
            "post_se2_historical_pseudolabel_read",
        ):
            if _scalar_bool(archive, key):
                raise ValueError(f"R31 route runtime contains forbidden provenance: {key}")
        split = _scalar_text(archive, "split")
        if split != str(expected_split).strip().lower():
            raise ValueError(f"expected split {expected_split!r}, got {split!r}")
        result = R31RouteRuntimeEpisode(
            sequence=_scalar_text(archive, "sequence"),
            split=split,
            route=_scalar_text(archive, "route"),
            base_branch=_scalar_text(archive, "base_branch"),
            frame_id=np.asarray(archive["frame_id"], dtype=np.int64).copy(),
            candidate_xy_m=np.asarray(archive["candidate_xy_m"], dtype=np.float32).copy(),
            candidate_valid=np.asarray(archive["candidate_valid"], dtype=bool).copy(),
            candidate_feature=np.asarray(archive["candidate_feature"], dtype=np.float32).copy(),
            base_xy_m=np.asarray(archive["base_xy_m"], dtype=np.float32).copy(),
            base_index=np.asarray(archive["base_index"], dtype=np.int64).copy(),
            allowed_weight=np.asarray(archive["allowed_weight"], dtype=np.float32).copy(),
            sample_weight=np.asarray(archive["sample_weight"], dtype=np.float32).copy(),
            radar_training_valid=np.asarray(archive["radar_training_valid"], dtype=bool).copy(),
            r31_set_mass_attached=_scalar_bool(archive, "r31_set_mass_attached"),
        )
    if result.allowed_weight.shape != result.candidate_valid.shape or result.sample_weight.shape != result.frame_id.shape:
        raise ValueError("R31 runtime supervision arrays do not align")
    if np.any(result.allowed_weight[~result.candidate_valid] != 0.0):
        raise ValueError("invalid R31 runtime candidates received supervision")
    return result
