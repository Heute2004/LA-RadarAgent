"""BRACE-V4: background-commissioned self-evolving radar sensing Agent."""

