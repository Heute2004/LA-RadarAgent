"""Training and deployment primitives for set-valued route specialists.

R11 support is deliberately represented as a distribution over *observed*
candidate peaks.  No function in this module accepts a target BEV coordinate.
"""

from __future__ import annotations

import torch
from torch import Tensor
from torch.nn import functional as functional


def split_identity_from_physical_association(
    candidate_logits: Tensor,
    allowed_weight: Tensor,
) -> tuple[Tensor, Tensor]:
    """Remove exact identity from physical-peak association supervision.

    Candidate zero remains available to the independent dispatcher gate.  It
    must not dominate the softmax that learns which measured RA/RA-MTI peak is
    the best physical alternative.
    """

    if candidate_logits.ndim != 3 or allowed_weight.shape != candidate_logits.shape:
        raise ValueError("candidate logits and allowed weights must align [batch,time,candidates]")
    if candidate_logits.shape[-1] < 2:
        raise ValueError("physical association needs identity plus at least one measured candidate")
    physical_logits = candidate_logits.clone()
    physical_logits[..., 0] = -torch.inf
    no_physical_action = ~torch.isfinite(physical_logits[..., 1:]).any(dim=-1)
    physical_logits[..., 0] = torch.where(
        no_physical_action,
        torch.zeros_like(physical_logits[..., 0]),
        physical_logits[..., 0],
    )
    physical_allowed = allowed_weight.clone()
    physical_allowed[..., 0] = 0.0
    total = physical_allowed.sum(dim=-1, keepdim=True)
    physical_allowed = torch.where(
        total > 0.0,
        physical_allowed / total.clamp_min(1.0e-8),
        torch.zeros_like(physical_allowed),
    )
    return physical_logits, physical_allowed


def candidate_set_mass_loss(
    candidate_logits: Tensor,
    allowed_weight: Tensor,
    sample_weight: Tensor,
    *,
    identity_weight: float = 0.05,
) -> dict[str, Tensor]:
    """Compute set-valued NLL plus a weak identity prior for abstained frames.

    An unsupported frame is never treated as an empty/no-person observation.
    It merely receives a small prior toward candidate zero, the frozen base
    action, so a route specialist cannot invent a correction without support.
    """

    if candidate_logits.ndim != 3:
        raise ValueError("candidate_logits must be [batch,time,candidates]")
    if allowed_weight.shape != candidate_logits.shape:
        raise ValueError("allowed_weight must match candidate_logits")
    if sample_weight.shape != candidate_logits.shape[:2]:
        raise ValueError("sample_weight must be [batch,time]")
    if identity_weight < 0.0:
        raise ValueError("identity_weight must be non-negative")
    if torch.any(allowed_weight < 0.0) or torch.any(sample_weight < 0.0):
        raise ValueError("set and sample weights must be non-negative")

    finite_zero = torch.where(
        torch.isfinite(candidate_logits), candidate_logits, torch.zeros_like(candidate_logits)
    ).sum() * 0.0
    allowed = allowed_weight.to(candidate_logits).clamp_min(0.0)
    allowed_mass = allowed.sum(dim=-1)
    normalized = allowed / allowed_mass[..., None].clamp_min(1.0e-8)
    supervised = sample_weight.gt(0.0) & allowed_mass.gt(0.0)
    log_probability = functional.log_softmax(candidate_logits.float(), dim=-1)
    log_set_mass = torch.logsumexp(
        log_probability + torch.log(normalized.clamp_min(1.0e-8)),
        dim=-1,
    )
    if bool(supervised.any()):
        mass = sample_weight[supervised].to(log_set_mass).clamp_min(0.05)
        set_mass = (-log_set_mass[supervised] * mass).sum() / mass.sum().clamp_min(1.0e-8)
    else:
        set_mass = finite_zero

    # A reachability specialist can deliberately mask candidate zero when its
    # graph has no physical identity edge.  Such a frame has no valid
    # identity action and must be left unconstrained, rather than turning a
    # masked log-probability (-inf) into a NaN training loss.
    identity_available = torch.isfinite(candidate_logits[..., 0])
    unsupported_identity = (~supervised) & identity_available
    if bool(unsupported_identity.any()):
        identity_nll = -log_probability[..., 0][unsupported_identity].mean()
    else:
        identity_nll = finite_zero
    return {
        "loss": set_mass + float(identity_weight) * identity_nll,
        "set_mass": set_mass.detach(),
        "identity_nll": identity_nll.detach(),
        "supervised_frames": supervised.sum().detach(),
    }


def dispatch_candidate_prediction(
    base_xy_m: Tensor,
    candidate_xy_m: Tensor,
    candidate_logits: Tensor,
    acceptance: Tensor,
    *,
    threshold: float,
) -> dict[str, Tensor]:
    """Apply a candidate specialist with a hard, exact frozen-base fallback."""

    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold must be in [0,1]")
    if base_xy_m.ndim != 3 or base_xy_m.shape[-1] != 2:
        raise ValueError("base_xy_m must be [batch,time,2]")
    if candidate_xy_m.ndim != 4 or candidate_xy_m.shape[:2] != base_xy_m.shape[:2] or candidate_xy_m.shape[-1] != 2:
        raise ValueError("candidate_xy_m must align as [batch,time,candidates,2]")
    if candidate_logits.shape != candidate_xy_m.shape[:3]:
        raise ValueError("candidate_logits must align with candidate_xy_m")
    if acceptance.shape != base_xy_m.shape[:2]:
        raise ValueError("acceptance must be [batch,time]")
    if torch.any(~torch.isfinite(base_xy_m)) or torch.any(~torch.isfinite(candidate_xy_m)):
        raise ValueError("base and candidate coordinates must be finite")

    selected_index = candidate_logits.argmax(dim=-1)
    selected_xy = candidate_xy_m.gather(2, selected_index[..., None, None].expand(-1, -1, 1, 2)).squeeze(2)
    intervened = selected_index.ne(0) & acceptance.ge(float(threshold))
    prediction = torch.where(intervened[..., None], selected_xy, base_xy_m)
    return {
        "prediction_xy_m": prediction,
        "selected_index": selected_index,
        "intervened": intervened,
    }


@torch.inference_mode()
def select_acceptance_threshold(
    candidate_logits: Tensor,
    acceptance: Tensor,
    allowed_weight: Tensor,
    sample_weight: Tensor,
    *,
    candidates: tuple[float, ...] = (0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90),
) -> tuple[float, dict[str, float]]:
    """Choose a train-calibration gate from set membership only.

    The score is weighted set-hit after dispatch.  It does not read any BEV
    coordinate or development label, and ties deliberately prefer a more
    conservative (larger) acceptance threshold.
    """

    if candidate_logits.ndim != 3 or allowed_weight.shape != candidate_logits.shape:
        raise ValueError("candidate logits and allowed weights must align [batch,time,candidates]")
    if acceptance.shape != candidate_logits.shape[:2] or sample_weight.shape != acceptance.shape:
        raise ValueError("acceptance/sample weight must be [batch,time]")
    if not candidates or any(not 0.0 <= value <= 1.0 for value in candidates):
        raise ValueError("threshold candidates must be values in [0,1]")
    support = sample_weight.gt(0.0) & allowed_weight.sum(dim=-1).gt(0.0)
    if not bool(support.any()):
        raise ValueError("calibration needs at least one R11-supported frame")
    selected = candidate_logits.argmax(dim=-1)
    weights = sample_weight[support].float().clamp_min(0.05)
    best: tuple[float, dict[str, float]] | None = None
    for threshold in sorted({float(value) for value in candidates}):
        dispatched = torch.where(acceptance.ge(threshold) & selected.ne(0), selected, torch.zeros_like(selected))
        hit = allowed_weight.gather(-1, dispatched[..., None]).squeeze(-1).gt(0.0)
        set_hit = float((hit[support].float() * weights).sum().div(weights.sum()).item())
        coverage = float((dispatched[support].ne(0).float() * weights).sum().div(weights.sum()).item())
        report = {"set_hit": set_hit, "intervention_coverage": coverage}
        if best is None or (set_hit, threshold) > (best[1]["set_hit"], best[0]):
            best = (threshold, report)
    assert best is not None
    return best
