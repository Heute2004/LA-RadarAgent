"""Offline soft posterior over observed radar candidate episodes.

This module is deliberately an *offline teacher*.  It consumes only a frozen
candidate lattice, Tier-A/B candidate preferences, and commissioned-background
costs.  It never creates a coordinate: all non-identity states refer to an
observed candidate slot in the current raw RA/RA-MTI frame.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class EpisodePosteriorConfig:
    """Frozen costs for one complete-episode candidate posterior."""

    candidate_score_weight: float = 1.0
    background_cost_weight: float = 1.0
    anchor_preference_weight: float = 3.0
    visual_bearing_weight: float = 0.0
    visual_bearing_scale_rad: float = 0.35
    identity_logit: float = -1.25
    identity_transition_cost: float = 0.75
    motion_cost_weight: float = 2.0
    max_step_m: float = 0.60
    surprise_relaxation: float = 1.5
    temperature: float = 1.0

    def __post_init__(self) -> None:
        for name in (
            "candidate_score_weight",
            "background_cost_weight",
            "anchor_preference_weight",
            "visual_bearing_weight",
            "identity_transition_cost",
            "motion_cost_weight",
            "surprise_relaxation",
        ):
            if float(getattr(self, name)) < 0.0:
                raise ValueError(f"{name} must be nonnegative")
        if self.max_step_m <= 0.0 or self.temperature <= 0.0 or self.visual_bearing_scale_rad <= 0.0:
            raise ValueError("max_step_m, temperature and visual_bearing_scale_rad must be positive")
        if not np.isfinite(self.identity_logit):
            raise ValueError("identity_logit must be finite")


def _logsumexp(values: np.ndarray, axis: int) -> np.ndarray:
    """Stable log-sum-exp that preserves all-impossible states as ``-inf``."""

    maximum = np.max(values, axis=axis, keepdims=True)
    finite = np.isfinite(maximum)
    shifted = np.full_like(values, -np.inf, dtype=np.float64)
    np.subtract(values, maximum, out=shifted, where=np.broadcast_to(finite, values.shape))
    total = np.sum(np.exp(np.where(np.isfinite(shifted), shifted, -np.inf)), axis=axis, keepdims=True)
    result = np.where(finite, maximum + np.log(np.maximum(total, 1e-300)), -np.inf)
    return np.squeeze(result, axis=axis)


def _normalise_scores(scores: np.ndarray, valid: np.ndarray) -> np.ndarray:
    output = np.full(scores.shape, -np.inf, dtype=np.float64)
    for frame in range(len(scores)):
        index = np.flatnonzero(valid[frame] & np.isfinite(scores[frame]))
        if not len(index):
            continue
        values = scores[frame, index].astype(np.float64, copy=False)
        standard_deviation = float(values.std())
        output[frame, index] = 0.0 if standard_deviation <= 1e-8 else (values - values.mean()) / standard_deviation
    return output


def _observation_surprise(scores: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Measure frame-to-frame response change without reading any target label."""

    top = np.full(len(scores), np.nan, dtype=np.float64)
    for frame in range(len(scores)):
        values = scores[frame, valid[frame] & np.isfinite(scores[frame])]
        if len(values):
            top[frame] = float(values.max())
    result = np.zeros(len(scores), dtype=np.float64)
    finite = np.isfinite(top)
    difference = np.zeros(len(scores), dtype=np.float64)
    difference[1:] = np.abs(top[1:] - top[:-1])
    usable = finite & np.r_[False, finite[:-1]]
    scale = float(np.median(difference[usable])) if usable.any() else 0.0
    if scale > 1e-6:
        result[usable] = np.clip(difference[usable] / scale, 0.0, 8.0)
    return result.astype(np.float32)


def _validate_inputs(
    candidate_xy_m: np.ndarray,
    candidate_scores: np.ndarray,
    candidate_valid: np.ndarray,
    anchor_index: np.ndarray,
    anchor_weight: np.ndarray,
    background_cost: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    coordinates = np.asarray(candidate_xy_m, dtype=np.float64)
    scores = np.asarray(candidate_scores, dtype=np.float64)
    valid = np.asarray(candidate_valid, dtype=np.bool_)
    indices = np.asarray(anchor_index, dtype=np.int64).reshape(-1)
    weights = np.asarray(anchor_weight, dtype=np.float64).reshape(-1)
    background = np.asarray(background_cost, dtype=np.float64)
    if coordinates.ndim != 3 or coordinates.shape[-1] != 2:
        raise ValueError("candidate_xy_m must have shape [T,K,2]")
    frames, candidates = coordinates.shape[:2]
    if scores.shape != (frames, candidates) or valid.shape != (frames, candidates) or background.shape != (frames, candidates):
        raise ValueError("candidate score, validity and background arrays must match [T,K]")
    if indices.shape != (frames,) or weights.shape != (frames,):
        raise ValueError("anchor_index and anchor_weight must have shape [T]")
    if np.any(~np.isfinite(weights)) or np.any(weights < 0.0):
        raise ValueError("anchor_weight must be finite and nonnegative")
    if np.any((indices < -1) | (indices >= candidates)):
        raise ValueError("anchor_index must be -1 or reference a candidate slot")
    if np.any(~np.isfinite(background)) or np.any(background < 0.0):
        raise ValueError("background_cost must be finite and nonnegative")
    valid &= np.isfinite(coordinates).all(axis=-1) & np.isfinite(scores)
    return coordinates, scores, valid, indices, weights, background


def _build_unary(
    coordinates: np.ndarray,
    scores: np.ndarray,
    valid: np.ndarray,
    anchor_index: np.ndarray,
    anchor_weight: np.ndarray,
    background_cost: np.ndarray,
    visual_theta_rad: np.ndarray,
    visual_reliability: np.ndarray,
    visual_presence: np.ndarray,
    config: EpisodePosteriorConfig,
) -> tuple[np.ndarray, np.ndarray]:
    frames, candidates = valid.shape
    unary = np.full((frames, candidates + 1), -np.inf, dtype=np.float64)
    radar = _normalise_scores(scores, valid)
    radar_term = np.zeros_like(radar) if float(config.candidate_score_weight) == 0.0 else float(config.candidate_score_weight) * radar
    background_term = np.zeros_like(background_cost) if float(config.background_cost_weight) == 0.0 else float(config.background_cost_weight) * background_cost
    unary[:, :candidates] = np.where(
        valid,
        radar_term - background_term,
        -np.inf,
    )
    if float(config.visual_bearing_weight) > 0.0:
        candidate_theta = np.arctan2(coordinates[..., 0], coordinates[..., 1])
        difference = np.abs(np.arctan2(
            np.sin(candidate_theta - visual_theta_rad[:, None]),
            np.cos(candidate_theta - visual_theta_rad[:, None]),
        ))
        visual_strength = np.clip(visual_reliability, 0.0, 1.0) * np.clip(visual_presence, 0.0, 1.0)
        visual_cost = difference / float(config.visual_bearing_scale_rad)
        unary[:, :candidates] -= np.where(valid, float(config.visual_bearing_weight) * visual_strength[:, None] * visual_cost, 0.0)
    anchor_applied = np.zeros(frames, dtype=np.bool_)
    for frame, candidate in enumerate(anchor_index):
        if candidate >= 0 and anchor_weight[frame] > 0.0 and valid[frame, candidate]:
            unary[frame, candidate] += float(config.anchor_preference_weight) * anchor_weight[frame]
            anchor_applied[frame] = True
    identity = candidates
    unary[:, identity] = float(config.identity_logit)
    unary[~valid.any(axis=1), identity] = 0.0
    return unary, anchor_applied


def _build_transition(
    coordinates: np.ndarray,
    valid: np.ndarray,
    surprise: np.ndarray,
    config: EpisodePosteriorConfig,
) -> np.ndarray:
    frames, candidates = valid.shape
    identity = candidates
    transition = np.full((max(frames - 1, 0), candidates + 1, candidates + 1), -np.inf, dtype=np.float64)
    for frame in range(frames - 1):
        previous = np.flatnonzero(valid[frame])
        current = np.flatnonzero(valid[frame + 1])
        inertia = 1.0 / (1.0 + float(config.surprise_relaxation) * float(max(surprise[frame + 1], 0.0)))
        if len(previous) and len(current):
            distance = np.linalg.norm(
                coordinates[frame, previous, None, :] - coordinates[frame + 1, None, current, :], axis=-1
            )
            reachable = distance <= float(config.max_step_m) + 1e-9
            cost = -float(config.motion_cost_weight) * inertia * distance / float(config.max_step_m)
            transition[frame][np.ix_(previous, current)] = np.where(reachable, cost, -np.inf)
        transition[frame, previous, identity] = -float(config.identity_transition_cost)
        transition[frame, identity, current] = -float(config.identity_transition_cost)
        transition[frame, identity, identity] = 0.0
    return transition


def _forward_backward(unary: np.ndarray, transition: np.ndarray, temperature: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    values = unary / float(temperature)
    edges = transition / float(temperature)
    frames, states = values.shape
    alpha = np.full((frames, states), -np.inf, dtype=np.float64)
    beta = np.full((frames, states), -np.inf, dtype=np.float64)
    alpha[0] = values[0]
    for frame in range(1, frames):
        alpha[frame] = values[frame] + _logsumexp(alpha[frame - 1, :, None] + edges[frame - 1], axis=0)
    beta[-1] = 0.0
    for frame in range(frames - 2, -1, -1):
        beta[frame] = _logsumexp(edges[frame] + values[frame + 1, None, :] + beta[frame + 1, None, :], axis=1)
    log_partition = float(_logsumexp(alpha[-1], axis=0))
    if not np.isfinite(log_partition):
        raise ValueError("episode graph has no feasible path; identity state must remain available")
    posterior = np.exp(alpha + beta - log_partition)
    posterior /= np.maximum(posterior.sum(axis=1, keepdims=True), 1e-12)
    forward = np.exp(alpha - _logsumexp(alpha, axis=1)[:, None])
    reverse_logits = values + beta
    backward = np.exp(reverse_logits - _logsumexp(reverse_logits, axis=1)[:, None])
    return posterior.astype(np.float32), forward.astype(np.float32), backward.astype(np.float32)


def build_episode_posterior(
    candidate_xy_m: np.ndarray,
    candidate_scores: np.ndarray,
    candidate_valid: np.ndarray,
    anchor_index: np.ndarray,
    anchor_weight: np.ndarray,
    background_cost: np.ndarray,
    *,
    config: EpisodePosteriorConfig,
    visual_theta_rad: np.ndarray | None = None,
    visual_reliability: np.ndarray | None = None,
    visual_presence: np.ndarray | None = None,
) -> dict[str, np.ndarray]:
    """Infer an offline posterior over observed candidates plus identity.

    The caller is responsible for ensuring that anchor preference originates
    only from admissible Tier-A/B evidence.  The returned map index is an index
    into the candidate lattice or ``-1`` for the identity state, never a newly
    interpolated coordinate.
    """

    coordinates, scores, valid, indices, weights, background = _validate_inputs(
        candidate_xy_m, candidate_scores, candidate_valid, anchor_index, anchor_weight, background_cost
    )
    frames = len(scores)
    theta = np.zeros(frames, dtype=np.float64) if visual_theta_rad is None else np.asarray(visual_theta_rad, dtype=np.float64).reshape(-1)
    reliability = np.zeros(frames, dtype=np.float64) if visual_reliability is None else np.asarray(visual_reliability, dtype=np.float64).reshape(-1)
    presence = np.zeros(frames, dtype=np.float64) if visual_presence is None else np.asarray(visual_presence, dtype=np.float64).reshape(-1)
    if theta.shape != (frames,) or reliability.shape != (frames,) or presence.shape != (frames,):
        raise ValueError("visual theta, reliability and presence must have shape [T]")
    usable_visual = np.isfinite(theta) & np.isfinite(reliability) & np.isfinite(presence)
    theta = np.where(usable_visual, theta, 0.0)
    reliability = np.where(usable_visual, reliability, 0.0)
    presence = np.where(usable_visual, presence, 0.0)
    surprise = _observation_surprise(scores, valid)
    unary, anchor_applied = _build_unary(
        coordinates, scores, valid, indices, weights, background, theta, reliability, presence, config
    )
    transition = _build_transition(coordinates, valid, surprise, config)
    posterior, forward, backward = _forward_backward(unary, transition, config.temperature)
    candidates = valid.shape[1]
    candidate_posterior = posterior[:, :candidates].copy()
    candidate_posterior[~valid] = 0.0
    map_state = posterior.argmax(axis=1).astype(np.int64)
    map_index = np.where(map_state == candidates, -1, map_state).astype(np.int64)
    entropy = -np.sum(np.where(posterior > 0.0, posterior * np.log(np.maximum(posterior, 1e-12)), 0.0), axis=1)
    agreement = 1.0 - 0.5 * np.abs(forward - backward).sum(axis=1)
    return {
        "posterior": posterior,
        "candidate_posterior": candidate_posterior,
        "identity_mass": posterior[:, candidates].astype(np.float32),
        "map_index": map_index,
        "entropy": entropy.astype(np.float32),
        "surprise": surprise,
        "forward_posterior": forward,
        "backward_posterior": backward,
        "forward_backward_agreement": np.clip(agreement, 0.0, 1.0).astype(np.float32),
        "anchor_applied": anchor_applied,
    }
