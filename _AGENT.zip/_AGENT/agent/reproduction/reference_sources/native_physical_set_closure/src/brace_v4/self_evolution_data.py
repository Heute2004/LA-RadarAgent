"""Strict-V4 data helpers for label-free target-site radar adaptation."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset

from .ris_response import stageb_v8_ris_feature_root
from .visual_protocol import VISUAL_DEGRADED_SEQUENCES


GLOBAL_EXCLUSIONS = frozenset({"seq_064", "seq_084", "seq_112", "seq_113", "seq_114", "seq_148"})


def sequence_number(sequence: str) -> int:
    normalized = sequence.strip().lower()
    if not normalized.startswith("seq_") or len(normalized) != 7 or not normalized[4:].isdigit():
        raise ValueError(f"invalid sequence identifier: {sequence!r}")
    return int(normalized[4:])


def route_for_record(record: dict[str, Any]) -> str:
    geometry = str(record.get("scene_geometry", "")).strip().lower()
    weather = str(record.get("weather", "")).strip().lower()
    if geometry == "l_corridor":
        return "corner_nlos_ris"
    if geometry == "cluttered_indoor":
        return "indoor_clutter"
    if geometry == "open_indoor":
        return "open_indoor_los"
    if geometry in {"complex_outdoor", "open_outdoor"}:
        return "outdoor_dry_complex" if weather == "dry" else "outdoor_wet_return"
    raise ValueError(f"unsupported Agent condition: geometry={geometry!r}, weather={weather!r}")


def radar_feature_root(dataset_root: str | Path, sequence: str) -> Path:
    root = Path(dataset_root) / "Data_train" / sequence
    number = sequence_number(sequence)
    if 1 <= number <= 21:
        return stageb_v8_ris_feature_root(root, sequence)
    standard = root / "Radar"
    if not (standard / "RA").is_dir() or not (standard / "RA-MIT").is_dir():
        raise FileNotFoundError(f"missing standard radar features: {standard}")
    return standard


def load_episode_records(split_path: str | Path, split: str) -> list[dict[str, Any]]:
    payload = json.loads(Path(split_path).read_text(encoding="utf-8"))
    normalized_split = split.strip().lower()
    if normalized_split not in {"train", "development"}:
        raise ValueError("only Agent Train or Development may be loaded")
    allowed = set(payload[normalized_split])
    forbidden = set(payload.get("locked_test", ())) | set(payload.get("global_excluded", ())) | set(GLOBAL_EXCLUSIONS)
    if allowed & forbidden:
        raise ValueError(f"forbidden sequence leaked into {normalized_split}: {sorted(allowed & forbidden)}")
    records = [record for record in payload["records"] if record["sequence"] in allowed]
    if {record["sequence"] for record in records} != allowed:
        raise ValueError(f"episode records are incomplete for split={normalized_split}")
    return records


def load_visual_runtime(path: str | Path) -> dict[tuple[str, int], dict[str, float | bool]]:
    """Load an allowed causal visual runtime.

    Both the legacy bearing CSV and the frozen VAST runtime are accepted for
    backwards-compatible audits.  When a VAST runtime is supplied, its
    ``teacher_accepted`` decision and ``q_teacher`` are authoritative: raw
    detector proposals must not become weak supervision by themselves.
    """

    def as_bool(value: object) -> bool:
        return str(value).strip().lower() in {"1", "true", "yes"}

    rows: dict[tuple[str, int], dict[str, float | bool]] = {}
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            sequence = row["sequence"].strip().lower()
            # Degraded RGB is a stress condition, never a trusted weak label.
            if sequence in GLOBAL_EXCLUSIONS or sequence in VISUAL_DEGRADED_SEQUENCES:
                continue
            key = (sequence, int(row["frame_id"]))
            is_vast = "teacher_accepted" in row or "q_teacher" in row
            if is_vast:
                # q_teacher already includes the temporal quality/presence
                # contract.  Never fall back to the raw Faster-RCNN anchor.
                reliability = float(row.get("q_teacher") or 0.0)
                accepted = as_bool(row.get("teacher_accepted"))
            else:
                reliability = float(row["reliability"])
                accepted = as_bool(row["presence_accepted"])
            rows[key] = {
                "presence_probability": float(row["presence_probability"]),
                "presence_accepted": accepted,
                "bearing_theta_rad": float(row["bearing_theta_rad"]),
                "reliability": reliability,
            }
    return rows


def load_radar_quality(sequence_root: Path, frame_count: int) -> np.ndarray:
    quality_path = sequence_root / "RadarFrameQualityV1" / "frame_quality.csv"
    valid = np.ones(frame_count, dtype=np.bool_)
    if not quality_path.is_file():
        return valid
    with quality_path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            frame_id = int(row["frame_id"])
            if 0 <= frame_id < frame_count:
                valid[frame_id] = str(row["radar_training_valid"]).strip().lower() in {"1", "true", "yes"}
    return valid


def load_empty_site_stats(empty_root: str | Path, site_name: str) -> tuple[Tensor, Tensor]:
    """Load matching commissioned-site RA/RA-MTI dB statistics."""

    path = Path(empty_root) / site_name / "BackgroundStats" / "background_stats.npz"
    if not path.is_file():
        raise FileNotFoundError(f"missing commissioned background statistics: {path}")
    with np.load(path, allow_pickle=False) as archive:
        mean = np.stack((archive["RA_mean_db"], archive["RA-MIT_mean_db"])).astype(np.float32, copy=True)
        std = np.stack((archive["RA_std_db"], archive["RA-MIT_std_db"])).astype(np.float32, copy=True)
    if mean.shape != (2, 128, 128) or std.shape != mean.shape:
        raise ValueError(f"invalid commissioned background statistics shape: {path}")
    return torch.from_numpy(mean), torch.from_numpy(std).clamp_min_(1e-3)


def load_development_labels(sequence_root: Path) -> dict[int, tuple[float, float, bool]]:
    """Load evaluation-only labels. Never call this from a training cache builder."""

    label_path = sequence_root / "BEVFinalLabelsV1" / "final_bev_track.csv"
    if not label_path.is_file():
        label_path = sequence_root / "BEVFinalLabels" / "final_bev_track.csv"
    rows: dict[int, tuple[float, float, bool]] = {}
    with label_path.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            frame_id = int(row["frame_id"])
            valid = str(row["final_label_valid"]).strip().lower() in {"1", "true", "yes"}
            raw_x = str(row.get("final_radar_x_m") or "").strip()
            raw_y = str(row.get("final_radar_y_m") or "").strip()
            if not valid:
                rows[frame_id] = (
                    float(raw_x) if raw_x else float("nan"),
                    float(raw_y) if raw_y else float("nan"),
                    False,
                )
                continue
            if not raw_x or not raw_y:
                raise ValueError(f"valid evaluation label lacks coordinates at frame={frame_id}: {label_path}")
            rows[frame_id] = (float(raw_x), float(raw_y), True)
    return rows


@dataclass(frozen=True)
class RadarSequenceFrames:
    sequence: str
    route: str
    feature_root: Path
    frame_ids: tuple[int, ...]
    training_valid: np.ndarray

    @classmethod
    def create(cls, dataset_root: str | Path, record: dict[str, Any]) -> "RadarSequenceFrames":
        sequence = str(record["sequence"]).strip().lower()
        feature_root = radar_feature_root(dataset_root, sequence)
        frame_ids = tuple(sorted(int(path.stem.split("_")[-1]) for path in (feature_root / "RA").glob("frame_*.npy")))
        if not frame_ids:
            raise ValueError(f"no radar frames found for {sequence}: {feature_root}")
        expected = tuple(range(frame_ids[-1] + 1))
        if frame_ids != expected:
            raise ValueError(f"radar frames are not contiguous for {sequence}")
        sequence_root = Path(dataset_root) / "Data_train" / sequence
        return cls(
            sequence=sequence,
            route=route_for_record(record),
            feature_root=feature_root,
            frame_ids=frame_ids,
            training_valid=load_radar_quality(sequence_root, len(frame_ids)),
        )

    def read_db(self, frame_id: int) -> Tensor:
        channels: list[Tensor] = []
        for view in ("RA", "RA-MIT"):
            values = np.load(self.feature_root / view / f"frame_{frame_id:04d}.npy", allow_pickle=False).astype(np.float32, copy=False)
            if values.shape != (128, 128):
                raise ValueError(f"{self.sequence} frame {frame_id} {view} is not 128x128")
            channels.append(torch.from_numpy(np.nan_to_num(values, nan=80.0, posinf=110.0, neginf=50.0).copy()))
        return torch.stack(channels, dim=0)

    def read_normalized(self, frame_id: int, *, db_center: float = 80.0, db_scale: float = 30.0) -> Tensor:
        values = self.read_db(frame_id)
        return ((values - float(db_center)) / float(db_scale)).clamp(-3.0, 3.0)

    def causal_clip(self, frame_id: int, clip_length: int = 16) -> Tensor:
        indices = [max(0, frame_id - clip_length + 1 + offset) for offset in range(clip_length)]
        return torch.stack([self.read_normalized(index) for index in indices], dim=0)

    def causal_clip_db(self, frame_id: int, clip_length: int = 16) -> Tensor:
        indices = [max(0, frame_id - clip_length + 1 + offset) for offset in range(clip_length)]
        return torch.stack([self.read_db(index) for index in indices], dim=0)


class CandidateCacheDataset(Dataset[dict[str, Tensor | str]]):
    """Causal candidate-token clips with label-free visual/radar pseudo targets."""

    def __init__(
        self,
        cache_dir: str | Path,
        route: str,
        partition: str,
        *,
        history_length: int = 8,
        shadow_fraction: float = 0.2,
        shadow_strategy: str = "tail",
        shadow_stride: int = 5,
        shadow_offset: int | None = None,
        allowed_sequences: set[str] | None = None,
    ) -> None:
        if partition not in {"train", "shadow", "all"}:
            raise ValueError("partition must be train, shadow or all")
        if history_length < 1:
            raise ValueError("history_length must be positive")
        if shadow_strategy not in {"tail", "interleaved"}:
            raise ValueError("shadow_strategy must be tail or interleaved")
        if shadow_strategy == "interleaved":
            if shadow_stride < 2:
                raise ValueError("interleaved shadow_stride must be at least two")
            if shadow_offset is None:
                shadow_offset = shadow_stride - 1
            if not 0 <= shadow_offset < shadow_stride:
                raise ValueError("shadow_offset must be within [0, shadow_stride)")
        self.history_length = int(history_length)
        allowed = None if allowed_sequences is None else {str(sequence) for sequence in allowed_sequences}
        self.sequences: list[dict[str, Any]] = []
        self.samples: list[tuple[int, int]] = []
        for path in sorted(Path(cache_dir).glob("seq_*.npz")):
            with np.load(path, allow_pickle=False) as payload:
                cached_route = str(payload["route"].item())
                if cached_route != route:
                    continue
                record = {key: payload[key].copy() for key in payload.files}
            if allowed is not None and str(record["sequence"].item()) not in allowed:
                continue
            sequence_index = len(self.sequences)
            self.sequences.append(record)
            frame_count = len(record["frame_id"])
            if shadow_strategy == "tail":
                split_at = max(1, min(frame_count - 1, int(round(frame_count * (1.0 - shadow_fraction)))))
                if partition == "train":
                    positions = range(0, split_at)
                elif partition == "shadow":
                    positions = range(split_at, frame_count)
                else:
                    positions = range(frame_count)
            else:
                assert shadow_offset is not None
                all_positions = range(frame_count)
                if partition == "train":
                    positions = (position for position in all_positions if position % shadow_stride != shadow_offset)
                elif partition == "shadow":
                    positions = (position for position in all_positions if position % shadow_stride == shadow_offset)
                else:
                    positions = all_positions
            self.samples.extend((sequence_index, position) for position in positions)
        if not self.samples:
            raise ValueError(f"no candidate-cache samples for route={route!r}, partition={partition!r}")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        sequence_index, position = self.samples[index]
        record = self.sequences[sequence_index]
        history = [max(0, position - self.history_length + 1 + offset) for offset in range(self.history_length)]
        accepted = bool(record["trainable"][position])
        if accepted and "pseudo_confidence" in record:
            sample_weight = float(np.clip(record["pseudo_confidence"][position], 0.25, 1.0))
        else:
            sample_weight = 1.0 if accepted else 0.15
        candidate_count = int(record["radar_score"].shape[1])

        def candidate_field(name: str, default: float) -> np.ndarray:
            if name in record:
                return record[name][position].astype(np.float32, copy=False)
            return np.full(candidate_count, default, dtype=np.float32)

        def frame_field(name: str, default: float) -> float:
            return float(record[name][position]) if name in record else float(default)

        candidate_quality = np.stack(
            (
                candidate_field("candidate_ra_mti_agreement", 0.0),
                candidate_field("candidate_background_risk", 0.0),
                candidate_field("candidate_temporal_persistence", 0.0),
            ),
            axis=1,
        )
        runtime_quality = np.asarray(
            (
                frame_field("visual_presence_accepted", 0.0),
                frame_field("visual_reliability", 0.0),
                frame_field("background_change_probability", 0.0),
                frame_field("base_presence_probability", 1.0),
                frame_field("base_observation_reliability", 1.0),
                frame_field("visual_polar_mode", 0.0),
            ),
            dtype=np.float32,
        )
        return {
            "history_tokens": torch.from_numpy(record["tokens"][history].astype(np.float32, copy=False)),
            "history_candidate_xy_m": torch.from_numpy(record["candidate_xy_m"][history].astype(np.float32, copy=False)),
            "base_scores": torch.from_numpy(record["radar_score"][position].astype(np.float32, copy=False)),
            "candidate_xy_m": torch.from_numpy(record["candidate_xy_m"][position].astype(np.float32, copy=False)),
            "candidate_quality": torch.from_numpy(candidate_quality),
            "runtime_quality": torch.from_numpy(runtime_quality),
            "target_index": torch.tensor(int(record["pseudo_selected_index"][position]) if accepted else 0, dtype=torch.long),
            "pseudo_accepted": torch.tensor(accepted, dtype=torch.bool),
            "sample_weight": torch.tensor(sample_weight, dtype=torch.float32),
            "frame_id": torch.tensor(int(record["frame_id"][position]), dtype=torch.long),
            "sequence": str(record["sequence"].item()),
        }
