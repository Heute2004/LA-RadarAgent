"""Read-only R11 candidate-set data contract for CORA-SE2 specialists."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


_FORBIDDEN_FLAGS = (
    "target_final_bev_read",
    "development_read",
    "locked_test_read",
    "right_rgb_read",
    "manual_ra_anchor_at_label_stage",
)
_ROUTE_TO_R11 = {
    "indoor_clutter": "indoor_clutter",
    "open_indoor_los": "open_indoor_los",
    "dry_complex": "outdoor_dry_complex",
    "outdoor_wet": "outdoor_wet_return",
}


@dataclass(frozen=True)
class RouteCandidateEpisode:
    """Observed candidate support, never an invented point-coordinate target."""

    sequence: str
    r11_route: str
    frame_id: np.ndarray
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_features: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    label_tier: np.ndarray

    def __post_init__(self) -> None:
        frames, candidates, dimensions = self.candidate_xy_m.shape
        if dimensions != 2 or self.candidate_valid.shape != (frames, candidates):
            raise ValueError("candidate coordinates/validity must be [frames,candidates,2]")
        if self.candidate_features.shape[:2] != (frames, candidates):
            raise ValueError("candidate features must align with candidate geometry")
        if self.allowed_weight.shape != (frames, candidates) or self.sample_weight.shape != (frames,):
            raise ValueError("set weights must align with candidate geometry")
        if self.frame_id.shape != (frames,) or self.label_tier.shape != (frames,):
            raise ValueError("frame metadata must align with candidate geometry")
        if np.any(~np.isfinite(self.candidate_xy_m[self.candidate_valid])):
            raise ValueError("valid physical candidates require finite coordinates")
        if np.any(self.allowed_weight[~self.candidate_valid] != 0.0):
            raise ValueError("invalid candidates cannot receive R11 set mass")
        if np.any(self.sample_weight < 0.0):
            raise ValueError("sample_weight must be nonnegative")

    @property
    def supervised(self) -> np.ndarray:
        return self.sample_weight > 0.0


def _scalar_text(archive: np.lib.npyio.NpzFile, key: str) -> str:
    value = np.asarray(archive[key])
    if value.shape != ():
        raise ValueError(f"{key} must be scalar")
    return str(value.item()).strip().lower()


def _require_false(archive: np.lib.npyio.NpzFile, key: str) -> None:
    value = np.asarray(archive[key])
    if value.shape != () or bool(value.item()):
        raise ValueError(f"forbidden R11 provenance flag: {key}")


def load_r11_candidate_episode(path: Path, *, expected_r11_route: str) -> RouteCandidateEpisode:
    """Load frozen R11 support and reject any parent artifact with forbidden reads."""

    if expected_r11_route not in _ROUTE_TO_R11.values():
        raise ValueError(f"unsupported R11 route: {expected_r11_route}")
    with np.load(path, allow_pickle=False) as archive:
        for key in _FORBIDDEN_FLAGS:
            _require_false(archive, key)
        if bool(np.asarray(archive["expert_training_performed"]).item()):
            raise ValueError("R11 candidate artifact must predate expert training")
        route = _scalar_text(archive, "route")
        if route != expected_r11_route:
            raise ValueError(f"route mismatch: expected {expected_r11_route}, got {route}")
        frame_id = np.asarray(archive["frame_id"], dtype=np.int64).copy()
        candidate_xy = np.asarray(archive["candidate_xy_m"], dtype=np.float32).copy()
        candidate_valid = np.asarray(archive["candidate_valid"], dtype=bool).copy()
        candidate_weight = np.asarray(archive["candidate_weight"], dtype=np.float32).copy()
        sample_weight = np.asarray(archive["sample_weight"], dtype=np.float32).copy()
        tier = np.asarray(archive["label_tier"], dtype=str).copy()
        quality = np.asarray(archive["evidence_quality"], dtype=np.float32).copy()
        posterior = np.asarray(archive["evidence_posterior_top1"], dtype=np.float32).copy()
        margin = np.asarray(archive["evidence_posterior_margin"], dtype=np.float32).copy()
        agreement = np.asarray(archive["evidence_forward_backward_agreement"], dtype=np.float32).copy()
        sequence = _scalar_text(archive, "sequence")

    frames, candidates, dimensions = candidate_xy.shape
    if dimensions != 2 or candidate_valid.shape != (frames, candidates):
        raise ValueError("R11 candidate geometry has invalid shape")
    if candidate_weight.shape != (frames, candidates) or frame_id.shape != (frames,):
        raise ValueError("R11 candidate weights do not align")
    if any(value.shape != (frames,) for value in (sample_weight, tier, quality, posterior, margin, agreement)):
        raise ValueError("R11 evidence metadata does not align")

    # Abstentions do not turn into implicit negative labels.
    supervised = np.isin(tier, ("high", "medium")) & (sample_weight > 0.0)
    allowed_weight = np.where(candidate_valid, np.maximum(candidate_weight, 0.0), 0.0).astype(np.float32)
    allowed_weight[~supervised] = 0.0
    allowed_weight /= np.maximum(allowed_weight.sum(axis=1, keepdims=True), 1.0e-8)
    sample_weight = np.where(supervised & (allowed_weight.sum(axis=1) > 0.0), sample_weight, 0.0).astype(np.float32)

    evidence = np.stack((quality, posterior, margin, agreement), axis=1)
    candidate_features = np.concatenate(
        (candidate_xy, allowed_weight[..., None], np.broadcast_to(evidence[:, None, :], (frames, candidates, 4))),
        axis=-1,
    ).astype(np.float32)
    candidate_features[~candidate_valid] = 0.0
    return RouteCandidateEpisode(
        sequence=sequence,
        r11_route=route,
        frame_id=frame_id,
        candidate_xy_m=candidate_xy,
        candidate_valid=candidate_valid,
        candidate_features=candidate_features,
        allowed_weight=allowed_weight,
        sample_weight=sample_weight,
        label_tier=tier,
    )
