"""R31 sequence-cross-fitted CORA candidate-label refinement.

R31 never regresses a coordinate.  It redistributes supervision over observed
current-frame RA/RA-MTI peaks using a sequence-excluded frozen CORA teacher,
the exact candidate-set support used to train SE2, and an offline
forward/backward physical-path posterior.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np

from brace_v4.candidate_episode_teacher import EpisodePosteriorConfig, build_episode_posterior


_ROUTES = (
    "clean",
    "cluttered",
    "cluttered_or_multipath_likely",
    "rain_or_wet_ground",
    "wet_ground",
)

_R11_TO_R31_ROUTE = {
    "open_indoor_los": "clean",
    "indoor_clutter": "cluttered",
    "outdoor_dry_complex": "cluttered_or_multipath_likely",
    "outdoor_wet_return": "rain_or_wet_ground",
}


@dataclass(frozen=True, order=True)
class RouteSequence:
    sequence: str
    route: str


@dataclass(frozen=True)
class CrossFitFold:
    fold_id: int
    fit: tuple[RouteSequence, ...]
    holdout: tuple[RouteSequence, ...]


@dataclass(frozen=True)
class R31Config:
    max_step_m: float = 0.30
    teacher_probability_weight: float = 2.0
    raw_score_weight: float = 0.50
    agreement_weight: float = 0.75
    persistence_weight: float = 0.75
    background_cost_weight: float = 0.75
    parent_anchor_weight: float = 3.0
    parent_anchor_margin: float = 0.15
    identity_logit: float = -3.0
    identity_transition_cost: float = 0.75
    motion_cost_weight: float = 1.5
    temperature: float = 0.70
    teacher_anchor_probability: float = 0.65
    teacher_anchor_margin: float = 0.15
    tier_a_probability: float = 0.65
    tier_a_margin: float = 0.15
    tier_a_agreement: float = 0.80
    tier_b_candidate_mass: float = 0.55
    tier_b_agreement: float = 0.50
    tier_b_relative_probability: float = 0.35
    tier_b_max_candidates: int = 4

    def __post_init__(self) -> None:
        if self.max_step_m <= 0.0 or self.temperature <= 0.0:
            raise ValueError("max_step_m and temperature must be positive")
        for name in (
            "teacher_anchor_probability",
            "teacher_anchor_margin",
            "parent_anchor_margin",
            "tier_a_probability",
            "tier_a_margin",
            "tier_a_agreement",
            "tier_b_candidate_mass",
            "tier_b_agreement",
            "tier_b_relative_probability",
        ):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0,1]")
        if self.tier_b_max_candidates < 2:
            raise ValueError("tier_b_max_candidates must be at least two")


@dataclass(frozen=True)
class R31CandidateLabels:
    candidate_xy_m: np.ndarray
    candidate_valid: np.ndarray
    candidate_posterior: np.ndarray
    allowed_weight: np.ndarray
    sample_weight: np.ndarray
    selected_index: np.ndarray
    selected_xy_m: np.ndarray
    tier: np.ndarray
    identity_mass: np.ndarray
    forward_backward_agreement: np.ndarray
    posterior_margin: np.ndarray
    anchor_index: np.ndarray

    def __post_init__(self) -> None:
        frames, candidates = self.candidate_valid.shape
        if self.candidate_xy_m.shape != (frames, candidates, 2):
            raise ValueError("candidate_xy_m must be [T,K,2]")
        for value in (self.candidate_posterior, self.allowed_weight):
            if value.shape != (frames, candidates):
                raise ValueError("candidate posterior/weights must align with candidates")
        for value in (
            self.sample_weight,
            self.selected_index,
            self.tier,
            self.identity_mass,
            self.forward_backward_agreement,
            self.posterior_margin,
            self.anchor_index,
        ):
            if value.shape != (frames,):
                raise ValueError("frame metadata does not align")
        if self.selected_xy_m.shape != (frames, 2):
            raise ValueError("selected_xy_m must be [T,2]")
        if np.any(self.allowed_weight[~self.candidate_valid] != 0.0):
            raise ValueError("invalid physical candidates cannot receive supervision")
        if np.any(self.allowed_weight[self.tier == "tier_c"] != 0.0):
            raise ValueError("tier_c must abstain from candidate supervision")


def _normalise_sequence(value: object) -> str:
    sequence = str(value).strip().lower()
    if not sequence.startswith("seq_"):
        digits = sequence.removeprefix("seq").lstrip("_")
        if digits.isdigit():
            sequence = f"seq_{int(digits):03d}"
    return sequence


def build_r31_train_records(r11_manifest: Mapping[str, object]) -> list[dict[str, str]]:
    """Map the immutable SE2 R11 manifest into the R31 route vocabulary."""

    rows = r11_manifest.get("sequences")
    if not isinstance(rows, list) or not rows:
        raise ValueError("R11 manifest has no sequence records")
    records: list[dict[str, str]] = []
    seen: set[str] = set()
    for row in rows:
        if not isinstance(row, Mapping):
            raise ValueError("R11 manifest contains an invalid sequence record")
        sequence = _normalise_sequence(row.get("sequence", ""))
        r11_route = str(row.get("route", "")).strip().lower()
        if not sequence or sequence in seen:
            raise ValueError(f"R11 manifest has duplicate or empty sequence: {sequence!r}")
        if r11_route not in _R11_TO_R31_ROUTE:
            raise ValueError(f"R11 route is outside R31: {r11_route!r}")
        seen.add(sequence)
        records.append({"sequence": sequence, "route": _R11_TO_R31_ROUTE[r11_route]})
    return sorted(records, key=lambda record: record["sequence"])


def source_replay_indices_excluding(
    samples: Sequence[tuple[str, int]],
    excluded_sequences: Sequence[str],
) -> list[int]:
    """Return source-replay indices that cannot expose a cross-fit holdout."""

    excluded = {_normalise_sequence(value) for value in excluded_sequences}
    return [
        index
        for index, (sequence, _position) in enumerate(samples)
        if _normalise_sequence(sequence) not in excluded
    ]


def candidate_probability_from_bev_logits(
    bev_logits: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    *,
    x_min_m: float = -10.0,
    y_min_m: float = 0.0,
    resolution_m: float = 0.1,
) -> np.ndarray:
    """Sample BEV logits at observed peaks and normalize within each frame."""

    logits = np.asarray(bev_logits, dtype=np.float32)
    if logits.ndim == 4 and logits.shape[1] == 1:
        logits = logits[:, 0]
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    if logits.ndim != 3 or xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("BEV logits and candidate arrays have incompatible shapes")
    if logits.shape[0] != xy.shape[0] or resolution_m <= 0.0:
        raise ValueError("BEV logits and candidates must share frames and positive resolution")
    valid = valid & np.isfinite(xy).all(axis=-1)
    if not valid.any(axis=1).all():
        raise ValueError("every frame requires at least one observed candidate")
    x_index = np.rint((np.nan_to_num(xy[..., 0], nan=x_min_m) - x_min_m) / resolution_m).astype(np.int64)
    y_index = np.rint((np.nan_to_num(xy[..., 1], nan=y_min_m) - y_min_m) / resolution_m).astype(np.int64)
    x_index = np.clip(x_index, 0, logits.shape[1] - 1)
    y_index = np.clip(y_index, 0, logits.shape[2] - 1)
    rows = np.arange(logits.shape[0])[:, None]
    sampled = logits[rows, x_index, y_index]
    sampled = np.where(valid, sampled, -np.inf)
    maximum = np.max(sampled, axis=1, keepdims=True)
    exponential = np.where(valid, np.exp(sampled - maximum), 0.0)
    return (exponential / np.maximum(exponential.sum(axis=1, keepdims=True), 1.0e-8)).astype(np.float32)


def make_route_stratified_folds(
    records: Iterable[Mapping[str, object]],
    *,
    folds: int = 4,
    locked_test_sequences: Sequence[str] = (),
) -> tuple[CrossFitFold, ...]:
    """Return deterministic route-stratified sequence-exclusion folds."""

    if folds < 2:
        raise ValueError("cross fitting needs at least two folds")
    locked = {_normalise_sequence(value) for value in locked_test_sequences}
    rows: list[RouteSequence] = []
    seen: set[str] = set()
    for record in records:
        sequence = _normalise_sequence(record.get("sequence", ""))
        route = str(record.get("route", "")).strip().lower()
        if not sequence or sequence in seen:
            raise ValueError(f"duplicate or empty sequence: {sequence!r}")
        if sequence in locked:
            raise ValueError(f"Locked Test sequence is forbidden: {sequence}")
        if route == "corner_nlos_ris":
            raise ValueError("RIS is outside the R31 non-RIS cross-fit contract")
        if route not in _ROUTES:
            raise ValueError(f"unsupported R31 route: {route!r}")
        seen.add(sequence)
        rows.append(RouteSequence(sequence=sequence, route=route))
    if len(rows) < folds:
        raise ValueError("cross fitting needs at least one holdout sequence per fold")

    holdouts: list[list[RouteSequence]] = [[] for _ in range(folds)]
    for route_index, route in enumerate(_ROUTES):
        grouped = sorted((row for row in rows if row.route == route), key=lambda row: row.sequence)
        for index, row in enumerate(grouped):
            minimum_size = min(len(partition) for partition in holdouts)
            eligible = {
                fold_id
                for fold_id, partition in enumerate(holdouts)
                if len(partition) == minimum_size
            }
            preferred_order = [
                (route_index + index + offset) % folds
                for offset in range(folds)
            ]
            fold_id = next(candidate for candidate in preferred_order if candidate in eligible)
            holdouts[fold_id].append(row)
    all_rows = tuple(sorted(rows))
    result: list[CrossFitFold] = []
    for fold_id, held in enumerate(holdouts):
        holdout = tuple(sorted(held))
        held_names = {row.sequence for row in holdout}
        fit = tuple(row for row in all_rows if row.sequence not in held_names)
        if not holdout or not fit:
            raise ValueError(f"fold {fold_id} has an empty fit or holdout partition")
        result.append(CrossFitFold(fold_id=fold_id, fit=fit, holdout=holdout))
    return tuple(result)


def build_crossfit_manifest(
    records: Iterable[Mapping[str, object]],
    *,
    folds: int,
    r11_manifest_sha256: str,
    parent_se2_checkpoint_sha256: str,
    locked_test_sequences: Sequence[str] = (),
) -> dict[str, object]:
    """Serialize the immutable sequence-exclusion plan for R31 teachers."""

    if not str(r11_manifest_sha256).strip() or not str(parent_se2_checkpoint_sha256).strip():
        raise ValueError("cross-fit parent hashes must be non-empty")
    partitions = make_route_stratified_folds(
        records,
        folds=folds,
        locked_test_sequences=locked_test_sequences,
    )
    return {
        "schema_version": "brace_v4_r31_crossfit_manifest_v1",
        "fold_count": int(folds),
        "r11_manifest_sha256": str(r11_manifest_sha256),
        "parent_se2_checkpoint_sha256": str(parent_se2_checkpoint_sha256),
        "locked_test_sequences": sorted(_normalise_sequence(value) for value in locked_test_sequences),
        "folds": [
            {
                "fold_id": fold.fold_id,
                "fit_sequences": [row.sequence for row in fold.fit],
                "holdout_sequences": [row.sequence for row in fold.holdout],
                "holdout_routes": {row.sequence: row.route for row in fold.holdout},
                "teacher_input_future_frames": False,
                "label_builder_may_use_complete_holdout_episode": True,
            }
            for fold in partitions
        ],
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
            "post_se2_historical_pseudolabel_read": False,
        },
    }


def make_crossfit_checkpoint_contract(
    fold: Mapping[str, object],
    *,
    cora0_sha256: str,
    se1_sha256: str,
    r11_manifest_sha256: str,
    parent_se2_checkpoint_sha256: str,
    epochs: int,
) -> dict[str, object]:
    """Create an honest adapter-only checkpoint contract for one fold."""

    fit = [_normalise_sequence(value) for value in fold.get("fit_sequences", ())]
    holdout = [_normalise_sequence(value) for value in fold.get("holdout_sequences", ())]
    if not fit or not holdout or set(fit) & set(holdout):
        raise ValueError("cross-fit fold has empty or overlapping fit/holdout sequences")
    if epochs < 1:
        raise ValueError("cross-fit epochs must be positive")
    hashes = (cora0_sha256, se1_sha256, r11_manifest_sha256, parent_se2_checkpoint_sha256)
    if not all(str(value).strip() for value in hashes):
        raise ValueError("cross-fit checkpoint hashes must be non-empty")
    return {
        "schema_version": "brace_v4_r31_crossfit_se2_checkpoint_v1",
        "architecture": "CORA-SE2-FrozenCORA0-SetMassResidualAdapter-V1",
        "fold_id": int(fold.get("fold_id", -1)),
        "fit_sequences": fit,
        "holdout_sequences": holdout,
        "holdout_routes": dict(fold.get("holdout_routes", {})),
        "epochs": int(epochs),
        "clip_length": 16,
        "cora0_checkpoint_sha256": str(cora0_sha256),
        "se1_checkpoint_sha256": str(se1_sha256),
        "r11_manifest_sha256": str(r11_manifest_sha256),
        "parent_se2_checkpoint_sha256": str(parent_se2_checkpoint_sha256),
        "adapter_only_trainable": True,
        "source_replay_excludes_holdout": True,
        "model_future_frame_input": False,
        "offline_label_builder_future_context": True,
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
            "post_se2_historical_pseudolabel_read": False,
        },
    }


def validate_crossfit_teacher_contract(
    contract: Mapping[str, object],
    *,
    inference_sequence: str,
    expected_r11_sha256: str,
    expected_parent_se2_sha256: str,
) -> None:
    """Reject a cross-fit teacher that has seen its inference sequence."""

    if contract.get("schema_version") != "brace_v4_r31_crossfit_se2_checkpoint_v1":
        raise ValueError("unsupported R31 cross-fit teacher checkpoint")
    fit = {_normalise_sequence(value) for value in contract.get("fit_sequences", ())}
    holdout = {_normalise_sequence(value) for value in contract.get("holdout_sequences", ())}
    if not fit or not holdout or fit & holdout:
        raise ValueError("cross-fit teacher fit/holdout overlap is forbidden")
    sequence = _normalise_sequence(inference_sequence)
    if sequence not in holdout or sequence in fit:
        raise ValueError(f"inference sequence must belong only to teacher holdout: {sequence}")
    if str(contract.get("r11_manifest_sha256", "")) != str(expected_r11_sha256):
        raise ValueError("cross-fit teacher R11 parent hash mismatch")
    if str(contract.get("parent_se2_checkpoint_sha256", "")) != str(expected_parent_se2_sha256):
        raise ValueError("cross-fit teacher parent SE2 hash mismatch")
    if int(contract.get("epochs", 0)) < 1 or int(contract.get("clip_length", 0)) != 16:
        raise ValueError("cross-fit teacher training contract is invalid")
    if not bool(contract.get("adapter_only_trainable", False)) or bool(contract.get("model_future_frame_input", True)):
        raise ValueError("cross-fit teacher must be an adapter-only causal model")
    if not bool(contract.get("source_replay_excludes_holdout", False)):
        raise ValueError("cross-fit teacher source replay must exclude holdout sequences")
    forbidden = contract.get("forbidden_reads")
    if not isinstance(forbidden, Mapping) or any(bool(value) for value in forbidden.values()):
        raise ValueError("cross-fit teacher contains a forbidden provenance read")


def _validated_arrays(
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    teacher_probability: np.ndarray,
    raw_score: np.ndarray,
    ra_mti_agreement: np.ndarray,
    background_risk: np.ndarray,
    temporal_persistence: np.ndarray,
    se2_parent_allowed_weight: np.ndarray,
    se2_parent_sample_weight: np.ndarray,
) -> tuple[np.ndarray, ...]:
    xy = np.asarray(candidate_xy_m, dtype=np.float32)
    valid = np.asarray(candidate_valid, dtype=bool)
    if xy.ndim != 3 or xy.shape[-1] != 2 or valid.shape != xy.shape[:2]:
        raise ValueError("physical candidate geometry must be [T,K,2]")
    arrays = [
        np.asarray(value, dtype=np.float32)
        for value in (
            teacher_probability,
            raw_score,
            ra_mti_agreement,
            background_risk,
            temporal_persistence,
            se2_parent_allowed_weight,
        )
    ]
    if any(value.shape != valid.shape for value in arrays):
        raise ValueError("candidate evidence arrays must match [T,K]")
    parent_sample = np.asarray(se2_parent_sample_weight, dtype=np.float32).reshape(-1)
    if parent_sample.shape != (len(xy),):
        raise ValueError("SE2-parent sample weight must be [T]")
    valid &= np.isfinite(xy).all(axis=-1)
    if not valid.any(axis=1).all():
        raise ValueError("every frame needs at least one observed physical candidate")
    if np.any(arrays[-1] < 0.0) or np.any(parent_sample < 0.0):
        raise ValueError("SE2-parent support must be non-negative")
    return (xy, valid, *arrays, parent_sample)


def _per_frame_zscore(value: np.ndarray, valid: np.ndarray) -> np.ndarray:
    masked = np.where(valid & np.isfinite(value), value, np.nan)
    mean = np.nanmean(masked, axis=1, keepdims=True)
    scale = np.nanstd(masked, axis=1, keepdims=True)
    return np.where(valid, (np.nan_to_num(value, nan=mean) - mean) / np.maximum(scale, 1.0e-3), 0.0)


def _top_two(value: np.ndarray, valid: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    masked = np.where(valid, value, -np.inf)
    order = np.argsort(-masked, axis=1, kind="stable")
    first = order[:, 0]
    first_value = masked[np.arange(len(masked)), first]
    second_value = masked[np.arange(len(masked)), order[:, 1]] if masked.shape[1] > 1 else np.zeros(len(masked))
    second_value = np.where(np.isfinite(second_value), second_value, 0.0)
    return first.astype(np.int64), first_value.astype(np.float32), (first_value - second_value).astype(np.float32)


def _anchor_indices(
    teacher: np.ndarray,
    valid: np.ndarray,
    parent: np.ndarray,
    parent_sample: np.ndarray,
    config: R31Config,
) -> tuple[np.ndarray, np.ndarray]:
    teacher_index, teacher_top, teacher_margin = _top_two(teacher, valid)
    parent_mask = np.where(valid, parent, 0.0)
    parent_index = parent_mask.argmax(axis=1)
    parent_mass = parent_mask[np.arange(len(parent_mask)), parent_index]
    parent_order = np.sort(parent_mask, axis=1)
    parent_second = parent_order[:, -2] if parent_mask.shape[1] > 1 else np.zeros(len(parent_mask), dtype=np.float32)
    parent_margin = parent_mass - parent_second
    parent_ok = (parent_sample > 0.0) & (parent_mass > 0.0) & (parent_margin >= config.parent_anchor_margin)
    teacher_ok = (teacher_top >= config.teacher_anchor_probability) & (teacher_margin >= config.teacher_anchor_margin)
    conflict = parent_ok & teacher_ok & (parent_index != teacher_index)
    index = np.where(parent_ok, parent_index, np.where(teacher_ok, teacher_index, -1))
    index = np.where(conflict, -1, index).astype(np.int64)
    weight = np.where(
        index >= 0,
        np.clip(parent_sample * parent_mass + teacher_top * teacher_ok.astype(np.float32), 0.0, 1.0),
        0.0,
    ).astype(np.float32)
    return index, weight


def _continuity_mask(selected: np.ndarray, xy: np.ndarray, maximum_step_m: float) -> np.ndarray:
    frames = len(selected)
    output = np.zeros(frames, dtype=bool)
    for frame, index in enumerate(selected):
        if index < 0:
            continue
        neighbours: list[bool] = []
        if frame > 0 and selected[frame - 1] >= 0:
            neighbours.append(float(np.linalg.norm(xy[frame, index] - xy[frame - 1, selected[frame - 1]])) <= maximum_step_m + 1e-8)
        if frame + 1 < frames and selected[frame + 1] >= 0:
            neighbours.append(float(np.linalg.norm(xy[frame, index] - xy[frame + 1, selected[frame + 1]])) <= maximum_step_m + 1e-8)
        output[frame] = bool(neighbours) and all(neighbours)
    return output


def build_conditioned_candidate_labels(
    *,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    teacher_probability: np.ndarray,
    raw_score: np.ndarray,
    ra_mti_agreement: np.ndarray,
    background_risk: np.ndarray,
    temporal_persistence: np.ndarray,
    se2_parent_allowed_weight: np.ndarray,
    se2_parent_sample_weight: np.ndarray,
    config: R31Config,
) -> R31CandidateLabels:
    """Build Tier-A/B/C supervision over current-frame observed peaks only."""

    (
        xy,
        valid,
        teacher,
        raw,
        agreement,
        background,
        persistence,
        parent,
        parent_sample,
    ) = _validated_arrays(
        candidate_xy_m,
        candidate_valid,
        teacher_probability,
        raw_score,
        ra_mti_agreement,
        background_risk,
        temporal_persistence,
        se2_parent_allowed_weight,
        se2_parent_sample_weight,
    )
    teacher = np.where(valid, np.clip(teacher, 1.0e-5, 1.0 - 1.0e-5), 0.0)
    teacher_logit = np.where(valid, np.log(teacher / np.maximum(1.0 - teacher, 1.0e-5)), 0.0)
    score = (
        config.teacher_probability_weight * teacher_logit
        + config.raw_score_weight * _per_frame_zscore(raw, valid)
        + config.agreement_weight * (2.0 * np.clip(agreement, 0.0, 1.0) - 1.0)
        + config.persistence_weight * (2.0 * np.clip(persistence, 0.0, 1.0) - 1.0)
    ).astype(np.float32)
    anchor_index, anchor_weight = _anchor_indices(teacher, valid, parent, parent_sample, config)
    posterior = build_episode_posterior(
        xy,
        score,
        valid,
        anchor_index,
        anchor_weight,
        np.clip(background, 0.0, 1.0),
        config=EpisodePosteriorConfig(
            candidate_score_weight=1.0,
            background_cost_weight=config.background_cost_weight,
            anchor_preference_weight=config.parent_anchor_weight,
            identity_logit=config.identity_logit,
            identity_transition_cost=config.identity_transition_cost,
            motion_cost_weight=config.motion_cost_weight,
            max_step_m=config.max_step_m,
            temperature=config.temperature,
        ),
    )
    candidate_probability = np.asarray(posterior["candidate_posterior"], dtype=np.float32)
    selected, top, margin = _top_two(candidate_probability, valid)
    candidate_mass = candidate_probability.sum(axis=1)
    map_index = np.asarray(posterior["map_index"], dtype=np.int64)
    selected = np.where(map_index >= 0, map_index, -1).astype(np.int64)
    continuous = _continuity_mask(selected, xy, config.max_step_m)
    fb = np.asarray(posterior["forward_backward_agreement"], dtype=np.float32)
    tier_a = (
        (selected >= 0)
        & (top >= config.tier_a_probability)
        & (margin >= config.tier_a_margin)
        & (fb >= config.tier_a_agreement)
        & continuous
    )
    tier_b = (~tier_a) & (candidate_mass >= config.tier_b_candidate_mass) & (fb >= config.tier_b_agreement)

    allowed = np.zeros_like(candidate_probability, dtype=np.float32)
    for frame in range(len(xy)):
        if tier_a[frame]:
            allowed[frame, selected[frame]] = 1.0
            continue
        if not tier_b[frame]:
            continue
        frame_valid = np.flatnonzero(valid[frame])
        order = frame_valid[np.argsort(-candidate_probability[frame, frame_valid], kind="stable")]
        keep = order[
            candidate_probability[frame, order]
            >= float(candidate_probability[frame, order[0]]) * config.tier_b_relative_probability
        ][: config.tier_b_max_candidates]
        if len(keep) < 2 and len(order) >= 2:
            keep = order[:2]
        if len(keep) < 2:
            tier_b[frame] = False
            continue
        value = candidate_probability[frame, keep] * (1.0 + np.maximum(parent[frame, keep], 0.0))
        allowed[frame, keep] = value / np.maximum(value.sum(), 1.0e-8)

    tier = np.full(len(xy), "tier_c", dtype="<U6")
    tier[tier_b] = "tier_b"
    tier[tier_a] = "tier_a"
    sample_weight = np.zeros(len(xy), dtype=np.float32)
    sample_weight[tier_a] = np.clip(top[tier_a] * fb[tier_a], 0.05, 1.0)
    sample_weight[tier_b] = np.clip(0.75 * candidate_mass[tier_b] * fb[tier_b], 0.05, 1.0)
    selected_xy = np.full((len(xy), 2), np.nan, dtype=np.float32)
    selected_frames = np.flatnonzero(selected >= 0)
    selected_xy[selected_frames] = xy[selected_frames, selected[selected_frames]]
    return R31CandidateLabels(
        candidate_xy_m=xy.copy(),
        candidate_valid=valid.copy(),
        candidate_posterior=candidate_probability,
        allowed_weight=allowed,
        sample_weight=sample_weight,
        selected_index=selected,
        selected_xy_m=selected_xy,
        tier=tier,
        identity_mass=np.asarray(posterior["identity_mass"], dtype=np.float32),
        forward_backward_agreement=fb,
        posterior_margin=margin.astype(np.float32),
        anchor_index=anchor_index,
    )
