"""Explicit V4 foundation-model registry.

Checkpoints record the selected architecture.  This avoids accidentally
evaluating a CORA state dict with the historical DREAM/Mamba model, or vice
versa.
"""

from __future__ import annotations

from torch import nn


def build_foundation_model(architecture: str) -> nn.Module:
    normalized = architecture.strip().lower()
    if normalized == "cora_bev":
        from .cora_bev import CORABEVFoundation

        return CORABEVFoundation()
    if normalized == "dream_bev":
        from .dream_bev import DREAMBEVFoundation

        return DREAMBEVFoundation()
    raise ValueError(f"Unknown V4 foundation architecture: {architecture!r}")
