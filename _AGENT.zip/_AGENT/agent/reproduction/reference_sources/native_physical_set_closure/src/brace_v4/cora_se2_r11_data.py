"""Immutable R11 set-valued data contract for CORA-SE2."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset

from .self_evolution_data import RadarSequenceFrames, load_episode_records


R11_MANIFEST_SCHEMA = "brace_v4_r11_physical_candidate_label_manifest_v1"
R11_PAYLOAD_SCHEMA = "brace_v4_r11_physical_candidate_labels_v1"
R11_STAGE_A_CALIBRATION = (
    "seq_037",
    "seq_050",
    "seq_122",
    "seq_154",
)
_ROUTE_ORDER = (
    "indoor_clutter",
    "open_indoor_los",
    "outdoor_dry_complex",
    "outdoor_wet_return",
)


def _scalar_text(payload: dict[str, np.ndarray], key: str) -> str:
    return str(np.asarray(payload[key]).item()).strip().lower()


def _scalar_bool(payload: dict[str, np.ndarray], key: str) -> bool:
    return bool(np.asarray(payload[key]).item())


def load_r11_set_manifest(cache_dir: str | Path) -> dict[str, Any]:
    """Load R11 only when its immutable no-target-label lineage is intact."""

    path = Path(cache_dir) / "R11_MANIFEST.json"
    if not path.is_file():
        raise FileNotFoundError(f"R11 manifest missing: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != R11_MANIFEST_SCHEMA:
        raise ValueError("unsupported R11 manifest schema")
    forbidden = payload.get("construction_forbidden_reads")
    if not isinstance(forbidden, dict):
        raise ValueError("R11 manifest has no forbidden-read contract")
    labels = {
        "target_final_bev_read": "target Final-BEV",
        "development_read": "Development",
        "locked_test_read": "Locked Test",
        "right_rgb_read": "right RGB",
        "manual_ra_anchor_at_label_stage": "manual RA anchor",
    }
    for key, label in labels.items():
        if bool(forbidden.get(key, True)):
            raise ValueError(f"R11 manifest may not read {label}")
    rows = payload.get("sequences")
    if not isinstance(rows, list) or not rows:
        raise ValueError("R11 manifest has no sequence rows")
    return payload


def r11_stage_a_split(manifest: dict[str, Any]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return the pre-registered route-balanced R11 fit/calibration split."""

    rows = manifest.get("sequences")
    if not isinstance(rows, list):
        raise ValueError("R11 manifest has no sequence rows")
    by_route: dict[str, list[str]] = {route: [] for route in _ROUTE_ORDER}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("R11 manifest has an invalid sequence row")
        route = str(row.get("route", "")).strip().lower()
        sequence = str(row.get("sequence", "")).strip().lower()
        if route not in by_route or not sequence:
            raise ValueError("R11 manifest route is outside SE2 scope")
        by_route[route].append(sequence)
    selected = tuple(max(values) for route, values in by_route.items() if values)
    if selected != R11_STAGE_A_CALIBRATION:
        raise ValueError(f"R11 route-balanced calibration differs from frozen split: {selected}")
    all_sequences = tuple(sorted(sequence for values in by_route.values() for sequence in values))
    if len(all_sequences) != 23 or len(set(all_sequences)) != 23:
        raise ValueError("R11 SE2 requires exactly 23 unique target-fit sequences")
    if set(selected) & {"seq_005", "seq_011", "seq_020", "seq_032", "seq_052", "seq_118", "seq_132", "seq_153"}:
        raise ValueError("R11 calibration may not contain Locked Test")
    fit = tuple(sequence for sequence in all_sequences if sequence not in set(selected))
    return fit, selected


def r11_route_stage_a_split(manifest: dict[str, Any], route: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Split one R11 route into immutable fit and calibration sequences.

    The route-local calibration sequence is the final lexicographic sequence in
    the already frozen R11 manifest.  This keeps selection entirely inside
    Agent-Train and avoids choosing a split after inspecting Development.
    """

    normalized_route = str(route).strip().lower()
    if normalized_route not in _ROUTE_ORDER:
        raise ValueError(f"unknown R11 route: {route}")
    rows = manifest.get("sequences")
    if not isinstance(rows, list):
        raise ValueError("R11 manifest has no sequence rows")
    sequences = tuple(sorted(
        str(row.get("sequence", "")).strip().lower()
        for row in rows
        if isinstance(row, dict) and str(row.get("route", "")).strip().lower() == normalized_route
    ))
    if len(sequences) < 3 or any(not sequence for sequence in sequences):
        raise ValueError(f"R11 route needs at least three Train sequences: {normalized_route}")
    calibration = (sequences[-1],)
    if calibration[0] in {"seq_005", "seq_011", "seq_020", "seq_032", "seq_052", "seq_118", "seq_132", "seq_153"}:
        raise ValueError("R11 route calibration may not contain Locked Test")
    return sequences[:-1], calibration


class R11SetMassRadarDataset(Dataset[dict[str, Tensor | str]]):
    """Causal RA/RA-MTI clips paired with R11 candidate sets, not coordinates."""

    _REQUIRED = {
        "schema_version",
        "sequence",
        "route",
        "frame_id",
        "candidate_xy_m",
        "candidate_valid",
        "candidate_weight",
        "sample_weight",
        "target_final_bev_read",
        "development_read",
        "locked_test_read",
        "right_rgb_read",
        "manual_ra_anchor_at_label_stage",
    }

    def __init__(
        self,
        data_root: str | Path,
        split_config: str | Path,
        r11_cache: str | Path,
        sequences: Iterable[str],
        *,
        clip_length: int = 16,
        preload_radar: bool = False,
    ) -> None:
        if clip_length < 1:
            raise ValueError("clip_length must be positive")
        self.cache_dir = Path(r11_cache)
        self.manifest = load_r11_set_manifest(self.cache_dir)
        available = {
            str(row["sequence"]).strip().lower(): str(row["route"]).strip().lower()
            for row in self.manifest["sequences"]
            if isinstance(row, dict)
        }
        requested = tuple(sorted({str(sequence).strip().lower() for sequence in sequences}))
        if not requested:
            raise ValueError("R11 dataset requires declared sequences")
        if set(requested) - available.keys():
            raise ValueError("R11 dataset requested sequence outside immutable manifest")
        dataset_root = Path(data_root)
        if not (dataset_root / "Data_train").is_dir():
            dataset_root = dataset_root.parent
        if not (dataset_root / "Data_train").is_dir():
            raise FileNotFoundError("data_root must be the dataset root or Data_train child")
        records = {str(record["sequence"]).strip().lower(): record for record in load_episode_records(split_config, "train")}
        if set(requested) - records.keys():
            raise ValueError("R11 dataset requested sequence outside Agent Train")
        self.clip_length = int(clip_length)
        self._archives: list[dict[str, np.ndarray]] = []
        self._sources: list[RadarSequenceFrames] = []
        self._raw_cache: list[Tensor | None] = []
        self._samples: list[tuple[int, int]] = []
        for sequence in requested:
            source = RadarSequenceFrames.create(dataset_root, records[sequence])
            path = self.cache_dir / f"{sequence}.npz"
            if not path.is_file():
                raise FileNotFoundError(f"R11 archive missing: {path}")
            with np.load(path, allow_pickle=False) as archive:
                cached = {key: archive[key].copy() for key in archive.files}
            missing = self._REQUIRED - cached.keys()
            if missing:
                raise ValueError(f"R11 archive missing fields for {sequence}: {sorted(missing)}")
            if _scalar_text(cached, "schema_version") != R11_PAYLOAD_SCHEMA:
                raise ValueError("unsupported R11 payload schema")
            if _scalar_text(cached, "sequence") != sequence or _scalar_text(cached, "route") != available[sequence]:
                raise ValueError("R11 payload identity mismatch")
            if any(_scalar_bool(cached, key) for key in self._REQUIRED.intersection({
                "target_final_bev_read", "development_read", "locked_test_read", "right_rgb_read", "manual_ra_anchor_at_label_stage"
            })):
                raise ValueError("R11 payload contains forbidden provenance")
            frame_ids = np.asarray(cached["frame_id"], dtype=np.int64)
            if tuple(frame_ids.tolist()) != source.frame_ids:
                raise ValueError("R11/radar frame timeline mismatch")
            candidate_xy = np.asarray(cached["candidate_xy_m"], dtype=np.float32)
            candidate_valid = np.asarray(cached["candidate_valid"], dtype=bool)
            candidate_weight = np.asarray(cached["candidate_weight"], dtype=np.float32)
            sample_weight = np.asarray(cached["sample_weight"], dtype=np.float32)
            if candidate_xy.ndim != 3 or candidate_xy.shape[-1] != 2:
                raise ValueError("R11 candidate_xy_m must be [T,K,2]")
            if candidate_valid.shape != candidate_xy.shape[:2] or candidate_weight.shape != candidate_valid.shape:
                raise ValueError("R11 candidate arrays have incompatible shapes")
            if sample_weight.shape != (frame_ids.size,):
                raise ValueError("R11 sample_weight must be [T]")
            index = len(self._archives)
            self._archives.append(cached)
            self._sources.append(source)
            self._raw_cache.append(
                torch.stack([source.read_normalized(frame_id) for frame_id in source.frame_ids], dim=0) if preload_radar else None
            )
            self._samples.extend((index, position) for position in range(frame_ids.size))

    def __len__(self) -> int:
        return len(self._samples)

    def _history(self, sequence_index: int, position: int) -> Tensor:
        positions = torch.tensor([max(0, position - self.clip_length + 1 + offset) for offset in range(self.clip_length)], dtype=torch.long)
        cached = self._raw_cache[sequence_index]
        if cached is not None:
            return cached.index_select(0, positions)
        source = self._sources[sequence_index]
        return source.causal_clip(int(source.frame_ids[position]), self.clip_length)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        sequence_index, position = self._samples[index]
        archive = self._archives[sequence_index]
        source = self._sources[sequence_index]
        return {
            "radar": self._history(sequence_index, position),
            "candidate_xy_m": torch.from_numpy(archive["candidate_xy_m"][position].astype(np.float32, copy=True)),
            "candidate_valid": torch.from_numpy(archive["candidate_valid"][position].astype(bool, copy=True)),
            "candidate_weight": torch.from_numpy(archive["candidate_weight"][position].astype(np.float32, copy=True)),
            "sample_weight": torch.tensor(float(np.clip(archive["sample_weight"][position], 0.0, 1.0)), dtype=torch.float32),
            "frame_id": torch.tensor(int(archive["frame_id"][position]), dtype=torch.long),
            "sequence": source.sequence,
            "route": source.route,
        }
