"""Training provenance contracts for the routed CORA-SE2 adapter."""

from __future__ import annotations

from typing import Any

from .cora_se2_r11_data import R11_STAGE_A_CALIBRATION


SE2_PROTOCOL_SCHEMA = "brace_v4_cora_se2_r11_setmass_protocol_v1"
SE2_CHECKPOINT_SCHEMA = "brace_v4_cora_se2_r11_setmass_checkpoint_v1"
SE2_ARCHITECTURE = "CORA-SE2-FrozenCORA0-SetMassResidualAdapter-V1"


def make_se2_protocol() -> dict[str, Any]:
    """Return the immutable no-target-label SE2 protocol skeleton."""

    return {
        "schema_version": SE2_PROTOCOL_SCHEMA,
        "architecture": SE2_ARCHITECTURE,
        "clip_length": 16,
        "stage_a_calibration_sequences": list(R11_STAGE_A_CALIBRATION),
        "stage_a_selection": "minimum_r11_set_mass_then_minimum_source_replay_loss",
        "stage_b_retrain_all_r11": True,
        "cora0_frozen": True,
        "se1_frozen": True,
        "zero_identity_initialization": True,
        "target_final_bev_read_train": False,
        "development_read_during_training": False,
        "locked_test_read": False,
        "depth_read": False,
        "right_rgb_read": False,
        "manual_ra_anchor_at_label_stage": False,
        "model_future_frame_input": False,
    }


def require_se2_protocol(payload: dict[str, Any]) -> None:
    """Reject any SE2 protocol that violates the frozen supervision boundary."""

    if payload.get("schema_version") != SE2_PROTOCOL_SCHEMA or payload.get("architecture") != SE2_ARCHITECTURE:
        raise ValueError("unsupported CORA-SE2 protocol")
    if int(payload.get("clip_length", 0)) != 16 or bool(payload.get("model_future_frame_input", True)):
        raise ValueError("CORA-SE2 requires a causal 16-frame model input")
    if tuple(payload.get("stage_a_calibration_sequences", ())) != R11_STAGE_A_CALIBRATION:
        raise ValueError("CORA-SE2 stage-A R11 calibration split mismatch")
    if not bool(payload.get("stage_b_retrain_all_r11", False)):
        raise ValueError("CORA-SE2 must retrain Stage B on all R11 sequences")
    if not bool(payload.get("cora0_frozen", False)):
        raise ValueError("CORA0 must remain frozen")
    if not bool(payload.get("se1_frozen", False)):
        raise ValueError("SE1 must remain frozen")
    if not bool(payload.get("zero_identity_initialization", False)):
        raise ValueError("CORA-SE2 requires zero-identity initialization")
    prohibited = {
        "target_final_bev_read_train": "target Final-BEV",
        "development_read_during_training": "Development",
        "locked_test_read": "Locked Test",
        "depth_read": "depth",
        "right_rgb_read": "right RGB",
        "manual_ra_anchor_at_label_stage": "manual RA anchor",
    }
    for key, label in prohibited.items():
        if bool(payload.get(key, True)):
            raise ValueError(f"CORA-SE2 may not read {label}")


def make_se2_checkpoint_contract(
    cora0_sha256: str,
    se1_sha256: str,
    r11_sha256: str,
    protocol_sha256: str,
) -> dict[str, Any]:
    """Return the checkpoint metadata shared by Stage A and Stage B."""

    if not all((cora0_sha256, se1_sha256, r11_sha256, protocol_sha256)):
        raise ValueError("SE2 checkpoint hashes must be non-empty")
    return make_se2_protocol() | {
        "schema_version": SE2_CHECKPOINT_SCHEMA,
        "cora0_checkpoint_sha256": str(cora0_sha256),
        "se1_checkpoint_sha256": str(se1_sha256),
        "r11_manifest_sha256": str(r11_sha256),
        "protocol_sha256": str(protocol_sha256),
        "adapter_only_trainable": True,
    }


def require_se2_checkpoint_contract(payload: dict[str, Any]) -> None:
    """Validate a saved adapter checkpoint before inference or auditing."""

    if payload.get("schema_version") != SE2_CHECKPOINT_SCHEMA:
        raise ValueError("unsupported CORA-SE2 checkpoint schema")
    protocol = dict(payload)
    protocol["schema_version"] = SE2_PROTOCOL_SCHEMA
    require_se2_protocol(protocol)
    if not bool(payload.get("adapter_only_trainable", False)):
        raise ValueError("CORA-SE2 checkpoint must train the adapter only")
    for key in ("cora0_checkpoint_sha256", "se1_checkpoint_sha256", "r11_manifest_sha256", "protocol_sha256"):
        if not str(payload.get(key, "")).strip():
            raise ValueError(f"CORA-SE2 checkpoint missing {key}")
