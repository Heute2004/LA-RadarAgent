"""Immutable no-leakage contract for CORA-SE2 route specialists."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any


ROUTE_ORDER = (
    "clean",
    "cluttered",
    "cluttered_or_multipath_likely",
    "rain_or_wet_ground",
    "wet_ground",
)

_FORBIDDEN_KEYS = (
    "target_final_bev_training",
    "development_training",
    "locked_test",
    "depth",
    "right_rgb",
    "manual_ra_anchor",
)


def _sequences(values: object, *, field: str) -> tuple[str, ...]:
    if not isinstance(values, list) or not values:
        raise ValueError(f"{field} must be a nonempty list")
    normalized = tuple(str(value).strip().lower() for value in values)
    if any(not value.startswith("seq_") for value in normalized):
        raise ValueError(f"{field} must use canonical sequence names")
    if len(set(normalized)) != len(normalized):
        raise ValueError(f"{field} contains duplicates")
    return normalized


def require_route_specialist_protocol(payload: Mapping[str, object]) -> None:
    if payload.get("schema_version") != "brace_v4_cora_se2_route_specialists_protocol_v1":
        raise ValueError("unexpected route-specialist protocol schema")
    if tuple(payload.get("route_order", ())) != ROUTE_ORDER:
        raise ValueError("route_order must contain the five frozen non-RIS routes")

    forbidden = payload.get("forbidden_reads")
    if not isinstance(forbidden, Mapping):
        raise ValueError("forbidden_reads is required")
    for key in _FORBIDDEN_KEYS:
        if forbidden.get(key) is not True:
            raise ValueError(f"forbidden read must remain true: {key}")

    development = set(_sequences(payload.get("development_sequences"), field="development_sequences"))
    locked_test = set(_sequences(payload.get("locked_test_sequences"), field="locked_test_sequences"))
    target_fit = set(_sequences(payload.get("r11_target_fit_sequences"), field="r11_target_fit_sequences"))
    if development & locked_test:
        raise ValueError("Development and Locked Test overlap")

    branches = payload.get("frozen_branches")
    if not isinstance(branches, list) or set(branches) != {"cora0", "cora_se1", "cora_se2"}:
        raise ValueError("all and only frozen CORA branches are required")

    pools = payload.get("training_pools")
    if not isinstance(pools, Mapping) or set(pools) != {"source_clean", "indoor_clutter", "dry_complex", "outdoor_wet"}:
        raise ValueError("expected four fixed specialist training pools")
    for name, record in pools.items():
        if not isinstance(record, Mapping):
            raise ValueError(f"training pool is not a mapping: {name}")
        fit = set(_sequences(record.get("fit_sequences"), field=f"{name}.fit_sequences"))
        calibration = set(_sequences(record.get("calibration_sequences"), field=f"{name}.calibration_sequences"))
        if fit & calibration:
            raise ValueError(f"fit/calibration overlap in {name}")
        if (fit | calibration) & development:
            raise ValueError(f"Development sequence appears in {name} fit/calibration")
        if (fit | calibration) & locked_test:
            raise ValueError(f"Locked Test sequence appears in {name} fit/calibration")
        if name == "source_clean":
            if record.get("kind") != "source_supervised_tail_refinement" or record.get("candidate_supervision") is not False:
                raise ValueError("source_clean must remain source-supervised tail refinement")
        else:
            if record.get("kind") != "r11_set_mass" or record.get("candidate_supervision") is not True:
                raise ValueError(f"{name} must use R11 set-mass supervision")
            if not (fit | calibration) <= target_fit:
                raise ValueError(f"{name} contains a sequence outside frozen R11 target-fit")

    routes = payload.get("routes")
    if not isinstance(routes, Mapping) or tuple(routes) != ROUTE_ORDER:
        raise ValueError("routes must match route_order exactly")
    for route, record in routes.items():
        if not isinstance(record, Mapping):
            raise ValueError(f"route is not a mapping: {route}")
        if record.get("training_pool") not in pools:
            raise ValueError(f"unknown training pool for {route}")
        if record.get("base_branch") not in branches:
            raise ValueError(f"route {route} does not select a frozen branch")
        if record.get("fallback") != "exact_identity":
            raise ValueError(f"route {route} must use exact identity fallback")
        if float(record.get("minimum_ap_0p3_delta", -1.0)) < 0.0:
            raise ValueError(f"route {route} has invalid AP threshold")
    if routes["clean"].get("training_pool") != "source_clean":
        raise ValueError("clean must remain a source-only tail refiner")
    if routes["rain_or_wet_ground"].get("training_pool") != "outdoor_wet" or routes["wet_ground"].get("training_pool") != "outdoor_wet":
        raise ValueError("rain and wet-ground must share the outdoor_wet train-only pool")

    ris = payload.get("ris_policy")
    if not isinstance(ris, Mapping) or ris.get("modified") is not False:
        raise ValueError("RIS must remain untouched by generic route specialists")


def load_route_specialist_protocol(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("route-specialist protocol must be a JSON object")
    require_route_specialist_protocol(payload)
    return payload
