"""Raw RA/RA-MTI candidate features shared by weak and full ranker training."""

from __future__ import annotations

import numpy as np


RAW_TOKEN_DIM = 10
RAW_CANDIDATE_PATCH_SIZE = 9


def default_foundation_runtime(frame_count: int) -> dict[str, np.ndarray]:
    """Safe non-label defaults when constructing a source-pretraining cache.

    A candidate ranker does not need a synthetic CORA coordinate or visual
    target to learn generic raw-peak semantics on the labelled source domain.
    The explicit zero fields keep those unavailable modalities distinguishable
    from a real accepted observation.
    """
    if frame_count < 1:
        raise ValueError("frame_count must be positive")
    return {
        "cora_identity_xy_m": np.zeros((frame_count, 2), dtype=np.float32),
        "cora_identity_observed": np.zeros(frame_count, dtype=bool),
        "base_presence_probability": np.ones(frame_count, dtype=np.float32),
        "base_observation_reliability": np.ones(frame_count, dtype=np.float32),
        "background_change_probability": np.zeros(frame_count, dtype=np.float32),
        "visual_polar_mode": np.zeros(frame_count, dtype=np.float32),
        "visual_theta_rad": np.zeros(frame_count, dtype=np.float32),
        "visual_reliability": np.zeros(frame_count, dtype=np.float32),
        "visual_presence_accepted": np.zeros(frame_count, dtype=np.float32),
    }


def _candidate_patch(values: np.ndarray, row: int, column: int, *, size: int = RAW_CANDIDATE_PATCH_SIZE) -> np.ndarray:
    """Return a fixed local RA/RA-MTI crop centred on an observed peak."""
    half = size // 2
    padded = np.pad(values, ((0, 0), (half, half), (half, half)), mode="constant")
    row += half; column += half
    return padded[:, row - half : row + half + 1, column - half : column + half + 1].astype(np.float32, copy=False)


def _extract_peaks(response: np.ndarray, *, maximum_candidates: int, radius: int, minimum_score: float) -> tuple[np.ndarray, np.ndarray]:
    valid = np.flatnonzero(np.isfinite(response) & (response > float(minimum_score)))
    if not valid.size:
        return np.empty((0, 2), dtype=np.int16), np.empty(0, dtype=np.float32)
    order = valid[np.argsort(response.reshape(-1)[valid])[::-1]]
    selected: list[tuple[int, int]] = []
    for flat in order:
        row, column = divmod(int(flat), response.shape[1])
        if any(max(abs(row - old_row), abs(column - old_column)) <= radius for old_row, old_column in selected):
            continue
        selected.append((row, column))
        if len(selected) == maximum_candidates:
            break
    indices = np.asarray(selected, dtype=np.int16)
    return indices, response[indices[:, 0], indices[:, 1]].astype(np.float32, copy=False)


def _polar_to_metric(indices: np.ndarray) -> np.ndarray:
    # Frozen IWR6843 processing geometry: 128 azimuth bins and 0.183 m range bin.
    radius = indices[:, 0].astype(np.float32) * (23.4 / 128.0)
    sine = np.clip(indices[:, 1].astype(np.float32) / 64.0 - 1.0, -1.0, 1.0)
    return np.stack((radius * sine, radius * np.sqrt(np.maximum(1.0 - sine * sine, 0.0))), axis=1).astype(np.float32)


def _sample(values: np.ndarray, row: int, column: int) -> tuple[float, float]:
    if row < 0 or column < 0:
        return 0.0, 0.0
    height, width = values.shape[-2:]
    row = min(row, height - 1); column = min(column, width - 1)
    patch = values[:, max(0, row - 1) : min(height, row + 2), max(0, column - 1) : min(width, column + 2)]
    return float(values[0, row, column]), float(values[1, row, column]), float(patch[0].mean()), float(patch[1].mean())


def build_raw_ra_mti_candidates(
    standardized_ra_mti: np.ndarray,
    *,
    top_k: int = 16,
    nms_radius_bins: int = 2,
    minimum_score: float = 0.0,
) -> dict[str, np.ndarray]:
    """Extract fixed raw RA-MTI candidates and compact local radar tokens.

    ``standardized_ra_mti`` is [2,128,128] after matching empty-site
    background normalization.  Every valid coordinate is a current observed
    RA-MTI bin; invalid slots are not coordinates and must remain masked.
    """
    response = np.asarray(standardized_ra_mti, dtype=np.float32)
    if response.shape != (2, 128, 128):
        raise ValueError("standardized_ra_mti must be [2,128,128]")
    indices, scores = _extract_peaks(response[1], maximum_candidates=top_k, radius=nms_radius_bins, minimum_score=minimum_score)
    fixed_indices = np.full((top_k, 2), -1, dtype=np.int16)
    fixed_scores = np.full(top_k, -np.inf, dtype=np.float32)
    count = min(len(scores), top_k)
    fixed_indices[:count] = indices[:count]
    fixed_scores[:count] = scores[:count]
    provenance = np.zeros(top_k, dtype=np.uint8); provenance[:count] = 2
    valid = np.isfinite(fixed_scores) & (fixed_indices[:, 0] >= 0) & (fixed_indices[:, 1] >= 0)
    xy = np.full((top_k, 2), np.nan, dtype=np.float32)
    if valid.any():
        xy[valid] = _polar_to_metric(fixed_indices[valid])
    token = np.zeros((top_k, RAW_TOKEN_DIM), dtype=np.float32)
    patch = np.zeros((top_k, 2, RAW_CANDIDATE_PATCH_SIZE, RAW_CANDIDATE_PATCH_SIZE), dtype=np.float32)
    agreement = np.zeros(top_k, dtype=np.float32)
    background_risk = np.ones(top_k, dtype=np.float32)
    for candidate in np.flatnonzero(valid):
        row, column = (int(value) for value in fixed_indices[candidate])
        ra_value, mti_value, ra_local, mti_local = _sample(response, row, column)
        difference = abs(ra_value - mti_value)
        agreement[candidate] = float(np.exp(-0.5 * difference * difference))
        background_risk[candidate] = float(1.0 / (1.0 + np.exp(-(ra_value - mti_value))))
        token[candidate] = np.asarray((
            row / 127.0, column / 127.0 * 2.0 - 1.0, ra_value, mti_value,
            ra_local, mti_local, float(fixed_scores[candidate]), agreement[candidate],
            background_risk[candidate], float(provenance[candidate] == 2),
        ), dtype=np.float32)
        patch[candidate] = _candidate_patch(response, row, column)
    return {
        # Retained unchanged for the causal full-polar encoder.  It contains
        # only current and past raw radar evidence after commissioned-site
        # normalization, never a label-derived heatmap.
        "standardized_ra_mti": response.copy(),
        "candidate_native_indices": fixed_indices,
        "candidate_xy_m": xy,
        "radar_score": fixed_scores.astype(np.float32),
        "candidate_valid": valid.astype(bool),
        "tokens": token,
        "candidate_patch": patch,
        "candidate_ra_mti_agreement": agreement,
        "candidate_background_risk": background_risk,
    }
