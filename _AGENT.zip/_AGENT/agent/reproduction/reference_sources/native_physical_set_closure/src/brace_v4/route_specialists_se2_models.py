"""Zero-identity bounded residual route-expert primitives."""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as functional

from .dream_bev import BEVGeometry


def _zero_linear(layer: nn.Linear) -> None:
    nn.init.zeros_(layer.weight)
    nn.init.zeros_(layer.bias)


def _bounded_vector(raw_offset: Tensor, *, max_norm: float) -> Tensor:
    """Project an unconstrained 2-D prediction into a strict metric-radius ball."""

    radius = torch.linalg.vector_norm(raw_offset, dim=-1, keepdim=True)
    direction = raw_offset / radius.clamp_min(1.0e-8)
    return direction * (float(max_norm) * torch.tanh(radius))


class CLORSE2Expert(nn.Module):
    """Causal local offset refiner for an already strong frozen branch.

    The expert intentionally has no global heatmap or candidate-replacement
    head.  It can only move the supplied base coordinate within a fixed local
    radius and report its uncertainty/acceptance for the route dispatcher.
    """

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64, max_offset_m: float = 0.45) -> None:
        super().__init__()
        if max_offset_m <= 0.0:
            raise ValueError("max_offset_m must be positive")
        self.max_offset_m = float(max_offset_m)
        self.encoder = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.temporal = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.offset_head = nn.Linear(hidden_dim, 2)
        self.acceptance_head = nn.Linear(hidden_dim, 1)
        self.covariance_head = nn.Linear(hidden_dim, 2)
        _zero_linear(self.offset_head)
        _zero_linear(self.acceptance_head)
        _zero_linear(self.covariance_head)

    def forward(self, base_xy_m: Tensor, feature: Tensor) -> dict[str, Tensor]:
        if base_xy_m.ndim != 3 or base_xy_m.shape[-1] != 2:
            raise ValueError("base_xy_m must be [batch,time,2]")
        if feature.ndim != 3 or feature.shape[:2] != base_xy_m.shape[:2]:
            raise ValueError("feature must align with base_xy_m as [batch,time,feature]")
        if feature.shape[-1] != self.encoder[0].in_features:
            raise ValueError("feature dimension mismatch")
        encoded = self.encoder(feature)
        temporal, _ = self.temporal(encoded)
        offset_m = _bounded_vector(self.offset_head(temporal), max_norm=self.max_offset_m)
        acceptance = torch.sigmoid(self.acceptance_head(temporal).squeeze(-1))
        covariance = functional.softplus(self.covariance_head(temporal)) + 1.0e-3
        return {
            "offset_m": offset_m,
            "proposal_xy": base_xy_m + offset_m,
            "acceptance": acceptance,
            "covariance": covariance,
        }


class TECSSE2Expert(nn.Module):
    """Causal observed-candidate disambiguator for extended radar echoes.

    Attention is only over candidate tokens in the *current* frame.  The GRU
    receives pooled current-frame candidate evidence, so it cannot read future
    frames.  Invalid candidate slots are masked to negative infinity before
    the caller can form a posterior.
    """

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64) -> None:
        super().__init__()
        if hidden_dim <= 0:
            raise ValueError("hidden_dim must be positive")
        attention_heads = 4 if hidden_dim % 4 == 0 else 1
        self.encoder = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.set_attention = nn.MultiheadAttention(hidden_dim, attention_heads, batch_first=True)
        self.temporal = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.residual_head = nn.Linear(hidden_dim, 1)
        self.acceptance_head = nn.Linear(hidden_dim, 1)
        self.covariance_head = nn.Linear(hidden_dim, 2)
        _zero_linear(self.residual_head)
        _zero_linear(self.acceptance_head)
        _zero_linear(self.covariance_head)

    def forward(self, candidate_features: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        if candidate_features.ndim != 4:
            raise ValueError("candidate_features must be [batch,time,candidates,feature]")
        batch, steps, candidates, dimensions = candidate_features.shape
        if dimensions != self.encoder[0].in_features:
            raise ValueError("candidate feature dimension mismatch")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [batch,time,candidates]")
        if not bool(candidate_valid.any(dim=-1).all()):
            raise ValueError("each frame requires one observed candidate")

        encoded = self.encoder(candidate_features)
        flattened = encoded.reshape(batch * steps, candidates, -1)
        padding_mask = ~candidate_valid.reshape(batch * steps, candidates)
        attended, _ = self.set_attention(flattened, flattened, flattened, key_padding_mask=padding_mask, need_weights=False)
        attended = attended.reshape(batch, steps, candidates, -1)
        weighted = attended * candidate_valid[..., None]
        pooled = weighted.sum(dim=2) / candidate_valid.sum(dim=2, keepdim=True).clamp_min(1)
        state, _ = self.temporal(pooled)
        combined = attended + state[:, :, None, :]
        candidate_logits = self.residual_head(combined).squeeze(-1)
        candidate_logits = candidate_logits.masked_fill(~candidate_valid, -torch.inf)
        acceptance = torch.sigmoid(self.acceptance_head(state).squeeze(-1))
        covariance = functional.softplus(self.covariance_head(state)) + 1.0e-3
        return {
            "candidate_logits": candidate_logits,
            "acceptance": acceptance,
            "covariance": covariance,
        }


class CandidateResidualRouteExpert(nn.Module):
    """Candidate-only residual head with a hard exact-identity initial state."""

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64, geometry: BEVGeometry | None = None) -> None:
        super().__init__()
        self.geometry = geometry or BEVGeometry()
        self.encoder = nn.Sequential(nn.Linear(feature_dim, hidden_dim), nn.SiLU(), nn.Linear(hidden_dim, hidden_dim), nn.SiLU())
        self.residual_head = nn.Linear(hidden_dim, 1)
        self.acceptance_head = nn.Linear(hidden_dim, 1)
        self.covariance_head = nn.Linear(hidden_dim, 2)
        _zero_linear(self.residual_head)
        _zero_linear(self.acceptance_head)
        _zero_linear(self.covariance_head)

    def _validate(self, base_logits: Tensor, candidate_xy_m: Tensor, candidate_features: Tensor, candidate_valid: Tensor) -> None:
        if base_logits.ndim != 4 or base_logits.shape[1:] != (1, self.geometry.x_bins, self.geometry.y_bins):
            raise ValueError("base_logits must be [batch,1,x_bins,y_bins]")
        batch, candidates, dimensions = candidate_xy_m.shape
        if dimensions != 2 or candidate_features.shape[:2] != (batch, candidates):
            raise ValueError("candidate tensors must align as [batch,candidates,...]")
        if candidate_valid.shape != (batch, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [batch,candidates]")
        if candidate_features.shape[2] != self.encoder[0].in_features:
            raise ValueError("candidate feature dimension mismatch")
        if not bool(candidate_valid.any(dim=1).all()):
            raise ValueError("each frame requires one observed candidate")

    def _sample_base(self, base_logits: Tensor, candidate_xy_m: Tensor) -> Tensor:
        indices = self.geometry.metric_to_index(candidate_xy_m)
        batch = torch.arange(base_logits.shape[0], device=base_logits.device)[:, None]
        return base_logits[:, 0][batch, indices[..., 0], indices[..., 1]]

    def _render_candidate_residual(self, candidate_xy_m: Tensor, candidate_residual: Tensor, candidate_valid: Tensor, *, dtype: torch.dtype) -> Tensor:
        batch, candidates = candidate_valid.shape
        indices = self.geometry.metric_to_index(candidate_xy_m)
        flat = torch.zeros((batch, self.geometry.x_bins * self.geometry.y_bins), dtype=dtype, device=candidate_xy_m.device)
        flat_index = indices[..., 0] * self.geometry.y_bins + indices[..., 1]
        values = torch.where(candidate_valid, candidate_residual.to(dtype), torch.zeros_like(candidate_residual, dtype=dtype))
        flat.scatter_add_(1, flat_index, values)
        return flat.reshape(batch, 1, self.geometry.x_bins, self.geometry.y_bins)

    def forward(self, base_logits: Tensor, candidate_xy_m: Tensor, candidate_features: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        self._validate(base_logits, candidate_xy_m, candidate_features, candidate_valid)
        encoded = self.encoder(candidate_features)
        residual = self.residual_head(encoded).squeeze(-1)
        base_score = self._sample_base(base_logits, candidate_xy_m)
        candidate_logits = (base_score + residual).masked_fill(~candidate_valid, torch.finfo(base_score.dtype).min)
        probability = functional.softmax(candidate_logits, dim=1)
        proposal_xy = (probability[..., None] * candidate_xy_m).sum(dim=1)
        pooled = (encoded * candidate_valid[..., None]).sum(dim=1) / candidate_valid.sum(dim=1, keepdim=True).clamp_min(1)
        acceptance = torch.sigmoid(self.acceptance_head(pooled).squeeze(-1))
        covariance = functional.softplus(self.covariance_head(pooled)) + 1.0e-3
        delta_logit = self._render_candidate_residual(candidate_xy_m, residual, candidate_valid, dtype=base_logits.dtype)
        final_logits = base_logits + acceptance[:, None, None, None] * delta_logit
        return {
            "delta_logit": delta_logit,
            "acceptance": acceptance,
            "covariance": covariance,
            "proposal_xy": proposal_xy,
            "candidate_logits": candidate_logits,
            "candidate_residual": residual,
            "final_logits": final_logits,
        }


class GBLESE2Expert(nn.Module):
    """Observed-branch scorer with a hard adjacent-frame reachability guard."""

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64, max_step_m: float = 0.30) -> None:
        super().__init__()
        if max_step_m <= 0.0:
            raise ValueError("max_step_m must be positive")
        self.max_step_m = float(max_step_m)
        self.scorer = TECSSE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim)

    def forward(self, candidate_features: Tensor, candidate_xy_m: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        if candidate_xy_m.ndim != 4 or candidate_xy_m.shape[-1] != 2:
            raise ValueError("candidate_xy_m must be [batch,time,candidates,2]")
        if candidate_features.shape[:3] != candidate_xy_m.shape[:3]:
            raise ValueError("candidate features must align with candidate_xy_m")
        if candidate_valid.shape != candidate_xy_m.shape[:3]:
            raise ValueError("candidate_valid must align with candidate_xy_m")
        output = self.scorer(candidate_features, candidate_valid)
        batch, steps, candidates = candidate_valid.shape
        reachable = candidate_valid.clone()
        if steps > 1:
            previous_xy = candidate_xy_m[:, :-1, :, None, :]
            current_xy = candidate_xy_m[:, 1:, None, :, :]
            distance = torch.linalg.vector_norm(previous_xy - current_xy, dim=-1)
            links = distance <= self.max_step_m
            links &= candidate_valid[:, :-1, :, None]
            links &= candidate_valid[:, 1:, None, :]
            from_previous = links.any(dim=2)
            # Candidate zero is always the frozen base/identity candidate.
            # It remains reachable so an empty graph cannot force a free jump.
            from_previous[..., 0] |= candidate_valid[:, 1:, 0]
            reachable[:, 1:] = from_previous
        allowed = candidate_valid & reachable
        candidate_logits = output["candidate_logits"].masked_fill(~allowed, -torch.inf)
        return {
            **output,
            "candidate_logits": candidate_logits,
            "reachable": reachable,
        }


class PathAssociationSE2Expert(nn.Module):
    """Causal multi-hypothesis association over measured radar candidates.

    Unlike :class:`GBLESE2Expert`, this module does not independently mask a
    frame by whether *some* preceding candidate is reachable.  It carries a
    Viterbi-style score for every physical branch, so a bright but isolated
    candidate receives only a penalised restart path.  Candidate zero remains
    the unmodified frozen-base action and can always be selected by the
    dispatcher for an exact identity fallback.
    """

    def __init__(
        self,
        *,
        feature_dim: int,
        hidden_dim: int = 64,
        max_step_m: float = 0.60,
        motion_scale_m: float = 0.22,
        restart_penalty: float = 0.70,
    ) -> None:
        super().__init__()
        if min(max_step_m, motion_scale_m, restart_penalty) <= 0.0:
            raise ValueError("path-association physical scales must be positive")
        self.max_step_m = float(max_step_m)
        self.motion_scale_m = float(motion_scale_m)
        self.restart_penalty = float(restart_penalty)
        self.encoder = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.unary_head = nn.Linear(hidden_dim, 1)
        self.temporal = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.acceptance_head = nn.Linear(hidden_dim, 1)
        self.covariance_head = nn.Linear(hidden_dim, 2)
        _zero_linear(self.unary_head)
        _zero_linear(self.acceptance_head)
        _zero_linear(self.covariance_head)

    def forward(self, candidate_features: Tensor, candidate_xy_m: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        if candidate_features.ndim != 4:
            raise ValueError("candidate_features must be [batch,time,candidates,feature]")
        batch, steps, candidates, dimensions = candidate_features.shape
        if dimensions != self.encoder[0].in_features:
            raise ValueError("candidate feature dimension mismatch")
        if candidate_xy_m.shape != (batch, steps, candidates, 2):
            raise ValueError("candidate_xy_m must align with candidate_features")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [batch,time,candidates]")
        if not bool(candidate_valid[..., 0].all()):
            raise ValueError("candidate zero must remain available as the frozen-base fallback")

        encoded = self.encoder(candidate_features)
        unary = self.unary_head(encoded).squeeze(-1).masked_fill(~candidate_valid, -torch.inf)
        pooled = (encoded * candidate_valid[..., None]).sum(dim=2)
        pooled = pooled / candidate_valid.sum(dim=2, keepdim=True).clamp_min(1)
        temporal, _ = self.temporal(pooled)

        path_scores: list[Tensor] = []
        previous: Tensor | None = None
        for index in range(steps):
            current_unary = unary[:, index]
            if previous is None:
                current = current_unary
            else:
                distance = torch.linalg.vector_norm(
                    candidate_xy_m[:, index - 1, :, None, :] - candidate_xy_m[:, index, None, :, :],
                    dim=-1,
                )
                reachable = (
                    candidate_valid[:, index - 1, :, None]
                    & candidate_valid[:, index, None, :]
                    & distance.le(self.max_step_m)
                )
                previous_log_posterior = functional.log_softmax(previous, dim=-1)
                transition = previous_log_posterior[:, :, None] - distance / self.motion_scale_m
                transition = transition.masked_fill(~reachable, -torch.inf)
                best_transition = transition.max(dim=1).values
                restart = torch.full_like(best_transition, -self.restart_penalty)
                non_identity = current_unary + torch.maximum(best_transition, restart)
                # Identity is deliberately not accumulated: it is the frozen
                # detector's current-frame action, not a synthetic track.
                current = torch.cat((current_unary[:, :1], non_identity[:, 1:]), dim=1)
                current = current.masked_fill(~candidate_valid[:, index], -torch.inf)
            path_scores.append(current)
            previous = current
        candidate_logits = torch.stack(path_scores, dim=1)
        acceptance = torch.sigmoid(self.acceptance_head(temporal).squeeze(-1))
        covariance = functional.softplus(self.covariance_head(temporal)) + 1.0e-3
        return {
            "candidate_logits": candidate_logits,
            "acceptance": acceptance,
            "covariance": covariance,
        }


class GGSRRESE2Expert(nn.Module):
    """Bounded candidate residual recovery with a separate expected-gain gate."""

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64, geometry: BEVGeometry | None = None) -> None:
        super().__init__()
        self.proposer = CandidateResidualRouteExpert(feature_dim=feature_dim, hidden_dim=hidden_dim, geometry=geometry)
        self.gain_encoder = nn.Sequential(
            nn.Linear(feature_dim + 3, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.gain_head = nn.Linear(hidden_dim, 1)
        _zero_linear(self.gain_head)

    def forward(
        self,
        base_logits: Tensor,
        candidate_xy_m: Tensor,
        candidate_features: Tensor,
        candidate_valid: Tensor,
    ) -> dict[str, Tensor]:
        if base_logits.ndim != 5 or base_logits.shape[2:] != (1, self.proposer.geometry.x_bins, self.proposer.geometry.y_bins):
            raise ValueError("base_logits must be [batch,time,1,x_bins,y_bins]")
        batch, steps = base_logits.shape[:2]
        if candidate_xy_m.shape[:2] != (batch, steps) or candidate_features.shape[:2] != (batch, steps):
            raise ValueError("candidate inputs must align with base_logits")
        candidates = candidate_xy_m.shape[2]
        flat = self.proposer(
            base_logits.flatten(0, 1),
            candidate_xy_m.flatten(0, 1),
            candidate_features.flatten(0, 1),
            candidate_valid.flatten(0, 1),
        )
        pooled = (candidate_features * candidate_valid[..., None]).sum(dim=2)
        pooled = pooled / candidate_valid.sum(dim=2, keepdim=True).clamp_min(1)
        posterior = functional.softmax(flat["candidate_logits"], dim=1).reshape(batch, steps, candidates)
        entropy = -(posterior.clamp_min(1.0e-8) * posterior.clamp_min(1.0e-8).log()).sum(dim=-1, keepdim=True)
        base_peak = flat["proposal_xy"].reshape(batch, steps, 2)
        proposal_spread = torch.linalg.vector_norm(
            candidate_xy_m - base_peak[:, :, None, :], dim=-1
        )
        expected_spread = (posterior * proposal_spread).sum(dim=-1, keepdim=True)
        proposer_acceptance = flat["acceptance"].reshape(batch, steps, 1)
        gain_feature = torch.cat((pooled, entropy, expected_spread, proposer_acceptance), dim=-1)
        gain = torch.sigmoid(self.gain_head(self.gain_encoder(gain_feature)).squeeze(-1))
        delta_logit = flat["delta_logit"].reshape(batch, steps, 1, self.proposer.geometry.x_bins, self.proposer.geometry.y_bins)
        overall_acceptance = flat["acceptance"].reshape(batch, steps) * gain
        proposed = base_logits + overall_acceptance[..., None, None, None] * delta_logit
        final_logits = torch.where(gain[..., None, None, None] == 0, base_logits, proposed)
        return {
            "delta_logit": delta_logit,
            "acceptance": overall_acceptance,
            "gain": gain,
            "covariance": flat["covariance"].reshape(batch, steps, 2),
            "proposal_xy": base_peak,
            "candidate_logits": flat["candidate_logits"].reshape(batch, steps, candidates),
            "final_logits": final_logits,
        }


class GGSRRECandidateSE2Expert(nn.Module):
    """Candidate-space GG-SRRE for raw RA/RA-MTI runtime evidence.

    Unlike :class:`GGSRRESE2Expert`, this primitive does not require a dense
    BEV logit map.  It first scores only physically observed candidates and
    then estimates whether using that recovered candidate posterior is worth
    leaving the frozen branch.  The dispatcher owns the final threshold and
    keeps candidate zero as the exact identity fallback.
    """

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64) -> None:
        super().__init__()
        self.proposer = TECSSE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim)
        self.gain_encoder = nn.Sequential(
            nn.Linear(feature_dim + 3, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.gain_head = nn.Linear(hidden_dim, 1)
        _zero_linear(self.gain_head)

    def forward(self, candidate_features: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        output = self.proposer(candidate_features, candidate_valid)
        posterior = functional.softmax(output["candidate_logits"], dim=-1)
        safe_posterior = posterior.clamp_min(1.0e-8)
        entropy = -(safe_posterior * safe_posterior.log()).sum(dim=-1, keepdim=True)
        top2 = posterior.topk(k=min(2, posterior.shape[-1]), dim=-1).values
        margin = (top2[..., :1] - top2[..., 1:2]) if top2.shape[-1] == 2 else top2
        pooled = (candidate_features * candidate_valid[..., None]).sum(dim=2)
        pooled = pooled / candidate_valid.sum(dim=2, keepdim=True).clamp_min(1)
        proposer_acceptance = output["acceptance"].unsqueeze(-1)
        gain_feature = torch.cat((pooled, entropy, margin, proposer_acceptance), dim=-1)
        recovery_gain = torch.sigmoid(self.gain_head(self.gain_encoder(gain_feature)).squeeze(-1))
        acceptance = output["acceptance"] * recovery_gain
        return {
            **output,
            "acceptance": acceptance,
            "recovery_gain": recovery_gain,
        }


class LTGESE2Expert(nn.Module):
    """Low-threshold temporal candidate scorer with evidence accumulation.

    It leaves coordinate selection to a later observed-candidate readout.  The
    scalar path evidence is an audit signal, not a substitute for a current
    radar measurement.
    """

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64) -> None:
        super().__init__()
        self.scorer = TECSSE2Expert(feature_dim=feature_dim, hidden_dim=hidden_dim)
        self.evidence_head = nn.Linear(1, 1)
        _zero_linear(self.evidence_head)

    def forward(self, candidate_features: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        output = self.scorer(candidate_features, candidate_valid)
        posterior = functional.softmax(output["candidate_logits"], dim=-1)
        frame_strength = posterior.masked_fill(~candidate_valid, 0.0).max(dim=-1).values
        # Causal cumulative evidence; no future-frame aggregation occurs here.
        cumulative = torch.cumsum(frame_strength, dim=1) / torch.arange(
            1, frame_strength.shape[1] + 1, dtype=frame_strength.dtype, device=frame_strength.device
        )[None, :]
        path_evidence = torch.sigmoid(self.evidence_head(cumulative[..., None]).squeeze(-1))
        return {
            **output,
            "path_evidence": path_evidence,
        }
