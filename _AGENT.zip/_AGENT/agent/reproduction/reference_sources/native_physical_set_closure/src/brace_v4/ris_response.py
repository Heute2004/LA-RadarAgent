"""Canonical and archived RIS-response contracts for V4 L-corridor experiments."""

from __future__ import annotations

import json
from pathlib import Path


DUALRIS_V21_CONDITION_TEMPLATE = "directeq_lcorridor9_v21_mht_{sequence}"
DUALRIS_V6_FEATURE_DIRECTORY = "ReceivedADCStandardFeaturesV1"
DUALRIS_V6_INPUT_SOURCE = "dualris_v6_v21_mht_directeq_ra_ra_mti"
DUALRIS_V6_REQUIRED_VIEWS = ("RA", "RA-MIT")


def dualris_v6_feature_root(sequence_root: str | Path, sequence: str) -> Path:
    """Resolve canonical V6-physical / V21-receiver direct-equivalent features.

    The public function name is retained for compatibility with the V4 dataset
    loader.  Its only accepted runtime source is the V21 safety-recovered
    receiver output; older V20 and archived V8 folders are never resolved.
    """

    sequence = str(sequence).strip().lower()
    root = (
        Path(sequence_root)
        / "RadarRIS"
        / DUALRIS_V21_CONDITION_TEMPLATE.format(sequence=sequence)
        / DUALRIS_V6_FEATURE_DIRECTORY
    )
    required = tuple(root / view for view in DUALRIS_V6_REQUIRED_VIEWS)
    if not all(path.is_dir() for path in required):
        raise FileNotFoundError(
            "Missing canonical Dual-RIS V6-physical/V21-receiver RA/RA-MIT features for "
            f"{sequence}: {root}"
        )
    return root


def validate_dualris_v6_metadata(feature_root: str | Path) -> None:
    """Require a causal V21 safety-recovered receiver provenance record."""

    metadata_path = Path(feature_root) / "metadata.json"
    if not metadata_path.is_file():
        raise FileNotFoundError(
            f"canonical Dual-RIS V6-physical/V21 metadata is required: {metadata_path}"
        )
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    source = metadata.get("source_ris_metadata", {})
    source_semantics = str(source.get("output_semantics", "")).lower()
    receiver_state = str(source.get("source_receiver_state", ""))
    if (
        metadata.get("processing_version") != "received_ris_adc_standard_features_v1"
        or source.get("processing_version")
        != "uniform_lcorridor9_phase_neutral_directequivalent_adc_v1"
        or source.get("receiver_label_access") != "none"
        or "direct-equivalent" not in source_semantics
        or "DualRISMultiHypothesisV21Final" not in receiver_state
    ):
        raise ValueError(f"unsupported canonical Dual-RIS V6-physical/V21 metadata: {metadata_path}")
    state_path = Path(receiver_state)
    state_contract = state_path.parent / "causal_direct_state_contract.json"
    receiver_contract = state_path.parent.parent / "receiver_contract.json"
    if not state_contract.is_file() or not receiver_contract.is_file():
        raise ValueError(f"missing V21 receiver provenance for {metadata_path}")
    state_metadata = json.loads(state_contract.read_text(encoding="utf-8"))
    receiver_metadata = json.loads(receiver_contract.read_text(encoding="utf-8"))
    fingerprint = receiver_metadata.get("input_fingerprint", {}).get("fingerprint_sha256")
    if (
        state_metadata.get("source_receiver") != "DualRISMultiHypothesisV21Final"
        or receiver_metadata.get("processing_version") != "dual_ris_mht_shadow_handoff_v21"
        or not isinstance(fingerprint, str)
        or not fingerprint
    ):
        raise ValueError(f"invalid V21 receiver provenance for {metadata_path}")


def audit_dualris_v6_materialization(
    dataset_root: str | Path,
    sequences: tuple[str, ...],
    *,
    expected_frames: int = 300,
) -> dict[str, object]:
    """Verify a V6-physical/V21 installation without reading labels or models."""

    if expected_frames < 1:
        raise ValueError("expected_frames must be positive")
    expected_ids = list(range(int(expected_frames)))
    rows: list[dict[str, object]] = []
    total_feature_files = 0
    for sequence in sequences:
        sequence_name = str(sequence).strip().lower()
        row: dict[str, object] = {"sequence": sequence_name, "errors": []}
        try:
            feature_root = dualris_v6_feature_root(
                Path(dataset_root) / "Data_train" / sequence_name,
                sequence_name,
            )
            validate_dualris_v6_metadata(feature_root)
            frame_counts: dict[str, int] = {}
            for view in DUALRIS_V6_REQUIRED_VIEWS:
                paths = sorted((feature_root / view).glob("frame_*.npy"))
                identifiers = [int(path.stem.rsplit("_", 1)[-1]) for path in paths]
                frame_counts[view] = len(identifiers)
                total_feature_files += len(identifiers)
                if identifiers != expected_ids:
                    row["errors"].append(
                        f"{view} expected contiguous frame ids 0..{expected_frames - 1}, "
                        f"found {len(identifiers)} files"
                    )
            row["feature_root"] = str(feature_root)
            row["view_frame_counts"] = frame_counts
        except (FileNotFoundError, ValueError, json.JSONDecodeError) as error:
            row["errors"].append(str(error))
        row["pass"] = not row["errors"]
        rows.append(row)
    return {
        "schema_version": "brace_v4_dualris_v21_materialization_audit_v1",
        "expected_frames_per_view": int(expected_frames),
        "required_views": list(DUALRIS_V6_REQUIRED_VIEWS),
        "sequence_count": len(rows),
        "total_feature_files": total_feature_files,
        "all_pass": all(bool(row["pass"]) for row in rows),
        "sequences": rows,
    }


STAGEB_V8_CONDITION_TEMPLATE = "stageb_realistic_scatter_v8_{sequence}"
STAGEB_V8_FEATURE_DIRECTORY = "StandardFeaturesV1"
STAGEB_V8_INPUT_SOURCE = "stageb_v8_ris_ra_ra_mti"
# The archived V8 training-equivalent package contains only the two runtime
# polar views. RD/RD-MIT/AD were never emitted for this response condition.
STAGEB_V8_REQUIRED_VIEWS = ("RA", "RA-MIT")
STAGEB_V8_UNAVAILABLE_VIEWS = ("RD", "RD-MIT", "AD")


def stageb_v8_ris_feature_root(sequence_root: str | Path, sequence: str) -> Path:
    """Resolve the canonical V8 RA/RA-MTI response directory for one sequence."""

    sequence = str(sequence).strip().lower()
    root = (
        Path(sequence_root)
        / "RadarRIS"
        / STAGEB_V8_CONDITION_TEMPLATE.format(sequence=sequence)
        / STAGEB_V8_FEATURE_DIRECTORY
    )
    required = (root / "RA", root / "RA-MIT")
    if not all(path.is_dir() for path in required):
        raise FileNotFoundError(
            f"Missing canonical Stage B V8 RIS RA/RA-MIT features for {sequence}: {root}"
        )
    return root


def validate_stageb_v8_metadata(feature_root: str | Path) -> None:
    """Reject feature folders that do not carry the archived V8 provenance."""

    metadata_path = Path(feature_root) / "metadata.json"
    if not metadata_path.is_file():
        raise FileNotFoundError(f"canonical Stage B V8 metadata is required: {metadata_path}")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    source = metadata.get("source_hard_ris_metadata", {})
    if (
        metadata.get("processing_version") != "radar_feature_folders_v1"
        or source.get("processing_version") != "stage_b_realistic_human_scatter_adc_v8"
    ):
        raise ValueError(f"unsupported canonical Stage B V8 metadata: {metadata_path}")


def audit_stageb_v8_materialization(
    dataset_root: str | Path,
    sequences: tuple[str, ...],
    *,
    expected_frames: int = 300,
) -> dict[str, object]:
    """Verify the local V8 feature installation without reading labels or models."""

    if expected_frames < 1:
        raise ValueError("expected_frames must be positive")
    expected_ids = list(range(int(expected_frames)))
    rows: list[dict[str, object]] = []
    total_feature_files = 0
    for sequence in sequences:
        sequence_name = str(sequence).strip().lower()
        row: dict[str, object] = {"sequence": sequence_name, "errors": []}
        try:
            feature_root = stageb_v8_ris_feature_root(
                Path(dataset_root) / "Data_train" / sequence_name,
                sequence_name,
            )
            validate_stageb_v8_metadata(feature_root)
            frame_counts: dict[str, int] = {}
            for view in STAGEB_V8_REQUIRED_VIEWS:
                paths = sorted((feature_root / view).glob("frame_*.npy"))
                identifiers = [int(path.stem.rsplit("_", 1)[-1]) for path in paths]
                frame_counts[view] = len(identifiers)
                total_feature_files += len(identifiers)
                if identifiers != expected_ids:
                    row["errors"].append(
                        f"{view} expected contiguous frame ids 0..{expected_frames - 1}, "
                        f"found {len(identifiers)} files"
                    )
            row["feature_root"] = str(feature_root)
            row["view_frame_counts"] = frame_counts
        except (FileNotFoundError, ValueError, json.JSONDecodeError) as error:
            row["errors"].append(str(error))
        row["pass"] = not row["errors"]
        rows.append(row)
    return {
        "schema_version": "brace_v4_stageb_v8_materialization_audit_v1",
        "expected_frames_per_view": int(expected_frames),
        "required_views": list(STAGEB_V8_REQUIRED_VIEWS),
        "sequence_count": len(rows),
        "total_feature_files": total_feature_files,
        "all_pass": all(bool(row["pass"]) for row in rows),
        "sequences": rows,
    }
