# Recorded GBLE Training Source

Exact server file recovered without editing or executing on 2026-09-10:
`/home/hyc/radar+ris/AGENT-JSAC/scripts/train_branch_router_recipe.py`.

SHA256: `17a615649e5bf53049b8ff6815678e0643bb3e425d2d671779001d0ce81549a6`.
This matches the trainer digest recorded by the GBLE candidate's actual
`TRAINING_RECEIPT.json` under the outdoor_dry_complex shadow pool in
`expert_pool_42_training_20260901`.

The model dependency is `src/agent_jsac/branch_router_recipe.py`, SHA256
`ce03fb4adc45a310dfadc1ca0d783cbb0b289a797a338cf32d32c645b5f18738`.
An exact copy already exists in the sibling
`agent_expert_runtime_contracts/src/agent_jsac/branch_router_recipe.py`.

This historical candidate used `CausalBranchRouter`, grouped out-of-fold
calibration and CORA0/SE1/SE2 branch outputs. It must not be represented as
the different native `GBLESE2Expert` candidate graph. Same public names do not
prove same training method. This is an exact provenance asset, not production
admission. Other dependencies and the original runtime manifest still require
binding before execution. No historical expert checkpoint was copied.
