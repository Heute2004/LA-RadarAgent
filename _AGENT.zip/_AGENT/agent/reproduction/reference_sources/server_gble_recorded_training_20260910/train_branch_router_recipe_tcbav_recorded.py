#!/usr/bin/env python3
"""Train a fresh CORA0/SE1/SE2 branch router from Support-only set supervision."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from agent_jsac.branch_router_recipe import (
    BRANCH_ORDER,
    CausalBranchRouter,
    branch_feature_tensor,
    hard_branch_selection,
    set_mass_branch_targets,
)
from agent_jsac.route_expert_recipe_registry import recipe_for_implementation
from agent_jsac.se_branch_route_runtime import validate_runtime_payload


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class BranchEpisode:
    sequence: str
    route: str
    feature: Tensor
    target: Tensor
    utility: Tensor
    valid: Tensor
    sample_weight: Tensor


def load_prediction_index(path: Path) -> dict[tuple[str, int], tuple[Tensor, float]]:
    with np.load(path, allow_pickle=False) as archive:
        sequence = np.asarray(archive["sequence"]).astype(str)
        frame_id = np.asarray(archive["frame_id"], dtype=np.int64)
        xy_m = np.asarray(archive["xy_m"], dtype=np.float32)
        score = np.asarray(archive["score"], dtype=np.float32)
    result: dict[tuple[str, int], tuple[Tensor, float]] = {}
    for name, frame, xy, confidence in zip(
        sequence, frame_id, xy_m, score, strict=True
    ):
        key = (str(name).strip().lower(), int(frame))
        if key in result:
            raise ValueError(f"duplicate frozen branch prediction: {key}")
        result[key] = (torch.from_numpy(xy.copy()), float(confidence))
    return result


def load_branch_prediction_root(
    root: Path,
) -> tuple[dict[str, dict[tuple[str, int], tuple[Tensor, float]]], dict[str, Any]]:
    manifest_path = Path(root) / "PREDICTION_FREEZE.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"branch prediction manifest missing: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files = manifest.get("prediction_files")
    if not isinstance(files, dict) or tuple(sorted(files)) != BRANCH_ORDER:
        raise ValueError("branch recipe requires exactly CORA0, CORA-SE1, and CORA-SE2")
    result: dict[str, dict[tuple[str, int], tuple[Tensor, float]]] = {}
    for branch in BRANCH_ORDER:
        entry = files[branch]
        path = Path(root) / str(entry["path"])
        if sha256(path) != str(entry["sha256"]):
            raise ValueError(f"branch prediction hash mismatch: {branch}")
        result[branch] = load_prediction_index(path)
    if bool(manifest.get("development_labels_read")) or bool(
        manifest.get("locked_test_read")
    ):
        raise ValueError("branch prediction freeze reports forbidden evaluation reads")
    return result, manifest


def assemble_branch_episode(
    *,
    sequence: str,
    route: str,
    frame_ids: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    allowed_weight: np.ndarray,
    sample_weight: np.ndarray,
    radar_training_valid: np.ndarray,
    branch_index: dict[str, dict[tuple[str, int], tuple[Tensor, float]]],
) -> BranchEpisode:
    sequence = str(sequence).strip().lower()
    frame_ids = np.asarray(frame_ids, dtype=np.int64)
    coordinates: list[Tensor] = []
    scores: list[Tensor] = []
    for frame in frame_ids:
        key = (sequence, int(frame))
        if any(key not in branch_index[branch] for branch in BRANCH_ORDER):
            raise ValueError(f"branch prediction missing Support frame: {key}")
        coordinates.append(
            torch.stack([branch_index[branch][key][0] for branch in BRANCH_ORDER])
        )
        scores.append(
            torch.tensor(
                [branch_index[branch][key][1] for branch in BRANCH_ORDER],
                dtype=torch.float32,
            )
        )
    branch_xy = torch.stack(coordinates)
    branch_score = torch.stack(scores)
    target, physical_valid = set_mass_branch_targets(
        branch_xy,
        torch.from_numpy(np.asarray(candidate_xy_m, dtype=np.float32).copy()),
        torch.from_numpy(np.asarray(candidate_valid, dtype=bool).copy()),
        torch.from_numpy(np.asarray(allowed_weight, dtype=np.float32).copy()),
    )
    sample = torch.from_numpy(np.asarray(sample_weight, dtype=np.float32).copy()).clamp(0.0, 1.0)
    radar_valid = torch.from_numpy(
        np.asarray(radar_training_valid, dtype=bool).copy()
    )
    valid = physical_valid & radar_valid & sample.gt(0.0)
    return BranchEpisode(
        sequence=sequence,
        route=str(route),
        feature=branch_feature_tensor(branch_xy, branch_score),
        target=target,
        utility=target.detach(),
        valid=valid,
        sample_weight=sample,
    )


def load_runtime_episodes(
    root: Path,
    *,
    expected_route: str,
    expected_parent: str,
    branch_index: dict[str, dict[tuple[str, int], tuple[Tensor, float]]],
) -> list[BranchEpisode]:
    result: list[BranchEpisode] = []
    for path in sorted(Path(root).glob("seq_*.npz")):
        with np.load(path, allow_pickle=False) as archive:
            payload = {key: archive[key].copy() for key in archive.files}
        validate_runtime_payload(payload)
        route = str(np.asarray(payload["route"]).item())
        role = str(np.asarray(payload["role"]).item())
        parent = str(np.asarray(payload["parent_branch"]).item())
        if route != expected_route or role != "fit" or parent != expected_parent:
            raise ValueError(f"branch runtime contract mismatch: {path}")
        result.append(
            assemble_branch_episode(
                sequence=str(np.asarray(payload["sequence"]).item()),
                route=route,
                frame_ids=np.asarray(payload["frame_id"], dtype=np.int64),
                candidate_xy_m=np.asarray(payload["candidate_xy_m"], dtype=np.float32),
                candidate_valid=np.asarray(payload["candidate_valid"], dtype=bool),
                allowed_weight=np.asarray(payload["allowed_weight"], dtype=np.float32),
                sample_weight=np.asarray(payload["sample_weight"], dtype=np.float32),
                radar_training_valid=np.asarray(payload["radar_training_valid"], dtype=bool),
                branch_index=branch_index,
            )
        )
    if not result:
        raise FileNotFoundError(f"no branch-router Support archives: {root}")
    return result


def split_episodes(
    episodes: list[BranchEpisode], *, fraction: float, seed: int
) -> tuple[list[BranchEpisode], list[BranchEpisode]]:
    if len(episodes) < 2 or not 0.0 < fraction < 1.0:
        raise ValueError("branch router needs at least two sequences and a valid split fraction")
    ordered = sorted(
        episodes,
        key=lambda item: hashlib.sha256(
            f"{int(seed)}:{item.sequence}".encode("utf-8")
        ).hexdigest(),
    )
    count = min(len(ordered) - 1, max(1, int(round(len(ordered) * fraction))))
    calibration_names = {item.sequence for item in ordered[:count]}
    fit = sorted(
        (item for item in episodes if item.sequence not in calibration_names),
        key=lambda item: item.sequence,
    )
    calibration = sorted(
        (item for item in episodes if item.sequence in calibration_names),
        key=lambda item: item.sequence,
    )
    return fit, calibration


def sequence_loss(model: CausalBranchRouter, episode: BranchEpisode, device: torch.device) -> Tensor:
    logits = model(episode.feature.to(device))[0]
    target = episode.target.to(device)
    weight = (
        episode.valid.to(device).float() * episode.sample_weight.to(device)
    ).clamp(0.0, 1.0)
    if float(weight.sum()) <= 0.0:
        return logits.sum() * 0.0
    cross_entropy = -(target * logits.log_softmax(dim=-1)).sum(dim=-1)
    probability = logits.softmax(dim=-1)
    smooth = (
        (probability[1:] - probability[:-1]).abs().mean()
        if logits.shape[0] > 1
        else logits.sum() * 0.0
    )
    return (cross_entropy * weight).sum() / weight.sum().clamp_min(1.0e-6) + 0.01 * smooth


@torch.inference_mode()
def calibration_utility(
    model: CausalBranchRouter,
    episodes: list[BranchEpisode],
    *,
    base_index: int,
    margin: float,
    device: torch.device,
) -> tuple[float, float, float]:
    selected_total = base_total = accepted_total = weight_total = 0.0
    model.eval()
    for episode in episodes:
        logits = model(episode.feature.to(device))[0]
        selected, accepted = hard_branch_selection(
            logits, base_index=base_index, margin=margin
        )
        utility = episode.utility.to(device)
        weight = (
            episode.valid.to(device).float() * episode.sample_weight.to(device)
        ).clamp(0.0, 1.0)
        selected_total += float(
            (utility.gather(1, selected.unsqueeze(1)).squeeze(1) * weight).sum().cpu()
        )
        base_total += float((utility[:, base_index] * weight).sum().cpu())
        accepted_total += float((accepted.float() * weight).sum().cpu())
        weight_total += float(weight.sum().cpu())
    if weight_total <= 0.0:
        return float("-inf"), 0.0, 0.0
    return (
        selected_total / weight_total,
        base_total / weight_total,
        accepted_total / weight_total,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-id", required=True)
    parser.add_argument("--route", required=True)
    parser.add_argument("--primitive", required=True)
    parser.add_argument("--implementation-id", required=True)
    parser.add_argument("--parent-branch", choices=BRANCH_ORDER, required=True)
    parser.add_argument("--target-fit-root", type=Path, required=True)
    parser.add_argument("--source-replay-root", type=Path, required=True)
    parser.add_argument("--branch-prediction-root", type=Path, required=True)
    parser.add_argument("--empty-guard-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--calibration-fraction", type=float, default=0.25)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"branch-router output already exists: {args.output_dir}")
    if recipe_for_implementation(args.implementation_id) != "branch_router":
        raise ValueError("implementation is not registered to the branch-router recipe")
    for path in (
        args.target_fit_root / "ROUTE_RUNTIME_MANIFEST.json",
        args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json",
        args.empty_guard_manifest,
    ):
        if not path.is_file():
            raise FileNotFoundError(f"required hash-bound training asset missing: {path}")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for branch-router shadow training")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    branch_index, branch_manifest = load_branch_prediction_root(
        args.branch_prediction_root
    )
    support = load_runtime_episodes(
        args.target_fit_root,
        expected_route=args.route,
        expected_parent=args.parent_branch,
        branch_index=branch_index,
    )
    fit, calibration = split_episodes(
        support, fraction=args.calibration_fraction, seed=args.seed
    )
    base_index = BRANCH_ORDER.index(args.parent_branch)
    model = CausalBranchRouter().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3.0e-3, weight_decay=1.0e-4)
    best_state: dict[str, Tensor] | None = None
    best_score = float("-inf")
    best_epoch = 0
    history: list[dict[str, float]] = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        ordered = list(fit)
        random.shuffle(ordered)
        losses: list[float] = []
        for episode in ordered:
            optimizer.zero_grad(set_to_none=True)
            loss = sequence_loss(model, episode, device)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        utility, base_utility, coverage = calibration_utility(
            model, calibration, base_index=base_index, margin=0.0, device=device
        )
        row = {
            "epoch": float(epoch),
            "fit_loss": float(np.mean(losses)),
            "calibration_utility_at_zero_margin": utility,
            "calibration_base_utility": base_utility,
            "calibration_coverage_at_zero_margin": coverage,
        }
        history.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
        if utility > best_score:
            best_score = utility
            best_epoch = epoch
            best_state = {
                name: value.detach().cpu().clone()
                for name, value in model.state_dict().items()
            }
    if best_state is None:
        raise RuntimeError("branch-router training produced no checkpoint")
    model.load_state_dict(best_state)
    margins = (0.0, 0.02, 0.05, 0.08, 0.12, 0.16, 0.22, 0.30)
    options = []
    for margin in margins:
        utility, base_utility, coverage = calibration_utility(
            model, calibration, base_index=base_index, margin=margin, device=device
        )
        options.append(
            {
                "margin": margin,
                "utility": utility,
                "base_utility": base_utility,
                "coverage": coverage,
            }
        )
    non_harmful = [
        item for item in options if item["utility"] >= item["base_utility"] - 1.0e-6
    ]
    chosen = max(
        non_harmful or options,
        key=lambda item: (item["utility"], item["coverage"], -item["margin"]),
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "agent_jsac_branch_router_checkpoint_v1",
        "recipe_type": "branch_router",
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "implementation_id": args.implementation_id,
        "parent_branch": args.parent_branch,
        "branch_order": BRANCH_ORDER,
        "model_kwargs": {"input_dim": 18, "hidden_dim": 48},
        "model_state": best_state,
        "selected_epoch": best_epoch,
        "selection_margin": chosen["margin"],
        "support_calibration": {"chosen": chosen, "all_margins": options},
        "execution_weight": 0.0,
        "historical_checkpoint_import": False,
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    branch_manifest_path = args.branch_prediction_root / "PREDICTION_FREEZE.json"
    receipt = {
        "schema_version": "agent_jsac_branch_router_training_receipt_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "implementation_id": args.implementation_id,
        "recipe_type": "branch_router",
        "parent_branch": args.parent_branch,
        "target_fit_sequences": [item.sequence for item in fit],
        "target_calibration_sequences": [item.sequence for item in calibration],
        "source_replay_sequences": [],
        "source_replay_role": "route-external identity retention; not consumed by branch router",
        "support_canary_read": False,
        "development_read": False,
        "locked_test_read": False,
        "selected_epoch": best_epoch,
        "selection_margin": chosen["margin"],
        "support_calibration": {"chosen": chosen, "all_margins": options},
        "checkpoint_path": str(checkpoint_path.resolve()),
        "checkpoint_sha256": sha256(checkpoint_path),
        "execution_weight": 0.0,
        "branch_prediction_manifest": str(branch_manifest_path.resolve()),
        "branch_prediction_manifest_sha256": sha256(branch_manifest_path),
        "branch_checkpoint_hashes": branch_manifest.get("checkpoint_hashes"),
        "runtime_manifests": {
            "target_support": sha256(
                args.target_fit_root / "ROUTE_RUNTIME_MANIFEST.json"
            ),
            "source_replay": sha256(
                args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json"
            ),
        },
        "empty_guard_sha256": sha256(args.empty_guard_manifest),
        "implementation_files": {
            "trainer": sha256(Path(__file__).resolve()),
            "model": sha256(ROOT / "src" / "agent_jsac" / "branch_router_recipe.py"),
        },
        "history": history,
    }
    (args.output_dir / "TRAINING_RECEIPT.json").write_text(
        json.dumps(receipt, ensure_ascii=True, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "candidate_id": args.candidate_id,
                "recipe_type": "branch_router",
                "selected_epoch": best_epoch,
                "selection_margin": chosen["margin"],
                "checkpoint_sha256": receipt["checkpoint_sha256"],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
