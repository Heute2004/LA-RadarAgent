#!/usr/bin/env python3
"""Train a fresh CORA0/SE1/SE2 branch router from Support-only set supervision."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import Tensor


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from agent_jsac.branch_router_recipe import (
    BRANCH_ORDER,
    CausalBranchRouter,
    branch_feature_tensor,
    hard_branch_selection,
    set_mass_branch_targets,
)
from agent_jsac.branch_prediction_freeze import load_branch_prediction_root
from agent_jsac.route_expert_recipe_registry import recipe_for_implementation
from agent_jsac.route_parent_selection import is_supported_parent_selection_policy
from agent_jsac.se_branch_route_runtime import validate_runtime_payload


_DIRECT_ROUTES = frozenset(
    {
        "open_indoor_los",
        "indoor_clutter",
        "open_outdoor_weak_return",
        "outdoor_dry_complex",
        "outdoor_wet_return",
    }
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def valid_sha256(value: object) -> bool:
    text = str(value).lower()
    return len(text) == 64 and all(character in "0123456789abcdef" for character in text)


def runtime_manifest_sequences(
    path: Path, *, expected_route: str, expected_role: str
) -> tuple[str, ...]:
    payload = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if payload.get("schema_version") != "agent_jsac_se_branch_route_runtime_manifest_v1":
        raise ValueError("unexpected route runtime manifest schema")
    if payload.get("route") != expected_route or payload.get("role") != expected_role:
        raise ValueError("route runtime manifest route/role mismatch")
    records = payload.get("records")
    if not isinstance(records, list) or not records:
        raise ValueError("route runtime manifest has no sequence records")
    sequences = tuple(
        str(record.get("sequence", "")).strip().lower()
        for record in records
        if isinstance(record, dict)
    )
    if (
        len(sequences) != len(records)
        or any(not sequence for sequence in sequences)
        or len(set(sequences)) != len(sequences)
    ):
        raise ValueError("route runtime manifest sequences are invalid")
    return sequences


def branch_checkpoint_hashes(manifest: dict[str, Any]) -> dict[str, str]:
    lineage = manifest.get("checkpoint_lineage")
    legacy = manifest.get("checkpoint_hashes")
    if isinstance(lineage, dict):
        raw = {
            branch: (
                lineage.get(branch, {}).get("sha256")
                if isinstance(lineage.get(branch), dict)
                else None
            )
            for branch in BRANCH_ORDER
        }
    elif isinstance(legacy, dict):
        raw = {branch: legacy.get(branch) for branch in BRANCH_ORDER}
    else:
        raise ValueError("branch prediction manifest lacks checkpoint lineage")
    result: dict[str, str] = {}
    for branch in BRANCH_ORDER:
        digest = raw[branch]
        if (
            not isinstance(digest, str)
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest.lower())
        ):
            raise ValueError(f"branch checkpoint hash is invalid: {branch}")
        result[branch] = digest.lower()
    return result


@dataclass(frozen=True)
class BranchEpisode:
    sequence: str
    route: str
    feature: Tensor
    target: Tensor
    utility: Tensor
    valid: Tensor
    sample_weight: Tensor


def assemble_branch_episode(
    *,
    sequence: str,
    route: str,
    frame_ids: np.ndarray,
    candidate_xy_m: np.ndarray,
    candidate_valid: np.ndarray,
    allowed_weight: np.ndarray,
    sample_weight: np.ndarray,
    radar_training_valid: np.ndarray,
    branch_index: dict[str, dict[tuple[str, int], tuple[Tensor, float]]],
) -> BranchEpisode:
    sequence = str(sequence).strip().lower()
    frame_ids = np.asarray(frame_ids, dtype=np.int64)
    coordinates: list[Tensor] = []
    scores: list[Tensor] = []
    for frame in frame_ids:
        key = (sequence, int(frame))
        if any(key not in branch_index[branch] for branch in BRANCH_ORDER):
            raise ValueError(f"branch prediction missing Support frame: {key}")
        coordinates.append(
            torch.stack([branch_index[branch][key][0] for branch in BRANCH_ORDER])
        )
        scores.append(
            torch.tensor(
                [branch_index[branch][key][1] for branch in BRANCH_ORDER],
                dtype=torch.float32,
            )
        )
    branch_xy = torch.stack(coordinates)
    branch_score = torch.stack(scores)
    target, physical_valid = set_mass_branch_targets(
        branch_xy,
        torch.from_numpy(np.asarray(candidate_xy_m, dtype=np.float32).copy()),
        torch.from_numpy(np.asarray(candidate_valid, dtype=bool).copy()),
        torch.from_numpy(np.asarray(allowed_weight, dtype=np.float32).copy()),
    )
    sample = torch.from_numpy(np.asarray(sample_weight, dtype=np.float32).copy()).clamp(0.0, 1.0)
    radar_valid = torch.from_numpy(
        np.asarray(radar_training_valid, dtype=bool).copy()
    )
    valid = physical_valid & radar_valid & sample.gt(0.0)
    return BranchEpisode(
        sequence=sequence,
        route=str(route),
        feature=branch_feature_tensor(branch_xy, branch_score),
        target=target,
        utility=target.detach(),
        valid=valid,
        sample_weight=sample,
    )


def load_runtime_episodes(
    root: Path,
    *,
    expected_route: str,
    expected_parent: str,
    expected_role: str,
    branch_index: dict[str, dict[tuple[str, int], tuple[Tensor, float]]],
) -> list[BranchEpisode]:
    result: list[BranchEpisode] = []
    for path in sorted(Path(root).glob("seq_*.npz")):
        with np.load(path, allow_pickle=False) as archive:
            payload = {key: archive[key].copy() for key in archive.files}
        validate_runtime_payload(payload)
        route = str(np.asarray(payload["route"]).item())
        role = str(np.asarray(payload["role"]).item())
        parent = str(np.asarray(payload["parent_branch"]).item())
        if route != expected_route or role != expected_role or parent != expected_parent:
            raise ValueError(f"branch runtime contract mismatch: {path}")
        result.append(
            assemble_branch_episode(
                sequence=str(np.asarray(payload["sequence"]).item()),
                route=route,
                frame_ids=np.asarray(payload["frame_id"], dtype=np.int64),
                candidate_xy_m=np.asarray(payload["candidate_xy_m"], dtype=np.float32),
                candidate_valid=np.asarray(payload["candidate_valid"], dtype=bool),
                allowed_weight=np.asarray(payload["allowed_weight"], dtype=np.float32),
                sample_weight=np.asarray(payload["sample_weight"], dtype=np.float32),
                radar_training_valid=np.asarray(payload["radar_training_valid"], dtype=bool),
                branch_index=branch_index,
            )
        )
    if not result:
        raise FileNotFoundError(f"no branch-router Support archives: {root}")
    return result


def weighted_training_schedule(
    target_fit: list[BranchEpisode],
    source_replay: list[BranchEpisode],
    *,
    source_replay_weight: float,
) -> list[tuple[str, BranchEpisode, float]]:
    """Build the auditable Target-plus-Source retention training schedule."""

    weight = float(source_replay_weight)
    if not math.isfinite(weight) or weight < 0.0:
        raise ValueError("source replay weight must be non-negative and finite")
    if not target_fit:
        raise ValueError("branch router requires Target fit episodes")
    target_schedule = [("target", episode, 1.0) for episode in target_fit]
    if weight == 0.0:
        return target_schedule
    if not source_replay:
        raise ValueError("positive source replay weight requires Source replay episodes")
    return [
        *target_schedule,
        *[("source", episode, weight) for episode in source_replay],
    ]


def split_episodes(
    episodes: list[BranchEpisode], *, fraction: float, seed: int
) -> tuple[list[BranchEpisode], list[BranchEpisode]]:
    if len(episodes) < 2 or not 0.0 < fraction < 1.0:
        raise ValueError("branch router needs at least two sequences and a valid split fraction")
    ordered = sorted(
        episodes,
        key=lambda item: hashlib.sha256(
            f"{int(seed)}:{item.sequence}".encode("utf-8")
        ).hexdigest(),
    )
    count = min(len(ordered) - 1, max(1, int(round(len(ordered) * fraction))))
    calibration_names = {item.sequence for item in ordered[:count]}
    fit = sorted(
        (item for item in episodes if item.sequence not in calibration_names),
        key=lambda item: item.sequence,
    )
    calibration = sorted(
        (item for item in episodes if item.sequence in calibration_names),
        key=lambda item: item.sequence,
    )
    return fit, calibration


def grouped_sequence_folds(
    episodes: list[BranchEpisode], *, fold_count: int, seed: int
) -> list[tuple[list[BranchEpisode], list[BranchEpisode]]]:
    """Build deterministic sequence-disjoint folds covering every Support episode."""

    if len(episodes) < 2:
        raise ValueError("branch router needs at least two Support sequences")
    count = min(int(fold_count), len(episodes))
    if count < 2:
        raise ValueError("grouped OOF calibration needs at least two folds")
    ordered = sorted(
        episodes,
        key=lambda item: hashlib.sha256(
            f"{int(seed)}:{item.sequence}".encode("utf-8")
        ).hexdigest(),
    )
    buckets: list[list[BranchEpisode]] = [[] for _ in range(count)]
    for index, episode in enumerate(ordered):
        buckets[index % count].append(episode)
    result: list[tuple[list[BranchEpisode], list[BranchEpisode]]] = []
    for calibration in buckets:
        names = {item.sequence for item in calibration}
        fit = sorted(
            (item for item in episodes if item.sequence not in names),
            key=lambda item: item.sequence,
        )
        result.append((fit, sorted(calibration, key=lambda item: item.sequence)))
    return result


def select_final_training_epoch(fold_reports: list[dict[str, Any]]) -> int:
    """Keep the latest epoch that produced genuine sequence-held-out benefit."""

    improving: list[int] = []
    for report in fold_reports:
        metrics = report.get("selected_epoch_metrics")
        if not isinstance(metrics, dict):
            raise ValueError("OOF fold report lacks selected-epoch metrics")
        utility = float(metrics["calibration_utility_at_zero_margin"])
        base = float(metrics["calibration_base_utility"])
        if utility > base + 1.0e-6:
            improving.append(int(report["selected_epoch"]))
    return max(improving) if improving else 1


def sequence_loss(model: CausalBranchRouter, episode: BranchEpisode, device: torch.device) -> Tensor:
    logits = model(episode.feature.to(device))[0]
    target = episode.target.to(device)
    weight = (
        episode.valid.to(device).float() * episode.sample_weight.to(device)
    ).clamp(0.0, 1.0)
    if float(weight.sum()) <= 0.0:
        return logits.sum() * 0.0
    cross_entropy = -(target * logits.log_softmax(dim=-1)).sum(dim=-1)
    probability = logits.softmax(dim=-1)
    smooth = (
        (probability[1:] - probability[:-1]).abs().mean()
        if logits.shape[0] > 1
        else logits.sum() * 0.0
    )
    return (cross_entropy * weight).sum() / weight.sum().clamp_min(1.0e-6) + 0.01 * smooth


@torch.inference_mode()
def calibration_utility(
    model: CausalBranchRouter,
    episodes: list[BranchEpisode],
    *,
    base_index: int,
    margin: float,
    device: torch.device,
) -> tuple[float, float, float]:
    selected_total = base_total = accepted_total = weight_total = 0.0
    model.eval()
    for episode in episodes:
        logits = model(episode.feature.to(device))[0]
        selected, accepted = hard_branch_selection(
            logits, base_index=base_index, margin=margin
        )
        utility = episode.utility.to(device)
        weight = (
            episode.valid.to(device).float() * episode.sample_weight.to(device)
        ).clamp(0.0, 1.0)
        selected_total += float(
            (utility.gather(1, selected.unsqueeze(1)).squeeze(1) * weight).sum().cpu()
        )
        base_total += float((utility[:, base_index] * weight).sum().cpu())
        accepted_total += float((accepted.float() * weight).sum().cpu())
        weight_total += float(weight.sum().cpu())
    if weight_total <= 0.0:
        return float("-inf"), 0.0, 0.0
    return (
        selected_total / weight_total,
        base_total / weight_total,
        accepted_total / weight_total,
    )


def calibration_utility_from_logits(
    predictions: list[tuple[BranchEpisode, Tensor]],
    *,
    base_index: int,
    margin: float,
) -> tuple[float, float, float]:
    """Score cross-fitted logits without reusing a sequence for fitting."""

    selected_total = base_total = accepted_total = weight_total = 0.0
    for episode, raw_logits in predictions:
        logits = raw_logits.detach().cpu()
        selected, accepted = hard_branch_selection(
            logits, base_index=base_index, margin=margin
        )
        utility = episode.utility.cpu()
        weight = (
            episode.valid.cpu().float() * episode.sample_weight.cpu()
        ).clamp(0.0, 1.0)
        selected_total += float(
            (utility.gather(1, selected.unsqueeze(1)).squeeze(1) * weight).sum()
        )
        base_total += float((utility[:, base_index] * weight).sum())
        accepted_total += float((accepted.float() * weight).sum())
        weight_total += float(weight.sum())
    if weight_total <= 0.0:
        return float("-inf"), 0.0, 0.0
    return (
        selected_total / weight_total,
        base_total / weight_total,
        accepted_total / weight_total,
    )


def train_router_fold(
    fit: list[BranchEpisode],
    calibration: list[BranchEpisode],
    source_replay: list[BranchEpisode],
    *,
    epochs: int,
    seed: int,
    base_index: int,
    device: torch.device,
    source_replay_weight: float,
) -> tuple[dict[str, Tensor], int, list[dict[str, float]]]:
    """Train one OOF model and choose its epoch only on held-out sequences."""

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    model = CausalBranchRouter().to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=3.0e-3, weight_decay=1.0e-4
    )
    best_state: dict[str, Tensor] | None = None
    best_score = float("-inf")
    best_epoch = 0
    history: list[dict[str, float]] = []
    for epoch in range(1, int(epochs) + 1):
        model.train()
        ordered = weighted_training_schedule(
            fit,
            source_replay,
            source_replay_weight=source_replay_weight,
        )
        random.shuffle(ordered)
        losses: list[float] = []
        target_losses: list[float] = []
        source_losses: list[float] = []
        for group, episode, loss_weight in ordered:
            optimizer.zero_grad(set_to_none=True)
            raw_loss = sequence_loss(model, episode, device)
            loss = raw_loss * float(loss_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
            (source_losses if group == "source" else target_losses).append(
                float(raw_loss.detach().cpu())
            )
        utility, base_utility, coverage = calibration_utility(
            model,
            calibration,
            base_index=base_index,
            margin=0.0,
            device=device,
        )
        history.append(
            {
                "epoch": float(epoch),
                "fit_loss": float(np.mean(losses)),
                "target_fit_loss": float(np.mean(target_losses)),
                "source_replay_loss": (
                    float(np.mean(source_losses)) if source_losses else 0.0
                ),
                "calibration_utility_at_zero_margin": utility,
                "calibration_base_utility": base_utility,
                "calibration_coverage_at_zero_margin": coverage,
            }
        )
        if utility > best_score:
            best_score = utility
            best_epoch = epoch
            best_state = {
                name: value.detach().cpu().clone()
                for name, value in model.state_dict().items()
            }
    if best_state is None:
        raise RuntimeError("branch-router OOF fold produced no checkpoint")
    return best_state, best_epoch, history


def train_final_router(
    support: list[BranchEpisode],
    source_replay: list[BranchEpisode],
    *,
    epochs: int,
    seed: int,
    device: torch.device,
    source_replay_weight: float,
) -> tuple[dict[str, Tensor], list[float]]:
    """Train the deployable router from random initialization on all Support."""

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    model = CausalBranchRouter().to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=3.0e-3, weight_decay=1.0e-4
    )
    history: list[float] = []
    for _ in range(int(epochs)):
        model.train()
        ordered = weighted_training_schedule(
            support,
            source_replay,
            source_replay_weight=source_replay_weight,
        )
        random.shuffle(ordered)
        losses: list[float] = []
        for _, episode, loss_weight in ordered:
            optimizer.zero_grad(set_to_none=True)
            loss = sequence_loss(model, episode, device) * float(loss_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        history.append(float(np.mean(losses)))
    return (
        {
            name: value.detach().cpu().clone()
            for name, value in model.state_dict().items()
        },
        history,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-id", required=True)
    parser.add_argument("--route", required=True)
    parser.add_argument("--primitive", required=True)
    parser.add_argument("--implementation-id", required=True)
    parser.add_argument("--parent-branch", choices=BRANCH_ORDER, required=True)
    parser.add_argument("--parent-selection-sha256")
    parser.add_argument("--parent-selection-policy-id")
    parser.add_argument("--target-fit-root", type=Path, required=True)
    parser.add_argument("--source-replay-root", type=Path, required=True)
    parser.add_argument("--branch-prediction-root", type=Path, required=True)
    parser.add_argument("--empty-guard-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--calibration-fraction", type=float, default=0.25)
    parser.add_argument("--oof-folds", type=int, default=3)
    parser.add_argument("--source-replay-weight", type=float, default=0.35)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists():
        raise FileExistsError(f"branch-router output already exists: {args.output_dir}")
    if recipe_for_implementation(args.implementation_id) != "branch_router":
        raise ValueError("implementation is not registered to the branch-router recipe")
    if args.route in _DIRECT_ROUTES and not valid_sha256(args.parent_selection_sha256):
        raise ValueError("direct-route branch router requires a signed parent-selection SHA256")
    if args.route in _DIRECT_ROUTES and not is_supported_parent_selection_policy(
        args.parent_selection_policy_id
    ):
        raise ValueError("direct-route branch router requires the current parent-selection policy")
    for path in (
        args.target_fit_root / "ROUTE_RUNTIME_MANIFEST.json",
        args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json",
        args.empty_guard_manifest,
    ):
        if not path.is_file():
            raise FileNotFoundError(f"required hash-bound training asset missing: {path}")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for branch-router shadow training")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    branch_index, branch_manifest = load_branch_prediction_root(
        args.branch_prediction_root
    )
    support = load_runtime_episodes(
        args.target_fit_root,
        expected_route=args.route,
        expected_parent=args.parent_branch,
        expected_role="fit",
        branch_index=branch_index,
    )
    source_replay_sequences = runtime_manifest_sequences(
        args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json",
        expected_route=args.route,
        expected_role="source_replay",
    )
    source_replay = load_runtime_episodes(
        args.source_replay_root,
        expected_route=args.route,
        expected_parent=args.parent_branch,
        expected_role="source_replay",
        branch_index=branch_index,
    )
    if tuple(item.sequence for item in source_replay) != source_replay_sequences:
        raise ValueError("Source replay manifest/archive sequence mismatch")
    base_index = BRANCH_ORDER.index(args.parent_branch)
    folds = grouped_sequence_folds(
        support, fold_count=args.oof_folds, seed=args.seed
    )
    oof_predictions: list[tuple[BranchEpisode, Tensor]] = []
    fold_reports: list[dict[str, Any]] = []
    for fold_index, (fit, calibration) in enumerate(folds):
        fold_seed = int(args.seed) + fold_index * 1009
        state, selected_epoch, history = train_router_fold(
            fit,
            calibration,
            source_replay,
            epochs=args.epochs,
            seed=fold_seed,
            base_index=base_index,
            device=device,
            source_replay_weight=args.source_replay_weight,
        )
        fold_model = CausalBranchRouter().to(device)
        fold_model.load_state_dict(state, strict=True)
        fold_model.eval()
        with torch.inference_mode():
            for episode in calibration:
                oof_predictions.append(
                    (episode, fold_model(episode.feature.to(device))[0].cpu())
                )
        fold_report = {
            "fold": fold_index,
            "seed": fold_seed,
            "fit_sequences": [item.sequence for item in fit],
            "calibration_sequences": [item.sequence for item in calibration],
            "selected_epoch": selected_epoch,
            "selected_epoch_metrics": history[selected_epoch - 1],
        }
        fold_reports.append(fold_report)
        print(json.dumps(fold_report, sort_keys=True), flush=True)
    margins = (0.0, 0.02, 0.05, 0.08, 0.12, 0.16, 0.22, 0.30)
    options = []
    for margin in margins:
        utility, base_utility, coverage = calibration_utility_from_logits(
            oof_predictions, base_index=base_index, margin=margin
        )
        options.append(
            {
                "margin": margin,
                "utility": utility,
                "base_utility": base_utility,
                "coverage": coverage,
            }
        )
    non_harmful = [
        item for item in options if item["utility"] >= item["base_utility"] - 1.0e-6
    ]
    chosen = max(
        non_harmful or options,
        key=lambda item: (item["utility"], item["coverage"], -item["margin"]),
    )
    final_epochs = select_final_training_epoch(fold_reports)
    best_state, final_loss_history = train_final_router(
        support,
        source_replay,
        epochs=final_epochs,
        seed=args.seed,
        device=device,
        source_replay_weight=args.source_replay_weight,
    )
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = args.output_dir / "best.pt"
    checkpoint = {
        "schema_version": "agent_jsac_branch_router_checkpoint_v1",
        "recipe_type": "branch_router",
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "implementation_id": args.implementation_id,
        "parent_branch": args.parent_branch,
        "parent_selection_sha256": args.parent_selection_sha256,
        "parent_selection_policy_id": args.parent_selection_policy_id,
        "branch_order": BRANCH_ORDER,
        "model_kwargs": {"input_dim": 18, "hidden_dim": 48},
        "model_state": best_state,
        "selected_epoch": final_epochs,
        "selection_margin": chosen["margin"],
        "support_calibration": {
            "mode": "sequence_grouped_out_of_fold",
            "fold_count": len(folds),
            "chosen": chosen,
            "all_margins": options,
        },
        "source_replay_weight": args.source_replay_weight,
        "execution_weight": 0.0,
        "historical_checkpoint_import": False,
        "forbidden_reads": {
            "target_final_bev_read": False,
            "development_label_read": False,
            "locked_test_read": False,
            "depth_read": False,
            "right_rgb_read": False,
            "manual_ra_anchor_read": False,
        },
    }
    torch.save(checkpoint, checkpoint_path)
    branch_manifest_path = args.branch_prediction_root / "PREDICTION_FREEZE.json"
    receipt = {
        "schema_version": "agent_jsac_branch_router_training_receipt_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "candidate_id": args.candidate_id,
        "route": args.route,
        "primitive": args.primitive,
        "implementation_id": args.implementation_id,
        "recipe_type": "branch_router",
        "parent_branch": args.parent_branch,
        "parent_selection_sha256": args.parent_selection_sha256,
        "parent_selection_policy_id": args.parent_selection_policy_id,
        "target_fit_sequences": [item.sequence for item in sorted(support, key=lambda item: item.sequence)],
        "target_calibration_sequences": [item.sequence for item in sorted(support, key=lambda item: item.sequence)],
        "calibration_role": "sequence_grouped_out_of_fold_only",
        "oof_folds": fold_reports,
        "source_replay_sequences": list(source_replay_sequences),
        "source_replay_role": "source_retention_training_replay",
        "source_replay_weight": args.source_replay_weight,
        "support_canary_read": False,
        "development_read": False,
        "locked_test_read": False,
        "selected_epoch": final_epochs,
        "selection_margin": chosen["margin"],
        "support_calibration": {
            "mode": "sequence_grouped_out_of_fold",
            "fold_count": len(folds),
            "chosen": chosen,
            "all_margins": options,
        },
        "checkpoint_path": str(checkpoint_path.resolve()),
        "checkpoint_sha256": sha256(checkpoint_path),
        "execution_weight": 0.0,
        "branch_prediction_manifest": str(branch_manifest_path.resolve()),
        "branch_prediction_manifest_sha256": sha256(branch_manifest_path),
        "branch_checkpoint_hashes": branch_checkpoint_hashes(branch_manifest),
        "runtime_manifests": {
            "target_support": sha256(
                args.target_fit_root / "ROUTE_RUNTIME_MANIFEST.json"
            ),
            "source_replay": sha256(
                args.source_replay_root / "ROUTE_RUNTIME_MANIFEST.json"
            ),
        },
        "empty_guard_sha256": sha256(args.empty_guard_manifest),
        "implementation_files": {
            "trainer": sha256(Path(__file__).resolve()),
            "model": sha256(ROOT / "src" / "agent_jsac" / "branch_router_recipe.py"),
        },
        "history": [
            {"epoch": index + 1, "target_fit_loss": loss}
            for index, loss in enumerate(final_loss_history)
        ],
    }
    (args.output_dir / "TRAINING_RECEIPT.json").write_text(
        json.dumps(receipt, ensure_ascii=True, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "candidate_id": args.candidate_id,
                "recipe_type": "branch_router",
                "selected_epoch": final_epochs,
                "selection_margin": chosen["margin"],
                "oof_utility": chosen["utility"],
                "oof_base_utility": chosen["base_utility"],
                "checkpoint_sha256": receipt["checkpoint_sha256"],
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
