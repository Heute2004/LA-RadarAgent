from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor
from torch.nn import functional as functional

from .e3_training import e3_loss_terms
from .losses import QualityAwareBEVLoss
from .models.e4_experts import _cartesian_to_rc


@dataclass(frozen=True)
class E4LossOutput:
    total: Tensor
    base: object
    mixture_nll: Tensor
    path_nll: Tensor


def _aurf_mixture_nll(output: dict[str, Tensor], target_xy_m: Tensor, target_mask: Tensor) -> Tensor:
    if "mixture_offset_rc_m" not in output or not bool(target_mask.any()):
        return target_xy_m.new_zeros(())
    base_xy_m = output["base_peak_xy_m"][target_mask]
    target_rc = _cartesian_to_rc(target_xy_m[target_mask] - base_xy_m, base_xy_m)
    center = output["mixture_offset_rc_m"][target_mask]
    std = output["mixture_std_rc_m"][target_mask].clamp_min(0.05)
    log_weight = torch.log_softmax(output["mixture_logits"][target_mask], dim=1)
    z = (target_rc[:, None] - center) / std
    component_log_prob = -0.5 * (z.square() + 2.0 * std.log() + torch.log(torch.tensor(2.0 * torch.pi, device=std.device))).sum(dim=-1)
    return -torch.logsumexp(log_weight + component_log_prob, dim=1).mean()


def _sdp_path_nll(output: dict[str, Tensor], history_target_xy_m: Tensor, history_target_valid: Tensor, target_mask: Tensor, radius_m: float = 0.45) -> Tensor:
    if "candidate_history_xy_m" not in output or not bool(target_mask.any()):
        return history_target_xy_m.new_zeros(())
    candidates = output["candidate_history_xy_m"][target_mask]
    logits = output["tbd_path_logits"][target_mask]
    targets = history_target_xy_m[target_mask]
    valid = history_target_valid[target_mask]
    distance = (candidates - targets[:, :, None]).norm(dim=-1)
    nearest_distance, nearest_index = distance.min(dim=-1)
    supervised = valid & (nearest_distance <= radius_m)
    if not bool(supervised.any()):
        return logits.new_zeros(())
    log_probability = torch.log_softmax(logits, dim=-1)
    chosen = log_probability.gather(2, nearest_index.unsqueeze(-1)).squeeze(-1)
    return -chosen[supervised].mean()


def e4_loss_terms(
    output: dict[str, Tensor],
    target_xy_m: Tensor,
    history_target_xy_m: Tensor,
    history_target_valid: Tensor,
    sample_weight: Tensor,
    identity_mask: Tensor,
    criterion: QualityAwareBEVLoss,
    acceptance_enabled: bool,
    mixture_weight: float = 0.12,
    path_weight: float = 0.12,
    **base_kwargs: float,
) -> E4LossOutput:
    """E4 adds one mechanism-specific training-only supervision term to E3 safety losses."""
    base = e3_loss_terms(
        output=output,
        target_xy_m=target_xy_m,
        history_target_xy_m=history_target_xy_m,
        history_target_valid=history_target_valid,
        sample_weight=sample_weight,
        identity_mask=identity_mask,
        criterion=criterion,
        acceptance_enabled=acceptance_enabled,
        gain_enabled=False,
        **base_kwargs,
    )
    target_mask = ~identity_mask.bool()
    mixture_nll = _aurf_mixture_nll(output, target_xy_m, target_mask)
    path_nll = _sdp_path_nll(output, history_target_xy_m, history_target_valid, target_mask)
    return E4LossOutput(
        total=base.total + mixture_weight * mixture_nll + path_weight * path_nll,
        base=base,
        mixture_nll=mixture_nll.detach(),
        path_nll=path_nll.detach(),
    )
