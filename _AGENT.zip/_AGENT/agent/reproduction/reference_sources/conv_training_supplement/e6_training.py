from __future__ import annotations

from dataclasses import dataclass

from torch import Tensor
from torch.nn import functional as functional

from .e3_training import e3_loss_terms
from .losses import QualityAwareBEVLoss


@dataclass(frozen=True)
class E6LossOutput:
    total: Tensor
    base: object
    center: Tensor
    compactness: Tensor


def e6_loss_terms(
    output: dict[str, Tensor],
    target_xy_m: Tensor,
    history_target_xy_m: Tensor,
    history_target_valid: Tensor,
    sample_weight: Tensor,
    identity_mask: Tensor,
    criterion: QualityAwareBEVLoss,
    acceptance_enabled: bool,
    center_weight: float = 0.25,
    compactness_weight: float = 0.02,
    **base_kwargs: float,
) -> E6LossOutput:
    """RHEM keeps all E3 safety terms and adds local-centre/support supervision."""
    base = e3_loss_terms(
        output=output,
        target_xy_m=target_xy_m,
        history_target_xy_m=history_target_xy_m,
        history_target_valid=history_target_valid,
        sample_weight=sample_weight,
        identity_mask=identity_mask,
        criterion=criterion,
        acceptance_enabled=acceptance_enabled,
        gain_enabled=False,
        **base_kwargs,
    )
    target_mask = ~identity_mask.bool()
    zero = target_xy_m.new_zeros(())
    if not bool(target_mask.any()):
        return E6LossOutput(total=base.total, base=base, center=zero, compactness=zero)
    center = functional.smooth_l1_loss(output["proposal_xy_m"][target_mask], target_xy_m[target_mask])
    compactness = output["support_compactness"][target_mask]
    # Preserve a compact connected support without allowing a one-cell collapse.
    compactness_penalty = (functional.relu(0.04 - compactness) + 0.15 * functional.relu(compactness - 0.50)).mean()
    total = base.total + center_weight * center + compactness_weight * compactness_penalty
    return E6LossOutput(total=total, base=base, center=center.detach(), compactness=compactness_penalty.detach())
