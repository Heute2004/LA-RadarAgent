from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import torch
from torch import Tensor
from torch.utils.data import ConcatDataset, DataLoader, Dataset

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from radar_bev.data import RadarWindowDataset
from radar_bev.e4_training import e4_loss_terms
from radar_bev.e5_training import e5_loss_terms
from radar_bev.e6_training import e6_loss_terms
from radar_bev.evaluation import evaluate_single_person_predictions, extract_single_peak
from radar_bev.geometry import BEVGeometry
from radar_bev.lockbox_v3 import (
    DEV_SPLIT,
    TRAIN_SPLIT,
    validate_training_manifest,
    validate_training_routing_manifest,
)
from radar_bev.losses import QualityAwareBEVLoss
from radar_bev.models import build_model
from radar_bev.training import has_converged_early_stop, manifest_sha256, seed_everything


E4_ROUTE_TO_EXPERT = {
    "indoor_clutter": "aurf_lite",
    "open_outdoor_weak_return": "sdp_tbd",
}

E5_ROUTE_TO_EXPERT = {
    "indoor_clutter": "scar",
    "open_outdoor_weak_return": "ltge_cen",
}

E6_ROUTE_TO_EXPERT = {
    "indoor_clutter": "rhem",
}


class TaggedDataset(Dataset[dict[str, Tensor | str]]):
    def __init__(self, dataset: RadarWindowDataset, identity_negative: bool) -> None:
        self.dataset = dataset
        self.identity_negative = identity_negative

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        item = dict(self.dataset[index])
        item["is_identity_negative"] = torch.tensor(self.identity_negative, dtype=torch.bool)
        return item


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a frozen-DREAM E4 route challenger")
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--routing-manifest", required=True)
    parser.add_argument("--expert-family", choices=("e4", "e5", "e6"), default="e4")
    parser.add_argument("--adapter-route", required=True, choices=tuple(sorted(set(E4_ROUTE_TO_EXPERT) | set(E5_ROUTE_TO_EXPERT))))
    parser.add_argument("--base-checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--train-epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--clip-length", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=8e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=3407)
    parser.add_argument("--eligibility", choices=("first", "later"), default="later")
    parser.add_argument("--negative-ratio", type=float, default=0.25)
    parser.add_argument("--candidate-count", type=int, default=8)
    parser.add_argument("--rd-mode", choices=("off", "mti", "dual"), default="off")
    parser.add_argument("--logit-cap", type=float, default=3.0)
    parser.add_argument("--coordinate-weight", type=float, default=0.05)
    parser.add_argument("--consistency-weight", type=float, default=0.01)
    parser.add_argument("--residual-weight", type=float, default=1e-4)
    parser.add_argument("--polar-residual-weight", type=float, default=1e-4)
    parser.add_argument("--regret-weight", type=float, default=0.05)
    parser.add_argument("--covariance-weight", type=float, default=0.02)
    parser.add_argument("--acceptance-weight", type=float, default=0.10)
    parser.add_argument("--identity-weight", type=float, default=0.25)
    parser.add_argument("--mixture-weight", type=float, default=0.12)
    parser.add_argument("--path-weight", type=float, default=0.12)
    parser.add_argument("--acceptance-warmup-epochs", type=int, default=3)
    parser.add_argument("--early-stop-patience", type=int, default=4)
    parser.add_argument("--progress-every-batches", type=int, default=200)
    parser.add_argument("--max-train-batches", type=int, default=0)
    parser.add_argument("--max-eval-batches", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--ram-cache", action="store_true")
    parser.add_argument("--no-amp", action="store_true")
    return parser.parse_args()


def _route_sequences(routing_manifest: Path, route: str, split: str) -> set[str]:
    sequences: set[str] = set()
    for raw_line in routing_manifest.read_text(encoding="utf-8").splitlines():
        if raw_line.strip():
            record = json.loads(raw_line)
            if record.get("adapter_route") == route and record.get("split", "").strip().lower() == split.lower() and bool(record.get("eligible_for_router_training", False)):
                sequences.add(str(record["sequence_name"]))
    if not sequences:
        raise ValueError(f"No {split} sequences are eligible for route={route!r}")
    return sequences


def _negative_sequences(routing_manifest: Path, route: str, route_count: int, ratio: float, seed: int) -> set[str]:
    if ratio < 0.0:
        raise ValueError("negative_ratio must be non-negative")
    candidates: set[str] = set()
    for raw_line in routing_manifest.read_text(encoding="utf-8").splitlines():
        if raw_line.strip():
            record = json.loads(raw_line)
            if record.get("adapter_route") != route and record.get("split", "").strip().lower() == "train" and bool(record.get("eligible_for_router_training", False)):
                candidates.add(str(record["sequence_name"]))
    requested = min(len(candidates), max(0, round(route_count * ratio)))
    return set(random.Random(seed).sample(sorted(candidates), requested)) if requested else set()


def _to_device(batch: dict[str, Tensor | str], device: torch.device) -> dict[str, Tensor | str]:
    return {key: value.to(device, non_blocking=True) if isinstance(value, Tensor) else value for key, value in batch.items()}


def _candidate_audit(output: dict[str, Tensor], batch: dict[str, Tensor | str]) -> tuple[float, float, int, int]:
    if "candidate_history_xy_m" not in output:
        return 0.0, 0.0, 0, 0
    candidate = output["candidate_history_xy_m"].detach()
    target = batch["history_target_xy_m"]
    valid = batch["history_target_valid"].bool()
    distance = (candidate - target[:, :, None]).norm(dim=-1).min(dim=-1).values
    covered = (distance <= 0.45) & valid
    current_valid = valid[:, -1]
    return float(covered.sum().item()), float(valid.sum().item()), int((covered[:, -1] & current_valid).sum().item()), int(current_valid.sum().item())


def _run_epoch(model: torch.nn.Module, loader: DataLoader, optimizer: torch.optim.Optimizer | None, criterion: QualityAwareBEVLoss, device: torch.device, amp: bool, acceptance_enabled: bool, args: argparse.Namespace, max_batches: int) -> dict[str, float]:
    training = optimizer is not None
    model.train(training)
    names = ("loss", "localization", "consistency", "residual_energy", "polar_residual_energy", "regret", "covariance_nll", "acceptance", "identity")
    if args.expert_family == "e4":
        names = (*names, "mixture_nll", "path_nll")
    elif args.expert_family == "e5":
        names = (*names, "coarse", "fine", "threshold_flip")
    else:
        names = (*names, "center", "compactness")
    totals = {name: 0.0 for name in names}
    samples = 0
    predictions: list[Tensor] = []
    confidences: list[Tensor] = []
    base_predictions: list[Tensor] = []
    base_confidences: list[Tensor] = []
    targets: list[Tensor] = []
    acceptances: list[Tensor] = []
    durations: list[float] = []
    audit_covered = audit_valid = audit_current_covered = audit_current_valid = 0.0
    for batch_index, raw_batch in enumerate(loader, start=1):
        if max_batches and batch_index > max_batches:
            break
        batch = _to_device(raw_batch, device)
        if not training and device.type == "cuda":
            torch.cuda.synchronize(device)
        started = perf_counter()
        with torch.set_grad_enabled(training), torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp and device.type == "cuda"):
            if args.rd_mode == "off":
                output = model(batch["radar"])
            elif args.rd_mode == "mti":
                output = model(batch["radar"], rd_mti=batch["rd_mti"])
            else:
                output = model(batch["radar"], rd=batch["rd"], rd_mti=batch["rd_mti"])
            common_loss_args = dict(
                output=output, target_xy_m=batch["target_xy_m"], history_target_xy_m=batch["history_target_xy_m"],
                history_target_valid=batch["history_target_valid"], sample_weight=batch["sample_weight"],
                identity_mask=batch["is_identity_negative"], criterion=criterion, acceptance_enabled=acceptance_enabled,
                consistency_weight=args.consistency_weight, residual_weight=args.residual_weight,
                polar_residual_weight=args.polar_residual_weight, regret_weight=args.regret_weight,
                covariance_weight=args.covariance_weight, acceptance_weight=args.acceptance_weight,
                identity_weight=args.identity_weight,
            )
            if args.expert_family == "e4":
                losses = e4_loss_terms(**common_loss_args, mixture_weight=args.mixture_weight, path_weight=args.path_weight)
            elif args.expert_family == "e5":
                losses = e5_loss_terms(**common_loss_args)
            else:
                losses = e6_loss_terms(**common_loss_args)
        if training:
            losses.total.backward()
            torch.nn.utils.clip_grad_norm_(model.expert_parameters(), max_norm=5.0)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
        if not training and device.type == "cuda":
            torch.cuda.synchronize(device)
        duration = perf_counter() - started
        count = int(batch["radar"].shape[0])
        samples += count
        values = {
            "loss": losses.total,
            "localization": losses.base.localization,
            "consistency": losses.base.consistency,
            "residual_energy": losses.base.residual_energy,
            "polar_residual_energy": losses.base.polar_residual_energy,
            "regret": losses.base.regret,
            "covariance_nll": losses.base.covariance_nll,
            "acceptance": losses.base.acceptance,
            "identity": losses.base.identity,
        }
        if args.expert_family == "e4":
            values["mixture_nll"] = losses.mixture_nll
            values["path_nll"] = losses.path_nll
        elif args.expert_family == "e5":
            values["coarse"] = losses.coarse
            values["fine"] = losses.fine
            values["threshold_flip"] = losses.threshold_flip
        else:
            values["center"] = losses.center
            values["compactness"] = losses.compactness
        for name, value in values.items():
            totals[name] += float(value.detach().item()) * count
        if training and args.progress_every_batches and batch_index % args.progress_every_batches == 0:
            print(json.dumps({"phase": "train", "batch": batch_index, "mean_loss": totals["loss"] / samples}), flush=True)
        if not training:
            prediction, confidence = extract_single_peak(output["logits"], BEVGeometry())
            base_prediction, base_confidence = extract_single_peak(output["base_logits"], BEVGeometry())
            predictions.append(prediction.cpu())
            confidences.append(confidence.cpu())
            base_predictions.append(base_prediction.cpu())
            base_confidences.append(base_confidence.cpu())
            targets.append(batch["target_xy_m"].cpu())
            acceptances.append(output["acceptance"].detach().cpu())
            durations.append(duration)
            covered, valid, current_covered, current_valid = _candidate_audit(output, batch)
            audit_covered += covered
            audit_valid += valid
            audit_current_covered += current_covered
            audit_current_valid += current_valid
    result = {name: value / max(samples, 1) for name, value in totals.items()}
    result["samples"] = float(samples)
    if not training:
        prediction = torch.cat(predictions)
        target = torch.cat(targets)
        confidence = torch.cat(confidences)
        base_prediction = torch.cat(base_predictions)
        base_confidence = torch.cat(base_confidences)
        result.update(evaluate_single_person_predictions(confidence, prediction, target, distance_thresholds=(0.25, 0.3, 0.4, 0.5, 1.0)))
        result.update({f"base_{key}": value for key, value in evaluate_single_person_predictions(base_confidence, base_prediction, target, distance_thresholds=(0.25, 0.3, 0.4, 0.5, 1.0)).items()})
        acceptance = torch.cat(acceptances)
        result["acceptance_mean"] = float(acceptance.mean().item())
        result["acceptance_coverage_0p5"] = float((acceptance >= 0.5).float().mean().item())
        result["fallback_rate_0p5"] = 1.0 - result["acceptance_coverage_0p5"]
        result["latency_ms_per_frame"] = 1000.0 * sum(durations) / max(samples, 1)
        result["fps"] = 1000.0 / max(result["latency_ms_per_frame"], 1e-6)
        if audit_valid:
            result["candidate_history_recall_0p45"] = audit_covered / audit_valid
            result["candidate_current_recall_0p45"] = audit_current_covered / max(audit_current_valid, 1.0)
    return result


def main() -> None:
    args = parse_args()
    validate_training_manifest(Path(args.manifest), scope="base")
    validate_training_routing_manifest(Path(args.routing_manifest), scope="base")
    route_to_expert = {"e4": E4_ROUTE_TO_EXPERT, "e5": E5_ROUTE_TO_EXPERT, "e6": E6_ROUTE_TO_EXPERT}[args.expert_family]
    if args.adapter_route not in route_to_expert:
        raise ValueError(f"route={args.adapter_route!r} is unavailable for expert family={args.expert_family!r}")
    if args.rd_mode != "off" and args.expert_family != "e5":
        raise ValueError("RD sidecar is currently implemented only for the E5 LTGE-CEN route")
    if args.rd_mode != "off" and args.adapter_route != "open_outdoor_weak_return":
        raise ValueError("RD sidecar is currently implemented only for open_outdoor_weak_return")
    expert_kind = route_to_expert[args.adapter_route]
    output_dir = Path(args.output_dir)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty output directory: {output_dir}")
    seed_everything(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    routing_manifest = Path(args.routing_manifest)
    route_train_sequences = _route_sequences(routing_manifest, args.adapter_route, TRAIN_SPLIT.lower())
    route_eval_sequences = _route_sequences(routing_manifest, args.adapter_route, DEV_SPLIT.lower())
    negative_sequences = _negative_sequences(routing_manifest, args.adapter_route, len(route_train_sequences), args.negative_ratio, args.seed)
    common = dict(
        data_root=Path(args.data_root), manifest_path=Path(args.manifest), clip_length=args.clip_length,
        eligibility=args.eligibility, cache_in_memory=args.ram_cache, include_aux_views=args.rd_mode != "off",
        aux_views=() if args.rd_mode == "off" else (("rd_mti",) if args.rd_mode == "mti" else ("rd", "rd_mti")),
    )
    route_train = RadarWindowDataset(split=TRAIN_SPLIT, allowed_sequences=route_train_sequences, **common)
    train_parts: list[Dataset] = [TaggedDataset(route_train, False)]
    if negative_sequences:
        train_parts.append(TaggedDataset(RadarWindowDataset(split=TRAIN_SPLIT, allowed_sequences=negative_sequences, **common), True))
    train_set: Dataset = ConcatDataset(train_parts)
    eval_set = TaggedDataset(RadarWindowDataset(split=DEV_SPLIT, allowed_sequences=route_eval_sequences, **common), False)
    loader_args = {"batch_size": args.batch_size, "num_workers": 0 if args.ram_cache else args.num_workers, "pin_memory": device.type == "cuda", "persistent_workers": (not args.ram_cache) and args.num_workers > 0}
    train_loader = DataLoader(train_set, shuffle=True, **loader_args)
    eval_loader = DataLoader(eval_set, shuffle=False, **loader_args)
    model_kwargs: dict[str, object] = {
        "expert_kind": expert_kind, "candidate_count": args.candidate_count, "logit_cap": args.logit_cap,
    }
    if args.expert_family == "e5":
        model_kwargs["rd_mode"] = args.rd_mode
    model = build_model(f"dream_{args.expert_family}_route_expert", **model_kwargs)
    base_sha256 = model.load_base_checkpoint(args.base_checkpoint)
    model = model.to(device)
    criterion = QualityAwareBEVLoss(coordinate_weight=args.coordinate_weight).to(device)
    optimizer = torch.optim.AdamW(model.expert_parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.train_epochs)
    output_dir.mkdir(parents=True, exist_ok=False)
    metadata = {
        "stage": f"M4_{args.expert_family.upper()}_oracle_route_challenger", "model": type(model).__name__, "expert_family": args.expert_family, "expert_kind": expert_kind, "adapter_route": args.adapter_route,
        "base_model": "DREAM-BEV/m_rodnet_lite", "base_checkpoint": str(Path(args.base_checkpoint).resolve()), "base_checkpoint_sha256": base_sha256,
        "manifest_sha256": manifest_sha256(args.manifest), "routing_manifest_sha256": hashlib.sha256(routing_manifest.read_bytes()).hexdigest(),
        "route_train_sequences": sorted(route_train_sequences), "identity_negative_sequences": sorted(negative_sequences), "route_eval_sequences": sorted(route_eval_sequences),
        "route_train_samples": len(route_train), "total_train_samples": len(train_set), "eval_samples": len(eval_set),
        "trainable_parameters": sum(parameter.numel() for parameter in model.expert_parameters()), "frozen_backbone_parameters": sum(parameter.numel() for parameter in model.backbone.parameters()),
        "runtime_input_modalities": ["RA", "RA-MIT"] + ([] if args.rd_mode == "off" else (["RD-MIT"] if args.rd_mode == "mti" else ["RD", "RD-MIT"])),
        "checkpoint_selection_metric": "ap_0p3m", "evaluation_protocol": "Lockbox V3 Train + Development Val; Locked Test is physically absent", "args": vars(args),
    }
    (output_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    history: list[dict[str, float | int]] = []
    best: dict[str, float | int] = {"ap_0p3m": -1.0}
    for epoch in range(1, args.train_epochs + 1):
        acceptance_enabled = epoch > args.acceptance_warmup_epochs
        train_metrics = _run_epoch(model, train_loader, optimizer, criterion, device, not args.no_amp, acceptance_enabled, args, args.max_train_batches)
        eval_metrics = _run_epoch(model, eval_loader, None, criterion, device, not args.no_amp, acceptance_enabled, args, args.max_eval_batches)
        scheduler.step()
        record = {"epoch": epoch, "lr": optimizer.param_groups[0]["lr"], **{f"train_{key}": value for key, value in train_metrics.items()}, **{f"eval_{key}": value for key, value in eval_metrics.items()}}
        history.append(record)
        print(json.dumps(record, ensure_ascii=True), flush=True)
        if float(eval_metrics["ap_0p3m"]) > float(best["ap_0p3m"]):
            best = {"epoch": epoch, **eval_metrics}
            torch.save({"model": type(model).__name__, "expert_family": args.expert_family, "adapter_route": args.adapter_route, "expert_kind": expert_kind, "rd_mode": args.rd_mode, "base_checkpoint_sha256": base_sha256, "expert_state": model.expert_state_dict(), "metrics": best}, output_dir / "best_expert.pt")
        (output_dir / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
        (output_dir / "best_metrics.json").write_text(json.dumps(best, indent=2), encoding="utf-8")
        if epoch < args.train_epochs and has_converged_early_stop([float(item["eval_ap_0p3m"]) for item in history], args.early_stop_patience):
            break
    (output_dir / "training_complete.json").write_text(json.dumps({"completed": True, "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "requested_epochs": args.train_epochs, "completed_epochs": len(history), "best_epoch": best.get("epoch"), "best_metrics": best}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
