from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import torch

from agent_jsac.evolution_manifest import load_evolution_manifest
from agent_jsac.registered_radar_contract import RegisteredRadarToolContext, file_sha256
from agent_jsac.scaa_data import load_manifest_packs
from agent_jsac.scaa_training import TrainingConfig, train_shadow_adapter


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the frozen indoor-clutter SCAA Shadow candidate.")
    parser.add_argument("--manifest", type=Path, default=Path("configs/indoor_clutter_evolution_pilot.json"))
    parser.add_argument("--runtime-root", type=Path)
    parser.add_argument("--label-root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--split-manifest", type=Path)
    parser.add_argument("--split-manifest-sha256")
    parser.add_argument("--registered-result", type=Path)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    manifest = load_evolution_manifest(args.manifest)
    packs = load_manifest_packs(
        manifest,
        runtime_root=args.runtime_root,
        label_root=args.label_root,
        roles=("shadow_fit", "shadow_calibration"),
    )
    training = manifest.training
    config = TrainingConfig(
        seed=manifest.seed,
        window=int(training["window"]),
        hidden_dim=int(training["hidden_dim"]),
        epochs=int(training["epochs"]),
        batch_size=int(training["batch_size"]),
        learning_rate=float(training["learning_rate"]),
        weight_decay=float(training["weight_decay"]),
        gradient_clip_norm=float(training["gradient_clip_norm"]),
        early_stopping_patience=int(training["early_stopping_patience"]),
        identity_weight=float(training["identity_weight"]),
    )
    output = args.output or manifest.output_root / "shadow_training"
    registered_context = None
    if args.registered_result is not None:
        if args.split_manifest is None or not args.split_manifest_sha256:
            parser.error("registered execution requires --split-manifest and --split-manifest-sha256")
        registered_context = RegisteredRadarToolContext.create(
            tool_run_id=os.environ.get("AGENT_JSAC_TOOL_RUN_ID", ""),
            split_manifest=args.split_manifest,
            expected_split_manifest_sha256=args.split_manifest_sha256,
            sequence_roles={
                "shadow_fit": manifest.shadow_fit,
                "shadow_calibration": manifest.shadow_calibration,
            },
        )
    result = train_shadow_adapter(
        [packs[sequence] for sequence in manifest.shadow_fit],
        packs[manifest.shadow_calibration[0]],
        config=config,
        output_dir=output,
        device=args.device,
    )
    if args.checkpoint is not None and result.checkpoint_path.resolve() != args.checkpoint.resolve():
        raise ValueError("registered checkpoint path does not match the trainer output")
    if registered_context is not None:
        checkpoint_file_sha256 = file_sha256(result.checkpoint_path)
        payload = {
            "schema_version": "agent_jsac_scaa_registered_training_v2",
            "status": "trained",
            **registered_context.to_dict(),
            "checkpoint": str(result.checkpoint_path.resolve()),
            "checkpoint_sha256": checkpoint_file_sha256,
            "model_state_sha256": result.checkpoint_sha256,
            "legacy_training_report": str(result.report_path.resolve()),
            "legacy_training_report_sha256": file_sha256(result.report_path),
            "manifest_sha256": file_sha256(args.manifest),
            "fit_sequences": list(result.fit_sequences),
            "calibration_sequences": list(result.calibration_sequences),
            "training_lineage": list(result.training_lineage),
            "best_epoch": result.best_epoch,
            "threshold": result.threshold,
            "calibration_set_hit": result.calibration_set_hit,
            "calibration_intervention_coverage": result.calibration_intervention_coverage,
        }
        args.registered_result.parent.mkdir(parents=True, exist_ok=True)
        args.registered_result.write_text(
            json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
        )
    print(
        json.dumps(
            {
                "checkpoint": str(result.checkpoint_path),
                "checkpoint_sha256": file_sha256(result.checkpoint_path),
                "model_state_sha256": result.checkpoint_sha256,
                "threshold": result.threshold,
                "best_epoch": result.best_epoch,
                "calibration_set_hit": result.calibration_set_hit,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
