"""Deterministic Shadow training and calibration for SCAA."""

from __future__ import annotations

import hashlib
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from .scaa import SelectiveCandidateAssociationAdapter, physical_candidate_set_loss
from .scaa_data import R31SequencePack, R31WindowDataset


@dataclass(frozen=True)
class TrainingConfig:
    seed: int
    window: int
    hidden_dim: int
    epochs: int
    batch_size: int
    learning_rate: float
    weight_decay: float
    gradient_clip_norm: float
    early_stopping_patience: int
    identity_weight: float


@dataclass(frozen=True)
class ShadowTrainingResult:
    checkpoint_path: Path
    checkpoint_sha256: str
    threshold: float
    best_epoch: int
    calibration_set_hit: float
    calibration_intervention_coverage: float
    fit_sequences: tuple[str, ...]
    calibration_sequences: tuple[str, ...]
    training_lineage: tuple[str, ...]
    report_path: Path


def _state_sha256(state: dict[str, torch.Tensor], metadata: dict[str, object]) -> str:
    digest = hashlib.sha256(json.dumps(metadata, sort_keys=True).encode("utf-8"))
    for key in sorted(state):
        tensor = state[key].detach().cpu().contiguous()
        digest.update(key.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(np.asarray(tensor.shape, dtype=np.int64).tobytes())
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


@torch.inference_mode()
def infer_sequence(
    model: SelectiveCandidateAssociationAdapter,
    pack: R31SequencePack,
    *,
    device: torch.device,
) -> dict[str, torch.Tensor]:
    features = torch.from_numpy(pack.candidate_features)[None].to(device)
    valid = torch.from_numpy(pack.candidate_valid)[None].to(device)
    model.eval()
    output = model(features, valid)
    return {key: value.detach().cpu().squeeze(0) for key, value in output.items()}


def select_calibration_threshold(
    output: dict[str, torch.Tensor],
    pack: R31SequencePack,
    *,
    candidates: tuple[float, ...] = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9),
) -> tuple[float, dict[str, float]]:
    logits = output["candidate_logits"]
    acceptance = output["acceptance"]
    selected_physical = logits.argmax(dim=-1).numpy() + 1
    dispatch_allowed = pack.dispatch_allowed_weight
    support = pack.radar_training_valid & (dispatch_allowed.sum(axis=1) > 0.0)
    weights = np.maximum(pack.sample_weight, 0.05)
    best: tuple[float, dict[str, float]] | None = None
    for threshold in sorted(set(float(value) for value in candidates)):
        dispatched = np.where(acceptance.numpy() >= threshold, selected_physical, 0)
        hit = dispatch_allowed[np.arange(pack.frames), dispatched] > 0.0
        denominator = float(weights[support].sum())
        set_hit = float((hit[support] * weights[support]).sum() / max(denominator, 1.0e-8))
        coverage = float(((dispatched[support] != 0) * weights[support]).sum() / max(denominator, 1.0e-8))
        report = {"set_hit": set_hit, "intervention_coverage": coverage}
        if best is None or (set_hit, threshold) > (best[1]["set_hit"], best[0]):
            best = (threshold, report)
    if best is None:
        raise ValueError("calibration threshold search has no candidates")
    return best


def train_shadow_adapter(
    fit_packs: list[R31SequencePack],
    calibration_pack: R31SequencePack,
    *,
    config: TrainingConfig,
    output_dir: Path,
    device: str,
) -> ShadowTrainingResult:
    if not fit_packs or any(pack.role != "shadow_fit" for pack in fit_packs):
        raise ValueError("optimizer input must contain only shadow_fit packs")
    if calibration_pack.role != "shadow_calibration":
        raise ValueError("threshold selection requires the shadow_calibration pack")
    feature_dims = {pack.candidate_features.shape[-1] for pack in fit_packs + [calibration_pack]}
    if len(feature_dims) != 1:
        raise ValueError("all R31 packs must share one candidate feature dimension")

    random.seed(config.seed)
    np.random.seed(config.seed)
    torch.manual_seed(config.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config.seed)
    torch.use_deterministic_algorithms(True)
    torch_device = torch.device(device)
    feature_dim = feature_dims.pop()
    model = SelectiveCandidateAssociationAdapter(
        feature_dim=feature_dim, hidden_dim=config.hidden_dim
    ).to(torch_device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay
    )
    generator = torch.Generator().manual_seed(config.seed)
    loader = DataLoader(
        R31WindowDataset(fit_packs, window=config.window),
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=0,
        generator=generator,
    )

    best_state: dict[str, torch.Tensor] | None = None
    best_threshold = 1.0
    best_epoch = 0
    best_report = {"set_hit": -1.0, "intervention_coverage": 0.0}
    stale = 0
    history: list[dict[str, float | int]] = []
    for epoch in range(1, config.epochs + 1):
        model.train()
        epoch_loss = 0.0
        batches = 0
        for batch in loader:
            features = batch["candidate_features"].to(torch_device)
            valid = batch["candidate_valid"].to(torch_device)
            output = model(features, valid)
            losses = physical_candidate_set_loss(
                output["candidate_logits"][:, -1:],
                batch["allowed_weight"][:, -1:].to(torch_device),
                batch["sample_weight"][:, -1:].to(torch_device),
                output["acceptance_logit"][:, -1:],
                batch["acceptance_target"][:, -1:].to(torch_device),
                acceptance_weight=config.identity_weight,
            )
            optimizer.zero_grad(set_to_none=True)
            losses["loss"].backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip_norm)
            optimizer.step()
            epoch_loss += float(losses["loss"].detach().cpu().item())
            batches += 1

        calibration_output = infer_sequence(model, calibration_pack, device=torch_device)
        threshold, report = select_calibration_threshold(calibration_output, calibration_pack)
        history.append(
            {
                "epoch": epoch,
                "train_loss": epoch_loss / max(batches, 1),
                "calibration_set_hit": report["set_hit"],
                "calibration_intervention_coverage": report["intervention_coverage"],
                "threshold": threshold,
            }
        )
        if report["set_hit"] > best_report["set_hit"] + 1.0e-9:
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            best_threshold = threshold
            best_epoch = epoch
            best_report = report
            stale = 0
        else:
            stale += 1
            if stale >= config.early_stopping_patience:
                break
    if best_state is None:
        raise RuntimeError("Shadow training did not produce a calibratable checkpoint")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    metadata: dict[str, object] = {
        "schema_version": "agent_jsac_scaa_checkpoint_v1",
        "seed": config.seed,
        "feature_dim": feature_dim,
        "hidden_dim": config.hidden_dim,
        "threshold": best_threshold,
        "best_epoch": best_epoch,
        "fit_sequences": [pack.sequence for pack in fit_packs],
        "calibration_sequences": [calibration_pack.sequence],
    }
    state_hash = _state_sha256(best_state, metadata)
    checkpoint_path = output_dir / "scaa_shadow_best.pt"
    torch.save({**metadata, "model_state": best_state, "model_state_sha256": state_hash}, checkpoint_path)
    report_path = output_dir / "training_report.json"
    report_payload = {
        **metadata,
        "status": "trained",
        "checkpoint_path": checkpoint_path.name,
        "checkpoint_sha256": state_hash,
        "calibration_set_hit": best_report["set_hit"],
        "calibration_intervention_coverage": best_report["intervention_coverage"],
        "training_lineage": [
            f"{pack.sequence}:{pack.runtime_sha256}:{pack.label_sha256}" for pack in fit_packs
        ],
        "history": history,
        "forbidden_reads": {key: False for key in (
            "target_final_bev_read",
            "development_read",
            "locked_test_read",
            "depth_read",
            "right_rgb_read",
            "manual_ra_anchor_read",
            "post_se2_historical_pseudolabel_read",
        )},
    }
    report_path.write_text(json.dumps(report_payload, indent=2, sort_keys=True), encoding="utf-8")
    return ShadowTrainingResult(
        checkpoint_path=checkpoint_path,
        checkpoint_sha256=state_hash,
        threshold=best_threshold,
        best_epoch=best_epoch,
        calibration_set_hit=best_report["set_hit"],
        calibration_intervention_coverage=best_report["intervention_coverage"],
        fit_sequences=tuple(pack.sequence for pack in fit_packs),
        calibration_sequences=(calibration_pack.sequence,),
        training_lineage=tuple(report_payload["training_lineage"]),
        report_path=report_path,
    )
