"""Selective Candidate Association Adapter for observed radar peaks."""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional


def _zero_linear(layer: nn.Linear) -> None:
    nn.init.zeros_(layer.weight)
    if layer.bias is not None:
        nn.init.zeros_(layer.bias)


class SelectiveCandidateAssociationAdapter(nn.Module):
    """Associate physical candidates causally, then independently accept a correction."""

    def __init__(self, *, feature_dim: int, hidden_dim: int = 64) -> None:
        super().__init__()
        if feature_dim <= 0 or hidden_dim <= 0:
            raise ValueError("feature_dim and hidden_dim must be positive")
        heads = 4 if hidden_dim % 4 == 0 else 1
        self.feature_dim = int(feature_dim)
        self.encoder = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
        )
        self.set_attention = nn.MultiheadAttention(hidden_dim, heads, batch_first=True)
        self.temporal = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.association_head = nn.Linear(hidden_dim, 1)
        self.acceptance_head = nn.Linear(hidden_dim, 1)
        self.covariance_head = nn.Linear(hidden_dim, 2)
        _zero_linear(self.association_head)
        _zero_linear(self.acceptance_head)
        _zero_linear(self.covariance_head)

    def forward(self, candidate_features: Tensor, candidate_valid: Tensor) -> dict[str, Tensor]:
        if candidate_features.ndim != 4:
            raise ValueError("candidate_features must be [batch,time,candidates,feature]")
        batch, steps, candidates, dimensions = candidate_features.shape
        if dimensions != self.feature_dim:
            raise ValueError("candidate feature dimension mismatch")
        if candidate_valid.shape != (batch, steps, candidates) or candidate_valid.dtype is not torch.bool:
            raise ValueError("candidate_valid must be bool [batch,time,candidates]")
        if not bool(candidate_valid.any(dim=-1).all()):
            raise ValueError("each frame requires one observed physical candidate")

        encoded = self.encoder(candidate_features)
        flattened = encoded.reshape(batch * steps, candidates, -1)
        padding_mask = ~candidate_valid.reshape(batch * steps, candidates)
        attended, _ = self.set_attention(
            flattened,
            flattened,
            flattened,
            key_padding_mask=padding_mask,
            need_weights=False,
        )
        attended = attended.reshape(batch, steps, candidates, -1)
        valid_float = candidate_valid[..., None].to(attended)
        pooled = (attended * valid_float).sum(dim=2)
        pooled = pooled / valid_float.sum(dim=2).clamp_min(1.0)
        causal_state, _ = self.temporal(pooled)
        fused = attended + causal_state[:, :, None, :]
        candidate_logits = self.association_head(fused).squeeze(-1)
        candidate_logits = candidate_logits.masked_fill(~candidate_valid, -torch.inf)

        raw_acceptance = self.acceptance_head(causal_state).squeeze(-1)
        acceptance = (2.0 * torch.sigmoid(raw_acceptance) - 1.0).clamp_min(0.0)
        covariance = functional.softplus(self.covariance_head(causal_state)) + 1.0e-3
        return {
            "candidate_logits": candidate_logits,
            "acceptance": acceptance,
            "acceptance_logit": raw_acceptance,
            "covariance": covariance,
        }


def physical_candidate_set_loss(
    candidate_logits: Tensor,
    allowed_weight: Tensor,
    sample_weight: Tensor,
    acceptance_logit: Tensor,
    acceptance_target: Tensor,
    *,
    acceptance_weight: float = 0.2,
) -> dict[str, Tensor]:
    """Train on a set of observed physical peaks without accepting target coordinates."""

    if candidate_logits.ndim != 3 or allowed_weight.shape != candidate_logits.shape:
        raise ValueError("candidate logits and allowed weights must align [batch,time,candidates]")
    if sample_weight.shape != candidate_logits.shape[:2]:
        raise ValueError("sample_weight must be [batch,time]")
    if acceptance_logit.shape != sample_weight.shape or acceptance_target.shape != sample_weight.shape:
        raise ValueError("acceptance tensors must be [batch,time]")
    if torch.any(allowed_weight < 0.0) or torch.any(sample_weight < 0.0):
        raise ValueError("set and sample weights must be non-negative")
    if not 0.0 <= acceptance_weight:
        raise ValueError("acceptance_weight must be non-negative")

    finite_zero = torch.where(
        torch.isfinite(candidate_logits), candidate_logits, torch.zeros_like(candidate_logits)
    ).sum() * 0.0
    allowed = allowed_weight.to(candidate_logits).clamp_min(0.0)
    allowed_mass = allowed.sum(dim=-1)
    normalized = allowed / allowed_mass[..., None].clamp_min(1.0e-8)
    supervised = sample_weight.gt(0.0) & allowed_mass.gt(0.0)
    log_probability = functional.log_softmax(candidate_logits.float(), dim=-1)
    log_set_mass = torch.logsumexp(
        log_probability + torch.log(normalized.clamp_min(1.0e-8)), dim=-1
    )
    if bool(supervised.any()):
        weights = sample_weight[supervised].to(log_set_mass).clamp_min(0.05)
        set_mass = (-log_set_mass[supervised] * weights).sum() / weights.sum().clamp_min(1.0e-8)
    else:
        set_mass = finite_zero

    acceptance_target = acceptance_target.to(acceptance_logit).clamp(0.0, 1.0)
    acceptance_loss = functional.binary_cross_entropy_with_logits(
        acceptance_logit, acceptance_target, reduction="none"
    )
    acceptance_weights = torch.where(
        supervised,
        sample_weight.to(acceptance_logit).clamp_min(0.05),
        torch.full_like(acceptance_logit, 0.05),
    )
    acceptance_loss = (acceptance_loss * acceptance_weights).sum() / acceptance_weights.sum().clamp_min(1.0e-8)
    total = set_mass + float(acceptance_weight) * acceptance_loss
    return {
        "loss": total,
        "set_mass": set_mass.detach(),
        "acceptance_bce": acceptance_loss.detach(),
        "supervised_frames": supervised.sum().detach(),
    }


def dispatch_scaa_prediction(
    base_xy_m: Tensor,
    physical_candidate_xy_m: Tensor,
    candidate_logits: Tensor,
    acceptance: Tensor,
    *,
    threshold: float,
) -> dict[str, Tensor]:
    """Dispatch a physical peak or preserve the frozen base coordinate exactly."""

    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold must be in [0,1]")
    if base_xy_m.ndim != 3 or base_xy_m.shape[-1] != 2:
        raise ValueError("base_xy_m must be [batch,time,2]")
    if physical_candidate_xy_m.ndim != 4 or physical_candidate_xy_m.shape[-1] != 2:
        raise ValueError("physical_candidate_xy_m must be [batch,time,candidates,2]")
    if physical_candidate_xy_m.shape[:2] != base_xy_m.shape[:2]:
        raise ValueError("base and candidate batch/time dimensions must align")
    if candidate_logits.shape != physical_candidate_xy_m.shape[:3]:
        raise ValueError("candidate_logits must align with candidates")
    if acceptance.shape != base_xy_m.shape[:2]:
        raise ValueError("acceptance must be [batch,time]")
    if torch.any(~torch.isfinite(base_xy_m)):
        raise ValueError("base coordinates must be finite")

    selected_index = candidate_logits.argmax(dim=-1)
    selected_xy = physical_candidate_xy_m.gather(
        2, selected_index[..., None, None].expand(-1, -1, 1, 2)
    ).squeeze(2)
    intervened = acceptance.ge(float(threshold))
    prediction = torch.where(intervened[..., None], selected_xy, base_xy_m)
    return {
        "prediction_xy_m": prediction,
        "selected_xy_m": selected_xy,
        "selected_index": selected_index,
        "intervened": intervened,
    }
