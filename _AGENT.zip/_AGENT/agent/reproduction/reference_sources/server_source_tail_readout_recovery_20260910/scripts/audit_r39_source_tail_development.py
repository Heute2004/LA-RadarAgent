#!/usr/bin/env python3
"""Run the one-shot source Development audit for an immutable R39 freeze."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.cora_se2_r11 import sha256
from audit_r11_pca_specialist_development import summarize
from freeze_r39_source_tail_predictions import SCHEMA
from train_r39_source_tail_adapter import PROTOCOL_SCHEMA


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("open_indoor_los", "open_outdoor_weak_return"), required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--prediction-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def as_bool(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def main() -> None:
    args = parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite one-shot R39 audit: {args.output}")
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    if protocol.get("schema_version") != PROTOCOL_SCHEMA:
        raise ValueError("unsupported R39 protocol")
    sequences = tuple(str(value).strip().lower() for value in protocol["routes"][args.route]["development_sequences"])
    freeze_path = args.prediction_dir / "PREDICTION_FREEZE.json"
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    if freeze.get("schema_version") != SCHEMA or freeze.get("route") != args.route:
        raise ValueError("R39 freeze route/schema mismatch")
    if any(bool(freeze.get(key, True)) for key in ("development_labels_read", "locked_test_read", "target_final_bev_read")):
        raise ValueError("R39 freeze is not label-free")
    prediction_path = args.prediction_dir / str(freeze["prediction_file"]["path"])
    if sha256(prediction_path) != str(freeze["prediction_file"]["sha256"]).lower():
        raise ValueError("R39 prediction hash mismatch")
    with np.load(prediction_path, allow_pickle=False) as archive:
        prediction = {key: archive[key].copy() for key in archive.files}
    index = {
        (str(sequence).strip().lower(), int(frame_id)): position
        for position, (sequence, frame_id) in enumerate(zip(prediction["sequence"].astype(str), prediction["frame_id"], strict=True))
    }

    rows: list[dict[str, Any]] = []
    per_sequence: dict[str, list[int]] = defaultdict(list)
    with args.source_manifest.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            sequence = str(row["sequence"]).strip().lower()
            if sequence not in sequences or str(row["split"]).strip().lower() != "development":
                continue
            if not as_bool(row["input_valid"]) or not as_bool(row["label_valid"]) or not as_bool(row.get("has_person", True)):
                continue
            frame_id = int(row["frame_id"])
            key = (sequence, frame_id)
            if key not in index:
                raise ValueError(f"R39 freeze misses source Development frame: {key}")
            position = index[key]
            rows.append({
                "sequence": sequence,
                "target": np.asarray((float(row["target_x_m"]), float(row["target_y_m"])), dtype=np.float32),
                "baseline_xy": prediction["baseline_xy_m"][position],
                "baseline_score": float(prediction["baseline_score"][position]),
                "expert_xy": prediction["xy_m"][position],
                "expert_score": float(prediction["score"][position]),
            })
            per_sequence[sequence].append(len(rows) - 1)
    if not rows:
        raise ValueError("R39 audit has no eligible source Development labels")
    target = np.stack([row["target"] for row in rows])
    baseline_xy = np.stack([row["baseline_xy"] for row in rows])
    expert_xy = np.stack([row["expert_xy"] for row in rows])
    baseline_score = np.asarray([row["baseline_score"] for row in rows], dtype=np.float32)
    expert_score = np.asarray([row["expert_score"] for row in rows], dtype=np.float32)
    baseline_metrics = summarize(baseline_xy, baseline_score, target)
    expert_metrics = summarize(expert_xy, expert_score, target)
    base_error = np.linalg.norm(baseline_xy - target, axis=1)
    expert_error = np.linalg.norm(expert_xy - target, axis=1)
    intervened = np.linalg.norm(expert_xy - baseline_xy, axis=1) > 1.0e-6
    harmful = intervened & (expert_error > base_error + 0.10)
    ap30_delta_pp = 100.0 * (float(expert_metrics["ap_0p3m"]) - float(baseline_metrics["ap_0p3m"]))
    p90_delta_m = float(expert_metrics["p90_error_m"]) - float(baseline_metrics["p90_error_m"])
    p95_delta_m = float(expert_metrics["p95_error_m"]) - float(baseline_metrics["p95_error_m"])
    promotion = (
        ap30_delta_pp >= -0.05
        and (p90_delta_m <= -0.005 or p95_delta_m <= -0.010)
        and float(harmful.mean()) <= 0.01 + 1.0e-12
    )
    sequence_metrics = {}
    for sequence, positions in sorted(per_sequence.items()):
        chosen = np.asarray(positions, dtype=np.int64)
        sequence_metrics[sequence] = {
            "baseline": summarize(baseline_xy[chosen], baseline_score[chosen], target[chosen]),
            "expert": summarize(expert_xy[chosen], expert_score[chosen], target[chosen]),
        }
    report = {
        "schema_version": "brace_v4_r39_source_tail_development_audit_v1",
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "prediction_freeze_sha256": sha256(freeze_path),
        "source_manifest_sha256": sha256(args.source_manifest),
        "development_labels_read_after_prediction_freeze": True,
        "locked_test_read": False,
        "scope": {"sequences": list(sequences), "frames": len(rows)},
        "baseline": baseline_metrics,
        "expert": expert_metrics,
        "comparison": {
            "ap_0p3_delta_pp": ap30_delta_pp,
            "p90_delta_m": p90_delta_m,
            "p95_delta_m": p95_delta_m,
            "intervention_coverage": float(intervened.mean()),
            "harmful_intervention_rate": float(harmful.mean()),
            "promotion_gate_pass": bool(promotion),
        },
        "per_sequence": sequence_metrics,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"route": args.route, "ap_0p3_delta_pp": ap30_delta_pp, "p90_delta_m": p90_delta_m, "promotion_gate_pass": promotion}, ensure_ascii=False))


if __name__ == "__main__":
    main()

