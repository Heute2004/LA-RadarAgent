#!/usr/bin/env python3
"""Freeze R39 source-route predictions without reading Development labels."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from brace_v4.cora_se2_r11 import load_cora, sha256
from brace_v4.r38_stacked_point_adapter import StackedPointAdapter, StackedRouteDetector
from freeze_cora_se2_r11_predictions import RawDevelopmentRadarDataset, freeze_model
from train_r39_source_tail_adapter import CHECKPOINT_SCHEMA, PROTOCOL_SCHEMA


SCHEMA = "brace_v4_r39_source_tail_prediction_freeze_v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("open_indoor_los", "open_outdoor_weak_return"), required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--policy", type=Path, required=True)
    parser.add_argument("--se1-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--preload-radar", action="store_true")
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"R39 freeze output is not empty: {args.output_dir}")
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    if protocol.get("schema_version") != PROTOCOL_SCHEMA:
        raise ValueError("unsupported R39 protocol")
    route = dict(protocol["routes"][args.route])
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if checkpoint.get("schema_version") != CHECKPOINT_SCHEMA or checkpoint.get("route") != args.route:
        raise ValueError("R39 checkpoint route/schema mismatch")
    if checkpoint.get("se1_checkpoint_sha256") != sha256(args.se1_checkpoint):
        raise ValueError("R39 checkpoint/SE1 provenance mismatch")
    policy = json.loads(args.policy.read_text(encoding="utf-8"))
    if policy.get("schema_version") != "brace_v4_r39_train_internal_policy_v1" or policy.get("route") != args.route:
        raise ValueError("R39 policy route/schema mismatch")
    if policy.get("checkpoint_sha256") != sha256(args.checkpoint):
        raise ValueError("R39 policy/checkpoint hash mismatch")

    device = torch.device(args.device)
    baseline = load_cora(args.se1_checkpoint, device)
    adapter = StackedPointAdapter(**dict(checkpoint["model_kwargs"])).to(device)
    adapter.load_state_dict(checkpoint["adapter_state"], strict=True)
    detector = StackedRouteDetector(baseline, adapter).to(device).eval()
    sequences = tuple(str(value).strip().lower() for value in route["development_sequences"])
    dataset = RawDevelopmentRadarDataset(args.data_root, sequences, preload=args.preload_radar)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=0, pin_memory=True)
    raw = freeze_model(detector, loader, device)
    base = freeze_model(baseline, loader, device)
    if not np.array_equal(raw["sequence"], base["sequence"]) or not np.array_equal(raw["frame_id"], base["frame_id"]):
        raise ValueError("R39 expert and baseline timelines differ")
    alpha = float(policy["selected"]["expert_alpha"])
    threshold = float(policy["selected"]["max_shift_m"])
    shift = np.linalg.norm(raw["xy_m"] - base["xy_m"], axis=1)
    accepted = (shift > 1.0e-6) & (shift <= threshold) & (alpha > 0.0)
    blended_xy = base["xy_m"] + alpha * (raw["xy_m"] - base["xy_m"])
    blended_score = base["score"] + alpha * (raw["score"] - base["score"])
    arrays = dict(raw)
    arrays.update({
        "raw_expert_xy_m": raw["xy_m"],
        "raw_expert_score": raw["score"],
        "baseline_xy_m": base["xy_m"],
        "baseline_score": base["score"],
        "fallback_accepted": accepted,
        "expert_shift_m": shift.astype(np.float32),
        "xy_m": np.where(accepted[:, None], blended_xy, base["xy_m"]).astype(np.float32),
        "score": np.where(accepted, blended_score, base["score"]).astype(np.float32),
    })
    args.output_dir.mkdir(parents=True, exist_ok=False)
    prediction_path = args.output_dir / "r39_source_tail_development_predictions.npz"
    np.savez_compressed(prediction_path, **arrays)
    manifest = {
        "schema_version": SCHEMA,
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "route": args.route,
        "development_sequences": list(sequences),
        "checkpoint": {"path": str(args.checkpoint), "sha256": sha256(args.checkpoint)},
        "policy": {"path": str(args.policy), "sha256": sha256(args.policy)},
        "prediction_file": {"path": prediction_path.name, "sha256": sha256(prediction_path)},
        "selected_expert_alpha": alpha,
        "selected_max_shift_m": threshold,
        "intervention_coverage_without_labels": float(accepted.mean()),
        "development_labels_read": False,
        "locked_test_read": False,
        "target_final_bev_read": False,
    }
    freeze_path = args.output_dir / "PREDICTION_FREEZE.json"
    freeze_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"route": args.route, "frames": len(dataset), "freeze_sha256": sha256(freeze_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

