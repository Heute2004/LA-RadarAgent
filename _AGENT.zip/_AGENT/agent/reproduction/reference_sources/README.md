# Recovered Native Reference Sources

These byte-preserved Python sources are historical structure and method
references, not active production entrypoints and not trained expert assets.
Do not launch their trainers or reuse their default dataset/split policy.

`code_radar_cbpr_v1_20260805` contains the local Python import closure of 19
explicitly recovered expert/model/trainer/test sources: 41 Python files in total.
The collection manifest records original absolute source paths for provenance,
not runtime resource resolution. To locate a local file, strip the `sources/`
prefix from its manifest name and resolve it relative to this directory.

The code is not on the production Python search path. Only an audited binding
may adapt a recovered head to an approved training contract. The user's fixed
42 semantic identifiers remain authoritative; this source collection is not a
second expert pool and does not expand the catalog.

Original trainer protocols differ from the current weak-supervised workflow.
See `docs/conv_expert_native_recovery_audit.md` and
`docs/conv_native_dependency_acceptance.md` for evidence and pending work.
