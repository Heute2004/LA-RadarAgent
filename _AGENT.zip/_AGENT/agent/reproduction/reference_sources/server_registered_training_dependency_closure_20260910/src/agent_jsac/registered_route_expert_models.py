"""Distinct, discrete-candidate models for registered route experts.

Unlike the retired generic four-family scorer, every registered implementation has
an explicit architecture signature.  They may share small building blocks, but a
semantic primitive cannot silently resolve to the same topology and hyperparameter
configuration as another primitive.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import NamedTuple

import torch
from torch import Tensor, nn
from torch.nn import functional as functional


class RegisteredCandidateExpertOutput(NamedTuple):
    candidate_logits: Tensor
    acceptance: Tensor


class DiscreteCandidateDecode(NamedTuple):
    choice_index: Tensor
    proposed_xy_m: Tensor
    final_xy_m: Tensor
    intervened: Tensor


@dataclass(frozen=True)
class RegisteredImplementationSpec:
    implementation_id: str
    mixer_kind: str
    temporal_kind: str
    gate_kind: str
    coordinate_kind: str

    @property
    def signature(self) -> str:
        return ":".join(
            (
                self.implementation_id,
                self.mixer_kind,
                self.temporal_kind,
                self.gate_kind,
                self.coordinate_kind,
            )
        )


def _spec(
    implementation_id: str,
    mixer_kind: str,
    temporal_kind: str,
    gate_kind: str,
    coordinate_kind: str,
) -> RegisteredImplementationSpec:
    return RegisteredImplementationSpec(
        implementation_id=implementation_id,
        mixer_kind=mixer_kind,
        temporal_kind=temporal_kind,
        gate_kind=gate_kind,
        coordinate_kind=coordinate_kind,
    )


_SPECS = {
    item.implementation_id: item
    for item in (
        _spec("local_offset_gru_v1", "local", "gru", "local", "cartesian"),
        _spec("polar_bev_cross_refiner_v1", "cross", "gru", "confidence", "polar"),
        _spec("subcell_uncertainty_refiner_v1", "uncertainty", "conv", "uncertainty", "cartesian"),
        _spec("innovation_gated_offset_v1", "innovation", "gru", "innovation", "delta"),
        _spec("temporal_precision_tail_v1", "local", "tail", "tail", "cartesian"),
        _spec("candidate_attention_set_v1", "attention", "none", "confidence", "cartesian"),
        _spec("candidate_graph_temporal_v1", "graph", "gru", "innovation", "delta"),
        _spec("dual_domain_set_mixer_v1", "set", "conv", "agreement", "polar"),
        _spec("echo_extent_disambiguator_v1", "extent", "none", "extent", "cartesian"),
        _spec("branch_persistence_selector_v1", "persistence", "gru", "persistence", "delta"),
        _spec("path_temporal_integrator_v1", "path", "gru", "persistence", "polar"),
        _spec("track_before_detect_v1", "track_before_detect", "tail", "confidence", "polar"),
        _spec("range_conditioned_tcn_v1", "range", "conv", "range", "polar"),
        _spec("weak_return_mixture_v1", "mixture", "gru", "uncertainty", "cartesian"),
        _spec("polar_evidence_gate_v1", "polar_gate", "none", "agreement", "polar"),
        _spec("graph_branch_linker_v1", "graph", "conv", "persistence", "delta"),
        _spec("multi_hypothesis_path_v1", "path", "tail", "uncertainty", "cartesian"),
        _spec("mti_agreement_rescuer_v1", "agreement", "none", "agreement", "polar"),
        _spec("candidate_survival_graph_v1", "survival", "gru", "survival", "delta"),
        _spec("selective_branch_recovery_v1", "risk", "conv", "risk", "cartesian"),
        _spec("risk_controlled_recovery_v1", "risk", "gru", "risk", "polar"),
        _spec("robust_quantile_recovery_v1", "uncertainty", "tail", "quantile", "cartesian"),
        _spec("wet_temporal_integrator_v1", "wet", "gru", "wet", "polar"),
        _spec("weather_risk_selector_v1", "risk", "none", "weather", "polar"),
        _spec("anisotropic_wet_mixture_v1", "mixture", "conv", "anisotropic", "polar"),
        _spec("risecho_temporal_gate_v1", "risecho", "gru", "codebook", "polar"),
        _spec("risecho_path_integrator_v1", "path", "tail", "codebook", "polar"),
        _spec("risecho_codebook_consensus_v1", "codebook", "none", "consensus", "polar"),
        _spec("risecho_selective_recovery_v1", "risk", "gru", "receiver", "cartesian"),
        _spec("risecho_dual_path_mixture_v1", "dual_path", "conv", "receiver", "polar"),
        _spec("state_consistent_local_refiner_v1", "state_space", "gru", "persistence", "cartesian"),
        _spec("local_shape_consensus_v1", "shape_consensus", "conv", "extent", "cartesian"),
        _spec("empty_guard_constrained_disambiguator_v1", "contrast", "gru", "agreement", "polar"),
        _spec("causal_tracklet_consensus_v1", "state_space", "tail", "persistence", "delta"),
        _spec("adaptive_threshold_tracklet_v1", "adaptive_range", "tail", "range", "polar"),
        _spec("evidence_hysteresis_selector_v1", "hysteresis", "gru", "persistence", "polar"),
        _spec("angular_consistency_associator_v1", "angular", "conv", "innovation", "polar"),
        _spec("background_guard_branch_pruner_v1", "residual", "none", "risk", "cartesian"),
        _spec("wet_guard_contrast_recovery_v1", "contrast", "gru", "wet", "polar"),
        _spec("anomaly_hysteresis_gate_v1", "hysteresis", "tail", "weather", "polar"),
        _spec("risecho_geometry_consensus_v1", "angular", "gru", "codebook", "polar"),
        _spec("risecho_dual_stream_stability_v1", "dual_stream", "conv", "consensus", "polar"),
    )
}


def registered_implementation_ids() -> tuple[str, ...]:
    return tuple(sorted(_SPECS))


def _coordinate_features(xy_m: Tensor, kind: str) -> Tensor:
    safe = torch.nan_to_num(xy_m, nan=0.0, posinf=0.0, neginf=0.0)
    x, y = safe.unbind(dim=-1)
    radius = torch.linalg.vector_norm(safe, dim=-1).clamp_min(1.0e-3)
    angle = torch.atan2(x, y)
    if kind == "cartesian":
        return torch.stack((x, y, radius), dim=-1)
    if kind == "polar":
        return torch.stack((radius, torch.sin(angle), torch.cos(angle)), dim=-1)
    if kind == "delta":
        delta = torch.zeros_like(safe)
        delta[:, 1:] = safe[:, 1:] - safe[:, :-1]
        return torch.cat((safe, delta[..., :1]), dim=-1)
    raise ValueError(f"unknown coordinate kind: {kind}")


class _IdentityMixer(nn.Module):
    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, valid, context
        return token


class _AttentionMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        rows = token.flatten(0, 1)
        mask = ~valid.flatten(0, 1)
        mixed, _ = self.attention(rows, rows, rows, key_padding_mask=mask, need_weights=False)
        return mixed.unflatten(0, token.shape[:2])


class _GraphMixer(nn.Module):
    def __init__(self, hidden_dim: int, *, survival: bool = False) -> None:
        super().__init__()
        self.message = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))
        self.survival = survival

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del context
        safe_xy = torch.nan_to_num(xy, nan=0.0, posinf=0.0, neginf=0.0)
        distance = torch.cdist(safe_xy.flatten(0, 1), safe_xy.flatten(0, 1))
        radius = 0.55 if self.survival else 0.75
        adjacency = (distance <= radius).to(token.dtype).unflatten(0, token.shape[:2])
        adjacency = adjacency * valid.unsqueeze(-1).to(token.dtype) * valid.unsqueeze(-2).to(token.dtype)
        adjacency = adjacency / adjacency.sum(dim=-1, keepdim=True).clamp_min(1.0)
        return token + self.message(torch.einsum("btij,btjh->btih", adjacency, token))


class _CrossMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.cross = nn.MultiheadAttention(hidden_dim, num_heads=4, batch_first=True)

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy
        query = token.flatten(0, 1)
        key_value = context.unsqueeze(2).flatten(0, 1)
        mixed, _ = self.cross(query, key_value, key_value, need_weights=False)
        return mixed.unflatten(0, token.shape[:2]) * valid.unsqueeze(-1).to(token.dtype)


class _ExtentMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(2, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del context
        safe_xy = torch.nan_to_num(xy, nan=0.0, posinf=0.0, neginf=0.0)
        centre = (safe_xy * valid.unsqueeze(-1)).sum(dim=2, keepdim=True) / valid.sum(dim=2, keepdim=True).clamp_min(1).unsqueeze(-1)
        spread = torch.linalg.vector_norm(safe_xy - centre, dim=-1, keepdim=True)
        extent = torch.cat((spread, spread.square()), dim=-1)
        return token + self.project(extent)


class _SetMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.gate = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.Sigmoid())

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        set_summary = (token * valid.unsqueeze(-1)).sum(dim=2, keepdim=True) / valid.sum(dim=2, keepdim=True).clamp_min(1).unsqueeze(-1)
        return token + self.gate(set_summary) * token


class _PathMixer(nn.Module):
    def __init__(self, hidden_dim: int, *, track_before_detect: bool = False) -> None:
        super().__init__()
        self.path_gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.track_before_detect = track_before_detect

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        batch, steps, candidates, channels = token.shape
        sequence = token.permute(0, 2, 1, 3).reshape(batch * candidates, steps, channels)
        mixed, _ = self.path_gru(sequence)
        if self.track_before_detect:
            mixed = mixed.cumsum(dim=1) / torch.arange(1, steps + 1, device=token.device).view(1, steps, 1)
        mixed = mixed.reshape(batch, candidates, steps, channels).permute(0, 2, 1, 3)
        return mixed * valid.unsqueeze(-1).to(token.dtype)


class _RangeMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(1, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del valid, context
        ranges = torch.linalg.vector_norm(torch.nan_to_num(xy, nan=0.0), dim=-1, keepdim=True)
        return token + self.project(ranges)


class _AgreementMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.Sigmoid())

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, valid, context
        return token * (1.0 + self.project(token))


class _RiskMixer(nn.Module):
    def __init__(self, hidden_dim: int, *, dual_path: bool = False) -> None:
        super().__init__()
        self.risk = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1), nn.Sigmoid())
        self.dual_path = dual_path

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, valid
        risk = self.risk(context).unsqueeze(2)
        if self.dual_path:
            return token * risk + token.flip(dims=(2,)) * (1.0 - risk)
        return token * risk


class _CodebookMixer(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.code = nn.Embedding(16, hidden_dim)

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, valid, context
        index = torch.arange(token.shape[2], device=token.device) % 16
        return token + self.code(index).view(1, 1, -1, token.shape[-1])


class _StateSpaceMixer(nn.Module):
    """Per-candidate causal state used for physically reachable tracklets."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.state = nn.GRU(hidden_dim, hidden_dim, batch_first=True)

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        batch, steps, candidates, channels = token.shape
        sequence = token.permute(0, 2, 1, 3).reshape(batch * candidates, steps, channels)
        mixed, _ = self.state(sequence)
        mixed = mixed.reshape(batch, candidates, steps, channels).permute(0, 2, 1, 3)
        return mixed * valid.unsqueeze(-1).to(token.dtype)


class _ShapeConsensusMixer(nn.Module):
    """Encode the local candidate cloud instead of trusting one bright response."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(3, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del context
        safe_xy = torch.nan_to_num(xy, nan=0.0, posinf=0.0, neginf=0.0)
        weights = valid.unsqueeze(-1).to(token.dtype)
        centre = (safe_xy * weights).sum(dim=2, keepdim=True) / weights.sum(dim=2, keepdim=True).clamp_min(1.0)
        residual = safe_xy - centre
        radius = torch.linalg.vector_norm(residual, dim=-1, keepdim=True)
        shape = torch.cat((residual, radius), dim=-1)
        return token + self.project(shape) * weights


class _ContrastMixer(nn.Module):
    """Score candidate evidence relative to its observed local candidate set."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        weights = valid.unsqueeze(-1).to(token.dtype)
        reference = (token * weights).sum(dim=2, keepdim=True) / weights.sum(dim=2, keepdim=True).clamp_min(1.0)
        return token + self.project(token - reference) * weights


class _AdaptiveRangeMixer(nn.Module):
    """Range-conditioned candidate weighting for weak-return threshold variation."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.range_gate = nn.Sequential(nn.Linear(1, hidden_dim), nn.Sigmoid())

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del context
        ranges = torch.linalg.vector_norm(torch.nan_to_num(xy, nan=0.0), dim=-1, keepdim=True)
        return token * (1.0 + self.range_gate(ranges)) * valid.unsqueeze(-1).to(token.dtype)


class _HysteresisMixer(nn.Module):
    """Learn a causal evidence carry-over without creating new candidate positions."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.alpha = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.Sigmoid())

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy
        gate = self.alpha(context).unsqueeze(2)
        states = [token[:, 0]]
        for step in range(1, token.shape[1]):
            states.append(gate[:, step] * token[:, step] + (1.0 - gate[:, step]) * states[-1])
        state = torch.stack(states, dim=1)
        return state * valid.unsqueeze(-1).to(token.dtype)


class _AngularMixer(nn.Module):
    """Preserve route-consistent bearing while allowing radar range to vary."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(1, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del context
        safe = torch.nan_to_num(xy, nan=0.0, posinf=0.0, neginf=0.0)
        angle = torch.atan2(safe[..., 0], safe[..., 1].clamp_min(1.0e-3))
        reference = angle[..., :1]
        consistency = torch.cos(angle - reference).unsqueeze(-1)
        return token + self.project(consistency) * valid.unsqueeze(-1).to(token.dtype)


class _ResidualMixer(nn.Module):
    """Prune candidates whose feature residual is inconsistent with the local set."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.project = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        weights = valid.unsqueeze(-1).to(token.dtype)
        centre = (token * weights).sum(dim=2, keepdim=True) / weights.sum(dim=2, keepdim=True).clamp_min(1.0)
        return token - self.project(token - centre) * weights


class _DualStreamMixer(nn.Module):
    """Cross-check two learned token subspaces for RIS reconstruction stability."""

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.gate = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.Sigmoid())

    def forward(self, token: Tensor, xy: Tensor, valid: Tensor, context: Tensor) -> Tensor:
        del xy, context
        left, right = torch.chunk(token, chunks=2, dim=-1)
        if left.shape[-1] != right.shape[-1]:
            right = functional.pad(right, (0, left.shape[-1] - right.shape[-1]))
        agreement = torch.cat((left * right, left - right), dim=-1)[..., : token.shape[-1]]
        return token + self.gate(agreement) * valid.unsqueeze(-1).to(token.dtype)


def _mixer(spec: RegisteredImplementationSpec, hidden_dim: int) -> nn.Module:
    if spec.mixer_kind in {"local", "uncertainty", "innovation", "mixture", "polar_gate", "wet", "risecho"}:
        return _IdentityMixer()
    if spec.mixer_kind == "attention":
        return _AttentionMixer(hidden_dim)
    if spec.mixer_kind in {"graph", "survival"}:
        return _GraphMixer(hidden_dim, survival=spec.mixer_kind == "survival")
    if spec.mixer_kind == "cross":
        return _CrossMixer(hidden_dim)
    if spec.mixer_kind == "extent":
        return _ExtentMixer(hidden_dim)
    if spec.mixer_kind == "set":
        return _SetMixer(hidden_dim)
    if spec.mixer_kind in {"persistence", "path", "track_before_detect"}:
        return _PathMixer(hidden_dim, track_before_detect=spec.mixer_kind == "track_before_detect")
    if spec.mixer_kind == "range":
        return _RangeMixer(hidden_dim)
    if spec.mixer_kind == "agreement":
        return _AgreementMixer(hidden_dim)
    if spec.mixer_kind in {"risk", "dual_path"}:
        return _RiskMixer(hidden_dim, dual_path=spec.mixer_kind == "dual_path")
    if spec.mixer_kind == "codebook":
        return _CodebookMixer(hidden_dim)
    if spec.mixer_kind == "state_space":
        return _StateSpaceMixer(hidden_dim)
    if spec.mixer_kind == "shape_consensus":
        return _ShapeConsensusMixer(hidden_dim)
    if spec.mixer_kind in {"contrast", "wet_contrast"}:
        return _ContrastMixer(hidden_dim)
    if spec.mixer_kind == "adaptive_range":
        return _AdaptiveRangeMixer(hidden_dim)
    if spec.mixer_kind == "hysteresis":
        return _HysteresisMixer(hidden_dim)
    if spec.mixer_kind in {"angular", "ris_geometry"}:
        return _AngularMixer(hidden_dim)
    if spec.mixer_kind == "residual":
        return _ResidualMixer(hidden_dim)
    if spec.mixer_kind in {"dual_stream", "ris_dual_stream"}:
        return _DualStreamMixer(hidden_dim)
    raise ValueError(f"unsupported registered mixer kind: {spec.mixer_kind}")


class RegisteredDiscreteCandidateExpert(nn.Module):
    """A registered scorer with configuration-specific temporal/candidate operators."""

    def __init__(self, *, spec: RegisteredImplementationSpec, feature_dim: int, hidden_dim: int) -> None:
        super().__init__()
        if feature_dim < 1 or hidden_dim < 16:
            raise ValueError("feature_dim must be positive and hidden_dim must be at least 16")
        self.implementation_id = spec.implementation_id
        self.architecture_signature = spec.signature
        self.spec = spec
        self.token = nn.Sequential(
            nn.LayerNorm(feature_dim),
            nn.Linear(feature_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.coordinate = nn.Sequential(nn.Linear(3, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))
        self.context_gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.mixer = _mixer(spec, hidden_dim)
        self.temporal = (
            nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=2)
            if spec.temporal_kind in {"conv", "tail"}
            else nn.Identity()
        )
        self.score = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1))
        self.accept = nn.Sequential(nn.Linear(hidden_dim, hidden_dim // 2), nn.GELU(), nn.Linear(hidden_dim // 2, 1))
        nn.init.zeros_(self.accept[-1].weight)
        nn.init.zeros_(self.accept[-1].bias)

    def _temporal_context(self, context: Tensor) -> Tensor:
        if self.spec.temporal_kind == "none":
            return context
        if self.spec.temporal_kind == "gru":
            mixed, _ = self.context_gru(context)
            return mixed
        mixed = self.temporal(context.transpose(1, 2))[..., : context.shape[1]].transpose(1, 2)
        if self.spec.temporal_kind == "tail":
            gate = torch.zeros_like(mixed)
            gate[:, -max(1, context.shape[1] // 4) :] = 1.0
            return context + gate * mixed
        return context + mixed

    def _gate_input(self, context: Tensor, token: Tensor) -> Tensor:
        if self.spec.gate_kind in {"innovation", "persistence", "survival", "tail"}:
            delta = torch.zeros_like(context)
            delta[:, 1:] = context[:, 1:] - context[:, :-1]
            return context - delta
        if self.spec.gate_kind in {"uncertainty", "quantile", "anisotropic", "extent"}:
            spread = token.var(dim=2, unbiased=False)
            return context - spread
        if self.spec.gate_kind in {"agreement", "codebook", "consensus", "receiver", "weather", "wet", "range"}:
            return context + token.mean(dim=2)
        if self.spec.gate_kind == "risk":
            return context - token.abs().mean(dim=2)
        return context

    def forward(self, candidate_feature: Tensor, candidate_xy_m: Tensor, candidate_valid: Tensor) -> RegisteredCandidateExpertOutput:
        if candidate_feature.ndim != 4 or candidate_xy_m.shape != candidate_feature.shape[:3] + (2,):
            raise ValueError("candidate feature/coordinate shape mismatch")
        if candidate_valid.shape != candidate_feature.shape[:3]:
            raise ValueError("candidate valid shape mismatch")
        safe_feature = torch.nan_to_num(candidate_feature, nan=0.0, posinf=0.0, neginf=0.0)
        token = self.token(safe_feature) + self.coordinate(_coordinate_features(candidate_xy_m, self.spec.coordinate_kind))
        mask = candidate_valid.unsqueeze(-1).to(token.dtype)
        context = (token * mask).sum(dim=2) / mask.sum(dim=2).clamp_min(1.0)
        context = self._temporal_context(context)
        mixed = self.mixer(token, candidate_xy_m, candidate_valid, context)
        expanded = context.unsqueeze(2).expand_as(mixed)
        logits = self.score(torch.cat((mixed, expanded), dim=-1)).squeeze(-1)
        logits = logits.masked_fill(~candidate_valid, -1.0e4)
        acceptance = torch.sigmoid(self.accept(self._gate_input(context, mixed)).squeeze(-1))
        return RegisteredCandidateExpertOutput(candidate_logits=logits, acceptance=acceptance)


def build_registered_route_expert(
    implementation_id: str, *, feature_dim: int, hidden_dim: int = 64
) -> RegisteredDiscreteCandidateExpert:
    try:
        spec = _SPECS[str(implementation_id)]
    except KeyError as error:
        raise ValueError(f"unknown registered route-expert implementation: {implementation_id!r}") from error
    return RegisteredDiscreteCandidateExpert(spec=spec, feature_dim=feature_dim, hidden_dim=hidden_dim)


def decode_discrete_physical_candidate(
    output: RegisteredCandidateExpertOutput,
    candidate_xy_m: Tensor,
    candidate_valid: Tensor,
    *,
    acceptance_threshold: float,
) -> DiscreteCandidateDecode:
    """Decode exact identity or one indexed measured candidate, never a mean point."""

    if not 0.0 <= acceptance_threshold <= 1.0:
        raise ValueError("acceptance_threshold must lie in [0, 1]")
    if candidate_xy_m.shape != output.candidate_logits.shape + (2,):
        raise ValueError("candidate coordinate shape mismatch")
    if candidate_valid.shape != output.candidate_logits.shape:
        raise ValueError("candidate validity shape mismatch")
    if not bool(candidate_valid[..., 0].all()):
        raise ValueError("candidate zero must be the valid exact identity fallback")
    choice = output.candidate_logits.masked_fill(~candidate_valid, -1.0e4).argmax(dim=-1)
    safe_xy = torch.nan_to_num(candidate_xy_m, nan=0.0, posinf=0.0, neginf=0.0)
    proposed = safe_xy.gather(2, choice.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, 1, 2)).squeeze(2)
    identity = safe_xy[:, :, 0]
    intervened = output.acceptance.ge(float(acceptance_threshold)) & choice.ne(0)
    final_xy = torch.where(intervened.unsqueeze(-1), proposed, identity)
    return DiscreteCandidateDecode(
        choice_index=choice,
        proposed_xy_m=proposed,
        final_xy_m=final_xy,
        intervened=intervened,
    )
