"""Minimal, auditable AGENT-JSAC orchestration package."""

__version__ = "0.1.0"
