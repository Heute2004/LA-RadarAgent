# Recovered Training Contract

## Authority

The five Python files and SOURCE_MANIFEST.json were collected from the laboratory server release portable_toolbox_full_lifecycle_ready_20260829. The model/trainer hash pair matches 252 catalog-matching historical receipts outside failed-attempt directories. This is not a claim of 252 independent models or successful promotions.

All archived Python files are unchanged. Their locations and SHA256 values are in SOURCE_MANIFEST.json. Collection parses source without executing imports. No checkpoint or dataset payload was accessed.

## Exact Objective

The recovered trainer uses:

`L = L_set + 0.10 L_preference + 0.50 L_acceptance + 0.02 L_continuity`.

Supervised frames require positive sample weight, radar_training_valid, and nonempty allowed_weight. Acceptance supervision is whether candidate zero is outside the allowed set. Continuity penalizes squared excess over 0.75 metres of expected candidate-position step on adjacent radar-valid frames. These are historical implementation facts, not newly selected hyperparameters.

Do not replace this objective with coefficients from another dated source snapshot merely because its filename is identical. Historical correctness and current production suitability must be assessed separately.

## Inputs and Parent Contract

The trainer accepts candidate coordinates, candidate validity/features, allowed-set weights, sample weights and radar validity in sequence-level runtime archives. Parent branch is one of cora0, cora_se1, cora_se2 and is checked against both target Support and source replay episodes. This is candidate-level expert training, not a raw RA feature-backbone trainer.

The historical entrypoint declares Support internal calibration and separate source replay. This static recovery does not prove the provenance of any concrete runtime cache or permit its use. Cache labels, hashes, split boundaries and receipt-specific arguments still require validation before production admission.

## Preparation Status

- Static Python dependency closure: five files; no missing local import and no detected dynamic import.
- Collector regression: eight tests passed on the server; eleven including package-closure tests passed locally.
- No optimization, model training, Development scoring or Locked Test read was run.
- Not yet admitted as a complete production recipe. Third-party environment, runtime payloads, prevention of training during preparation, and dispatcher binding remain separate gates.

The collector now treats agent_jsac as a local source package. Previously its local imports could be incorrectly classified as external dependencies.
