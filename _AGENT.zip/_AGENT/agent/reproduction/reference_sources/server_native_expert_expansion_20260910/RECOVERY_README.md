# Historical Native Expert Source Recovery

Recovered on 2026-09-10 from `/home/hyc/radar+ris/JSAC-AGENT-V4`.
These are original source bytes, not newly designed expert implementations.
Historical filenames remain unchanged for provenance; they are not public task identifiers.

## Scope

- Ten historical training entrypoints and their statically discovered local Python dependencies: 48 files.
- `SOURCE_MANIFEST.json` records the SHA256 of each recovered source file.
- Compared with `reproduction/sources/JSAC-AGENT-V4`: 41 files absent, seven identical, zero conflicting files.
- Stored separately; no existing production implementation was overwritten.
- No training entrypoint was executed. No model weights or dataset payloads were collected.
- No Locked Test data was read.

## Entrypoints

| Original script | Recovered mechanism or role |
|---|---|
| train_r8_route_specialist_v2.py | MHPC dry / WTTI wet scorers and partial-label trajectory objectives |
| train_r8_outdoor_set_expert.py | Outdoor candidate-set expert |
| train_r23_hybrid_tbd_specialist.py | Hybrid existence / track-before-detect candidate manager |
| train_r17_tcrg_specialist.py | Causal reachability candidate graph |
| train_wrca_expert.py | Daytime wet-return physical candidate association |
| train_full_ra_wet_expert.py | Full-RA wet expert |
| train_wet_return_radar_setmass_expert.py | Radar set-mass training entrypoint |
| train_freeze_wet_return_classical_expert.py | Classical wet-return candidate / gate pipeline |
| train_causal_offset_route_expert_v4.py | Causal route offset training |
| train_correctness_gated_route_expert_v4.py | Correctness-gated route training |

The closure also includes the historical CPB-ConvLSTM expert factory, wrappers,
geometry, heterogeneous / E3 / E7 / E9 model modules, and data/loss helpers.

## Supplemental Protocol Files

These five files were copied directly from the same server source root. Local
SHA256 values were independently compared with server `sha256sum` and matched.
They supplement, but are not members of, the original 48-file source manifest.

| File under configs/ | SHA256 |
|---|---|
| WRCA_DAYTIME_PROTOCOL_V1.json | 906efdbfcfa99e26f8418fbbe0b557c1294ce2549dd7bff8338848ee2a98fc07 |
| R23_HYBRID_TBD_WET_GROUND_PROTOCOL_V1.json | 9e031f56704927b87d1509c8b84b87db05d59bd858afa7f1547d31af0cc54aaf |
| R17_TCRG_SPECIALISTS_PROTOCOL_V1.json | e07134d9b87abf9c7d79de24ece4a66edd64d5bd22eaf8c188c3513c094598c4 |
| CORA_SE2_ROUTE_SPECIALISTS_PROTOCOL_V1.json | 3853d957ad0a234354b4ad5cab6cdc7b7bfeed7ab702257fc0c72298918c322b |
| FULL_RA_WET_EXPERT_PROTOCOL.json | f262e7f012fd99a95c6a679873f5c19c476c9ffbd35e8e3714ee48412fc473c6 |

## Acceptance Boundary

Source recovery is not equivalent to validating all 42 catalog entries. Next,
match each original architecture to its launcher, supervision contract, parent
contract and historical completion receipt. Do not infer equivalence from names.
Unmatched entries remain unresolved; do not invent replacements.

The AST dependency scan reported no missing local imports or dynamic imports.
This does not certify third-party environment availability, arbitrary runtime
file dependencies, or historical numerical reproduction.

This collection belongs to Human. UAV has no expert pool.
