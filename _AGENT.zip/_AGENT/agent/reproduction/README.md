# Reproduction Asset Audit

## Status

Code/metadata collection and static verification passed. This is not a numerical
reproduction certificate and does not authorize training or Test access.

Start with `INDEX.json`. It separates the Human and UAV contracts, the current
Human Development-best registry, its rain-night extension, and the earlier
Human reference-only table. Never pool Human distance AP and UAV OLS metrics.

## What Was Recovered

- 259 server code/config/receipt files; 83 Python files passed syntax checks.
- 13 local recovery files; 10 Python files passed syntax checks.
- Three Human execution plans (77, 14 and 82 jobs) have no missing script
  references or dependency identifiers. These plans overlap; they are not
  173 independent experiments. Candidate counts are 30, 5 and 30 respectively.
- CSS training config exactly matches the hash stored in its frozen checkpoint.
- UAV source and adaptation run parameters, completion receipts and teacher
  provenance were recovered from the server. Do not substitute CLI defaults.
- Related task-package and inventory regression suite: 37 passed.

## Resolved Collection Requests

The original collector reports two missing paths. Preserve that report:

1. SE1 has no root `run_contract.json`; its actual parameters are in the nested
   `source_training/raw_adapted/run_config.json`, linked by the index.
2. The server copy of the CSS trainer was absent. Its local trainer and import
   closure are sealed under `local_recovered/`, with the original training config.

## Important Boundaries

- The SE1 receipt grants internal upstream use only. Later Development-best
  replay selection is not equivalent to online promotion authorization.
- SE2 is a set-mass residual adapter with frozen CORA0/SE1 references; do not
  replace it with a generic whole-backbone fine-tuning recipe.
- RIS gate reproduction requires its shared proposal checkpoint, not just CORA0.
- Rain-night use is zero-shot radar-only takeover, not training with night data.
- UAV support_dev RTK is used for checkpoint selection, not target training
  loss or pseudo-label construction. Its offline teacher also references a
  Doppler support cache. Deployment input and teacher dependencies are distinct.
- The original UAV trainer embeds post-fit evaluation, including source_test.
  It must not be launched under this no-Test audit authorization.
- Existing coordinate-reencoding quarantine and RIS provenance caveats remain.

## Still Required Before Fresh Execution

1. Verify external model/data/label-cache hashes and split bindings on the host.
2. Bind production tool adapters to these exact commands and their dependencies;
   passing the control-flow simulator does not establish this binding.
3. Verify historical source equivalence where an original code hash is available.
   Current collected source hashes alone cannot prove the historical revision.
4. Run authorized inference/evaluation to verify numerical reproduction. A new
   stochastic training run cannot be guaranteed bit-identical from scripts alone.

No trainer was imported or executed by the inventory audit. No sample datasets
or Test records were opened. CSS checkpoint inspection extracted metadata only.

## Audit Command

```powershell
python scripts/audit_reproduction_inventory.py --output artifacts/reproduction_inventory/AUDIT.json
```

`COLLECTION_MANIFEST.json` seals the server snapshot. The independent manifest
under `local_recovered/` seals the local recovery. Historical names in evidence
paths are intentionally retained for provenance; public stage names are in the index.
