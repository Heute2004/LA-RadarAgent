# 并行准备验收记录

本轮只做正式训练前准备。没有启动感知模型训练，没有打开 Locked Test，没有修改冻结指标或装入冻结专家权重。

## 已验证

| 项目 | 当前证据 | 边界 |
| --- | --- | --- |
| 14 个已审核专家入口、三个父分支 | 本地相关三组测试 146 passed | 是合成缓存下的准备合同，不是 42 个专家全部可训练 |
| 隔离服务器版本 | 1,764 个文件安装后逐项哈希通过 | 增量候选版本，不是最终完成包 |
| 服务器回归 | 相关三组测试及 UAV 编译计数，共 147 passed | 不运行优化器训练 |
| UAV 计数修复 | 独立复跑相关六组测试，26 passed | 拒绝请求不计为已进入原生命令编译 |
| UAV 当前原生解析器 | 5 passed | 接受冻结参数，拒绝 source_test、locked_test、test 三种 postfit 请求 |
| SetMixer 真实 Qwen 调用 | 正常配置到 monitor，错误代码哈希到 rollback | 其他阶段用模拟回执，不能称为数值复现 |
| MTI Agreement 真实 Qwen 调用 | 父分支 SE1，正常配置到 monitor | 不证明专家选择最优或训练收益 |
| RIS 恢复证据 | 10 个文件独立哈希核验，零不一致 | selective 回执源码未精确绑定；geometry 仍缺自己的训练回执 |

各测试组有重叠，不应把本表的测试数直接相加当作独立覆盖总数。

服务器版本：`/home/hyc/radar+ris/AGENT-JSAC/releases/parallel_preparation_candidate_20260910`。
本地 ZIP：`PARALLEL_PREPARATION_CANDIDATE_20260910.zip`。
SHA256：`fef9f7758e7616e1973a83a7c9f572b3d155a0b403a6320ee1512fe75298f838`。

## 仍未完成

- 42 个原名专家并非全部已完成真实结构、训练损失、输入和回执绑定。
- 历史源文件/训练回执的匹配，不等于完整的新谱系准备验收。
- 逐专家覆盖报告正在修正对原生 Qwen 回执的精确标识匹配，未将漏报当作新功能缺失。
- UAV 旧脚本与当前任务入口分开审计；不能用历史脚本的 Test 分支误判当前入口，也不能将参考缓存的拦截成功外推为新缓存生成已验收。
- 最终合包、逐阶段新谱系依赖及完整 go/no-go 仍需继续收口。

以上是阶段进展，不是目标完成声明。

## 后续独立验收

修订审计包 `PARALLEL_AUDIT_REVIEWED_20260910.zip` 已安装至服务器
`releases/parallel_audit_reviewed_20260910`，1,775 个文件校验通过。
ZIP SHA256：`db41a8d222a2923318cbb2d544e167749f47ff8ad142afbb384479a0449187a8`。
包闭包、UAV 原生解析器及专家审计测试在服务器独立执行：9 passed in 2.94s。

逐项回执精确匹配发现已审核入口中仅 Track-Before-Detect 缺正例，因此在该服务器版本补跑真实 Qwen，选择 CORA0 父分支，13 次记忆恢复后到达 monitor。
`TBD_QWEN_VALID_20260910.json` 已回传本地；新鲜汇总
`EXPERT_PREPARATION_COVERAGE_WITH_TBD_20260910.json` 确认 42 项中有 14 项通过准备入口审核且存在匹配的 Qwen 正例。
这不代表其余 28 项已完成，也不授权这 14 项正式训练。
