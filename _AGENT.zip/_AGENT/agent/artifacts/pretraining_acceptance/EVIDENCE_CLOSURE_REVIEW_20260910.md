# Evidence Closure Integration Review

Scope: pretraining readiness only. No sensing-model training, optimizer step,
Locked Test read, model promotion or numerical reproduction was performed.

## Verified changes

- Human task instructions now state 40 expert intents. Cardinality and branch
  entry regressions: 24 passed. UAV remains expert-free.
- The original branch Qwen positive reached `monitor_reached` with 13 restores;
  missing Support reached `rollback_executed` with 11 restores. Both raw reports,
  raw memories and their exact copies match the evidence-index SHA256 values.
- The coverage audit finds 35 reviewed preparation entries in the 40-ID catalog.
  This is not full original-training-DAG admission.
- The release packager now follows pinned JSON references in the candidate and
  branch evidence indexes, verifies their hashes, and includes the raw memory,
  report and profile metadata. No model or sensor payload is added.
- Fourteen remote candidate profile JSONs were retrieved byte-for-byte and
  validated against the existing index. The original batch report, including its
  failed aggregate flag, was not rewritten.
- Evidence path traversal, model payload inclusion and hash mismatch are
  rejected. Remote profile relocation uses one explicitly declared remote root.
  Packaging and atomic-publication regressions: 14 passed.

## Server candidate installation

This is an intermediate candidate, not the final seal:

```text
artifacts/pretraining_acceptance/EVIDENCE_CLOSURE_CANDIDATE_20260910.zip
SHA256 feb0fe0d05f33e8a694f19e99b598b016c423aa71bc832e190138ceba8179442
1982 files; 7698978 bytes
server: /home/hyc/radar+ris/AGENT-JSAC/releases/evidence_closure_candidate_20260910
installer result: 1982 installed files, pre/post extraction hashes verified
```

Later working-tree additions are not retroactively part of this package. A final
seal must be rebuilt after the original-DAG and RIS preparation work completes.

## Linux behavioral crosscheck

A subsequent independent candidate was installed without modifying either
earlier release:

```text
READINESS_PROFILE_CANDIDATE_20260910.zip
SHA256 e0b28f2d88e4601880722c76ec5b60a4713a070c850eca0712606d3f8fe27a3a
1987 files; 7719675 bytes
server: /home/hyc/radar+ris/AGENT-JSAC/releases/readiness_profile_candidate_20260910
```

The first requested test list stopped before collection because
`test_human_source_compiler.py` was not in that package. The packager and its
closure test were corrected in the working tree; packaging and atomic tests
then passed (14 tests). This correction is not retroactively in the candidate.

The remaining bundled Linux tests ran independently with CUDA hidden:

```text
test_human_external_profile_replacement_readiness.py
test_portable_profile_preflight.py
test_profile_dependency_restore.py
test_qwen_original_branch_router_fixture.py
test_prepare_original_branch_router.py
test_qwen_historical_ris_preparation.py
test_ris_prepare_only_integration.py
56 passed in 4.82s
```

These are synthetic contract/forward/loss and fault-path checks, not a new Qwen
model run or sensing training. The missing source-compiler test passed locally
with the replacement-profile set (18 tests); its Linux rerun remains required
in the final complete package.

The same isolated Linux release also exercised all configured control states
using `check_pretraining_control_paths.py`. The 29 success/failure cases passed,
with disk restore after every request and simulated non-promotable receipts.
Evidence: `READINESS_PROFILE_CONTROL_PATHS_20260910.json`.
Its decision source is explicitly `deterministic_first_legal_tool` and
`qwen_decision_quality_verified=false`; this is state-machine and recovery
evidence, not an additional real-Qwen success claim.

## Original CLI bootstrap checks

The isolated Linux release ran the following original entrypoints with `--help`
only, using `/home/hyc/.conda/envs/rvmg/bin/python` and hidden CUDA devices. All
four exited 0. No training arguments, dataset paths or output directories were
supplied, and argparse exited before training setup.

| Relative path under `reproduction/reference_sources` | Explicit source import root | Result |
| --- | --- | --- |
| `server_registered_training_dependency_closure_20260910/scripts/train_se_branch_route_expert.py` | Script-local `src` | CLI import/parser PASS |
| `server_gble_recorded_training_20260910/train_branch_router_recipe.py` | `agent_expert_runtime_contracts/src` through PYTHONPATH | CLI import/parser PASS |
| `server_registered_training_exact_20260829/train_se_branch_route_expert_recorded_aug31.py` | `agent_expert_runtime_contracts/src` through PYTHONPATH | CLI import/parser PASS |
| `agent_expert_runtime_contracts/scripts/train_se_branch_route_expert.py` | Script-local `src` | CLI import/parser PASS |

The original parser's historical ID choices are not current execution
authorization: retired IDs and codebook quarantine are still enforced by the
active 40-entry catalog and dispatcher. These bootstrap checks do not prove
full input/receipt binding or authorize any original trainer to run.

## Remaining explicit limits

## Subsequent local integration verification

The current worktree (not either earlier immutable release) now bundles the
34 byte-exact RIS server JSON records through their relative-path/hash index.
Packaging rejects traversal, non-JSON payloads and changed hashes. The index
SHA256 is `4d220b7cc173cf120f849158834546d45ab220c53d94032f51c9fd255ad857a6`.
The new original-DAG dispatcher test is also explicitly included in the package.

Independent local regression:

```text
test_pretraining_package_closure.py
test_registered_original_dag_dispatch.py
test_original_dag_preparation.py
72 passed in 8.85s
```

This checks compilation/preparation and evidence packaging only. It does not
execute a trainer, load a training checkpoint, or prove numerical reproduction.
The dispatcher still needs an explicit readiness distinction for historical
reference inputs whose supervision origins do not satisfy the original CLI
contract. Such reference preparation must not imply formal training readiness.
The remaining separate-ABI expert contracts and SE1/UAV fixes are in progress.
No final server release has been sealed from these latest changes.

## Overall decision retained

## Offline calibration-origin compatibility correction

The earlier c3 source-origin blockage is resolved by the main integration.
The exact pinned runtime already has `calibrated_depth_lineage` and persists
the four-field offline-only provenance in `write_runtime_manifest`; its trainer
accepts the concrete origin string. The new compiler had accidentally omitted
that admitted variant. It now validates the original lineage fields and keeps
the origin unchanged. Missing lineage, reopening depth or generating free
coordinates still fail. Only newly generated synthetic fixture metadata was
completed; historical label files, reports and frozen results were unchanged.

The added test first failed at the incorrect origin allow-list; the actual
dispatcher test then failed at its matching omission. After both fixes, c3
compiler plus c3/branch-dispatch regression completed with
`70 passed in 6.53s`. This supersedes the earlier unresolved-origin notes above.
The updated real-Qwen preparation path still needs its final server rerun.

## All original ABI helper families delivered

The separate RIS compiler/receipt validator has now been independently checked
with the c3, branch and graph modules: `90 passed in 5.57s`. The five named RIS
identities are represented; four compile synthetic preparation commands and
the quarantined Codebook identity is rejected before output creation. The
RIS-specific zero-weight replay and observed-candidate origins are preserved.
Tests/documents are included in the package allowlist. This completes the
standalone helper coverage, not their actual Agent dispatch integration or
the final independent Linux release acceptance.

## Graph contracts and changed UAV behavior

The three Graph Aug31 original CLI/receipt contracts are delivered in
`original_graph_dag_preparation.py`. They retain the required production-family
argument and an explicit import-root environment for the independently archived
trainer. Independent c3+branch+graph verification: `83 passed in 5.63s`.
Agent dispatcher integration is a separate remaining requirement.

The changed UAV backend was exercised with real Qwen plus the existing LoRA in
an isolated server release. The valid teacher receipt reached monitor (12 memory
restores); omission of the required teacher receipt caused a shadow-train
rejection and rollback (10 restores). All receipts remain simulated,
non-promotable, with training/Test/numerical reproduction false. The main
integration independently verified the hashes of 14 original JSON artifacts
including the acceptance index, reports, memories and metadata. Their package
closure is pinned by `QWEN_UAV_RECEIPT_RECOVERY_EVIDENCE_INDEX_20260910.json`.
Closure/publication regression after adding them: `18 passed in 3.70s`.

The RIS inventory correction is recorded in
`RIS_CODEBOOK_PROVENANCE_DRY_RUN_INVENTORY_20260910.json`, SHA256
`f4690c8214685ea50ee6ce39dcc1572503bb11f28f751768c6472bfe05215366`.
Unlike the earlier guessed Windows mirrors, the actual H:/Data root contains
the eight metadata files and eight referenced state CSVs. These are potential
missing-only filesystem copies, not proof of admission; no synchronization or
quarantine release was performed. The inventory preserves the superseded
incorrect local-root finding and its digest in a correction note.

## Separate branch-router ABI delivered

`original_branch_dag_preparation.py` now compiles the exact recovered branch
trainer and validates its declared receipt without importing the trainer or
opening checkpoint/NPZ payloads. It preserves 80 epochs, three grouped OOF
folds, the original 18-input/48-hidden model and the three-branch prediction
freeze contract. It does not substitute the c3 trainer's optimizer flags.

Independent local branch+c3 regression: `66 passed in 4.42s`.
Package closure and atomic publication after adding the branch test/document:
`18 passed in 3.94s`. These totals overlap earlier verification. Integration
into the actual branch preparation dispatcher is still pending; a standalone
compiler pass is not counted as an Agent calling that compiler.

The integration review identified concrete missing fields in the old branch
profile: current target-fit root, independent source-replay root, EmptyGuard
artifact and fresh output namespace. Its single Support manifest is not a
replacement for these inputs. The verified parent report also needs the
original parent-selection content hash, not a renamed generic file digest.
The existing prediction root can be reused only after its manifest hash and
three-branch freeze are verified. The dispatcher extension is being implemented
against these requirements; no missing input has been fabricated from the old
reference profile.

## Current catalog reconciliation

`EXPERT_READINESS_CURRENT_20260910_1945.json` was generated by the existing
readiness reporter without executing trainers. All 40 entrypoint hashes match;
35 entries have discoverable preparation methods. The report retains 38
`unbound` production bindings, one explicit native replacement and one
quarantine. Those production statuses are not counts of missing scripts and
must not be conflated with the 31 compiled source-contract identities or
successful synthetic/Qwen preparation. No route has blanket five-candidate
production authorization; integrating remaining preparation contracts must
not silently grant it.

## SE1 reference classification and in-flight UAV packaging

SE1's nine questioned references resolve to seven explicitly V4-rooted external
hash-bound inputs, one real package-local parameter-evidence file, and one
future output namespace. `tasks/human/integration_manifest.json` now registers
the package-local `configs/source_scene_registered_tools.json`. No external
dataset or future output is fabricated or bundled to satisfy the audit.

A full current-worktree portability run completed with 5 passed / 2 failed.
The reference-classification case passed; both failures reject the in-flight
UAV backend edit because its integration-manifest digest is stale. This is
fail-closed behavior, not a completed UAV regression. The UAV owner must finish
the verified patch and update its exact code pins, then all seven cases must be
rerun. Do not bypass the asset-drift check or call this run passing.

After the UAV owner updated only the two verified code pins, the independent
rerun of whole-package portability plus UAV training-preflight/native-backend
tests completed with `21 passed in 14.06s`. This supersedes the two in-flight
hash failures above without deleting their record. The changed teacher-handoff
denial must still receive its targeted real-Qwen behavioral rerun.

## Independent original-DAG candidate on Linux

Archive: `ORIGINAL_DAG_CANDIDATE_20260910_1932.zip`, 2,035 files, 7,841,513 bytes.
SHA256: `a1e41e1caac3313a2e93352762f3cf43e3e4b455e92b62e6df6a8c3febc19f54`.
Installed in a new directory at
`/home/hyc/radar+ris/AGENT-JSAC/releases/original_dag_candidate_20260910_1932`;
all archive and installed member hashes passed. Earlier releases were unchanged.

With CUDA hidden, the independent Linux package passed:

```text
test_human_source_compiler.py
test_original_dag_preparation.py
test_registered_original_dag_dispatch.py
test_historical_ris_qwen_synthetic_release.py
test_qwen_historical_ris_preparation.py
81 passed in 8.85s
```

The previously missing source-compiler test is now included and verified on
Linux. These tests validate compilation, synthetic preparation and evidence
checking, not an additional real-Qwen run or sensing-model training. This
candidate predates the still-running SE1/UAV and separate-ABI follow-up fixes
and is not the final production release.

## Live infrastructure check (2026-09-10 11:31 UTC)

Direct SSH to the configured lab407 target succeeded. The selected runtime is
Python 3.11.15, Torch 2.12.0+cu130, CUDA 13.0; CUDA availability returned true.
The project filesystem reported 882 GiB available. Four RTX 5090 GPUs reported
free memory of 21,563 / 16,731 / 8,150 / 18,602 MiB respectively. These are
point-in-time observations, not reservations or permission to stop other jobs.
No model training was launched during this inspection.

An independent local run of atomic-publication, Human-source-compiler,
external-profile-replacement, portable-preflight and dependency-restore tests
completed with `24 passed in 1.34s`. Test totals overlap previous runs and must
not be summed as unique coverage.

The Human six-stage Qwen preparation chain and adopted UAV preparation flow are
verified, but complete per-expert original commands and future producer-receipt
contracts remain under integration. RIS codebook provenance stays quarantined:
recovering missing local metadata does not make position-preserving provenance
pass the current contract. Synthetic RIS structure checks cannot authorize
formal RIS training. Overall goal remains active and production remains NO-GO.

## Original command and release-closure regression

The c3 compiler now accepts the pinned runtime's existing
`sealed_RadarCandidateSet_with_offline_calibrated_depth_lineage` origin only
with its explicit offline-calibration provenance. Missing or contradictory
lineage remains a rejection. This fixes a compiler allow-list omission; it
does not modify historical labels, open raw depth, or relax forbidden reads.

The combined c3/branch dispatch test was initially absent from the release.
A package-membership regression failed on that exact missing file, then the
packager was updated to include it. The following bounded local suite passed:

```text
test_pretraining_package_closure.py
test_combined_original_native_dag_dispatch.py
test_original_dag_preparation.py
test_original_branch_dag_preparation.py
test_original_graph_dag_preparation.py
test_original_ris_dag_preparation.py
105 passed in 10.04s
```

This proves the tested synthetic dispatch, metadata-only original-command
compilation and package closure. It is not a fresh real-Qwen invocation,
training run, numerical reproduction, or authorization to admit the
quarantined Codebook candidate. Graph and RIS dispatcher integrations and
the final isolated-server release still require their own current evidence.
