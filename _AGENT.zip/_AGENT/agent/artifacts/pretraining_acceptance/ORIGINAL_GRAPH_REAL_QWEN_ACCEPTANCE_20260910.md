# 原生图专家真实 Qwen 准备验收

日期：2026-09-10。范围：Human 两个原生图专家；UAV 不涉及专家库。

## 已执行

服务器 `lab407`，独立 release：
`/home/hyc/radar+ris/AGENT-JSAC/releases/original_graph_qwen_20260910`。

发布包 1,874 文件，SHA256：
`166645da4f61dcd4f2c85b827b37398db3af82c01197c7bc22d0d4533d4c4e74`。
上传后核对 ZIP SHA256，安装器逐文件核对发布 manifest。

使用现有 Qwen2.5-0.5B-Instruct 与 qwen_gate_continuation_20260908/adapter；GPU3 只运行语言模型推理。雷达准备入口使用 synthetic Support，并在优化器之前拦截。

| 用例 | 实际结果 | 状态恢复次数 | 原生准备调用 |
|---|---|---:|---:|
| tcbav_temporal_candidate_graph / cora_se1 | monitor_reached | 13 | 1 |
| candidate_survival_graph / cora_se2 | monitor_reached | 13 | 1 |
| tcbav 缺失 native-support-manifest | rollback_executed | 11 | 1 次被拒绝 |

第三项实际错误：`historical graph dispatch requires --native-support-manifest; generic fallback is disabled`。

本地原始回执：
- `QWEN_GRAPH_TCBAV_NATIVE_20260910.json`
- `QWEN_GRAPH_SURVIVAL_NATIVE_20260910.json`
- `QWEN_GRAPH_MISSING_SUPPORT_20260910.json`

正常案例检查原历史模型、结构签名、输入 ABI、原损失、源文件 SHA256，以及当前 profile 父分支和 Support 绑定；不能拿 generic preparation 的布尔通过字段代替。

## 证据边界

这是实际 Qwen 发出工具请求、Dispatcher 执行原生准备、生命周期恢复及失败回滚的证据。其他阶段明确模拟；并非 source-to-expert 全流程的真实训练或数值复现。

未执行感知训练、未建立优化器、未读取 Locked Test、未修改冻结结果、未授权生产晋级。状态机中的模拟 `promote` 不代表部署了专家。

主线程独立回归：graph fixture/dispatch 77 passed；SE1 preparation-to-SE2 handoff 45 passed。两组不是全工具箱验收结论。

## 尚未完成

其余原生专家准备入口、最新 source/SE1 活动配置整体验收与最终统一发布仍在集成。不得依据本报告标记整个训练前 goal 完成。
