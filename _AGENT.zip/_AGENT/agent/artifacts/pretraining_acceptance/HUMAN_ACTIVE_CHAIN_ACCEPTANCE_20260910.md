# Human Active-Profile Integrated Preparation Acceptance

## Verified Result

The real Qwen + verified existing LoRA run reached `monitor_reached` after all
six native preparation checks, in order:

`source -> sentinel -> se1 -> se2 -> teacher -> specialist`

Report: `HUMAN_ACTIVE_FACTORY_QWEN_20260910.json`

Report SHA256:
`0d68ebbe4d11d32e62159ff9d296d36a0b9f6a9b14d99ae72f69d76832d0e792`

The report verifies active SE1 profile mapping, current-run simulated source
binding, native SE2 consumption of the current SE1 preparation receipt, and
13 memory restores. SE2 reports `GO`, `se2_reference_only=false`.
All receipts remain non-promotable; `training_performed=false`, `test_read=false`,
and `numerical_reproduction_verified=false`.

## Runtime and Reproduction

Server release:
`/home/hyc/radar+ris/AGENT-JSAC/releases/human_active_factory_acceptance_20260910`

Release archive SHA256:
`38b01033dec7e8594dc6af3fb4c9bf3acde7112fb7dd337c7c413e6c960d08d2`

All 1,921 package member hashes were verified during installation.
The source reference configuration is the existing
`artifacts/QWEN_INTEGRATED_HANDOFF_20260909_PROFILE.json` on the server.
The fixture compiler emits a separate profile, verifies existing external pins,
and records old/new script hashes without overwriting the reference configuration.

Fixture: server `artifacts/HUMAN_ACTIVE_FACTORY_FIXTURE_20260910/FIXTURE.json`.
Run: server `artifacts/HUMAN_ACTIVE_FACTORY_QWEN_20260910`.
Execution uses the fixture's explicit checker command with the existing Qwen
model and LoRA paths, on GPU0. Sensor-training subprocesses stay intercepted.

## Bugs Exposed and Fixed by the Actual Run

1. Fixture script-hash keys now match the checker short filenames rather than
   an incompatible `scripts/`-prefixed key convention.
2. Direct fixture CLI execution now includes the release root in its import
   path. A subprocess regression runs without PYTHONPATH from another directory.
3. The historical specialist wrapper imports `train_stage` without re-exporting
   `make_model`. Model preparation now resolves the actual factory bound in
   that imported function. Conflicting exported/global factories are rejected;
   no replacement head is invented and the training function is never called.

The earlier failed run is preserved as
`HUMAN_ACTIVE_CHAIN_QWEN_ENV_20260910.json`. It reached the specialist boundary,
reported the factory error, and Qwen rolled back. It was not edited into a pass.

## Scope and Remaining Work

This is a real controller invocation with native preparation checks and
synthetic/reference producer inputs, NOT fresh sensing-model training or a
numerical reproduction. Source/Sentinel byte placeholders are marked not-a-model;
teacher and specialist inputs remain pinned reference inputs. No new teacher
labels or model checkpoints are claimed.

This proves the integrated path for the exercised profile. It does not by itself
certify all 40 candidate families, every deployment resource binding, RIS
receiver provenance, or the final packaged toolbox. Those remain separate gates.
