# UAV Teacher Binding Integration

Source candidate fitting, source temporal calibration and target temporal
application now accept the four explicit parent-cache binding arguments. With
these supplied, they resolve exact cache files instead of historical globs and
validate source reports against the bound checkpoint/index identity. Historical
calls with no binding retain the old reproduction behavior. Partial bindings
are rejected.

The three changed native scripts were backed up with matching hashes; current
task integration hashes were updated. Frozen reproduction source archives and
existing results were not overwritten. Twenty candidate/temporal/cache tests
passed locally. No fitting or target label regeneration was executed.

Remaining acceptance: native new-parent fixtures through all three entrypoints,
server release, cache exporter provenance, dispatcher requirement that fresh
runs supply these arguments, and actual Qwen nested orchestration. Optional CLI
support alone does not prove the production workflow uses it correctly.
