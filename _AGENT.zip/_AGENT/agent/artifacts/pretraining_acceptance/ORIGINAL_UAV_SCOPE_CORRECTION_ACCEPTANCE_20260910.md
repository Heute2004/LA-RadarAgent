# UAV 原交接口径修正验收

本轮只恢复原始 UAV 交接的准备范围，不新增实验、不修改冻结结果。

- 权威文件：`docs/handoffs/2026-09-08_UAV_TO_HUMAN_LINE_HANDOFF.md`，原 SHA256 未改变。
- 方法仍为 CORA-U0 与已注册目标场地的粗候选集适配分支；UAV 不使用专家库。
- `UAV_BINDING_EVIDENCE_AUDIT_20260910.json` 保留历史结论和证据，新增机器可读 scope_correction，明确旧新谱系结论不是当前准入门槛。
- 计划增加原交接优先级声明；未采纳的新谱系四文件继续排除出正式包。
- 新回归用例先失败（缺少 scope_correction），修复后通过。
- 本地选择性回归：13 passed，3.40 秒。
- 服务器独立安装后相同回归：13 passed，3.24 秒。
- 覆盖范围：原交接哈希、父权重与标签绑定、两分支路由、无专家、监督禁读边界、真实训练参数解析和包文件排除。不等价于全工具箱验收通过。

服务器候选目录：
`/home/hyc/radar+ris/AGENT-JSAC/releases/original_uav_scope_corrected_20260910`

包：`ORIGINAL_UAV_SCOPE_CORRECTED_20260910.zip`，1790 文件，6300968 字节。
SHA256：`d4cbc9633398c718e4ffe973cf0e10de2286a7c43a0715c53502f0c1ba7804d9`。

本次未启动感知训练、未读 Locked Test、未重新计算论文指标，未重复运行 Qwen。已有 Qwen 回执只保留各自原验证范围。

Human 尚未全通过：当前覆盖审计记录 42 个目录条目中 16 个具有精确身份匹配的准备及 Qwen 正向证据。其余条目继续逐项核查，不能从名称相似直接认定恢复。例如已存在的 CLOR 原生前向回执与目录 local_offset_gru 条目的映射仍需结构和训练合同核实，不能只给回执补 ID 就宣称完成。
