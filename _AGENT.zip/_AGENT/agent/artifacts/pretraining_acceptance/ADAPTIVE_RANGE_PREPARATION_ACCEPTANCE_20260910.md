# 距离自适应轨迹候选：训练前验收

## 本轮完成

- 恢复条目 `adaptive_threshold_tracklet` 的准备入口，不改变42项的名字或新增替代模型。
- 从服务器读取并保留原训练回执；回执绑定模型源码 SHA256 `3b379ea9955f23183b38b4368a096836f0cc50667943993ae58156e9a81ea9b8` 和训练器 `c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70`，本地精确恢复文件均通过哈希检查。
- `_AdaptiveRangeMixer` 与上述源码 AST 一致；只补准备入口与既有历史窗口执行器的连接。
- 无状态距离门接受合法 reset 元数据但不改变其前向；错 shape 拒绝。跨帧间隙由原有输入分段处理，不让状态跨序列延续。
- 覆盖 CORA0、SE1、SE2 三种父权重选择，以及 Support、source replay、EmptyGuard 绑定。
- 直接训练函数仍在构建优化器前拒绝该准备条目。

## 实测

- 本地主要回归：134 passed；补源码回执核验后机制测试42 passed。
- 服务器独立安装后同组测试：135 passed，6.03秒。
- 原 Qwen + 已验证 LoRA：合法请求 `monitor_reached`，13次记忆恢复，1次原生准备请求，passed=true。
- 同一 Qwen 对错误代码哈希：`rollback_executed`，11次恢复，passed=true。计数 native_compilations=1 表示请求尝试，不能解释为成功编译或训练。
- 目录覆盖审计：17/42具备精确实现身份匹配的准备正向调用证据。不是17个专家训练晋级，也不是全工具箱完成。

## 服务器封装

目录：`/home/hyc/radar+ris/AGENT-JSAC/releases/adaptive_range_preparation_20260910`

包：`ADAPTIVE_RANGE_PREPARATION_20260910.zip`，1791文件，6305340字节。
SHA256：`e7ca1d1ecfcccfc9e1cb88c55f2ed8e5ef58e16de09c1cb9f96a8ced7419ad73`。

本次 Qwen 使用合成缓存，不读取真实训练/开发/Test 数据；未优化感知模型，未加载专家权重，未重算冻结指标。准备执行器的因果窗口不宣称与历史整段推理数值等同。

## 未完成边界

其余25项逐条继续核对。CLOR原生连续偏移模型与42目录中的同名离散候选模型不能仅按名称合并；恢复从零训练入口不要求导入历史专家权重。UAV仍严格使用原始交接，排除专家库与未采纳的新谱系工作。
