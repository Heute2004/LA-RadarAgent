# Candidate and Branch Preparation: Independent Integration Check

## Scope

This is an intermediate acceptance record, not a final GO, training permission,
model promotion, or numerical reproduction claim. The active Human catalog has
40 original expert IDs. UAV follows its adopted handoff without experts.

## Independently Verified in This Pass

- Candidate fixture, candidate native entry, branch cache inputs, and active SE1
  profile checks: 80 tests passed in 6.34 seconds.
- Atomic package publication, pool cardinality, optimizer boundary, original UAV
  handoff/accounting, source receipt recovery, and RIS provenance: 68 tests passed
  in 5.21 seconds. These counts describe selected suites, not cumulative coverage.
- Original branch wrapper, branch cache loader, and original branch helper:
  16 tests passed in 2.14 seconds. The wrapper is not yet proof of Agent dispatch.
- Expert discovery and package publication: 12 tests passed in 2.02 seconds.
  Discovery now includes the original 20 declarations and 14 additional historical
  candidate declarations. Duplicate or missing identity declarations fail closed.
  Discovery does not grant production binding or bypass RIS quarantine.

## Server Release

An intermediate release was uploaded and installed with all 1,894 member hashes
verified before and after extraction:

`/home/hyc/radar+ris/AGENT-JSAC/releases/candidate_native_acceptance_20260910`

Archive SHA256:
`9c15bb4239a9ed53fb440b9f168f32b4f857796c639524eabc38b8cd561c38a2`

This archive predates the subsequent discovery repair and final branch/RIS
integration. It is an isolated candidate-Qwen verification release, not the final
toolbox snapshot. A later release must include and revalidate remaining changes.

## Remaining Acceptance

1. Actual Qwen invocation of the 14 original candidate preparation entries,
   including missing-Support rejection. Synthetic lifecycle outcomes must stay
   explicitly separate from sensing-model training or numerical reproduction.
2. Original branch-router and RIS Agent wiring, native input and loss receipts,
   and independently trusted RIS provenance. Do not weaken quarantine to fill
   a five-candidate shortlist.
3. Real integrated Human source/Sentinel/SE1/SE2/teacher/specialist interception
   with active source-parent profile binding, recovery and failure checks.
4. Final server/local release, English operating contracts, and Chinese
   requirement-by-requirement GO/NO_GO record.

No sensing optimizer, backward pass, training run, or Locked Test was executed
by this verification pass. Frozen results were not changed.
