# Source Payload Acceptance

The independent server verifier accepted 16 source sequences, 4,800 causal
windows and 9,616 payload files. See UAV_SOURCE_FULL_PAYLOAD_ACCEPTANCE.json.
This is data-loader and identity acceptance, not model performance reproduction.
No sensing optimization or Test payload access occurred.

The initial digest discrepancy was a provenance-binding bug in the audit:
the historical manifest retains the original truth digest, while the protocol
builder writes a field-restricted polar ledger to the server. Its existing
EASY53_HIT15_PROTOCOL_RECEIPT.json records both source and sanitized digests.
The verifier now requires an explicitly pinned receipt digest, checks that
receipt against the frozen server manifest, checks each original digest against
the manifest and each sanitized digest against the file actually loaded.
Neither the frozen manifest nor truth files were modified.

Receipt SHA256:
16a66a167902573b6514f9704a3502c7217dbc261aa3d401fc3624be4d787075

Regression tests reject an unpinned/changed receipt, changed manifest and
changed payload. Two focused tests passed. The earlier discrepancy report is
retained as audit history, not an unresolved corruption claim.

Overall toolbox readiness remains NO_GO until all remaining native stage,
portable binding and real-Qwen nested lifecycle gates pass.
