# 内部阶段训练前审计

当前总目标仍为进行中，不能启动正式训练。

## 本轮实查

- 直连确认主机为 lab407。
- 复用旧注册表的原生 SE1、SE2 工具，逐一验证其注册脚本和输入清单哈希，失败项为 0。
- SE1 真实入口为 `run_registered_cora_se1_stage.py`，不是顶层模拟中的空操作。
- SE2 真实入口为 `train_cora_se2_prospective.py`，调用原 set-mass residual trainer，SE1 权重通过 upstream checkpoint 参数绑定。
- SE2 metadata：fit 19 个序列、calibration 4 个、第二阶段合并 23 个，集合互斥及并集检查通过。
- 独立 support-canary 为 0。这个结果不能解释为独立 Canary 已通过；后续必须明确对应验收证据或保持禁止晋级。

## 本轮增加

新增独立分区预检：拒绝 fit/calibration 重叠、重复序列、合并集合不一致、canary 混入训练、缺失字段。原历史包装器未显式拦截其中部分情况。新检查目前接在训练前审计入口，尚未宣称全部正式 Dispatcher 路径已接入。

测试先失败后实现：新增 7 个测试通过。联合旧工具注册表和任务模拟回归，共 46 passed。

## 不能外推的结论

注册清单哈希匹配不等于目录中所有标签 payload 已核验，也不等于新任务的 DatasetProfile 已绑定。当前没有读取 Test 数据，没有启动感知训练，没有修改历史 checkpoint，没有新 AP。

## 下一步

把阶段预检与 runtime DatasetProfile、父模型回执和新输出目录绑定到同一可拦截执行入口；检查原生脚本的内部子命令，再跑真实 Qwen 的嵌套调用验收。UAV 按自身合同单独接入，不使用 Human 专家库。

证据：`pretraining_stage_partition_20260908.json`、`stage_preflight_regression.xml`。
