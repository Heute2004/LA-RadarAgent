# UAV Source Command Preparation

`agent_jsac.uav_source_preflight.compile_source_arguments` compiles the source
training argv from the frozen source parameter record. Runtime bindings contain
only manifest, truth root, output directory and device. They cannot override
training policy. The native entrypoint remains `train_cora_u_easy53.py`.

The frozen source run used 16 epochs, a minimum of 8 epochs, 400 steps per epoch
and batch size 4. Native defaults differ (18, 6, 300 and 2). All optimization and
architecture options are emitted explicitly. The source role is `u0`, its
selection role remains `source_development`, and intercepted preparation limits
postfit roles to source Development. UAV source selection uses native
`ols_map_50_90`; adaptation selection separately uses `ols_mid_map_30_70` on
support Development. Neither is Human distance AP.

Nine CPU unit tests passed, recorded in
`artifacts/pretraining_acceptance/uav_source_command_tests.xml`. They verify
frozen argument values, forbidden scope changes and runtime override rejection.
This does not certify payload access or live workflow binding. File hashes,
native parser execution, source payload membership and the task dispatch adapter
still need integration verification before the source request is executable.

No optimizer, model training or Test evaluation was executed for this check.
