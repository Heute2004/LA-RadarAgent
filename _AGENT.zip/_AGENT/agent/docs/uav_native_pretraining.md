# UAV Native Adaptation Preflight

The UAV task is independent from Human experts. Its native adaptation trainer
is `train_cora_u_coarse_set.py`; this preflight compiles a command but never
imports that trainer or creates a training subprocess.

## Parameter Authority

Read `tasks/uav/training.json` and its `adaptation_parameters` evidence file.
Explicitly render every supported training argument. Do not use trainer defaults:
the recovered run uses 4 epochs, 30 steps per epoch and target loss weight 0.05,
whereas the trainer defaults are 10, 160 and 0.20. The runtime binding may change
storage locations and device, not silently change the learning policy.

The checkpoint selection role is `support_dev` and metric is
`ols_mid_map_30_70`. Support-development truth is selection-only, not target
training loss or pseudo-label construction. Postfit roles are explicitly limited
to source development, support development and development query. Historical
source-test postfit evaluation is intentionally excluded by current authorization.

## External Bindings

The interception profile supplies absolute manifest, truth-root, source checkpoint,
pseudo-label CSV, fresh output directory and Python paths. It pins SHA256 for the
trainer, recovered parameters, manifest, source checkpoint and pseudo-label CSV.
Task must equal `uav`, mode must equal `intercept`. No Human expert or arbitrary
shell arguments are accepted.

Run on the server with the release `src` directory on PYTHONPATH:

```text
python scripts/pretraining_uav_adaptation.py --profile <external-profile.json> --output <new-audit.json>
```

This command is an audit, not a launch command. Do not execute its returned
training argv until remaining lifecycle and data-admission checks pass.

## Verified Scope

The server report `UAV_ADAPTATION_COMMAND_PREFLIGHT_20260908.json` verifies five
registered file identities and command compilation. Unit/integration tests cover
missing parameters, incorrect selection roles, typed flags, cross-task requests,
changed pseudo-label hashes, and no trainer import/output creation.

This does not prove all sequence payloads are eligible, truth reads are gated
inside the loader, or a newly trained upstream checkpoint has a valid lineage
receipt. Those remain mandatory before production launch. No new accuracy result
or model promotion is implied.
