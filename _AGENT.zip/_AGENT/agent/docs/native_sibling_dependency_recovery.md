# Native Script Sibling Dependency Recovery

## Defect and Repair

The source collector recognized `brace_v4.*` and `scripts.*` imports but
misclassified bare imports of existing files in the source root's `scripts/`
directory as external packages. Historical exporters use this form for their
training constants and prediction helpers. The old `complete=true` therefore
did not establish the claimed static local Python closure.

The collector now inventories existing top-level script modules and packages
without importing them. Transitive dependencies and package initializers are
collected, and original file hashes and containment checks remain enforced.
This is a tooling correction, not a new expert architecture.

Two regression tests failed before the repair and passed after it. Local and
server runs of source-closure and package tests both returned **9 passed**.
The server release includes the previously omitted source-closure regression
test file; the first attempted server test correctly failed because that file
was absent, before the corrected immutable release was installed.

Verified tool release:
`/home/hyc/radar+ris/AGENT-JSAC/releases/control_sibling_source_verified_20260910`

Release ZIP SHA256:
`6a503ca88d5694268e100e324b66af967aeafe77c65087645aa8e00e29c61c20`

## Recovered Source Results

- Source-tail training, export, audit and original test: 22 unique Python files.
  Four dependencies were absent from the union of the preceding two closures:
  `audit_r11_pca_specialist_development.py`,
  `freeze_cora_se2_r11_predictions.py`, `cora_se2_prediction_freeze.py`, and
  `r24_branch_selector.py`.
- The ten additional expert entrypoints still resolve to 48 Python files.
  Their count did not grow; their sibling helpers were already explicit entries.
- Both fresh archives were hash-verified before extraction into separate local
  reference directories. Earlier archives were preserved as audit evidence.

Reference directories under `reproduction/reference_sources/`:
`server_source_tail_sibling_closure_20260910` and
`server_expert_expansion_sibling_closure_20260910`.

Archive hashes respectively:
`b4ad09c205e65c620a319c5f839f56231ae2e8f9e0fa0335593ec0638165587d`
and `e29a0fbc31620c514051e4abddbe78629a6c44bd5a688ce41413ab1678d4ada3`.

## Original Tail Contract Check

Original protocol SHA256, matched between server and local:
`dee9a0bc867aa611cc3ec0f4c7e16b3753528be1aab27570e9d024313983ffe4`.

Two original tests passed locally on CPU: source sequence partition disjointness
and zero-adapter exact identity for logits and presence. Only synthetic tensors
and the protocol metadata were used. The source manifest coverage test was not
run; no source coordinate records were collected for this step.

## Remaining Admission Boundary

Static collection is not runtime certification: arbitrary path reads, optional
third-party dependencies, protocol bindings and historical receipts still need
verification. Bare missing module names cannot always be distinguished from
third-party packages by static analysis. Review external imports explicitly.

The recovered copies are historical references, not automatically active recipes.
No claim is made that all 42 semantic entries now have native production bindings.
No sensing training, checkpoint loading, sample inference or Locked Test access
occurred. UAV remains outside the expert pool.
