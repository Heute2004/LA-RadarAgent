# Pretraining Acceptance Matrix

Scope: the complete requested preparation and intercepted behavioral
acceptance, not sensing-model training or numerical frozen-result reproduction.
Paths below are relative to the toolbox. Evidence with synthetic/reference
inputs must retain that qualification.

| Requirement | Evidence inspected | What it proves |
| --- | --- | --- |
| Human source/Sentinel/SE1/SE2/teacher/specialist chain | `artifacts/pretraining_acceptance/human_completion_current_qwen_20260910/EVIDENCE_INDEX.json` | Real Qwen executes all six native preparation stages, active SE1 mapping, SE2 current receipt consumption, 13 restores, monitor reached |
| Original expert identities and five-candidate direct batches | `artifacts/pretraining_acceptance/qwen_batch_bound_actual_20260910/EVIDENCE_INDEX.json`; original-DAG regression suite | Five direct routes prepare five exact native candidates each; missing profile rolls back; original C3/Graph/Branch contracts remain distinct |
| RIS five-candidate selection and dispatch | `artifacts/pretraining_acceptance/ris_task_selection_standalone_actual_20260910/EVIDENCE_INDEX.json` | Real Qwen task selection flows to public mixed dispatch; missing H16 rolls back; quarantined codebook is not selected |
| Native RIS teacher and payload compatibility | `artifacts/pretraining_acceptance/RIS_CURRENT_TEACHER_TENSOR_AUDIT_20260910.json`; `docs/ris_real_teacher_acceptance.md` | Current six-Fit/two-calibration loader reads 2,400 causal clips and 4,800 arrays; separate 24 sidecars have matching data hashes; no physical-measurement claim |
| Source Human payload and causality | `artifacts/pretraining_acceptance/HUMAN_SOURCE_NATIVE_PAYLOAD_20260908.json` | 10,326 train and 2,806 source-validation windows inspected with native normalization and membership |
| Sparse SE1 and empty-background input | `artifacts/pretraining_acceptance/HUMAN_SE1_PAYLOAD_PREFLIGHT_20260908.json`; `SENTINEL_NATIVE_PAYLOAD_20260908.json` | Sparse Fit/Calibration anchors and unknown masks; 2,100 empty frames; not dense target manual supervision |
| Independent original UAV route | `artifacts/pretraining_acceptance/QWEN_UAV_RECEIPT_RECOVERY_EVIDENCE_INDEX_20260910.json` | Real Qwen/native source-teacher-adaptation preflight with positive and missing-receipt rejection, UAV-specific contracts and no experts |
| UAV measurement payload | `artifacts/pretraining_acceptance/UAV_SOURCE_FULL_PAYLOAD_ACCEPTANCE.json`; `UAV_MEASUREMENT_CONTENT_RECHECK_20260910.json` | 4,800 source windows/9,616 files; 36,000 measurement-file content hashes; no Test payload |
| Parent, split, hash, namespace and negative cases | `artifacts/pretraining_acceptance/TASK_LIFECYCLE_CLOSURE_REGRESSION_20260910.json` | 196 server tests for original DAGs, profiles, current manifests, current parents, isolation, recovery and intercepted backends |
| Current catalog reporting and isolated package | `tests/test_current_expert_preparation_report.py`; `tests/test_pretraining_package_closure.py` | Legacy replacement status cannot override current 39+1 preparation coverage; safe archive/evidence inclusion and no model payload |
| Portable workflow/skill/tool/metric contracts | `tasks/human/task.json`; `tasks/uav/task.json`; `docs/pretraining_operator_contract.md` | Separate task roots, external data/model/environment, native gates, Dispatcher-only actions and explicit receipt ownership |
| Server installation and local reproduction | Final `RELEASE_MANIFEST.json` and separate installation receipt | Must pass per-member checks on the final installed archive before completion is declared |

## GO / NO-GO interpretation

GO for preparation means the named scripts, profiles, dependencies, native
interfaces and behavioral boundaries have evidence. It never means that the
simulated source/SE1 placeholders are trained weights or that reference teacher
inputs were freshly generated. Real model training and fresh scientific metrics
were intentionally excluded by the user.

NO-GO remains mandatory for missing input pins, mismatched/current-run parent
receipts, wrong task, changed manifests, quarantined candidates, unauthorized
Test access and attempts to promote synthetic receipts. These refusals are
required successful safety behavior, not waivers of unfinished preparation.

Final package installation/retest is the last unclosed row until its separate
receipt is written. Do not infer completion from this document alone.
