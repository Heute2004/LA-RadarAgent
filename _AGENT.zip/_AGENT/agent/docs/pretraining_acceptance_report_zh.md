# 训练复现前审计与验收

## 当前状态（2026-09-10）

**整体尚未最终放行，但 Human 当前配置的六阶段真实 Qwen 准备链已通过。**
下面“历史检查记录”保留早期审计，不能当作当前缺口清单，也不能将不同批次的
测试数相加当作覆盖率。当前专家池为 **Human 40 个原名结构；UAV 不使用专家库**。

| 当前项目 | 已核验结果 | 尚未覆盖的边界 |
|---|---|---|
| Human 六阶段调用 | Source、Sentinel、SE1、SE2、教师、专家全部准备成功，Qwen 进入 monitor，13 次记忆恢复 | 使用明确标注的模拟/参考生产输入；不代表训练或指标复现 |
| SE1→SE2 | SE1 active profile 与当前运行父绑定通过；SE2 实际消费本轮准备回执，非 reference-only | 未生成新的感知权重或教师标签，因本任务禁止训练 |
| 新增14个候选 | 14个真实 Qwen 正例通过，缺 Support 的单独真实 Qwen 案例正确 rollback | 原总报告的失败旗标保留；负例回退不等于候选训练成功 |
| 专家发现 | 20个旧准备入口、14个原始候选入口及1个分支路由入口已验证可发现 | 35个准备入口不等于40个完整训练依赖图；RIS仍需独立来源检查 |
| 原始训练命令 | 四类原始接口已接入准备调用链；目录40项无遗漏/重复，39项可准备、Codebook明确拒绝；四类最新真实Qwen正例通过，回执含未执行的原始命令 | RIS仍为隔离入口；真实调用不等同模型训练、指标复现或正式生产放行 |
| 精确负例 | 缺source replay时真实Qwen回滚，11次记忆恢复；修正验收器后PASS，旧误判报告原样保留；相关Linux回归58项通过 | 只允许预先指定错误的精确匹配，不将任意异常当作验收成功 |
| 分支路由 | 真实 Qwen 正例进入 monitor；缺 Support 时正确 rollback，原始报告和记忆副本哈希均匹配 | 仅验证准备、原模型 forward/loss 和故障处理，不代表实际训练 |
| RIS 独立合成准备 | 最新原始命令接入后，四个真实 Qwen 正例通过；四份记忆均含未执行的原始训练命令；缺 Support 回退，Codebook 在 Qwen 调用前被拒绝 | 独立检查入口，不是正常训练 Dispatcher；来源验证、生产放行仍为 false |
| RIS 来源 | 本地8个Support序列的元数据找回；服务器存在同步缺口 | 本地合同仍声明位置复制，不能解除 Codebook 隔离；缺件同步不能替代合法来源证明 |
| UAV | 修复后真实Qwen正例到达monitor；缺教师回执在shadow_train被拒绝并rollback；原始报告和记忆已入哈希索引 | 不采用撤回的新谱系实验，不共享Human指标和专家；结果仅证明拦截环境的流程行为 |
| 发布封装 | `ORIGINAL_DAG_INTEGRATED_CANDIDATE_20260910_2035` 独立服务器包2065文件哈希通过，相关135项测试通过；RIS与UAV原始JSON证据已收录 | 仍需纳入最终真实Qwen调用证据后封存；候选 ZIP 不代表整体放行 |

当前证据入口（项目相对路径）：

- `artifacts/pretraining_acceptance/HUMAN_ACTIVE_CHAIN_ACCEPTANCE_20260910.md`
- `artifacts/pretraining_acceptance/HUMAN_ACTIVE_FACTORY_QWEN_20260910.json`
- `artifacts/pretraining_acceptance/HISTORICAL_CANDIDATE_EVIDENCE_INDEX_20260910.json`
- `artifacts/pretraining_acceptance/HUMAN_ACTIVE_BRANCH_EVIDENCE_INDEX_20260910.json`
- `artifacts/pretraining_acceptance/RIS_QWEN_SYNTHETIC_SERVER_ACCEPTANCE_20260910.json`
- `artifacts/pretraining_acceptance/ris_qwen_original_dag_integrated_candidate_20260910_2035_raw_evidence/EVIDENCE_INDEX.json`
- `artifacts/pretraining_acceptance/original_dag_qwen_raw_verified/EVIDENCE_INDEX.json`
- `docs/expected_preflight_rejection_acceptance.md`
- `artifacts/pretraining_acceptance/QWEN_HISTORICAL_CANDIDATE_anisotropic_wet_mixture_MISSING_SUPPORT_20260910.json`
- `docs/ris_codebook_provenance_blocker_audit_20260910.md`
- `artifacts/pretraining_acceptance/EVIDENCE_CLOSURE_REVIEW_20260910.md`
- `docs/pretraining_completion_plan.md` 中的七项原始验收范围

本轮没有感知训练、模型晋级、Test 读取或冻结结果改写。完整 Goal 仍在进行，
当前成功不能替代其他候选、输入来源与最终封包的验收。

## 历史检查记录

以下为早期检查原文，保留作溯源；其中数量、待办和路径需结合上方当前证据解释。

### 当时结论

当前结论是 **NO-GO，尚不能放行全流程训练**。这是训练前发现的真实
工具接入问题，不是模型训练失败，也不是已经证明标签质量不足。

本轮没有训练、没有晋级模型、没有打开 Test 样本或其真值文件，也没有
覆盖任何冻结预测或指标。服务器为 lab407/hyc；本地是备份与审计端。

## 已验证项目

| 检查 | 结果 | 边界 |
|---|---|---|
| 服务器明确列出的资源 | 299 项固定哈希匹配，12 项路径存在 | 目录存在不等于目录内所有文件已校验 |
| 原快照与本地补回 | 259 + 13 份文件通过哈希/语法检查 | 不是模型数值重现 |
| 子进程脚本调用依赖 | 另外补回 39 个 Python 文件 | 未覆盖原快照，独立补充清单留痕 |
| 历史训练命令 | 173 条命令的静态 argparse 选项均可解析到声明 | 三份计划有重叠，不是 173 个独立实验 |
| Human 划分 | Train 62、Dev 31、Test 8、排除 6；互不交叉 | 只读划分元数据 |
| SE1 稀疏监督 | Fit 23 序列、Calibration 8 序列，全部在 Train 内且互斥 | 实际高置信锚点为 315 / 69，不是密集真值 |
| SE2 集合监督 | 23 序列、6900 帧通过真实加载器、时间轴、数值及权重检查 | 未重新判断伪标签定位精度 |
| UAV 监督 | 600 条合法 support-train 标签，来自 040/075 | 没有打开 Target RTK 真值文件 |
| 状态机与恢复 | 本地和服务器 29 条正常/故障路径通过，逐步恢复记忆 | 使用拦截工具，不代表 Qwen 自主选优或真实训练 |
| 回归测试 | 92 passed | CPU 合成样例，不是训练或 Test 评测 |

## 本轮已修复

1. 补回服务器缺失的 CSS 原始训练配置与训练脚本，不覆盖已有文件。
   配置 SHA256 与冻结 checkpoint 内记录一致；脚本双端哈希一致，
   服务器 `--help` 导入与参数入口验证通过，未执行训练。
2. 修复发布包遗漏 UAV 已引用的训练参数、教师回执和复现索引的问题。
   先通过回归测试复现缺失，再补齐打包依赖。
3. 扩展收集器：除 import 以外，也跟踪脚本字面量引用，补回
   `train_cora_universal.py` 等 39 个依赖。动态构造的路径仍须实际适配器验证。
4. 纠正审计自身的预期：Human 某些证据不足状态应返回 monitor，而非
   全部 rollback；UAV monitor 后可以返回 observe。按各自 workflow 验证，
   没有修改生产状态机来迎合测试。

## 必须修复的阻塞项

### 专家语义入口与生产线没有连接

Human 库有 42 个入口，但全部调用
`agent_jsac.registered_route_expert_entrypoint`。该实现明确标记
`archive_only_superseded_generic_entrypoint`，仅允许 describe，拒绝 train/audit。

正确原生多候选生产线仍存在，历史命令也已经找齐。因此不是没有专家代码，
而是新 Human 任务入口还没有绑定它们。不能重新启用被淘汰的通用 trainer，
也不能只把历史赢家权重装回来冒充从零训练。

验收条件：语义候选必须映射到兼容的原生 recipe、准确父分支、标签适配器、
参数和输出合同；五候选请求需真正解析出五条合法命令，并在启动前拦截验证。

### 双任务生产后端和阈值仍未激活

当前 `TaskWorkflowRuntime` 只接受 SimulationBackend。UAV 的工具状态仍是
`external_profiles_and_typed_runtime_binding_required`；Human 阈值参考仍为
`alignment_pending`，任务层需要外部批准的数值 profile。

已有旧 Dispatcher 和 native executor 可以复用，但不能把它们的存在当成
新 task=human/uav 的生产接入已经完成。也不能依据冻结 Dev AP 自动反推晋级阈值。

验收条件：绑定数据、模型、指标 profile 的哈希；真实工具适配器接收任务限定
请求，并产生同一任务/父谱系/标签配方的真实回执。模拟回执不能被生产接纳。

### UAV 训练脚本包含自动 Test 后评测

`train_cora_u_coarse_set.py` 的末尾 `_evaluate_roles` 固定包含 source_test。
这不表示本轮读了 Test，但说明以后直接启动原脚本会违反当前授权。

验收条件：复用原训练损失与权重选择逻辑，增加独立、经过测试的后评测角色白名单；
默认不读任何 Test，不能只修改日志里的 `locked_test_read` 字段。

### 输出目录与历史结果必须隔离

找回的执行计划指向已存在的历史输出目录。原命令只能作为配方证据，不能
原样开训；新任务必须分配新的 run_id，重绑定输出及新生成依赖，并拒绝碰撞。

### 历史评选和自主晋级不是同一合同

当前最佳表是 Development-selected replay；SE1 创建回执中仍存在
internal-stage-only 约束。不能把事后最佳表直接变成无标签在线晋级资格。

验收条件：分别声明训练内部续行、无标签运行时晋级、研究复现评选的权限和指标；
不悄悄放宽门槛，也不拿冻结专家权重初始化新的专家。

## 还不能签字的范围

- 本轮没有用真实传感器输入重新推理各模型，数值一致性没有重新验证。
- 专家衍生缓存需要按最终绑定的 recipe 做逐文件/逐字段验收；SE2 候选集
  加载器通过不能替代所有专家缓存的验收。
- 某些原生加载器写死 23 个目标序列及校准序列。这是旧协议的保护条件，
  不是通用数据接口；更换数据集需要显式 profile 适配，不能宣称现在可任意替换。
- 历史训练代码没有原始哈希的地方，当前源码快照不能证明历史字节版本一致。
- 当前 RIS 条件仍保留既有 signal-provenance caveat，不在本轮自动解除。
- UAV 台账含候选命中率等审计字段；这些字段不能传给 Agent 作为无标签决策输入。

## 下一步顺序

先修原生专家绑定和任务级执行后端，再绑定已有批准的阈值与外部 profile；
随后处理 UAV 后评测白名单和全新输出目录。全部完成后，用启动拦截器验证
每条真实命令、输入和回执，再进行授权的训练。不要现在启动长训练来试错。

机器可读结论：`reproduction/TRAINING_READINESS.json`。
详细证据：`artifacts/pretraining_acceptance/`。
