# Semantic-to-native selection acceptance

The real Qwen audit on 2026-09-09 used synthetic neutral diagnostic scores and
the verified lifecycle LoRA. Each of six routes returned five distinct,
route-compatible semantic descriptors. This checks constrained retrieval only,
not diagnostic correctness or scientific performance ranking.

| Route | Explicit native bindings | Unbound | Quarantined |
| --- | ---: | ---: | ---: |
| open_indoor_los | 0 | 5 | 0 |
| indoor_clutter | 0 | 5 | 0 |
| open_outdoor_weak_return | 0 | 5 | 0 |
| outdoor_dry_complex | 0 | 5 | 0 |
| outdoor_wet_return | 0 | 5 | 0 |
| corner_nlos_ris | 1 | 3 | 1 |

Evidence: `artifacts/pretraining_acceptance/QWEN_SEMANTIC_RETRIEVAL_20260909.json`.
The isolated native pool has thirty intercepted candidate implementations,
but same-route membership does not prove equivalence to these descriptors.
Therefore autonomous semantic Top-5-to-training acceptance is **NO_GO**.

The public semantic receipt now explicitly denies training authorization and
native verification. `bind_semantic_shortlist` rejects unbound, quarantined,
cross-route, cross-task, duplicate and many-to-one selections. It requires five
explicit native recipe bindings and still requires per-stage hash verification.
It never silently falls back to a same-route candidate.

## Required repair

Inspect each descriptor against its actual historical native mechanism, label
consumer, parent policy and script. Register only proven explicit bindings; for
different implementations preserve distinct native descriptors instead of
claiming equivalence. Filter quarantined/unbound entries before executable
ranking. If fewer than five remain, return a capability shortfall, not a fake
training ticket. Then rerun real Qwen retrieval-to-native compilation across
all routes. Keep the original 42-entry scope visible in the acceptance matrix.

No training, Test payload access or frozen-result mutation occurred. This
finding does not negate the separate six-stage reference preparation success;
it identifies the remaining autonomous candidate-selection boundary.
