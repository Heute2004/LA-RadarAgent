# Route Runtime Member Consumption

The candidate trainer must consume the membership declared in
`ROUTE_RUNTIME_MANIFEST.json`, not discover training inputs by directory glob.

Before NumPy payload parsing, validate the manifest schema, expected route and
role, exact false forbidden-read declarations, nonempty unique sequence records,
contained existing file paths, and exact directory membership. For each member,
read its bytes once, verify its declared SHA256, then parse those same bytes with
`allow_pickle=False`. Verify payload sequence, frame count and supervision origin
against the member record. Existing payload and fit/calibration checks still apply.

Extra files are rejected, not silently ignored or added. A changed cache requires
the authorized cache producer to issue a fresh manifest; the training consumer
must never rewrite hashes to make a mismatch pass.

This is integrity and membership validation, not proof that the manifest was
authorized. Dispatcher must still bind the manifest to the admitted label recipe,
selected parent, and source/target split. Self-declared provenance flags alone do
not prove absence of label leakage. No promotion or model-quality claim follows.

This repair does not grant native structural equivalence to the old generic
trainer or enable currently unbound experts. It preserves its models and losses.
# Numerical integrity before any expert invocation

The shared payload validator is part of the Dispatcher code-hash allowlist.
Candidate zero must equal the selected parent coordinate exactly, rather than
within an approximate numerical tolerance. Validity is a boolean mask, not a
score that may be silently converted. Empty frame/candidate axes are rejected.

All supervision weights must be finite and nonnegative. Invalid candidates
cannot carry positive supervision. A positively weighted frame must have a
supported set; supported set mass must sum to one (floating-point tolerance
only), or be zero for an abstained frame. These checks do not estimate label
accuracy and never promote an expert. Historical artifacts are not rewritten;
an invalid artifact requires rebuilding from its authorized provenance.
