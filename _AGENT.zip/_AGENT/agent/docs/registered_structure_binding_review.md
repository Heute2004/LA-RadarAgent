# Registered Structure Binding Review

## Evidence Boundary Correction

The preparation count is NOT a count of historically equivalent training
recipes. Statements below that objectives are "unchanged" refer to the current
runtime reference used by the preparation tests, not every receipt-bound trainer.
In particular, the recovered August 29 trainer (SHA256
`c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70`)
trains intervention when identity has zero allowed mass. The current trainer
trains intervention when the best physical candidate has more preference mass
than identity, and adds family-specific objective terms. These are different
training contracts even if the mixer structure and input ABI match.

For allowed weights `[0.2, 0.8]`, the old gate target is zero and the current
target is one. `test_historical_objective_evidence_boundary.py` records this
counterexample without optimization or checkpoint IO. Do not automatically
restore the old objective: an old receipt may belong to a failed recipe rather
than the frozen successful lineage. Exact training admission requires binding
the authoritative recipe, supervision and objective together. Until that binding
is proved, preparation success grants no historical-reproduction claim or
training authority. No frozen result is changed by this correction.

## Multi-Hypothesis Path Preparation

The `multi_hypothesis_path` entry belongs to `outdoor_dry_complex` and uses
`branch_stability_router` supervision, not the outdoor-weak-return recipe.
Its receipt is preserved as `MULTIPATH_HISTORICAL_RECEIPT_20260910.json`.
The receipt binds the recovered model `a6e64474...5415486` and August 31
trainer `55c7a9a5...6f51f`; the test checks their full hashes. Its original
per-candidate GRU, tail context, uncertainty gate and Cartesian inputs remain.
There is no Viterbi dynamic-programming decoder in this recovered implementation;
the historical semantic description must not be used as proof of one.

The dry-route loss AST is unchanged after excluding the later unrelated RIS
dispatch and wet-route branch. The full trainers are not byte-identical. The
existing aligned-slot/reset path and bounded endpoint executor prevent recurrent
state crossing a candidate reassignment or frame gap. For uninterrupted valid
tracklets, isolated original/current GRU mixers agree with identical initialized
weights; reset corrections are not claimed byte-identical historical inference.
Fit/calibration supervision and three selected parent branches are checked by
the real preparation CLI. Direct training remains prohibited.

`branch_persistence_selector` is NOT admitted by these tests. Its historical
receipts bind `branch_router_recipe.py`, not this registered GRU trainer.
Shared-mixer functional tests remain diagnostics only. It requires its own
native training-contract recovery; a name-based alias is forbidden.

## Recovered Adaptive Range Preparation

`adaptive_threshold_tracklet` now retains the original `_AdaptiveRangeMixer`
and `adaptive_range:tail:range:polar` specification. The August 28 server
receipt is copied as `ADAPTIVE_TRACKLET_HISTORICAL_RECEIPT_20260910.json`;
tests hash-check its exact recovered model/trainer sources and compare the
range-mixer AST. This is learned range-conditioned feature weighting, not
a recovered CFAR detector or a newly invented raw-spectrum threshold algorithm.

Preparation uses the existing aligned, contiguous candidate loader and explicit
historical-window endpoint execution. All three selectable parents are checked.
The range mixer is stateless across candidate slots, so validated reset metadata
does not alter its output; gap/sequence segmentation and the endpoint wrapper
bound the pooled temporal context. No network layers or loss coefficients were
changed. These execution-boundary checks do not prove numerical equality with
historical whole-episode inference. Direct optimization remains prohibited.

The preparation registry contains seventeen entries after this increment.
Successful Qwen evidence is counted independently; adding an entry alone does
not count as a passed Qwen call or production admission.

## Recovered Risk Preparation

`selective_branch_recovery` and `weather_risk_selector` preserve the historical
`_RiskMixer` with `dual_path=False`. They share a context-conditioned sigmoid
gate, not two newly invented architectures. The former uses causal temporal
convolution; the latter has no temporal mixer. Preparation checks all three
parent branches and retains their distinct application contracts: exact measured
candidate selection versus a convex update with scale 0.5 and maximum 0.5 m.

The complete current `_RiskMixer` AST differs from the archive because its
unrelated dual-path branch has a padding correction. These two candidates never
enable that branch. Tests instantiate the isolated historical class and verify
exact output equality under identical weights with partial validity masks for
their actual non-dual-path mode. The original objective, calibration and
optimizer functions remain unchanged; no optimization is performed. Direct
training is explicitly refused pending admission. REVIEWED now contains sixteen
preparation entries, not sixteen production-certified experts.

## Additional Candidate Preparation Coverage

The original `dual_domain_set_mixer` (`_SetMixer`) and
`mti_agreement_rescuer` (`_AgreementMixer`) now have explicit preparation-only
bindings. Tests compare their class AST to recovered source, exercise original
objective gradients without optimization, and check all three selected parent
branches through the actual CLI with hash-bound Support/replay and EmptyGuard.
Their network layers and objective coefficients were not replaced. Direct
production training remains refused pending complete admission.

The SetMixer gates candidate tokens using a validity-masked set summary. The
AgreementMixer applies a learned per-token gate. Both consume provided candidate
features, including RA/MTI agreement evidence; this is not evidence of separate
raw-RA and raw-MTI encoders or an explicit multi-Gaussian density model. Their
original names are retained without expanding the scientific claim.

The positive CLI matrix must exactly equal the REVIEWED registry, with each
entry exercised against CORA0, SE1 and SE2. This prevents entries being added
without corresponding preparation coverage. Native TECS/GBLE/GG-SRRE are checked
against their original native symbols and loss receipts, not the registered
generic loss flags.

Code-only continuation, 2026-09-09. All 42 semantic names are preserved.
No expert weights are bundled and no sensing training is authorized.

## Verified Preparation Mechanisms

| Semantic name | Original primitive | Implementation | Actual mechanism | Native objective family |
| --- | --- | --- | --- | --- |
| dual_domain_set_mixer | dual_domain_set_mixer | dual_domain_set_mixer_v1 | Validity-masked candidate-set summary and token gate with temporal convolution, no independent raw-domain encoders | selective_candidate_composite |
| mti_agreement_rescuer | mti_agreement_rescuer | mti_agreement_rescuer_v1 | Learned per-token agreement gate, no temporal mixer | branch_stability_router |
| selective_branch_recovery | selective_branch_recovery | selective_branch_recovery_v1 | Original non-dual-path context risk gate with causal temporal convolution; exact observed-candidate output | branch_stability_router |
| weather_risk_selector | weather_risk_selector | weather_risk_selector_v1 | Original non-dual-path context risk gate without temporal mixing; bounded convex candidate update | bounded_wet_return_router |
| angular_consistency_associator | angular_consistency_associator | angular_consistency_associator_v1 | Candidate-to-parent angle encoding, causal convolution, innovation gate | branch_stability_router |
| echo_extent_disambiguator | echo_extent_disambiguator | echo_extent_disambiguator_v1 | Candidate-cloud extent encoding, no recurrence, extent gate | selective_candidate_composite |
| range_conditioned_tcn | range_conditioned_tcn | range_conditioned_tcn_v1 | Metric range embedding, causal convolution, range gate | source_tail_refinement |
| tecs_candidate_attention | candidate_attention | candidate_attention_set_v1 | Current-frame four-head candidate attention, no temporal mixer | selective_candidate_composite |
| local_shape_consensus | local_shape_consensus | local_shape_consensus_v1 | Relative candidate-cloud dx/dy/radius encoding, causal convolution, extent gate | source_tail_refinement |
| state_consistent_local_refiner | state_consistent_local_refiner | state_consistent_local_refiner_v1 | Per-candidate recurrent state with explicit causal slot alignment and frame-gap segmentation in preparation | source_tail_refinement |
| evidence_hysteresis_selector | evidence_hysteresis_selector | evidence_hysteresis_selector_v1 | Learned soft recurrence with explicit candidate-reset input in preparation; not a classical two-threshold state machine | source_tail_refinement |

These are distinct real mixers within the recovered shared registered framework,
not seven unrelated complete networks. The first five mixer ASTs match their historical originals.
The two temporal mixers retain their recovered structure, with explicit state-reset
support added and tested separately; this extension is not byte-identical source recovery.
The original shared losses, fit/calibration split and optimization functions are
unchanged. Synthetic backward tests verify finite nonzero mixer gradients without
optimizer steps or parameter updates. Prefix tests check the causal boundary.

TECS's semantic name, primitive and implementation identifier differ. The actual
preparation CLI resolves all three through the existing catalog, not string
concatenation. This registered candidate-attention method is not the native
Conv-TECS three-domain ROI architecture; both sources remain distinguishable.

All seven preparation paths support a selected CORA0, SE1 or composite SE2 parent.
Candidate zero remains that parent's current prediction, not a brightness-ranked
measurement. Each path stops before optimization and reports no training authority.
Successful preparation is not a completed expert binding or a promotion result.

## Registered Objective Input Acceptance

Preparation now executes the original registered forward, episode objective and
calibration functions for non-native registered mechanisms as well as aligned
temporal mechanisms. It checks every loaded Support and source-replay episode
for finite logits, acceptance and loss; calibration uses only the internally
partitioned calibration episodes. These checks run in evaluation mode without
optimizer steps or checkpoint IO. Native TECS/GBLE/GG retain their separate
native preparation path and are not passed through the registered objective.

The receipt distinguishes `registered_loss_inputs_verified`,
`registered_calibration_inputs_verified` and `registered_episodes_checked` from
native structure evidence. These fields establish input compatibility only, not
accuracy, calibrated probabilities, promotion eligibility or training authority.
The smoke thresholds 0, 0.5 and 1 do not select a deployment policy. Original
training and final calibration settings remain unchanged.

Local CPU synthetic-cache verification on 2026-09-10: 36 preparation tests plus
36 mechanism, native-factory and packaging tests passed. Training, checkpoint
reads/writes and AdamW steps are forbidden by the preparation tests.

## Further Recovered Mechanisms With Unresolved Inputs

| Original name | Recovered class | Required evidence before enabling |
| --- | --- | --- |
| state_consistent_local_refiner | _StateSpaceMixer | Alignment/reset verified in preparation; production batch integration and resource-authorized motion gates still pending |
| evidence_hysteresis_selector | _HysteresisMixer | Alignment/reset verified in preparation; production integration pending; learned soft recurrence is not a two-threshold state machine |
| empty_guard_constrained_disambiguator | _ContrastMixer | Actual external EmptyGuard constraint evidence; existence of a manifest is insufficient |

Their original code is recovered, not missing simply because an explicit registry
entry is absent: the historical registry also resolves entries from its Pool42
catalog. Nevertheless, their input and constraint gaps must not be hidden behind
wrappers or fabricated completion receipts.

`local_shape_consensus` is now included in preparation, but its geometric contract
remains important: it describes the provided candidate cloud and returns an
existing candidate. It does not create a sub-grid coordinate independently of
candidate generation. The native source-tail objective and mixer are unchanged.

Reference source:
`reproduction/reference_sources/agent_expert_runtime_contracts/`.
Native Conv heads remain in:
`reproduction/reference_sources/code_radar_cbpr_v1_20260805/`.

## Parent Cache Contract

The runtime exporter snapshots all actual parent files before model loading and
after cache export. CORA0 and SE1 each have one dependency; the composite SE2 loader
has CORA0, SE1 and SE2 dependencies. Changed files prevent manifest sealing.

Preparation requires independent `--parent-checkpoint-hash BRANCH=SHA256` values.
Both Support and replay cache manifests must match those hashes and the dependency
topology before array loading. Absent lineage is rejected, not inferred from a
folder or checkpoint name. Historical manifests are not silently backfilled.

Remaining admission: authenticate the expected hashes through the current-run
profile, validate the parent-selection receipt and EmptyGuard content, then bind
the complete native request to the real Qwen/Dispatcher lifecycle. The successful
cache check alone does not authorize training. Overall readiness remains NO-GO.

The Dispatcher profile pins also include the parent-selection policy code,
runtime-parentage verifier, weak-admission parser, shared candidate model,
execution/recipe/search registries and the three archived application catalogs.
This closes a known gap where the trainer could remain unchanged while its
parent or output-contract dependency changed. Stale profiles fail closed and
must be regenerated by trusted Dispatcher configuration; model requests cannot
provide replacement pins. This is a critical-dependency list, not a claim of
exhaustively pinning every external Python library or operating-system dependency.

## Complete Mixer Inventory

The existing AST inventory now records the actual `_mixer` constructor branch
for all 42 descriptors, not just declared component names. The active Human
library must equal the legacy catalog under audit; divergence fails explicitly.
Both catalogs and model source are hashed in the report. Four local tests pass,
including detection of a changed active catalog. No model or dataset is loaded.

Ten descriptors currently resolve to `_IdentityMixer`:
`clor_local_offset`, `subcell_uncertainty_refiner`, `innovation_gated_offset`,
`temporal_precision_tail`, `weak_return_mixture`, `polar_evidence_gate`,
`robust_quantile_recovery`, `wet_temporal_integrator`,
`anisotropic_wet_mixture`, and `ris_temporal_gate_h32`.

This is a component finding, not a claim that the entire network is identity:
shared encoders, temporal context and gates still execute. Conversely, a unique
declared signature does not prove continuous offset, mixture covariance, or
quantile supervision. Native H32 also has a separate explicit production recipe;
its registered mixer does not describe that entire production path.

Authoritative inventory for this increment:
`artifacts/pretraining_acceptance/HUMAN_ACTIVE_SEMANTIC_MIXER_INVENTORY_20260909.json`.
This audit prioritizes historical structure recovery; it does not replace any
expert name, authorize a generic substitute or claim full native coverage.

## Seven-Entry Server CLI Acceptance

The isolated Human release `human_seven_cli_preparation_20260909` passes all 33
tests in `test_registered_training_preparation.py` on lab407 CPU (4.02 seconds).
The positive cases cover seven entries times three selected parents. Negative
cases reject wrong identities, unbound parents and stale Support summaries.
Tests intercept training, optimizer steps and checkpoint IO; all caches are
generated synthetic fixtures. EmptyGuard content remains explicitly unverified,
not silently accepted from an existing file. No scientific metric is reproduced.

Local receipt:
`artifacts/pretraining_acceptance/HUMAN_SEVEN_CLI_SERVER_20260909.xml`.
The release reuses read-only dependencies from `selection_cache_bound_20260909`
and its archived Human application contracts. It is an isolated test overlay,
not yet a standalone portable release. No UAV task was copied or executed.

Subsequent EmptyGuard increment: all seven preparation paths now require and
verify independent Sentinel/projection hashes, before loading candidate arrays.
The server `human_bound_guard_cli_20260909` suite passes 63 checks, including
the same seven-entry/three-parent matrix. Content is verified, but chronology
and metric remeasurement remain false. See `human_empty_guard_evidence_boundary.md`
for the new arguments and exact admission limits. The earlier 33-check receipt
is retained as historical evidence, not overwritten as a new result.
