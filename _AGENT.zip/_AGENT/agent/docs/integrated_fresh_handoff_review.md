# Integrated Fresh Handoff Review

Status: restored in place and available to the parallel packager.

## Decision

The Human preparation backend now has an explicit `strict_upstream` mode. The
default remains the legacy/reference-compatible mode. A legacy preparation
receipt may still pass its existing checks, but it is never treated as strict
upstream evidence.

Strict mode verifies the current run's source native-preparation result before
the `shadow_train` stages start:

```text
existing TaskWorkflowRuntime memory
    -> TaskWorkflowRuntime(..., resume=True)
    -> existing task/contract/record hash restore
    -> current state/step/context checks
    -> first preflight source native-preparation result
    -> SE1 stage_context.source_preparation_receipt
    -> existing SE1 -> SE2 upstream_receipt propagation
```

This is a control-plane and preparation check. It is not a source producer, it
does not bind the source fixture, and it does not create or claim a new
checkpoint. The later Qwen checker remains responsible for binding a source
fixture.

## Implemented Boundary

`HumanIntegratedPreparationBackend(checks, root=..., strict_upstream=True)`
requires the task package root. On `shadow_train`, it reopens the same
`simulation_memory.json` through `TaskWorkflowRuntime` with a plain
`SimulationBackend` and `resume=True`. It therefore reuses the existing
`TaskWorkflowRuntime._restore()` path and its current memory format; it does
not create a second memory schema or write a recovery record.

After restore, strict mode requires all of the following:

1. The memory task is `human` and the context task is also `human`.
2. The restored state equals the context state.
3. The context step equals `len(restored.records)`. A stale caller cannot use
   an old step against a newer memory file.
4. The context `contract_hash` and `metric_contract` equal the restored
   runtime values.
5. Exactly one source record exists. It must be the first record, with
   `task=human`, `state_before=preflight`, `parent_hash=ROOT`, and a request
   for `verify_preflight`.
6. The outer source receipt is successful, simulation-bound, and has
   `authority=SIMULATED_NOT_PROMOTABLE` and
   `model_mutation_allowed=false`.
7. Exactly one `native_stage_preparation` entry has `stage=source`; its result
   is successful, has `training_started=false` and
   `promotion_authorized=false`, and passes the existing
   `normalize_native_preparation('source', ...)` checks. Both a raw native
   report and the existing normalized wrapper form are accepted.

The recovered source result is deep-copied into the SE1 callback context as
`source_preparation_receipt`. No source result is regenerated. The existing
SE1-to-SE2 behavior remains unchanged: the completed SE1 callback result is
passed as `upstream_stage=se1` and `upstream_receipt` to SE2.

If any strict check fails, the backend returns a simulation receipt with
`passed=false` and does not invoke SE1, SE2, teacher, or specialist callbacks.
The outer `TaskWorkflowRuntime` can therefore take its normal failure
transition, but the bad source state cannot be recorded as a successful
preparation.

## Why This Does Not Grant Fresh Lineage

The recovered object is the source **native-preparation result already stored
inside the current runtime memory**. It is not a source fixture receipt and it
is not a trained parent checkpoint. In particular:

- `source_preparation_receipt` is context evidence for the SE1 preparation
  callback, not a producer output.
- No `foundation_checkpoint`, SE1 checkpoint, or SE2 checkpoint is created by
  this backend.
- A future checker must still bind the source fixture with
  `source_parent_receipt.verify_source_parent_for_interception()` and
  `se1_source_handoff.bind_source_parent()`.
- The existing `pretraining_human_se1_commands.py` compiler is not changed.
  Its source-parent flags remain a later explicit binding step.
- The current SE2 prospective wrapper remains a negative safety boundary for
  simulated parents: `bind_teacher_parent()` may identify a simulated SE1
  handoff, but `train_cora_se2_prospective.py` must reject it before native
  trainer import.

Consequently, a strict integrated result may claim that a current source
native-preparation receipt was recovered and passed to SE1. It may not claim
fresh source-to-SE1-to-SE2 weights, numerical reproduction, promotion, or
training completion.

## Evidence Map

| Component | Reusable evidence | Boundary |
| --- | --- | --- |
| `src/agent_jsac/task_workflow_runtime.py` | `resume=True` reads the existing memory and validates task, contract hash, row hash chain, parent hash, and state | It validates runtime memory; it does not identify a native source stage by itself |
| `src/agent_jsac/human_integrated_preparation.py` | Strict restore checks current context and passes recovered source evidence to SE1 | Default mode remains legacy/reference-compatible and is not strict |
| `src/agent_jsac/source_parent_receipt.py` | Verifies a separately signed source fixture binding | Reserved for the later checker-side source fixture handoff |
| `src/agent_jsac/se1_source_handoff.py` | Binds a verified source fixture to SE1 preparation arguments | Does not start training |
| `tests/test_source_parent_receipt.py` | Small synthetic receipt and file-hash fixture pattern | Fixture bytes are evidence-only, never a trained model |
| `tests/test_task_workflow_runtime.py` | Existing recovery, task mismatch, stale state, contract, and tamper coverage | Its memory contract is reused rather than duplicated |
| `scripts/audit_pretraining_se2_flow.py` | Native SE2 preparation/interception reaches the intended stages without optimizer/checkpoint save | The audit may read support-label candidate inputs required by candidate confirmation; the valid claim is no forbidden labels and no Test/locked-Test payload access, not no target payload at all |
| `scripts/train_cora_se2_prospective.py` | Current `bind_teacher_parent()` gate rejects a simulated SE1 parent before native load | Use this as an expected rejection, not as a successful simulated producer |

## Rejection Matrix

| Fault | Strict result | Reason |
| --- | --- | --- |
| No source native-preparation entry in current memory | `passed=false` | A legacy/reference-only or generic receipt is not strict evidence |
| Source outer or native result failed | `passed=false` | A failed source stage cannot seed SE1 |
| Memory task differs from `human` | `passed=false` | Existing restore or strict task binding rejects cross-task recovery |
| Memory row or source result is modified without a valid hash chain | `passed=false` | Existing restore rejects memory integrity drift |
| Context step is older or newer than restored record count | `passed=false` | Strict stale-step check rejects the expired caller context |
| Current contract hash or metric contract differs | `passed=false` | Strict context binding rejects a different contract |

The tests intentionally exercise these cases with synthetic JSON and callback
receipts only. They do not load model data and do not start a trainer.

## Synthetic Verification

Command used for the new tests:

```powershell
$env:PYTHONPATH='H:\Project\AGENT-JSAC;H:\Project\AGENT-JSAC\src;H:\Project\AGENT-JSAC\tests'
$env:PYTHONDONTWRITEBYTECODE='1'
& 'D:\anaconda3\envs\vlm3b\python.exe' -m pytest -q --disable-warnings tests/test_integrated_source_receipt_recovery.py
```

Observed result: `6 passed in 2.10s`.

A broader non-training regression command also ran. The new tests, existing
integrated backend tests, and existing runtime tests passed. Two unrelated
existing assertions in `tests/test_human_stage_contract_crosscheck.py` still
fail because they require the prohibited legacy/compiler changes in
`scripts/pretraining_human_se1_commands.py`; that compiler and those old tests
were not changed here.

No real Qwen invocation, training, model-data read, or
`registered_training_smoke` run was performed.
