# Historical Expert Source Recovery

## User decision

Preserve all 42 original expert names and intended structures. Recover historical
training code before implementing anything new. Expert assets contain code and
required dependencies, not pretrained expert weights or prediction payloads.

## Verified search

The read-only server scan visited 8,154 Python/shell files and indexed 1,110
potential structural/training files. No training or dataset loading was executed.
The search covers historical JSAC projects, radar code trees, toolbox snapshots,
and backups under `/home/hyc/radar+ris`. Generated artifacts, runs, releases and
prediction directories were excluded; this is a code search, not a completed
training-result provenance audit.

All 42 canonical expert identifiers were found in the historical toolbox:

`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX`

For all 42 entries, the original wrapper IMPLEMENTATION_ID matches the current
catalog and a matching historical `_spec` registration exists. The historical
dispatcher invokes `scripts/train_se_branch_route_expert.py`. That trainer
instantiates registered models and contains an AdamW optimization loop, actual
weak-label loss computation and checkpoint serialization.

This corrects any implication that no historical training implementation exists.
It does NOT establish that all 42 implementations reproduce their intended
semantic architectures or the best historical results.

## Important distinction

The recovered registered models use a common discrete-candidate framework with
different mixer/temporal/gating operators. Their outputs are candidate logits
and acceptance. For example, the registered `local_offset_gru_v1` is not the
same implementation as the separate historical `CLORSE2Expert`, which outputs
a bounded continuous offset and covariance. A matching name is insufficient
to select one as the authoritative implementation.

Do not remove the active archive-only guard or alias native recipes merely
because the old dispatcher permits training. Compare intended mechanisms,
label loaders, parent binding, losses and historical launch records first.

## Additional native sources located

Under `/home/hyc/radar+ris/JSAC-AGENT-V4`:

- `scripts/train_cora_se2_clean_clor.py`
- `scripts/train_cora_se2_route_specialists.py`
- `src/brace_v4/route_specialists_se2_models.py`: CLORSE2Expert, TECSSE2Expert,
  GBLESE2Expert, PathAssociationSE2Expert, GGSRRESE2Expert,
  GGSRRECandidateSE2Expert and LTGESE2Expert.
- `scripts/train_r7_tecs_indoor_clutter.py`
- `scripts/train_vast_v2_expanded_tecs.py`
- `scripts/train_r24_branch_stability_router.py`
- `scripts/train_r31_route_specialist.py`
- `scripts/train_r39_source_tail_adapter.py`
- `scripts/train_route_setmass_specialist.py`

Under `code_radar_convlstm_expert_transfer_20260805`:

- `scripts/train_convlstm_heterogeneous_expert.py`
- `radar_bev/models/heterogeneous_experts.py`: CLOREXpert, DCMDEXpert,
  PATEIExpert and SRREExpert.

## Recovered code-only archive

`artifacts/pretraining_acceptance/HISTORICAL_42_EXPERT_SOURCE_20260909.zip`

Contains 42 original wrappers and six shared Python dependencies (48 files),
plus a SOURCE_MANIFEST with per-file hashes and all 42 identifier mappings.
Sources are unmodified historical bytes. No expert weights, metrics or data
are included. Static local-import traversal is not a runtime dependency test.

ZIP SHA256:
`98432edb1aa6c96f55d1cb8ec805d8ef426ce8e558aeafd3492c319cf05dacda`

Full search index:
`artifacts/pretraining_acceptance/HISTORICAL_EXPERT_CODE_SEARCH_20260909.json`

## Receipt-matched snapshot recovered

A later check of the immutable E2E ZIP found the exact trainer and model hashes
recorded by the earlier expert-expansion training receipts:

- Archive: `/home/hyc/radar+ris/AGENT-JSAC/artifacts/e2e_retrain_20260830/AGENT_JSAC_E2E_RETRAIN_cc2a4da2ec284ffbad911d12ae52dce8.zip`
- Member `toolbox/scripts/train_se_branch_route_expert.py`:
  `c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70`
- Member `toolbox/src/agent_jsac/registered_route_expert_models.py`:
  `3b379ea9955f23183b38b4368a096836f0cc50667943993ae58156e9a81ea9b8`

These two original files were copied without modification to
`artifacts/pretraining_acceptance/EXPERT_RECEIPT_MATCHED_SOURCE_20260909.zip`.
ZIP SHA256: `3969faa450ddfc61e524b09328c6cb5ad6c53be57444c53915cab1a82e2233c4`.
Only the two Python members were read/copied; no weights or prediction payloads
were extracted. This is stronger provenance than finding a same-named file,
but not yet a complete dependency closure or structural acceptance of all 42.

The later 20260901 receipt's trainer hash
`e56929325354f290c7ec7829dd2f9929f0ba9b59eb6a02623398b80b2b021e88`
was not found in this bounded archive scan. Preserve this gap explicitly.

## Remaining acceptance

Resolve each original semantic architecture against the actual historical
model and launch record, then repair invocation and portable data contracts.
Only after isolated no-training dispatch and structural tests pass may a
recovered entry become executable in the current production toolbox.
