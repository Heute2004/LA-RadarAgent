# Shared Temporal Episode Contract

## Scope

This contract covers the five reviewed registered temporal preparation methods.
It does not authorize optimization, promote an expert, or validate label quality.
Native Conv experts and UAV have separate contracts and are not substituted.

## Data flow

The existing Support loader verifies the selected parent and recomputes the
Support summary. Whole sequences are assigned to fit or train-internal calibration
before any temporal segmentation. The hash-bound runtime loader verifies sequence,
route, role and parent, associates current measured candidates into causal slots,
permutes features/coordinates/validity/preference together, and splits frame gaps.
The resulting Episode retains sequence identity, source hash, frames and reset flags.
No new labels, held coordinates or interpolated measurements are generated.

Candidate zero remains the exact parent fallback. Motion gates remain explicit
resource configuration; neither the network nor a semantic name invents them.

## Shared execution

Preparation, episode loss and calibration call `forward_episode`. It rejects
missing/malformed reset metadata, nonconsecutive frames, absent source digest and
segments that fail to reset initially valid slots. Each segment is a separate
model call so pooled state cannot leak across sequence/frame gaps. Candidate reset
flags also reset individual tracklet state inside a segment.

The numerical loss equations, weights, threshold objective and optimizer body
remain those of the archived training contract. Tests compare their AST after
accounting only for the explicit shared-forward substitution and admission guard.
This proves code continuity, not that those objectives yield good real-data experts.

## Acceptance evidence

- Synthetic rank permutations leave aligned inputs, loss and calibration unchanged.
- Physical preference-weighted coordinates are conserved by candidate permutation.
- All five reviewed temporal mixers receive finite nonzero gradients without updates.
- Loss and calibration forward identical features, coordinates and reset flags.
- Missing metadata is rejected before network execution.
- Direct optimization requests remain rejected before optimizer construction.

The CLI preparation executes the common loss and internal-calibration code without
gradients or optimization. Its receipt states input verification only; it does not
report synthetic AP as experimental performance. No target Development/Test labels
are needed or allowed.

## Remaining admission requirements

Real recipe/data authority, supervision provenance, EmptyGuard safety, and complete
native-structure binding must still pass. The optimization admission guard remains
closed even after these synthetic tests pass. Existing historical receipts and
checkpoints are not rewritten. Modified code requires freshly pinned profiles.
