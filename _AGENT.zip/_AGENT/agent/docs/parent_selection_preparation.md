# Parent Selection Preparation Contract

## What Is Verified

Preparation uses the existing Support-only three-parent selector without changing
its thresholds, tie breaks, safety rule or training losses. It verifies the
selection receipt's file hash, schema, route, forbidden-read declarations, all
three checkpoint hashes and independently supplied Support scope.

It then reruns `select_route_parent` on the reported evidence and compares all
generated decision fields: selected parent, reason, safety reference, per-branch
safety decisions and Support identity. A hash-valid receipt with a changed winner
or relaxed guard is rejected. Historical fixed-parent control receipts are not
accepted as prospective Agent decisions.

The selected parent's actual Support cache is loaded through the manifest/hash
validator. Before model construction, the unchanged `summarize_runtime_archives`
recomputes scope, weighted frames, physical support, weak agreement and temporal
consistency on those same arrays. Each must match the selected evidence row.
There is no second unhashed array load and no new metric threshold.

## Invocation

The real trainer's `--prepare-only --device cpu` interface also requires:

```text
--parent-selection-receipt <absolute-receipt-path>
--parent-selection-sha256 <receipt-sha256>
--support-scope-sha256 <independent-current-run-support-scope>
--parent-checkpoint-hash cora0=<current-cora0-sha256>
--parent-checkpoint-hash cora_se1=<current-se1-sha256>
--parent-checkpoint-hash cora_se2=<current-se2-sha256>
```

The Dispatcher must obtain these expected values from its pinned current-run
configuration. It must not fill them from an untrusted receipt merely to make
comparison succeed. No checkpoint is deserialized by this check.

## Evidence Limits

`parent_selection_content_verified` means the reported decision reproduces the
existing selector with the bound identities. `selected_parent_support_recomputed`
means the selected parent's Support measurements also match the loaded cache.

The two unselected parents' measurements and EmptyGuard predictions are not
remeasured here. The receipt explicitly leaves `metric_measurements_recomputed`
false for the complete three-parent comparison. Nor does this validate the
scientific accuracy of the pseudo-labels, independently authorize a split, or
prove a human-readable no-read declaration. The pinned resource/label admission
and real Dispatcher integration remain separate requirements.

All tests use generated data. No actual Development, Locked Test or trained-model
evaluation is performed. No optimizer step, checkpoint save or promotion occurs.
The historical training math is unchanged and the production launch guard is not
relaxed by this preparation path.
