# RIS Five-Candidate Behavioral Acceptance

## Independent input contracts

The four original RIS candidate-set structures retain their profile-bound
native graph, source, Support and parent-selection checks. The fifth candidate,
`ris_temporal_gate_h16`, retains its shadow adapter, hard gate and prediction
freezing stages. It is a capacity variant, not a fifth distinct architecture.

`RISMixedBatchBackend` accepts exactly these five pinned profile bindings.
It rejects UAV, missing/extra candidates, wrong identities, code drift,
foundation disagreement and requests for production execution. Original
candidate receipts and the H16 receipt remain individually visible.

The H16 command profile validates current parent bytes by hash, teacher member
hashes, exact fit/calibration membership and disjoint prospective roles. It
checks all three actual script parsers. It never imports training entrypoints.

## Explicit limit

The fixture parent is a marker file, not a neural checkpoint. The H16 fixture
teacher is a hashable synthetic marker archive, not a training-compatible
teacher cache. Passing this exercise proves command binding and Qwen workflow
behavior only. Tensor compatibility, real receiver/teacher provenance and real
current-parent readiness require separate evidence before formal training.
`production_admission` remains false; the original RIS provenance gate is not
bypassed. No synthetic metric is a reproduced scientific result.

## Reproduction

Run `scripts/prepare_ris_mixed_batch_fixture.py --native-root <native-code-root>
--output <fresh-fixture-root>`. Pass the generated request path/hash into
`scripts/check_qwen_selected_expert_batch.py --batch-kind ris-mixed` with the
verified Qwen model and LoRA paths. Use separate fresh fixture roots for each
run. The complete request must reach monitor; removing H16 must reach rollback.
No sensing training or Locked Test is allowed in either case.

## Server observation

The installed `ris_mixed_qwen_preparation_20260910` release passed 16 reviewed
regression tests. Actual frozen-LoRA Qwen then completed the full request with
13 memory restores and one batch compilation. The missing-H16 request rolled
back with 11 restores and one failed batch compilation. Both reports passed
their behavioral checks and remained non-promotable. Raw reports and memory
receipts are pinned by `artifacts/pretraining_acceptance/ris_mixed_qwen_actual_20260910/EVIDENCE_INDEX.json`.

Outstanding: real H16 teacher tensor compatibility and receiver provenance are
not established by this synthetic exercise. Final acceptance must list them
separately instead of treating the five-candidate behavioral pass as proof.
