# Original RIS CLI and Receipt Preparation

## Scope

`src/agent_jsac/original_ris_dag_preparation.py` is a preparation-only
compiler for the recovered RIS route trainer. It does not execute the command,
import the trainer/model/runtime, create an optimizer, open a checkpoint or
`.npz` member, read Test data, train, write a checkpoint, or change the
quarantine file.

The compiler uses the current Human catalog and the exact source-coverage
artifact at `artifacts/pretraining_acceptance/EXPERT_EXACT_SOURCE_COVERAGE_20260910.json`.
The recovered source pair is under
`reproduction/reference_sources/agent_expert_runtime_contracts`:

- model `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`
- trainer `01a7aac1d09a5ec4bbc06b7bf0ae0d5bd739ecc6ffef01daf13ab22be91c02dd`
- runtime `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3`

The coverage artifact itself must remain hash `4260f9f51d6dc6f454577a8cec59f7935e49f7935b3926ffd2ba23375f461011`.

## Identity Boundary

The current RIS route must contain exactly these five library IDs:

1. `ris_temporal_gate_h32`
2. `risecho_path_integrator`
3. `risecho_codebook_consensus`
4. `risecho_dual_path_mixture`
5. `risecho_dual_stream_stability`

`risecho_codebook_consensus` remains denied because its existing quarantine
decision is unchanged. It is rejected before source binding or compilation;
this helper does not reinterpret or release that decision. The other four IDs
are the only IDs accepted by `compile_original_ris_cli`.

For an accepted ID, the helper compares the complete current catalog row,
entrypoint bytes, coverage source pair, and the literal `_spec(...)` topology
in the pinned model source. The resulting identity remains the native
`RegisteredDiscreteCandidateExpert` identity and its historical mixer/topology
mapping. No implementation is inferred from an expert name.

The original trainer's shared `episode_loss` is the declared loss contract for
all registered RIS IDs. There is no new codebook-specific loss. The trainer
and model pins are the pair recorded by the current coverage evidence.

## CLI Contract

`compile_original_ris_cli(root, expert_id, context, ...)` returns
`CompiledOriginalRISCLI` with `command`, `cli_contract`, `receipt_contract`,
and `audit`. The command is the native
`reproduction/reference_sources/agent_expert_runtime_contracts/scripts/train_se_branch_route_expert.py`
command. Its parser is checked from the pinned `parse_args` function, including
the c3-family flags plus the required
`--production-trainer-family ris_temporal_hard_gate`. Parent-selection flags
are rendered from the current context when bound to the current selection.

The pinned defaults are retained, notably `--epochs 24` and `--hidden-dim 64`:

- learning rate `0.0003`, weight decay `0.0001`
- source-replay loss coefficient `0.35`
- calibration fraction `0.25`, harm budget `0.02`
- seed `3407`, device default `cuda` (the context may choose the rendered device)

The source-replay loss coefficient is not a sample-weight declaration. The
RIS source policy below still requires every source-replay sample weight to be
zero.

## Current RIS Data Contract

The separate `OriginalRISPreparationContext` binds task, candidate, parent,
current fit/replay roots, EmptyGuard, output root, and current parent-selection
metadata. The current RIS supervision contract requires `task=human` and the
recovered `cora0` parent because that is the native RIS route contract, not a
new default.

Both current roots must contain exactly their native
`ROUTE_RUNTIME_MANIFEST.json` file. JSON-only validation checks:

- schema `agent_jsac_se_branch_route_runtime_manifest_v1`, route
  `corner_nlos_ris`, task, role, current parent branch/checkpoint, and the
  exact runtime input list;
- target `fit` records with origin
  `offline_bidirectional_RISEcho_observed_candidate_set`;
- source `source_replay` records with origin
  `zero_weight_ris_canary_or_identity_replay`;
- the native train-only supervision declaration;
- non-overlapping sequence membership, valid native `seq_<digits>` names,
  frame counts, record SHA256 declarations, and all forbidden reads false.

The receipt contract records the RIS source policy explicitly:

```text
target origin:             offline_bidirectional_RISEcho_observed_candidate_set
source-replay origin:      zero_weight_ris_canary_or_identity_replay
source-replay weights:     all_zero
```

The compiler never opens source arrays, so its audit says
`source_replay_weights_read=false` and
`source_replay_weights_verified=false`. An optional JSON declaration of
`sample_weight_policy=all_zero` is checked for consistency, but it is not
treated as physical-array verification. The native trainer/data preflight must
verify the actual arrays before any future execution.

## Receipt Validation

`validate_original_ris_training_receipt` accepts only native schema
`agent_jsac_se_branch_route_expert_training_receipt_v2`. It checks the native
identity, trainer family, parent-selection binding, fit/calibration/replay
sequence partition, EmptyGuard path/hash, runtime-manifest paths/hashes, and
model/trainer source hashes. Runtime-manifest paths must be the exact current
context roots; a historical receipt path is not accepted. A declared
checkpoint path must remain under the current output directory, but its bytes
are deliberately not opened.

The returned audit remains non-authorizing: execution, training, optimizer
creation, checkpoint loading, and production admission are all false. The
focused synthetic coverage is in
`tests/test_original_ris_dag_preparation.py`; no dispatcher, packager, c3
module, catalog, quarantine, or existing test is changed by this feature.
