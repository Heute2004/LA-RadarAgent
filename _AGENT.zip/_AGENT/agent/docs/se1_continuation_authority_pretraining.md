# SE1 continuation authority

The recovered configuration-search policy evaluates the complete four-point
weight-composition grid, with candidate-specific measurements on one sealed
Support scope. The subsequent operator-authorized policy permits a two
percentage-point absolute tolerance for physical support, temporal consistency
and weak-label agreement, and an internal empty false-alarm cap of 0.02.
Source-forgetting and intervention-coverage gates remain unchanged.

This permission is exclusively zero-weight SE1-to-SE2 continuation. It neither
promotes SE1 to runtime nor grants expert training/promotion. SE2 requires its
own audit. The historical exact-scope checkpoint authorization is a different,
post-audit artifact and is not a transferable threshold profile.

The implementation now requires the supplied audit object to equal its persisted
JSON, hashes that file before checking candidates, and rejects any file change
before issuing the handoff. Missing or different audit files fail closed.
The numerical budgets, original search outcome and sorting are unchanged.

Required assets are bundled as the original search policy, original continuation
policy and `se1_internal_stage_handoff.py`. These checks do not resolve the
separate pending live weak-evidence and expert-promotion threshold profiles.
