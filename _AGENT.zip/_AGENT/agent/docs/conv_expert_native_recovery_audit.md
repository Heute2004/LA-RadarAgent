# Native Conv Expert Source Recovery

## Scope

Read-only recovery on 2026-09-09 from the verified server `lab407`, user `hyc`.
Source root: `/home/hyc/radar+ris/code_radar_cbpr_v1_20260805`.
The sibling `code_radar_convlstm_expert_transfer_20260805` also contains expert
sources; this collection uses the first root only. No claim of byte equality
between the two roots is made.

Only 19 explicitly requested Python sources were copied. No dataset, checkpoint,
prediction, development sample, or Locked Test sample was opened. No recovered
module or training entrypoint was executed. All 19 sources pass AST parsing and
all 19 copied-file SHA256 hashes match the collection manifest.

Archive: `artifacts/pretraining_acceptance/CONV_EXPERT_NATIVE_SOURCE_20260909.zip`

SHA256: `8e8085365c649dee29e2ec704e00e239f323c29c570bebded0efcb2e1090ea2b`

Requests: `artifacts/pretraining_acceptance/conv_expert_source_requests.json`.
Expanded evidence: `artifacts/pretraining_acceptance/conv_expert_native_source_20260909/`.
Exact source paths, sizes and hashes are in its `COLLECTION_MANIFEST.json`.
This is a provenance collection, NOT an independently installable training bundle.
Transitive imports, environments and data adapters are not yet closed.

## Verified Structure Locations

Paths below are relative to the original source root.

| Family | Source and line | Observed implementation |
|---|---|---|
| CLOR | `radar_bev/models/heterogeneous_experts.py:106` | BEV ROI encoder, 64D radar state, continuous bounded offset, covariance and acceptance heads |
| DCMD | `radar_bev/models/heterogeneous_experts.py:143` | Original class recovered; mechanism equivalence with catalog entries still requires review |
| PATEI | `radar_bev/models/heterogeneous_experts.py:210` | Original class recovered; not automatically equated to every temporal integrator |
| SRRE | `radar_bev/models/heterogeneous_experts.py:262` | Original class recovered; separate from the later GG-SRRE class |
| LTGE | `radar_bev/models/e3_experts.py:159` | Original class recovered; not automatically equated to the later SE2 implementation |
| GG-SRRE | `radar_bev/models/e3_experts.py:251` | Separate recovery and gain modules; joint/recovery/gain training phases |
| TECS | `radar_bev/models/e7_experts.py:65` | `TECSEchoCandidateSelector` recovered |
| PB-MHBR | `radar_bev/models/e9_pbm_hbr.py:123` | Stage-one candidate reranker, with separately named later variants |
| Conv adapters | `radar_bev/models/convlstm_expert_wrappers.py:40` | Frozen ConvLSTM parent wrappers for the original heads |

Additional recovered classes include CUCRE, AURF-Lite, SDP-TBD, SCAR, LTGE-CEN,
RHEM, DPBR and CBGAR. Their existence does not authorize adding or replacing any
of the user's fixed 42 catalog entries. RD variants are archival code only;
recovering them does not authorize an extra model input.

CLOR's bound in this source is `0.45 * tanh(offset_head(...))` per coordinate,
followed by geometry clamping, not a 0.45 m Euclidean-norm guarantee. Its logit
residual strength head is zero initialized. Its proposal can be continuous;
it cannot be represented faithfully as `exact_observed_candidate` alone.

GG-SRRE uses a 0.60 m per-coordinate offset parameterization. During recovery,
acceptance is explicitly overridden to one; gain training freezes recovery
modules. A single generic candidate-classification trainer does not reproduce
this training schedule.

## Training Contract Conflict

`scripts/train_convlstm_heterogeneous_expert.py:15` replaces model construction
in the existing heterogeneous trainer. It does not change that trainer's labels,
split handling, loss, or checkpoint selection.

In `scripts/train_dream_heterogeneous_expert.py`:

- Lines 243-245 consume `target_xy_m`, `history_target_xy_m` and validity.
- Lines 358-364 construct `RadarWindowDataset` for training and Development.
- Line 410 records the old evaluation protocol text.
- Lines 432-433 select checkpoints by Development `ap_0p3m`.

The underlying dataset loader was not recovered in this 19-file batch; this
audit does not assert the on-disk provenance of every coordinate label. The
coordinate-supervised interface and Development-based checkpoint selection are
already sufficient to reject direct launch under the current weak-supervision
pretraining contract.

Reuse the verified model and loss mechanisms only after adapting the explicit
approved label bundle, Fit/Calibration episode roles, selected parent features,
and stage-specific selection rules. Do not silently remap Development to
Calibration or treat old target coordinates as automatically generated labels.

## Binding Decision

- Original 42 identifiers and structures remain unchanged.
- This collection does not increase the count of executable semantic bindings.
- No historical expert weight or old experiment score becomes a toolbox asset.
- No old trainer is placed into an executable Agent whitelist by this recovery.
- Overall pretraining acceptance remains NO-GO until native structures, training
  contracts, label lineage and Agent dispatch are jointly verified.

Next: establish a source-level mapping from each catalog mechanism to its actual
head and trainer, retaining explicit conflicts instead of alias substitution.
