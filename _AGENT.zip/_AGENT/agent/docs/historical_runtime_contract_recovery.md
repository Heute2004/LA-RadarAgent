# Historical Expert Runtime Contract Recovery

## Scope

Preserve the 42 original semantic identifiers and recover their original server
code and declarative dependencies. This is not permission to train, deploy, read
Locked Test, import historical expert weights, or reinstate old supervision.

## Recovered Evidence

Server source: `/home/hyc/radar+ris/AGENT-JSAC`, verified as `lab407 / hyc`.
The registered model source still matches historical receipt hash
`a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`.

Archive: `HISTORICAL_EXPERT_RUNTIME_CONTRACTS_20260909.zip`.
SHA256: `4a1d7e2ea4b11950afcca7625922f027cb72826a578b19472383ba2db8b478ad`.
Local source directory: `reproduction/reference_sources/agent_expert_runtime_contracts`.

The archive contains 63 hash-checked code/config files: 59 Python sources and four
JSON contracts. All 42 wrapper identifiers match their catalog implementation
identifiers. The collector now follows these explicit runtime dependencies in
addition to AST imports:

- the registered execution library;
- the semantic template library;
- the 42-entry catalog;
- the execution library's canonical supervision recipe metadata.

It follows declared Python entrypoints and verifies their hashes. It does not
follow any data paths, checkpoint paths or prediction references inside metadata.
Old originals and active production registries are not overwritten.

## What Now Resolves

The original application-contract loader, in an isolated process, resolves all
42 identifiers against the recovered directory. Previously its required JSON
files were absent from the Python-only recovery.

The resolved contracts are NOT identical:

| Archived output contract | Count |
| --- | ---: |
| Exact observed candidate | 35 |
| Exact frozen branch | 2 |
| Bounded convex candidate update | 5 |

This establishes the archived dependency closure for contract lookup, not semantic
equivalence or training readiness. In particular, archived CLOR's discrete
candidate contract still conflicts with native continuous-offset CLOR. The native
Conv implementations remain separately preserved. Do not silently replace one
with the other or treat an old registry's authorization flags as current authority.

## Two Mechanism Checks

`angular_consistency_associator` retains its original `_AngularMixer`, polar
coordinate embedding, causal convolution and innovation gate. Its reference is
candidate zero, the current selected parent's prediction, NOT a brightness-sorted
peak or a previous-frame coordinate. It is not a full trajectory association
solver.

`echo_extent_disambiguator` retains its original `_ExtentMixer`, Cartesian
embedding and extent gate without temporal recurrence. Extent means the candidate
cloud, including the parent at index zero, not a segmented raw body echo.

Synthetic CPU checks establish, for both mechanisms:

1. Mixer AST equality to the recovered original.
2. The existing route training loss produces finite, nonzero mixer gradients.
3. No parameter changes occur, and no optimizer step or saved model is used.
4. Future frames do not alter prefix logits or acceptance.

These tests do not prove real-label quality or trained accuracy. Their labels are
explicit synthetic tensors. The original loss is reused rather than replaced by
a new loss under the old expert name.

## Reproduce the Metadata Audit

```powershell
python scripts/audit_recovered_expert_contracts.py --source-root reproduction/reference_sources/agent_expert_runtime_contracts --report artifacts/expert_contract_audit.json
python -m pytest tests/test_historical_registry_collection.py tests/test_recovered_expert_contracts.py tests/test_registered_mechanism_training_contract.py -q
```

The report path must be fresh. Current local result: 12 tests passed. The audit
report is `artifacts/pretraining_acceptance/HISTORICAL_EXPERT_RUNTIME_CONTRACT_AUDIT_20260909.json`.

## Remaining Gate

The next binding must reconcile actual input features, label lineage, parent
identity, output semantics and original mechanism-specific training. Existence
of all 42 wrappers is not evidence that all 42 described structures are fully
implemented. No additional production expert is authorized by this recovery.
