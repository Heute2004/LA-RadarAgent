# Original Conv Expert Head Loading

The callable `agent_jsac.original_conv_expert_loader.build_original_conv_head`
constructs an untrained original head from the recovered, byte-preserved Conv
dependency closure. It does not call a historical trainer or import weights.

```python
head, provenance = build_original_conv_head(
    toolbox_root, task="human", symbol="CLOREXpert"
)
```

Allowed original symbols: `CLOREXpert`, `TECSEchoCandidateSelector`, `LTGEExpert`,
`GGSRREExpert`, `PBMHBRStage1CandidateReranker`. These are exact original class
names, not inferred aliases for the 42 semantic catalog entries.

## Integrity and Isolation

- Verify the pinned collection manifest and all 41 source file hashes before
  imports, including repeated factory calls.
- Import verified source bytes in a root-specific private Python namespace.
- Do not mutate `sys.path`, overwrite `radar_bev`, or trust stale bytecode.
- Reject UAV calls and unknown symbols.
- Preserve native signatures and output dictionaries; there is no shared
  candidate-logit adapter that erases continuous-offset semantics.
- Return `training_authorized=false` and `semantic_binding_authorized=false`.

CLOR preserves its per-coordinate 0.45 m bounded continuous offset and initial
zero residual. GG-SRRE preserves its per-coordinate 0.60 m bound and separate
recovery/gain parameter-freezing behavior. These are not new hyperparameters.

## Next Binding Work

The original feature inputs must come from a compatible, selected frozen parent.
Approved weak-label Fit/Calibration records, native losses, checkpoint format,
and Canary decoding still need explicit training bindings. The existing generic
discrete-candidate trainer must not consume this head as though it returned
`candidate_logits`.

This factory is a reusable original-structure component, not permission to run
historical supervised trainers, access target Final-BEV, or promote a candidate.
The 42-entry semantic pool is unchanged.
