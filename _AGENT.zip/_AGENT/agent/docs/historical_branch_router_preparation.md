# Historical Branch Router Preparation

Date: 2026-09-10. This is a standalone prepare-only surface for the Human
`branch_persistence_selector` entry. It checks the recovered implementation
and evaluates its original Support data/loss path in memory. It is not a
training, checkpoint, promotion, or numerical-reproduction result.

## Exact binding

The helper binds the current Human library entry field-by-field and verifies
the recovered entrypoint before loading the two requested sources:

| role | path | SHA256 |
|---|---|---|
| model | `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/branch_router_recipe.py` | `ce03fb4adc45a310dfadc1ca0d783cbb0b289a797a338cf32d32c645b5f18738` |
| trainer | `reproduction/reference_sources/server_gble_recorded_training_20260910/train_branch_router_recipe.py` | `17a615649e5bf53049b8ff6815678e0643bb3e425d2d671779001d0ce81549a6` |
| registered entrypoint | `reproduction/reference_sources/agent_expert_runtime_contracts/scripts/route_experts/branch_persistence_selector.py` | `22adc9a8d10272eb489fb933cee3a73beb330b4842a465c1938e1e94b084895d` |

The registry identity is fixed to:

```text
expert_id       = branch_persistence_selector
implementation  = branch_persistence_selector_v1
primitive       = branch_persistence_selector
route           = indoor_clutter
parent_branch   = route_selected
mode            = exact_frozen_branch
```

`route_selected` is the outer runtime parent-selection slot. Support members
must still carry one concrete branch in `cora0`, `cora_se1`, or `cora_se2`, and
one manifest cannot mix those branches. No parent checkpoint hash is an input
to this helper.

## Original model and trainer closure

The model is instantiated from the recovered module as
`CausalBranchRouter(18, 48)`. The trainer is not imported or run as a CLI
module. Only these top-level nodes are extracted from its verified AST:

```text
BranchEpisode
assemble_branch_episode
sequence_loss
```

Therefore the original conversion remains authoritative: three branch
coordinates/scores are assembled by `assemble_branch_episode`, then the
original `branch_feature_tensor` and `set_mass_branch_targets` from the
recovered model source produce the feature and physical-candidate target. The
original loss is used unchanged:

```text
weighted branch cross-entropy + 0.01 * adjacent-probability smoothness
```

The preparation module does not reproduce either formula in a second local
implementation. The extracted closure is the only data/loss call site.

## API and Support boundary

Use `prepare_historical_branch_router()` with:

```text
support_manifest
support_manifest_sha256
branch_index
device="cpu"
```

The manifest must be the exact
`agent_jsac_se_branch_route_runtime_manifest_v1` Support manifest. Its role
is limited to `fit`, `calibration`, or `source_replay`; `development`,
`canary`, and `locked_test` fail closed. The manifest hash is checked before
any archive is decoded, and every declared `.npz` member is hash checked
before `np.load(..., allow_pickle=False)`.

The loader requires the original route-runtime fields, Boolean forbidden-read
flags set to false, physical candidate zero equal to the parent, normalized
candidate mass, and finite/shape-valid Support arrays. It rejects route,
role, sequence, frame, member, and parent-branch mixing. The in-memory
`branch_index` is the three frozen branch-output map required by the original
assembler; it is not a checkpoint loader and is not used to open parent
weights.

## Prepare-only guarantees

The model is freshly constructed in a CPU RNG scope, set to evaluation mode,
and checked under `torch.no_grad()`. The helper never creates an optimizer,
calls backward, loads or saves a checkpoint, reads parent weights, starts a
training loop, or claims a historical best. It checks finite logits/loss and
that the model state dictionary is unchanged.

This addition is intentionally standalone. It does not edit the main entry,
packager, registry, or configuration. Mainline integration can pass its
already-resolved Support manifest hash and frozen branch index into this
surface later.

## Verification

The focused test command is:

```powershell
$env:PYTHONPATH='H:\Project\AGENT-JSAC\src;H:\Project\AGENT-JSAC\tests'
D:/anaconda3/envs/vlm3b/python.exe -m pytest -q tests/test_historical_branch_router_preparation.py
```

The test uses only temporary synthetic Support archives. It covers exact
source binding, original data conversion and loss, manifest-before-decode
hash checking, member hash checking, Support-role rejection, route isolation,
CPU-only enforcement, and monkeypatched failures for optimizer/checkpoint/
backward operations.
