# RIS synthetic profile release acceptance

This is a new isolated release record. The prior `RIS_CODEBOOK_PROVENANCE_BLOCKER_AUDIT_20260910` report was not rewritten.

## Scope

`scripts/build_historical_ris_qwen_synthetic_profiles.py` builds exactly four profile-bound synthetic fixtures from the existing native RIS test fixture and ABI. Each profile binds the current synthetic `cora0` parent selection, fit `seq_022`/`seq_023`, zero-weight source replay `seq_038`, every manifest/member hash, the parent checkpoint hash set, and the original source pins. The builder creates no checkpoint, model payload, dataset, ground truth, optimizer, or training output.

The native source pins are unchanged:

| binding | SHA256 |
| --- | --- |
| recovered model | `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486` |
| recovered trainer/loss AST closure | `01a7aac1d09a5ec4bbc06b7bf0ae0d5bd739ecc6ffef01daf13ab22be91c02dd` |
| recovered runtime | `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3` |
| native preparation helper | `d365f7acfca147d28ec61539040a0b1c224643f57d6dd9f8dd74da7ea6b8b737` |

The independent runner `scripts/run_historical_ris_qwen_synthetic_acceptance.py` calls the existing native Qwen checker. It adds only two explicit negative checks: a missing native Support profile must roll back, and a codebook profile must be rejected before Qwen dispatch.

The current v21 local provenance is position-preserving only. It is not a trusted receiver/label provenance bundle and therefore does not clear RIS codebook quarantine or formal preparation blocking.

## Server evidence

The isolated server release was `/home/hyc/radar+ris/AGENT-JSAC/artifacts/pretraining_acceptance/ris_qwen_synthetic_release_20260910`; profiles were regenerated inside that release after copying the checker and fixture builder. The real Qwen scorer ran on `CUDA_VISIBLE_DEVICES=0` with `Qwen2.5-0.5B-Instruct` and the existing adapter. No training was started.

The new server receipt reports:

| case | result |
| --- | --- |
| `ris_temporal_gate_h32` | `monitor_reached`, native preparation passed |
| `risecho_path_integrator` | `monitor_reached`, native preparation passed |
| `risecho_dual_path_mixture` | `monitor_reached`, native preparation passed |
| `risecho_dual_stream_stability` | `monitor_reached`, native preparation passed |
| missing native Support | `rollback_executed`; rejected for missing `native-support-manifest` |
| `risecho_codebook_consensus` | rejected as `forbid_retrieval_and_execution`; Qwen not invoked for this case |

Every case remains `formal_training_preparation_status=PROVENANCE_BLOCKED`, `provenance_verified=false`, `production_admission=false`, and `normal_agent_dispatch_bound=false`. The server release contains zero `.pt`, `.pth`, or `.ckpt` files; the quarantine hash remains `a6d882ec403c3494be1667b12a64bea2536b78cbf0e012672349eca5fac1e2a7`.

## New evidence files

- `artifacts/pretraining_acceptance/ris_qwen_synthetic_release_20260910/FIXTURE_MANIFEST.json` is the local reproducible synthetic release manifest, SHA256 `f142d1356c80b767bcb284a405af06bf343290ee5d6fa69f264b1f3bd1294cd1`.
- `artifacts/pretraining_acceptance/RIS_QWEN_SYNTHETIC_SERVER_FIXTURE_MANIFEST_20260910.json` is the server-path manifest, SHA256 `e9a20fb5fa6bc03c7bd4a9b7017efff6190eca4f28e59b5e921f7c1ae947b67d`.
- `artifacts/pretraining_acceptance/RIS_QWEN_SYNTHETIC_SERVER_ACCEPTANCE_20260910.json` is the full server receipt, SHA256 `4bbb22ec4be38807ebb543342a75bd750d4fc2729ed0bf8c205cc16711480779`.
- `artifacts/pretraining_acceptance/RIS_QWEN_SYNTHETIC_SERVER_POSITIVE_20260910.json` is the positive checker receipt, SHA256 `41435119ea256145f0a4316c43176519bf0e8e363ea1e6d6aae53f8876041a33`.

The source files used for the new release are `scripts/build_historical_ris_qwen_synthetic_profiles.py`, `scripts/run_historical_ris_qwen_synthetic_acceptance.py`, and `tests/test_historical_ris_qwen_synthetic_release.py`. The builder SHA256 is `3fcebf50d4cbc1bbccb4aa6b1909d83bc6a39ec0e3a4a4a05c5864727407bb65`; the runner SHA256 is `ce52dcdf04b0127a1d8336799bceed51f7a710ef8f1a00e662a52d6df7c64290`; the existing independent checker remains pinned at `098300de0156481d4cdacde509e71f671ed2013f8930cc15eed0c07e7e602374`.

Local verification: `32 passed`. This is synthetic preparation/readiness evidence, not a training result, provenance admission, normal dispatcher binding, or claim that the historical RIS structures are frozen best models.
