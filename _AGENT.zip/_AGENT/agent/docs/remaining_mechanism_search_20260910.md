# Remaining Mechanism Search

## Scope

Read-only source inspection was performed on `lab407` as user `hyc` under:

- `/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2`
- `/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX`
- `/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R3`
- `/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_SUPERSEDED_20260827_r2`
- `/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_SUPERSEDED_20260827_r3`
- `/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_SUPERSEDED_20260827_r5`

The search was limited to loose `*.py`, `*.sh`, and `*.md` source files. The
five archives already listed in `docs/original_expert_mechanism_gaps.md` were
not rescanned, and no compressed archive member was opened or extracted. No
payload, checkpoint, Locked Test, or Test result was read. Exact paths, hashes,
symbols, and copied-file locations are recorded in
`reproduction/reference_sources/remaining_mechanism_search_20260910/SOURCE_EVIDENCE_MANIFEST.json`.

## Verified Independent Component

The search found a genuine independent SCAA source component at
`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2/src/agent_jsac/scaa.py`.
Its SHA256 is
`4ff942e30eb27e20c15aa86865aa411f7f5c784d094ee9b840856b6199ada048`.

Concrete symbols are present in `SelectiveCandidateAssociationAdapter`:

- `association_head` at line 33;
- `acceptance_head` at line 34;
- `covariance_head` at line 35;
- `softplus(self.covariance_head(causal_state)) + 1.0e-3` at line 72;
- `physical_candidate_set_loss` at line 81;
- `binary_cross_entropy_with_logits` at lines 121-130;
- `dispatch_scaa_prediction` at line 139.

This is real covariance-head evidence, but it is not a covariance-trained
mechanism: `physical_candidate_set_loss` optimizes set mass and acceptance BCE,
and receives no covariance target or covariance term. The dispatcher chooses an
observed physical candidate or preserves the base coordinate; it has no
continuous offset head. The trainer at
`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2/src/agent_jsac/scaa_training.py`
binds `train_shadow_adapter` to that same loss, with SHA256
`1a08556cb500c74e515f54a0d57bd5f9bc763ea148836b03dce0c40d40f84e09`.
The source launch contract
`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2/scripts/train_indoor_clutter_shadow.py`
is also preserved; its SHA256 is
`9e50c04f76c887947d0dec2daaf7e370cc418ddcb73f09183a3983402bbb187c`.

These three files are copied without modification under:

`reproduction/reference_sources/remaining_mechanism_search_20260910/server_native/`

SCAA is recorded as a verified independent component only. There is no
one-to-one evidence binding it to any of the six unresolved catalog names, so
it is not renamed, admitted, or substituted for one of them.

## Six Gap Comparison

The six named wrappers all have the same one-line execution pattern: import
`run_registered_route_expert_entrypoint`, set `PRIMITIVE` and
`IMPLEMENTATION_ID`, and dispatch to the shared route-expert code. Their hashes
are preserved in the manifest and are identical across all six loose toolbox
roots.

The shared registered model is
`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2/src/agent_jsac/registered_route_expert_models.py`
with SHA256
`8e380886d2e682965ccce7cbe75419c1d5971db3aabba55bee21679a7d0aec3e`.
The relevant concrete behavior is:

- `polar_bev_cross_refiner`: `_CrossMixer` uses one pooled context token at lines 173-183; there are no separate polar/BEV local streams or continuous refinement outputs.
- `subcell_uncertainty_refiner`: `gate_kind="uncertainty"` reaches `token.var(dim=2, unbiased=False)` at lines 487-489; there is no subcell offset head or covariance loss.
- `innovation_gated_offset`: `gate_kind="innovation"` uses a context difference at lines 483-486, and `coordinate_kind="delta"` is only a coordinate feature encoding; there is no tracker prediction/innovation head or offset loss.
- `temporal_precision_tail`: `temporal_kind="tail"` applies a fixed last-quarter convolution gate at lines 469-480; there is no risk-defined tail selector or bounded precision residual loss.
- `robust_quantile_recovery`: `gate_kind="quantile"` again reaches token variance; there is no quantile head, target, or pinball loss.
- `anisotropic_wet_mixture`: `mixer_kind="mixture"` and `gate_kind="anisotropic"` still use the shared scorer and token-variance gate; there are no range/cross-range mixture parameters or mixture NLL.
- `risecho_geometry_consensus`: the registered signature is angular mixer, GRU temporal operator, codebook gate, and polar coordinates at line 111; no independent geometry head or geometry-specific loss is present.

The route trainer at
`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2/scripts/train_se_branch_route_expert.py`
has SHA256
`7772da28c4ccc1c5c628ed90142266930bdd9075d08c7fb22c49b2ef16c150ae`.
Its `episode_loss` is only set-mass loss, acceptance BCE, and continuity
penalty at lines 114-142. The name hits therefore do not establish the missing
mechanisms or their method-specific objectives.

## Bounded Conclusion

Within the six specified loose toolbox roots, the uncovered independent source
evidence is SCAA's explicit covariance output head plus its actual set/
acceptance training binding. Its covariance is not included in the loss, and
no quantile/pinball, continuous-offset, tracker-innovation, tail-residual, or
range/cross-range mixture-NLL head/loss was found. This is a bounded source
recovery result, not a proof that such code is absent from every unsearched
server directory or archive. No implementation was invented and no training
was run.
