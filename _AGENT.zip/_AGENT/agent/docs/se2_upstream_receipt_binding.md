# SE2 Upstream Receipt Binding

The active prospective wrapper verifies a sealed SE1 producer before importing
the native SE2 trainer. It reuses `bind_teacher_parent`; it does not introduce
a second signature format, weaker acceptance rule or new supervision recipe.

Required wrapper arguments:

- `--se1-checkpoint`: must match the receipt path and verified file digest.
- `--se1-upstream-receipt` and `--se1-upstream-receipt-sha256`.
- `--se1-producer-run-id`, `--se1-producer-protocol-sha256` and
  `--se1-producer-candidate-id`: independently supplied producer bindings.

The existing validator checks Human task, SE1 tool, signature, accepted internal
stage, forbidden-read evidence, zero runtime weight, current producer identity
and checkpoint hash. Only the verified checkpoint argument is forwarded. The
checkpoint writer checks the loaded SE1 digest against the handoff and records
the parent result digest. CORA0 initialization and the native SE2 objective are
unchanged. A simulated parent may be checked by the argument compiler, but
`main()` refuses it before native import; it cannot authorize real training.

Dispatcher integration must obtain these values from the sealed upstream tool
result, never free-form Qwen text. Legacy invocations without this handoff now
fail closed. Updating the active command compiler and its fixtures is still
required; this wrapper patch alone is not end-to-end lifecycle acceptance.

Verification uses synthetic receipt/checkpoint bytes only. Before the change,
all five new binding tests failed. After the change and simulated-parent guard,
the wrapper, shared parent validator and prospective lineage tests pass (35).
No sensing optimizer, native trainer, real checkpoint or Locked Test was used.
