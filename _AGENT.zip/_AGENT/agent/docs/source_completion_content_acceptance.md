# Source-Tail Completion Content Acceptance

## Defect and Repair

The Canary producer verified the native result file hash but did not parse that
file. A hash-bound empty JSON object could therefore reach model loading as
purported source-tail training evidence. Existing unit fixtures even used an
empty object. Those fixtures now reflect the actual producer's JSON schema.

`source_tail_completion.validate_source_tail_completion` checks the native
completion schema, route, checkpoint hash, positive integer fit/calibration
frame counts, completed and selected epoch bounds, timezone-aware completion
time, strict false Development/Test declarations and original policy agreement.
It is used both by shared policy-candidate binding and by the Canary producer,
before loading models or consulting an existing successful Canary receipt.

The content contract comes from the recovered
`train_r39_source_tail_adapter.py` completion writer, not a newly invented
quality threshold. Candidate-specific policies may differ from the original
selection, but cannot rewrite the original completion and policy lineage.

## Verification

Twelve malformed native-result cases reached the prohibited model-load stub
before the fix. All twelve are rejected before model loading after the fix.
The broader source-policy/Canary suite passes: **57 tests**.

Covered rejection cases: empty JSON, wrong schema/route/checkpoint, no fit data,
invalid selected epoch, Boolean epoch, missing calibration count or timestamp,
Development access, string rather than Boolean Test declaration, and altered
original policy. Positive cases preserve separate policy candidates, unchanged
shared weights, actual policy application and verified Canary recovery.

Tests use explicitly synthetic fixtures. No real sensing training, model
checkpoint loading, dataset access or Locked Test access was performed for this
repair. A valid receipt is not proof of accuracy, promotion, or independent
authentication: result hashes provide integrity, not cryptographic identity.

## Remaining Integration Work

The complete native DAG still needs canonical training-result production and
all expert-family audit stages attached. This repair prevents malformed source
completion evidence from being consumed; it does not by itself provide the
missing end-to-end orchestration or all 42 native expert bindings.
