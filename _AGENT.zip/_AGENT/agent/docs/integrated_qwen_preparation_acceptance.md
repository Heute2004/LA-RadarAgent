# Integrated Qwen preparation acceptance

## Verified scope

On 2026-09-09, the existing verified Qwen adapter requested the Human lifecycle
using the registered Dispatcher. Native preparation checks completed in order:
source, Sentinel, SE1, SE2, teacher, specialist. The lifecycle reached monitor,
restoring persisted state thirteen times. All receipts remain non-promotable.

The source/Sentinel checks compile hash-bound commands. SE1 compiles its native
cache and sparse-anchor training commands. SE2 enters the actual native wrapper,
intercepts Stage A before optimization, supplies a clearly synthetic duration,
and intercepts Stage B before training. Teacher parsing validates the four-fold
manifest and parent identities. Specialist preparation verifies admission and
native episode loading without executing optimization.

This is reference-backed preparation, not fresh model or teacher production.
The aligned teacher command has not generated the historical specialist label
cache. Its ancestry must not be rewritten. Fresh output lineage and autonomous
scientific expert ranking remain unverified. Other lifecycle outcomes are
explicitly simulated. This result does not authorize unattended training.

## Failure and repair

The first integrated attempt passed source/Sentinel then rejected a stale SE1
handoff registry hash. Qwen executed rollback instead of continuing. Inspection
confirmed that the shipped implementation included persisted-audit equality and
mutation checks while the registry still bound the earlier implementation.
Only that registry hash was refreshed. Existing internal-only continuation
budgets and runtime prohibitions were not changed. A regression test now binds
the registry to the shipped implementation.

## Evidence

- Server negative: `artifacts/QWEN_INTEGRATED_NATIVE_20260909`.
- Server positive: `artifacts/QWEN_INTEGRATED_HANDOFF_20260909`.
- Local positive: `artifacts/pretraining_acceptance/QWEN_INTEGRATED_HANDOFF_20260909`.
- Release: `releases/integrated_handoff_20260909` on the server.
- Local ZIP: `artifacts/pretraining_acceptance/integrated_handoff_20260909.zip`.
- ZIP SHA256: `ee5120ea5b04e21076a2fbc1a073731bba8971f74737c1492a77dc67cfc7e1d1`.
- Packaged server regression: 437 passed in 15.45 seconds, CPU only.

No sensing optimizer ran; no Locked Test payload was read; frozen outputs were
not overwritten. Final requirement-level acceptance and release closure remain
pending. This document postdates the ZIP and is not claimed as part of its hash.
