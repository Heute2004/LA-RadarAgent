# Real Qwen Ranked Native Dispatch

## Evidence

Release: `native_selection_profile_bound_20260909` on lab407.
Report: `artifacts/pretraining_acceptance/QWEN_RANKED_NATIVE_CHAIN_20260909/REPORT.json`.
The matching server artifact directory retains the original report.

The verified Qwen LoRA was invoked with `--rank-native`. Twelve synthetic
readiness cases returned the expected train-request or hold decision. All six
ready-route requests compiled with zero compilation rejections. For every
ready route, `native_selection.recipe_ids` exactly equals
`request_receipt.execution.selected_native_recipe_ids`, including order.
No sensing training or Test payload read occurred.

Observed first choices (not measured best experts):

| Route | First requested native candidate |
|---|---|
| corner_nlos_ris | ris_temporal_gate_h64 |
| indoor_clutter | indoor_nscan_association |
| open_indoor_los | indoor_source_tail_auto |
| open_outdoor_weak_return | outdoor_source_tail_auto |
| outdoor_dry_complex | dry_route_setmass |
| outdoor_wet_return | wet_bounded_consensus |

The wet binding profile has SHA256
`60943095d6633e7ec0bf900a9aab92f4f0231c2483762078ec81e95b3fb4db14`.
Each specialist has a separate profile and fresh output namespace; native
method, protocol, admission and reference runtime identities were preserved.

## Interpretation

This proves actual model-driven native-ID ordering survives request validation
and route compilation. Each active route still has only five native choices,
so all five are included regardless of their order. It does not prove choosing
the scientific best five from a larger pool, valid novel-condition diagnosis,
fresh label generation, or numerical reproduction. Readiness evidence and
post-training results remain explicitly synthetic/reference-backed.

The report's `preparation_complete=false` remains correct. Larger semantic
inventory binding, prospective artifact handoff and full method-specific
promotion integration remain open.
