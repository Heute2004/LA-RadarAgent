# Source-Tail Policy-Bound Canary

## Shared training receipt handoff

`scripts/bind_source_policy_candidate.py` derives a policy-specific receipt from
an unchanged signed shared training result. Its CLI requires both input-file
hashes, a candidate ID, an explicit run root and a separate candidate root.
The checkpoint and native completion receipt must remain inside the same run;
the selected policy and output receipt must remain inside the candidate root.
All original training fields other than candidate identity are retained and
checked against the nested original result. Recursive derived bindings are
rejected. No weights are copied and no new training is claimed.

The existing source Canary producer accepts this explicit binding and writes
its audit under the policy candidate directory. Original single-candidate
receipts retain their stricter candidate-local artifact requirement. A checksum
seal detects accidental receipt changes; it is not cryptographic signer identity.

The existing `scripts/run_native_source_canary.py` also accepts the complete
optional group `--candidate-id`, `--run-root`, `--policy`, `--policy-sha256`.
With that group it binds the shared receipt internally before the existing
Canary executor. The preflight report contains the sealed effective training
result and marks whether a policy binding was applied. Without `--execute-audit`
it does not load a model or dataset and cannot be used as a runtime Canary pass.
Incomplete argument groups and mismatched file hashes fail before audit.

This helper is callable but not yet inserted into every native execution DAG.
Shared policy variants are not distinct network architectures and cannot fill
the requirement for five original expert structures.

## Purpose

## Episode isolation

Before any runtime audit, the external Human episode profile is validated across
all routes. An episode may be shared by routes in the same role, but cannot be
assigned to two of support-fit, support-calibration, support-canary, Development
or Locked Test. All role lists must be explicit, duplicate-free and use canonical
nonblank identifiers without surrounding whitespace. This check reads metadata
only; it never opens the episodes. The requested Canary list must be nonempty.

## Policy identity

A source-tail checkpoint can have several post-decode policies. Auditing the
default policy must not count as auditing another policy selected by the Agent.
Model architecture and training loss are unchanged by this repair.

## Policy materialization

The input training policy must already reference the exact checkpoint SHA256.
Materialization cannot rewrite a policy from another checkpoint as if it were
calibrated on the current one. Both fixed and internally selected policies require
finite numeric `expert_alpha` in [0, 1] and positive finite `max_shift_m`. Booleans,
NaN, infinity and out-of-range values are rejected before runtime use.

## Canary binding

The signed training result may contain `candidate_policy` with exactly `path`
and `sha256`. This path must remain inside the candidate root. When present, it
replaces the default `TRAIN_INTERNAL_POLICY.json`; failure to resolve it is an
error, never a request to fall back silently to the default file.

The policy checkpoint and route must match the signed training result. The
Canary context binds the actual policy hash, and recovery rejects a changed
policy or a receipt that did not execute the policy transform.

For parent coordinate b, raw candidate c, alpha a and maximum shift d:

```
accept = 1e-6 < norm(c-b) <= d and a > 0
proposal = b + a * (c-b) if accept else b
```

This is the historical decoded-coordinate policy. It is executed before the
zero-weight shadow comparison. Nonfinite transformed outputs fail the audit.
The test measures zero-weight identity and registered parent-state isolation;
it does not prove positive-weight accuracy, beneficial correction or promotion.
The underlying raw expert logits are checked separately; this coordinate policy
does not invent a new policy-adjusted logit map.

## Explicit remaining integration work

The source-tail shared-checkpoint DAG still needs candidate-specific signed
result materialization and an independent Support Canary stage. The shared
checkpoint must not be copied or relabelled as a separately trained model.
The current producer only accepts artifacts contained in the supplied current
candidate root. Do not broaden that root arbitrarily to bypass lineage checks.

Synthetic unit tests demonstrate code behavior only. No fresh sensing training,
real-model Canary or Locked Test evaluation was performed for this repair.
