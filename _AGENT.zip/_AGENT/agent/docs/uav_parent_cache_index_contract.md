# UAV Parent Cache Index

`ParentCacheIndex` provides exact runtime cache binding without historical path
globs. Its caller must supply the independently pinned index digest, current run,
manifest digest, verified parent receipt digest and manifest sequence-role map.
Values asserted only by the index are not independent authorization.

Required index fields:

```json
{
  "task": "uav",
  "run_id": "CURRENT_RUN",
  "manifest_sha256": "MANIFEST_DIGEST",
  "parent_receipt_sha256": "VERIFIED_PARENT_RECEIPT_DIGEST",
  "parent_checkpoint": {"path": "/external/parent.pt", "sha256": "CHECKPOINT_DIGEST"},
  "sequences": [
    {"sequence_id": 2, "role": "source_supervised_train",
     "path": "/external/cache.npz", "sha256": "CACHE_DIGEST"}
  ]
}
```

Only source training, source Development and target Support training can appear.
Each requesting stage must further restrict allowed roles. A source teacher
cannot resolve a Support entry through its source-only role scope. Test and
Development-query entries are rejected before their files are hashed.

The resolver checks parent and cache file digests again on use. It does not
claim that a valid digest proves how a cache was generated or that model quality
is sufficient. The upstream exporter and receipt validator must certify that
provenance; consumers must still validate NPZ frame IDs, shapes and finite values.

Status: unit-tested primitive, not yet bound to native teacher entrypoints.
Seventeen tests passed jointly with source command tests. Historical teacher
scripts remain unchanged until their source/temporal/target handoff is connected
to this resolver and independently exercised without fitting.
