# Recovered Expert Behavioral Boundary

## Evidence

Two server CPU audits used the same active 42-entry catalog, seed 41, synthetic
two-batch 16-frame five-candidate tensors, and the same behavior audit script.
The audit makes the otherwise constant acceptance head nonzero in memory to
probe dependencies; it performs no optimizer step and saves no model.

| Source | Constructed | Prefix failures | Invalid-candidate contamination |
| --- | ---: | ---: | ---: |
| Exact August 29 historical model (3b379ea9955f...) | 42 | 8 | 23 |
| Current control_source_recovery release model | 42 | 8 | 0 |

Reports: EXACT_AUG29_EXPERT_BEHAVIOR_20260910.json and
ACTIVE_EXPERT_BEHAVIOR_MATCHED_PROBE_20260910.json in pretraining_acceptance.
Both reports contain complete source and catalog hashes. Construction does not
prove historical training, scientific utility, or structural equivalence to
the descriptions in the semantic library.

## Prefix-Sensitive Entries

- temporal_precision_tail
- track_before_detect
- multi_hypothesis_path
- robust_quantile_recovery
- risecho_path_integrator
- causal_tracklet_consensus
- adaptive_threshold_tracklet
- anomaly_hysteresis_gate

The prefix probe compares the first eight outputs from a 16-frame invocation
with an eight-frame invocation. A failure means these invocation forms are not
interchangeable. In particular, the historical tail-context operation gates the
last quarter of the supplied sequence, so its boundary depends on input length.
This is not by itself proof that a last-frame-only historical-window deployment
reads physical future frames. It does prohibit claiming prefix-invariant dense
online outputs without a separate execution contract and test.

Do not silently replace the historical temporal structure. A causal deployment
may require an explicitly bounded historical window with supervision and decode
only at its endpoint. That integration is not verified by this audit. Archived
scripts remain unchanged and production admission remains separate.

## Invalid Padding

The audit changes invalid candidate feature/coordinate values while retaining
the validity mask, then checks valid logits and acceptance. Current masking
passes this probe for all 42 descriptors. This is a bounded synthetic check,
not proof against every malformed tensor or a claim of detection improvement.

## Auditor Compatibility

Historical specs lack topology_signature. The auditor now records null for an
absent signature and retains the actual dataclass fields; it does not synthesize
an equivalent signature or modify the recovered model. Two regression tests
verify legacy and newer metadata handling.

## Endpoint Executor Candidate

`agent_jsac.candidate_endpoint_execution.forward_endpoints` now implements an
explicit positive-integer historical window. For each frame it invokes the
unchanged model on history ending at that frame and retains only the endpoint
output. It preserves gradients and restarts candidate slots at truncated window
boundaries without mutating supplied reset metadata. Window length has no default
and cannot be selected by silently inferring it from episode length.

Fifteen local and server CPU tests pass, including all eight actual prefix-sensitive
registered structures, gradient flow without optimizer updates, and reset copying.
This is an execution helper, not an admitted production policy. Current full-episode
training remains distinct. Before binding, loss, calibration and inference must
all call the same endpoint contract, sequence/gap boundaries must be validated,
and Dispatcher must pin the selected window and helper source. No such full
integration or model accuracy is claimed by these tests.

Subsequent preparation integration: the common `forward_episode` used by original
loss and calibration now requires an explicit window for tail-context registered
models. The reviewed track-before-detect, path-temporal-integrator and causal
tracklet preparations accept `--temporal-history-window`; other entries cannot
use this option to bypass their contract. The same hash-bound, gap-split aligned
episodes reach both objective and calibration. Dispatcher pins the endpoint
executor source. Preparation receipts record the window and endpoint execution.

Synthetic fixtures use 16 frames as an explicit test value, not as a newly chosen
scientific hyperparameter. Production inference and training authorization are
still not granted. The remaining five prefix-sensitive descriptors have not
been admitted through this integration. No loss coefficient or network layer
was changed; the temporal execution contract is explicitly different from old
full-episode invocation and must not be presented as bitwise historical replay.
