# Bound Reference Runtime Acceptance

The native-derived exporter completed 23 Train sequences (6,900 frames) in the
separate server directory `artifacts/BOUND_REFERENCE_TRAIN_RUNTIME_20260909`.
This was frozen-parent inference, not model training. Original caches and
frozen research results were not overwritten.

The completed manifest SHA256 is:

```text
7894aac7a2ae302a6f10311313b933841501743417807f2e15001cc8098bc176
```

Independent audit verified the three supplied checkpoint paths/hashes against
the export manifest, each route/branch grouping, all archive hashes and Train
membership. The native loader verified all 23 archives, finite features,
candidate support, frame order and positive-weight consistency. Four route
groups passed. Evidence: `artifacts/pretraining_acceptance/BOUND_RUNTIME_AUDIT_20260909.json`.

The parents are explicitly reference parents. This is not a fresh source/SE1/
SE2 training lineage, and the audit does not prove label accuracy or admission
quality. The `clean` cache is not authorization to train a source-tail expert
with target weak supervision. Source-tail and RIS recipes remain separate.

The inspected current server threshold directory contains an integrity-only
frozen replay profile and a live-route template with ten numeric placeholders.
Replay equality checks cannot substitute for live weak-evidence thresholds.
Next: recover the correct method-specific frozen rules and metric producers;
do not invent permissive threshold values to obtain a successful admission.
