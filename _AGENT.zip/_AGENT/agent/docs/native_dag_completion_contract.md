# Native DAG Completion and Recovery

Source-tail training completion is `training_complete.json`, not `best.pt`.
A checkpoint alone can be partial work and must not release dependent jobs.

The runner now records successful process return code, a canonical hash of the
entire job descriptor, the registered completion path and its content hash.
Recovery requires all of them to match the current job. Legacy completion
markers without those bindings are not automatically trusted. Existing
unbound artifacts and unresolved running/failed states are preserved and stop
automatic recovery; they are not converted into a fresh training launch.

This is process/artifact lineage verification, not scientific success. A job
with a valid receipt may still fail label, accuracy or Canary acceptance.
Downstream promotion continues to require independent checks. The pretraining
release launch prohibition remains in force.

Tests use temporary synthetic files only. No historical state, checkpoints or
frozen results are migrated by this change. Explicit reconciliation of a legacy
run remains separate from launching a new run.

## Parallel Failure Ownership

When a child exits nonzero, exits without its registered completion artifact,
or cannot be launched, the scheduler stops launching pending jobs. It retains
ownership of already-running children in `draining_after_failure` and continues
polling them until they terminate. Each successful sibling retains its verified
completion evidence. Only then does the scheduler exit with failure.

`running_jobs` lists the outstanding children during draining and is empty at
terminal failure. Pending work is not falsely marked completed or silently
restarted. Launch errors close their log handle and persist `launch_error`.
This policy does not terminate unrelated server processes or restart failed work.

Tests exercise all three failure modes with fake process handles. No real
training subprocess is launched. Controller interruption or an indefinitely
running child still requires explicit process reconciliation; draining does not
claim to solve that separate recovery problem.
