# Native recipe selection acceptance

Real Qwen with the verified lifecycle adapter ordered five explicit native
recipe IDs for each of the six Human routes. Registered candidate mechanisms,
label recipes and parent policies were included in each choice description.
Choices were removed after selection; no duplicate, invented script or legacy
alias was accepted. Diagnostic inputs were synthetic neutral fixtures, so this
does not establish scientifically optimal ranking.

An independent native preflight recompiled the six route dependency graphs:
30 candidates and 87 intercepted jobs. Exact candidate identity verification
passed for all six routes using the existing canonical plan's structured
`candidate_id` to `native_candidate_id` mapping. No prefix stripping or fuzzy
alias matching was used. Compilation order may differ from Qwen ranking because
of dependencies. This is identity agreement between selection and compilation,
not evidence of a live training scheduler or new numerical results.

## Evidence

- `artifacts/pretraining_acceptance/QWEN_NATIVE_RECIPE_SELECTION_20260909.json`
- `artifacts/pretraining_acceptance/QWEN_NATIVE_SELECTION_DAG_BINDING_20260909.json`
- Server `artifacts/QWEN_SELECTED_NATIVE_DAG_20260909/REPORT.json`
- Release `releases/native_recipe_selection_20260909`
- ZIP SHA256: `5f4fd8a8e61915a0209ce93c045900a0a873703a67625ef85f39708741190040`
- Server packaged regression: 442 passed in 14.32 seconds.
- Later exact-ID verifier: seven local tests passed; it postdates that ZIP.

The native pool contains five candidates per route; Qwen currently orders all
five rather than reducing a larger verified set. Source-tail options are
calibration variants over shared training, and RIS options share a shadow
adapter with different gate widths. Do not call them thirty independent model
architectures. The 42 legacy semantic descriptors remain incompletely bound;
this native path does not satisfy or erase that separate requirement.

No sensing training was launched, no Test payload was read, and frozen outputs
were not modified. Final full-toolbox acceptance remains pending.
