# Native Source Profile Binding

The archived CORA source trainer is unchanged. A scoped dependency binding
replaces its module-local dataset constructor with the profile-authorized source
adapter, restoring the original symbol on success, failure or interception.
It does not mutate global source sequence constants.

The binding rejects alternate data roots/manifests, empty inputs, non-16-frame
windows and unexpected split construction. Normal construction preserves the
caller's RAM cache choice. The audit variant disables preloading explicitly and
raises a dedicated stop after constructing both real source datasets, before
the native main reaches DataLoader, model, optimizer or output creation.

## Verified Evidence

- Seven CPU unit tests passed for real construction/cache, scoped restoration,
  boundary violations and the two-dataset interception point.
- Server native main accepted the original hash-pinned recipe arguments.
- Train: 10,326 samples, 35 sequences. Source Development: 2,806 samples,
  10 sequences. No empty samples were used by CORA.
- Recipe requests RAM caching; this audit intentionally uses metadata-only
  construction. Cached/uncached numerical parity is covered separately, not
  inferred from this test.
- No model or optimizer was created and no Locked Test data was read.

Report: `artifacts/pretraining_acceptance/NATIVE_SOURCE_PROFILE_BINDING_20260908.json`.
Audit: `scripts/audit_pretraining_native_source_binding.py`.
Binding: `src/agent_jsac/foundation_profile_binding.py`.

The report is dataset-entry evidence, not model reproduction. The Dispatcher
source-stage registration, full fresh-parent receipts and Qwen request-to-native
source execution still need integration acceptance. Overall readiness is NO_GO.
