# Weak Admission Artifact Binding

The Dispatcher, not the language model, supplies the pinned bundle path/hash and
the expected route, parent checkpoint, label files and fit/calibration sequences.
`authorize_bundle` verifies every file hash before evaluating the existing weak
evidence rules. It returns exact sequence roles for `run_admitted_route`.

Bundle fields:
- `route`, `baseline_id`: must match the native route context.
- `fit_sequences`, `calibration_sequences`: exact nonempty disjoint lists.
- `parent`: absolute checkpoint path and SHA256.
- `labels`: nonempty list of absolute label paths and SHA256 values.
- `evidence`: files whose digests are referenced by the metric receipts.
- `receipts`: pinned JSON list of existing weak evidence metric receipts.
- `threshold_profile`: pinned JSON threshold profile, using existing comparisons.

Each file binding contains exactly `path` and `sha256`. Receipt denominators must
belong to their declared role, not merely to the union of training episodes.
Development and Locked Test must not be used as expert admission roles.

The hash pin must be trusted independently of the bundle. Hash equality proves
identity, not correctness of measurements. The metric producer and its input
provenance still require validation. Merely changing a receipt's claimed pass
cannot override the deterministic threshold check.

Acceptance scope: six synthetic bundle tests, including end-to-end connection to
the native training interceptor. These are not actual weak-label quality results.
The production CLI/Dispatcher attachment and actual payload-to-loader binding
remain pending; do not treat this module alone as authorization for live training.
