# SE2 Lineage Safety Field Types

SE2 producer checkpoints and their run contracts must use JSON booleans for
all safety fields. Do not use strings, integers or null as boolean substitutes.

- `cora0_frozen`, `se1_frozen`, `zero_identity_initialization`,
  `adapter_only_trainable` and `stage_b_retrain_all_r11` must be exactly true.
- Forbidden-read flags and `model_future_frame_input` must be exactly false.
- `clip_length` must be integer 16, not a value that becomes 16 after truncation.

Previously Python truthiness accepted examples such as `cora0_frozen="false"`
and `locked_test_read=null`. Nine regression cases reproduced that defect and
now reject the malformed contracts. Valid nonlegacy Support partitions and
the accepted historical Stage-B field remain supported. Related local lineage,
SE2 receipt and teacher handoff tests: 51 passed.

This changes type validation only. It does not change training recipes, allowed
data, promotion metrics, current frozen model files or historical results.
Server revalidation passed in release `lineage_freeze_closure_20260909`:
1122 files verified, **585 tests passed in 23.69 seconds**, exit code 0.
Archive SHA256:
`6ef956e5e3cbf414d248221ff38e2ebb3492989780f31faa31923efaa88ae92d`.
The first candidate package omitted a branch-freeze script needed by a test;
that package failed and was not accepted. The corrected package includes it.

The existing registered SE2 checkpoint was read on CPU after verifying SHA256
`64d504368ea19aa66f735e5965ee17b183f2905e1c82a06e717945de30d33893`.
Its metadata passed the typed contract without changing the file. Evidence:
`artifacts/pretraining_acceptance/SE2_TYPED_CONTRACT_REFERENCE_CHECK_20260909.json`.
No model forward, optimizer, dataset iteration or Test read occurred.
This proves compatibility with that reference checkpoint, not fresh training.
