# Original branch17a DAG preparation

This package contains a prepare-only binding for the single historical
identity `branch_persistence_selector`. It does not authorize production
training, retrieve an expert, or execute a historical script.

## Exact source pair

The binding verifies these local recovered files by bytes before compiling a
command:

| Role | Local path | SHA256 |
| --- | --- | --- |
| model | `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/branch_router_recipe.py` | `ce03fb4adc45a310dfadc1ca0d783cbb0b289a797a338cf32d32c645b5f18738` |
| trainer | `reproduction/reference_sources/server_gble_recorded_training_20260910/train_branch_router_recipe.py` | `17a615649e5bf53049b8ff6815678e0643bb3e425d2d671779001d0ce81549a6` |
| runtime | `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/se_branch_route_runtime.py` | `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3` |
| prediction-freeze helper | `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/branch_prediction_freeze.py` | `0ea4664f8cf9c3b8a359d248a1de56384db12c6839cb6dfa0c4c60d2c5bdd437` |

The pair is selected from
`artifacts/pretraining_acceptance/EXPERT_SOURCE_COVERAGE_WITH_LEGACY_HINTS_20260910.json`
(`68b454f7ffb23d956f7a8db082c4ae525209fd9f84729e96bd7891343333ecc6`). The
coverage row must have exactly one matching pair, `missing_roles: []`, and the
recorded historical receipt reference. The trainer and model are recovered
from different source roots; the recovery directory is provenance, not a
standalone executable project.

The current library row is also pinned: implementation
`branch_persistence_selector_v1`, primitive `branch_persistence_selector`,
route `indoor_clutter`, historical parent `route_selected`, and entrypoint
`scripts/route_experts/branch_persistence_selector.py` with SHA256
`22adc9a8d10272eb489fb933cee3a73beb330b4842a465c1938e1e94b084895d`.

## API

```python
from agent_jsac.original_branch_dag_preparation import (
    compile_original_branch_cli,
    validate_branch_training_receipt,
)

compiled = compile_original_branch_cli(
    project_root,
    "branch_persistence_selector",
    current_preparation_context,
    branch_prediction_root=prediction_root,
    python_executable=None,
)

validated = validate_branch_training_receipt(
    receipt,
    binding=compiled.binding,
    context=current_preparation_context,
    branch_prediction_root=prediction_root,
)
```

`compiled` has the existing `CompiledOriginalCLI` shape: `binding`,
`command`, `cli_contract`, `receipt_contract`, and `audit`. The command is an
exact rendering of the pinned trainer parser. It is returned as data only.

## Original CLI contract

The command includes the parser's exact flags, in source order:

```text
--candidate-id --route --primitive --implementation-id --parent-branch
--parent-selection-sha256 --parent-selection-policy-id --target-fit-root
--source-replay-root --branch-prediction-root --empty-guard-manifest
--output-dir --epochs --calibration-fraction --oof-folds
--source-replay-weight --seed --device
```

The pinned defaults are `epochs=80`, `calibration-fraction=0.25`,
`oof-folds=3`, `source-replay-weight=0.35`, `seed=3407`, and `device=cuda`.
The current context may override only the device value. The parent-selection
SHA must come from the current validated context, and the policy is the
source-pinned `support-confirmation-relative-safety-v2`. A supplied context
policy must match it. No `production-trainer-family` flag is added.

The model source is AST-checked, without import, for
`CausalBranchRouter(input_dim=18, hidden_dim=48)` and branch order
`cora0, cora_se1, cora_se2`. The original loss is represented as the recorded
contract `weighted branch cross-entropy + 0.01 temporal smoothness`; no new
network or loss is constructed.

The helper reuses the c3 pure `CurrentPreparationContext` coercion and
current-context validators for task, parent lineage, separated target/source
roots, runtime manifests, EmptyGuard, and disjoint sequence roles. The
branch-specific prediction-freeze checks are local to this helper because the
branch trainer requires the additional freeze root and grouped OOF contract.

## Prediction freeze and receipt

`PREDICTION_FREEZE.json` must declare exactly `cora0`, `cora_se1`, and
`cora_se2` prediction files, relative paths, SHA256 values, and checkpoint
lineage hashes. Forbidden read and authorization fields must be false. The
helper hashes and parses this JSON manifest only; it does not open any NPZ
member or prediction payload.

The producer receipt schema is
`agent_jsac_branch_router_training_receipt_v1`. Validation requires grouped
OOF calibration (`sequence_grouped_out_of_fold`, three folds), source replay
role `source_retention_training_replay`, exact current runtime-manifest
hashes, exact EmptyGuard hash, exact model/trainer implementation hashes,
zero execution weight, and a checkpoint path under the output directory.
The checkpoint path and SHA are declarations only: the checkpoint is not
opened or hashed by this prepare-only validator.

Every successful result remains non-authorizing. Any identity, source hash,
parent, label/read, freeze, role, or receipt mismatch fails closed. Codebook
retrieval and execution are outside this branch recipe and remain blocked.

## Verification

```powershell
$env:PYTHONPATH = 'H:\Project\AGENT-JSAC\src;H:\Project\AGENT-JSAC\tests'
& 'D:/anaconda3/envs/vlm3b/python.exe' -m pytest -q tests/test_original_branch_dag_preparation.py
```

The focused suite uses only temporary JSON manifests and no training data,
NPZ payload, checkpoint, Locked Test, or historical trainer execution.
