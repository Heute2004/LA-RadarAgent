# Original Graph DAG Preparation

This helper covers exactly three Aug31 Human graph identities:

| expert ID | implementation | model spec | route | production trainer family |
| --- | --- | --- | --- | --- |
| `candidate_survival_graph` | `candidate_survival_graph_v1` | `survival:gru:survival:delta` | `outdoor_dry_complex` | `branch_stability_router` |
| `multi_hypothesis_path` | `multi_hypothesis_path_v1` | `path:tail:uncertainty:cartesian` | `outdoor_dry_complex` | `branch_stability_router` |
| `tcbav_temporal_candidate_graph` | `candidate_graph_temporal_v1` | `graph:gru:innovation:delta` | `indoor_clutter` | `selective_candidate_composite` |

Resolution is by the explicit `expert_id` table. The helper also verifies the
current Human library and the exact Aug31 source-coverage row; it does not
infer an implementation from a name.

## Exact Source Closure

All recovered source files are under `reproduction/reference_sources`:

- model: `agent_expert_runtime_contracts/src/agent_jsac/registered_route_expert_models.py`
  SHA256 `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`
- trainer: `server_registered_training_exact_20260829/train_se_branch_route_expert_recorded_aug31.py`
  SHA256 `55c7a9a59fec705f11fc474f9c7ab979545a28212942a7a93206be19d8a6f51f`
- runtime: `agent_expert_runtime_contracts/src/agent_jsac/se_branch_route_runtime.py`
  SHA256 `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3`

The library pin is
`tasks/human/experts/library.json` SHA256
`5c0fac53e5a1801803eb2c54e7346d6633019f0ae12976e9693a154b40ca5a7b`.
The coverage pin is
`artifacts/pretraining_acceptance/EXPERT_EXACT_SOURCE_COVERAGE_AUG31_RECOVERY_20260910.json`
SHA256
`fb883b00c5ad760e8ac621768a27f84e8e14f36a912cc96387729bdb949a144e`.
Each selected coverage pair must have no missing roles and must name the
pinned model and trainer files.

The model `_spec` declarations and trainer parser are read with AST only.
The helper reuses the c3 context and receipt validators where the runtime and
`receipt_v2` ABI is identical. It does not import the recovered model or
trainer, open a checkpoint, read Test/model payloads, create an optimizer, or
start training.

## API

```python
compile_original_graph_cli(root, expert_id, context, python_executable=None)
```

The result has the same compiled shape as the c3 helper:
`binding`, `command`, `cli_contract`, `receipt_contract`, and `audit`.
The rendered command includes the real Aug31 flags and defaults: 24 epochs,
hidden dimension 64, learning rate `3e-4`, weight decay `1e-4`, source replay
weight `0.35`, calibration fraction `0.25`, harm budget `0.02`, seed `3407`,
and the context device. The required
`--production-trainer-family`, `--parent-selection-sha256`, and
`--parent-selection-policy-id` arguments are rendered from the bound current
context, because the recovered trainer treats these routes as direct routes.

The returned `cli_contract.environment.PYTHONPATH` explicitly lists the
recovered model/runtime `src`, the isolated trainer root, and the project
`src` fallback, in that order. The command is only compiled; the caller must
make any later execution decision outside this helper.

```python
validate_original_graph_training_receipt(receipt, binding=binding, context=context)
```

The validator requires
`agent_jsac_se_branch_route_expert_training_receipt_v2`, exact graph identity,
the production family, current parent-selection hash/policy, the library
application contract, disjoint fit/calibration/source sequence roles, exact
runtime manifest hashes, exact model/trainer implementation hashes, the
24/64 calibration defaults, and a zero execution weight. The declared
checkpoint path and SHA256 are checked as receipt fields only; checkpoint
bytes are not opened.

## Verification

The red baseline was collection failure because the new helper did not yet
exist. After implementation, the scoped synthetic suite passed:

```text
17 passed in 2.76s
```

The tests use only temporary runtime manifests, an EmptyGuard manifest, and a
synthetic receipt dictionary. No trainer subprocess, model import, optimizer,
checkpoint, Test payload, or training data is used.
