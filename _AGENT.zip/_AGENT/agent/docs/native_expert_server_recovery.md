# Native Expert Server Recovery

## Scope

Recovered original server code, without changing expert names or structures.
This is source recovery and import validation, not training acceptance or proof
that every catalog entry has the intended architecture.

## Source and Integrity

Server project: `/home/hyc/radar+ris/JSAC-AGENT-V4`.

Archive: `artifacts/pretraining_acceptance/NATIVE_EXPERT_TRAINERS_SOURCE_CLOSURE_20260909.zip`.

SHA256: `57b05cd2fdb0c338570ffaa09eda44d87f76e827fa3a9985c6b8f50d947a5a17`.

The archive contains eight Python files and a collection manifest. Every Python
member passed AST parsing and its manifest hash check. Six dependencies exactly
matched the existing reproduction copy; only these missing files were added:

- `reproduction/sources/JSAC-AGENT-V4/scripts/train_cora_se2_clean_clor.py`
- `reproduction/sources/JSAC-AGENT-V4/scripts/train_cora_se2_route_specialists.py`

Both restored entrypoints successfully executed `--help` with CUDA disabled and
the reproduction source directory on PYTHONPATH. No optimizer, dataset reader,
checkpoint loader or training job was invoked by this check.

## Remaining Acceptance

Synthetic CPU behavior checks were added in
`tests/test_recovered_native_models.py`: nine local checks passed. They cover
CLOR, TECS, GBLE, PathAssociation, candidate-space GG-SRRE and LTGE. Nonzero
heads are used for prefix-causality checks, so zero initialization cannot hide
future leakage. CLOR's initial proposal is identity but acceptance is 0.5,
not zero. LTGE's evidence head is audit-only: changing it does not change
candidate logits or acceptance. These checks do not validate training quality,
all input-corruption cases, or all 42 intended semantic architectures.

The original trainers retain their historical route and protocol assumptions.
They are not yet portable production bindings for all 42 semantic entries.
Do not bypass archive-only guards merely because imports now succeed.

Next verify model-specific forward contracts and trace each catalog binding to
its original implementation. Preserve the distinction between continuous offset
refinement and discrete physical-candidate selection. Verify training label,
parent checkpoint, calibration and canary contracts before enabling execution.

Weights, predictions and datasets were not included or opened. Locked Test
remains unopened. No expert performance or promotion is claimed here.
