# Native Parent Handoff Contract

## Normal Fresh-Lineage Handoff

The existing lifecycle Dispatcher validates an upstream result before observing
or buffering the downstream candidate. It must satisfy all of the following:

1. The canonical result digest verifies.
2. Run ID and protocol digest match the destination run.
3. Candidate and tool producer identities are present.
4. Status is `internal_stage_qualified` or `promoted`, not merely `trained`.
5. If the request names a parent candidate, the returned identity matches it.
6. The checkpoint exists and its content matches the declared SHA256.
7. The checkpoint reference does not violate the destination forbidden scope.

The sealed Support buffer retains the upstream result digest, producer tool ID,
producer candidate ID, checkpoint path and checkpoint digest. Invalid handoffs
must leave the child absent from lifecycle state; no trainer or optimizer runs.
The downstream runner still rechecks checkpoint contents at command rendering.

## Explicit Reuse of Qualified Internal Stages

This is a distinct operator-selected mode, exposed through the existing
`--qualified-stage-result` CLI option. It does not permit historical experts.
The imported receipt must be a verified, accepted internal stage with zero
execution weight, no runtime eligibility, passing harm budget and the required
forbidden-read attestations.

`QualifiedStageProvider` revalidates the receipt and checkpoint at construction
and on each request. With a destination run/protocol binding, it creates a
separate explicit-import envelope. The original receipt remains unchanged and
is preserved inside that envelope. The envelope states `fresh_stage_training=false`.
The Support buffer preserves original run, protocol and result digest.

These digests provide consistency and provenance, not cryptographic proof that
an untrusted party reported true scientific metrics. Promotion policy and the
independent evidence providers remain necessary.

## Preparation Evidence

The focused tests cover missing or altered result hashes, wrong run, wrong
protocol, missing or changed checkpoint files, requested-parent substitution,
unqualified parents, malformed nested import receipts, normal handoff and
explicit internal-stage reuse. Test checkpoints are marked fixture bytes and
are not trained models. None of these tests reports accuracy reproduction.

This check does not yet replace the final task-level dataset/model/threshold
profile binding or complete Human/UAV nested-Qwen acceptance. Those gates remain
separate and mandatory before unattended training is authorized.
