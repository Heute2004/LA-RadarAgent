# Train Label Observable Audit

Server audit processed 23 Train sequences and 3,602 positive-weight eligible
frames. Input manifest, protocol, split and each archive were hash checked.
No target reference positions or Test sensor data were loaded.

Evidence: `artifacts/pretraining_acceptance/TRAIN_LABEL_OBSERVABLES_20260909.json`.

| Native route | Accepted | Coverage | Selected candidate support | Mean bidirectional agreement | Adjacent reachability |
|---|---:|---:|---:|---:|---:|
| clean | 338 | 56.33% | 99.41% | 93.53% | 97.89% |
| cluttered | 1372 | 45.93% | 99.71% | 82.52% | 96.29% |
| cluttered_or_multipath_likely | 790 | 52.67% | 99.49% | 91.48% | 92.08% |
| rain_or_wet_ground | 1102 | 61.22% | 99.73% | 90.32% | 90.44% |

Coverage uses radar-training-valid frames as denominator. Acceptance means
positive sample weight AND a valid radar training frame. Selected-candidate
support tests index validity and coordinate agreement with that candidate
(atol=1e-6). This is a representative-point check, not a verification of every
allowed member of a set-valued label, and certainly not reference accuracy.
Bidirectional agreement is the saved scalar averaged over accepted frames.
Reachability uses only consecutive accepted frame pairs within the same
sequence, with the pinned 0.3 m adjacent-step bound; gaps are not bridged.
Empty denominators produce null, never an artificial perfect score.

These are descriptive outputs, not approval receipts. The currently recovered
live threshold profile remains a template. Native tier thresholds operate
per frame and must not silently become route-level mean thresholds. Historical
Hit@0.30 admission uses reference labels and cannot be replaced with the rates
above. Current expert admission remains unapproved until the intended
method-specific threshold and evidence contract is resolved.

The clean-route numbers are a label-construction audit only. They do not
authorize replacing the native source-supervised clean expert recipe with
target weak labels. Set-valued support and point representation should be
audited separately before interpreting the small support mismatch count.

## Set-valued follow-up

`TRAIN_SET_LABEL_OBSERVABLES_20260909.json` checks all positive allowed-weight
members. All 3,602 accepted frames have nonempty sets with finite, valid physical
members. No invalid or empty accepted set was found. Adjacent feasible set pairs:

| Native route | Feasible pairs / adjacent accepted pairs |
|---|---:|
| clean | 189 / 190 |
| cluttered | 779 / 782 |
| cluttered_or_multipath_likely | 379 / 379 |
| rain_or_wet_ground | 700 / 701 |

Native Tier-B selection can retain a legal set even when the MAP action is
identity and its representative coordinate is absent. Thus the earlier point
support values must not reject those sets. Pairwise feasible connections do
not prove a single globally feasible sequence; they may involve different
members at consecutive edges. No thresholds or training permissions changed.

## Native expert consumption

`NATIVE_EXPERT_SET_CONSUMPTION_20260909.json` replays the native attachment onto
the rebuilt 97-candidate bank (identity plus physical candidates). All 23
archives match the original attachment, including normalization and sample
weights. 2,241 frames retain multiple physical members. Uniform-logit forward
loss after explicit identity separation is finite for every sequence. There
was no backward pass, optimizer or model training.

Important: the original `episode_loss` defaults to `association_mode=joint`.
`physical_only` is an explicit alternative, not the default. The first report
tests the latter helper directly, not the full episode loss or default mode.
The separate `NATIVE_EXPERT_JOINT_SET_CONSUMPTION_20260909.json` now records
both uniform-logit losses for all 23 sequences on the server. Both are finite,
and attachment matches in every sequence. This remains a loss-forward audit,
not a trained-model or full episode-loss quality result. Production interception
must record the actual association mode before claiming recipe equality.
