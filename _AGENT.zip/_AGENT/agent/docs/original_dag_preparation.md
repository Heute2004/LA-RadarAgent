# Original c3 DAG Preparation

## Scope

The admitted offline-calibration origin
`sealed_RadarCandidateSet_with_offline_calibrated_depth_lineage` is supported
without renaming it. The pinned runtime already defines `calibrated_depth_lineage`
and writes `offline_calibrated_depth_lineage` into its manifest. For this target
Fit origin the compiler requires `used=true`,
`role=soft_range_likelihood_for_existing_candidate_reordering`,
`free_coordinate_generation=false`, and
`raw_depth_reopened_in_this_runtime=false`. All existing forbidden-read checks
still apply. This consumes sealed candidate provenance, not raw depth, new
coordinates, or target human truth. Missing/contradictory lineage is rejected.
The earlier compiler-only allow-list omission was an integration bug, not a
reason to rewrite historical labels or change the original trainer ABI.

`src/agent_jsac/original_dag_preparation.py` is a prepare-only binding for the
explicit c3 Human candidate IDs. It does not alter the dispatcher,
native production registry, `FORBIDDEN_GENERIC_TRAINERS`, configs, or any
training switch. It never imports or executes a trainer, creates an optimizer,
opens a checkpoint, writes a model, or claims numerical reproduction.

The current c3 source pair is fixed as follows:

| role | source namespace | relative source | SHA256 |
|---|---|---|---|
| model | `server_registered_training_dependency_closure_20260910` | `src/agent_jsac/registered_route_expert_models.py` | `3b379ea9955f23183b38b4368a096836f0cc50667943993ae58156e9a81ea9b8` |
| trainer | `server_registered_training_dependency_closure_20260910` | `scripts/train_se_branch_route_expert.py` | `c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70` |
| runtime | `server_registered_training_dependency_closure_20260910` | `src/agent_jsac/se_branch_route_runtime.py` | `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3` |

The source-coverage evidence is
`artifacts/pretraining_acceptance/EXPERT_EXACT_SOURCE_COVERAGE_20260910.json`
with SHA256
`4260f9f51d6dc6f454577a8cec59f7935e49f7935b3926ffd2ba23375f461011`.
Only the coverage row whose model and trainer hashes match the c3 pair and
whose missing-role list is empty is accepted. Its recorded receipt paths are
retained as historical provenance; they are not followed as local files.

The binding key is:

```text
expert_id|source_root|model=<sha256>|trainer=<sha256>|runtime=<sha256>
```

This prevents a same-name implementation from another source namespace from
being silently substituted. The original library's `parent_branch` is
`route_selected`; the compiled c3 CLI instead receives the current selected
CORA branch from the current-run binding. These are different contracts and
are intentionally not conflated.

`C3_CANDIDATE_IDS` remains the original fourteen-row historical-candidate
table. `C3_EXACT_CANDIDATE_IDS` is the explicit 31-ID c3 extension accepted by
this module. The extension is admitted only when the hash-pinned coverage row
has the c3 model/trainer pair, `missing_roles=[]`, a nonempty recorded receipt
set, the same `implementation_id` as Human `library.json`, and a literal
matching `_SPECS` entry in the pinned model source. It is not name-based
variant generation. The 17 IDs added beyond the original fourteen are:

```text
tecs_candidate_attention, dual_domain_set_mixer, echo_extent_disambiguator,
ltge_path_integrator, track_before_detect, range_conditioned_tcn,
mti_agreement_rescuer, selective_branch_recovery, weather_risk_selector,
state_consistent_local_refiner, local_shape_consensus,
causal_tracklet_consensus, adaptive_threshold_tracklet,
evidence_hysteresis_selector, angular_consistency_associator,
gble_branch_linker, gg_srre_recovery
```

`gble_branch_linker` and `gg_srre_recovery` are included only because their
own coverage rows prove this exact c3 pair; no graph, branch, RIS, or wet
family ABI is generalized from their names. The 26 identities outside the
original fourteen therefore split into these 17 c3 exact bindings and the
following nine separate pair contracts, which remain unbound here:

```text
branch_persistence_selector, candidate_survival_graph, multi_hypothesis_path,
ris_temporal_gate_h32, risecho_codebook_consensus, risecho_dual_path_mixture,
risecho_dual_stream_stability, risecho_path_integrator,
tcbav_temporal_candidate_graph
```

## Current-Run Profile

`CurrentPreparationContext` can be passed as the dataclass or as a mapping with
these required fields:

```json
{
  "task": "human",
  "candidate_id": "<current candidate id>",
  "parent_branch": "cora0|cora_se1|cora_se2",
  "target_fit_root": "<directory>",
  "source_replay_root": "<directory>",
  "empty_guard_manifest": "<file>",
  "output_dir": "<not-yet-created directory>",
  "parent_selection": {
    "selected_parent_branch": "<same parent_branch>",
    "selected_parent_checkpoint_sha256": "<sha256>",
    "support_scope_sha256": "<sha256>",
    "parent_selection_sha256": "<sha256>",
    "decision_replayed": true,
    "metric_measurements_recomputed": false,
    "training_authorized": false
  },
  "device": "cpu|cuda"
}
```

The main dispatcher may obtain `target-fit-root`, `source-replay-root`,
`empty-guard-manifest`, `output-dir`, `parent-branch`, and `candidate-id` from
its existing argv/report binding. The parent-selection receipt is an upstream
input to `_validate_historical_candidate_report`; this helper consumes the
validated `report["parent_selection_check"]` mapping shown above, not the raw
receipt path. That mapping is the expected integration schema and matches the
synthetic fixture.

Optional `target_fit_manifest` and `source_replay_manifest` override the
`ROUTE_RUNTIME_MANIFEST.json` under each root. Both manifests must use
`agent_jsac_se_branch_route_runtime_manifest_v1`, match the bound route, have
roles `fit` and `source_replay`, carry the same current parent lineage, use the
five radar-only runtime inputs, declare
`SourceBEV_replay_or_sealed_RadarCandidateSet`, and mark every protected read
false. Record sequences must be unique, hash-shaped, and disjoint between the
two roles. The target receipt fit/calibration union must equal the target
manifest; source replay sequences must equal the source manifest.

The EmptyGuard must be an
`agent_jsac_empty_guard_audit_v1` projection frozen before query, with a
hash-pinned Sentinel source audit, `metric_recomputed=false`, and false
`locked_test_read`, `final_bev_read`, and `target_human_label_read` fields.

## Exact c3 CLI

```python
from agent_jsac.original_dag_preparation import compile_original_cli

compiled = compile_original_cli(
    project_root,
    expert_id="polar_bev_cross_refiner",
    context=current_preparation_context,
    python_executable="D:/anaconda3/envs/vlm3b/python.exe",
)
```

The command is the pinned c3 trainer with these semantic inputs:

```text
--candidate-id --route --primitive --implementation-id --parent-branch
--target-fit-root --source-replay-root --empty-guard-manifest --output-dir
```

The source parser defaults are rendered explicitly: `epochs=24`,
`hidden-dim=64`, `learning-rate=0.0003`, `weight-decay=0.0001`,
`source-replay-weight=0.35`, `calibration-fraction=0.25`,
`calibration-harm-budget=0.02`, `seed=3407`, and the context's `device`.
The c3 command deliberately does **not** add
`--production-trainer-family`, parent-selection flags, `--prepare-only`, or
any current-tree ABI. The helper AST-checks that the pinned parser still has
exactly this option set and these defaults.

## Producer Receipt Contract

The producer schema is the original
`agent_jsac_se_branch_route_expert_training_receipt_v2`. Required fields are
the identity, fit/calibration/source sequence lists, three original read
flags, calibration/selection fields, checkpoint path and SHA, zero
`execution_weight`, EmptyGuard path/SHA, target/source runtime manifest
path/SHA pairs, model/trainer `implementation_files`, and `history`.

Receipt validation checks the current candidate ID, route, primitive,
implementation ID, registered architecture signature, current parent branch,
role-separated sequences, manifest hashes, EmptyGuard hash, and model/trainer
source hashes. It does not require the fresh checkpoint bytes to exist, so
absence of a fresh model remains the explicitly prohibited-training boundary,
not a false failure of source preparation. If a producer includes an optional
runtime implementation hash, it must equal the c3 runtime pin. The original
producer does not emit that runtime source field; the helper-side source-pair
binding carries it explicitly.

Every successful result reports `executed=false`, `training_started=false`,
`checkpoint_loaded=false`, `training_authorized=false`,
`production_admission=false`, and `numerical_reproduction_verified=false`.
Wrong parent, protected-label/read flags, model/trainer hash, source root,
task, runtime role, or cross-role sequence membership fails closed.

## Verification

Run the focused synthetic suite with the requested environment:

```powershell
$env:PYTHONPATH='H:\Project\AGENT-JSAC\src;H:\Project\AGENT-JSAC\tests'
& 'D:/anaconda3/envs/vlm3b/python.exe' -m pytest -q tests/test_original_dag_preparation.py
```

Current result: `55 passed` in the focused suite. The fixture is synthetic
JSON only and does not read Locked Test data or execute a training command.

## Coverage Boundary

The helper binds 31 exact c3 identities under one ABI because the model,
trainer, and runtime source hashes are identical and the trainer parser and
receipt schema are AST-checked. It does not bind the nine separate pair
contracts listed above. Fresh checkpoint bytes are intentionally not required
for prepare-only validation because real training is prohibited; a validated
receipt declares the checkpoint and its hash without opening it. No result is
promotable or a numerical reproduction claim.
