# Human Runtime Parent Provenance

## Observed gap

The historical route-runtime exporter loads SE1 directly and loads SE2 using
CORA0, SE1 and SE2 checkpoint arguments. Its manifest records only the SE2
checkpoint digest. Episode `base_branch` identifies a branch, not the checkpoint
bytes that produced its features and coordinates.

The inspected 23-sequence Train runtime manifest contains the SE2 digest
`64d504368ea19aa66f735e5965ee17b183f2905e1c82a06e717945de30d33893`
but no CORA0/SE1 digest. This observation does not establish that its parents
were wrong; it means the manifest alone is insufficient to prove all parents.

## Scoped repair

`scripts/build_bound_route_runtime.py` was copied from the preserved native
exporter. Candidate extraction, support attachment, normalization and inference
are unchanged. It adds:

1. Absolute-path and existence checks for CORA0, SE1 and SE2.
2. A three-parent path/SHA256 snapshot before model loading.
3. Rehashing after export; changed parents prevent completion of the manifest.
4. The complete `parent_checkpoints` map in the output manifest.

The historical script and runtime archives were not overwritten. Existing
archives must not be assigned guessed parent metadata retroactively.

## Verification and limits

The two new tests verify the actual snapshot helper with temporary parent files
and missing/changed parents. The server selection also includes native route
interception and admission bundle tests: 19 passed. These tests did not run the
full radar export and do not prove a completed cache's numerical provenance.

This native family still selects SE1 for `clean` and SE2 for other routes. It is
not a general implementation of best-parent routing, and must not override the
Agent's per-route parent decision. A route-specific parent mismatch must remain
a failure until an explicit compatible exporter is selected.

## Admission integration follow-up

The admission bundle and native trainer now require the same pinned runtime
manifest, complete parent map, branch dependencies and per-sequence cache hash.
The trainer rechecks these bindings before and after its native episode loader.
Missing legacy metadata is rejected, not silently inferred from a branch name.
The selected local and server regression suites both passed 27 tests, including
changed parents, wrong selected branches, missing receipts and mismatched labels.
These are interception tests, not numerical reproduction of trained experts.

The original execution plan records all three parent arguments and digests.
However, the inspected DAG state marks the runtime job as completed through
`reused_existing_fresh_output`, based on a sentinel manifest. That state alone
does not prove the checkpoint bytes used to generate the reused cache. Neither
the historical cache nor its manifest has been amended using that inference.

Remaining: recover stronger legacy producer evidence where available, complete
the production Dispatcher command binding, and exercise the complete Human path
under training interception. Additions to this candidate release are not yet a
sealed training-ready package. No model training or Locked Test access occurred.
