# Native Portable Stage Binding

`ProspectiveToolRunner` accepts a Dataset Profile path, SHA256 and explicit
environment mapping. Both path and digest are required together. At command
construction it re-resolves the profile, verifies its metadata and adapter
digests and compares the native data root against the profile data root.

For candidate-confirmation training, the stage-B pool must exactly match the
profile `adaptation_fit` membership. Stage A splits this same pool into fitting
and internal calibration. It does not borrow the external profile calibration
set. An explicitly nonempty independent canary must be drawn from the declared
`adaptation_calibration` set and remain disjoint from training. An empty canary
is reported as unavailable, not a successful safety test.

These checks execute before command return, output-directory creation, nonce
claiming and subprocess launch. Changed profile files are rejected on each use.
Unimplemented native stages reject profile-bound dispatch rather than claiming
portable compatibility. Existing reference runners without a profile retain
their historical behavior; they are not approved portable production runners.

Current scope: candidate-confirmation command membership and data-root binding.
Still required: native source/Sentinel/anchor/expert adapters, model-profile
binding, stage receipts and complete real-Qwen lifecycle integration. Passing
this check does not enable training or waive these remaining gates.
