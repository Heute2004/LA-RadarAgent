# UAV Measurement-Bound Real Qwen Acceptance

## Result

The server executed the existing Qwen2.5-0.5B model and previously verified LoRA
with the assembled `uav_measurement_admitted_20260910` candidate. No local GPU
was used and no sensing optimizer/training process was started.

| Case | Outcome | Memory restores | Teacher compilations | Adaptation compilations |
|---|---|---:|---:|---:|
| Valid reference fixture | monitor_reached | 12 | 1 | 1 |
| Changed label hash | rollback_executed | 10 | 0 | 1 |
| Changed teacher hash | rollback_executed | 8 | 1 | 0 |

The normal run visited preflight, commissioning, observation, diagnosis, memory
retrieval, support buffering, weak evidence, branch selection, shadow training,
candidate audit, zero-weight canary, and simulated promotion before monitoring.
All receipts remain `SIMULATED_NOT_PROMOTABLE`. Qwen uses the existing constrained
choice scorer; this does not demonstrate unrestricted planning or code writing.

## Actual data checks

Each of the weak-evidence and shadow-training requests independently verified
36,000 files against the same inventory, after checking current method,
manifest, parent, role membership and report identity. Inventory SHA256:
`628b95a81d8a12f34912f364759c3c13bbef7e0e6d972412f45bdb597dc6c517`.

Teacher profile SHA256:
`779b728ec6ac5c6faa0fe03c246500f2a4f4f7d8b0e6054a0f85fd3c9c1fb1a0`.
Snapshot report SHA256:
`ec0a2ede0cf9febe818db70142073ae62569f4a1ad12fdf5787beb3b3224b019`.

The new fixture explicitly repackages the pinned reference U0 predictions and
historical label CSV. It does not claim new source training or labels generated
by a newly executed teacher. No old run was overwritten or assigned a new ID.

## Reproduction and evidence

- Preparation: `scripts/prepare_uav_measurement_qwen_fixture.py`, reusing the
  existing reference-cache, teacher-command and teacher-handoff utilities.
- Measurement snapshot: `scripts/audit_uav_teacher_measurements.py`.
- Qwen runner: `scripts/check_pretraining_qwen_uav_native.py`, with all four
  measurement path/hash arguments and without the reference-only bypass.
- Server fixture: `artifacts/UAV_MEASUREMENT_QWEN_FIXTURE_20260910`.
- Server result: `artifacts/QWEN_UAV_MEASUREMENT_BOUND_20260910`.
- Local summary: `artifacts/pretraining_acceptance/QWEN_UAV_MEASUREMENT_BOUND_20260910_SUMMARY.json`.
- Local normal-case detail: `artifacts/pretraining_acceptance/QWEN_UAV_MEASUREMENT_BOUND_20260910_VALID.json`.

## Not established

Fresh source-training receipt/cache production, actual native teacher fitting,
numerical reproduction and original ADC-to-DSP provenance are not demonstrated
by this run. The content gate is point-in-time, not an immutable file lease.
Missing/modified snapshot behavior was subsequently exercised with real Qwen
using independent reference fixtures in
`artifacts/UAV_ISOLATED_FAULT_ACCEPTANCE_20260910`. The server summary and both
underlying failure reports were independently reread on September 10:

- Valid fixture: `monitor_reached`, 12 restores, one teacher and one adaptation
  compilation.
- Missing snapshot: `rollback_executed`, 8 restores, zero adaptation
  compilations; the native error names `MISSING_MEASUREMENT_REPORT.json`.
- Modified snapshot hash: `rollback_executed`, 8 restores, zero adaptation
  compilations; native error `measurement report hash mismatch`.

All three cases passed their intended checks. Local evidence is
`artifacts/pretraining_acceptance/UAV_ISOLATED_FAULT_SUMMARY_20260910.json`.
These are completed reference-backed behavior tests, not a fresh training run.
Human original-40 implementation bindings and final independent packaging are
still unfinished. Locked Test remains closed.
