# UAV native teacher read boundaries

The no-training regression invokes the native role filters and loader entry
points rather than trusting report booleans. It replaces truth loading with
a recorder/interruption and uses synthetic metadata and tiny source arrays.
No real truth, measurement payload, estimator fit or optimizer is invoked.

Verified boundaries:

- Candidate records may request truth only for `source_supervised_train` and
  `source_development`; target/support/query roles are skipped before that call.
- Motion-envelope calibration requests truth only for source training.
- Target application selects `support_train`, not support validation or query.
- A manifest containing `locked_test_query` is rejected by target application.
- The target CLI rejects `--truth-root`, even when required arguments are present.

This proves these native control-flow boundaries, not all filesystem reads of
a future run or successful fresh teacher generation. Keep the fresh cache,
measurement/Doppler and parent receipt checks separate. Existing reference
teacher simulations remain explicitly non-promotable.
