# Native Route Scope and Dependency Failure

Date: 2026-09-10. Human preparation only.

## Native route names are not the current six-route taxonomy

The recovered `route_specialists_se2_cache.py` has this actual ledger mapping:

| Ledger condition | Historical native route |
|---|---|
| open_indoor | clean |
| cluttered_indoor | cluttered |
| open_outdoor or complex_outdoor, dry | cluttered_or_multipath_likely |
| open_outdoor or complex_outdoor, wet_after_rain | wet_ground |
| other outdoor weather | rain_or_wet_ground |

Its native factory in `train_cora_se2_route_specialists.py` maps:
`cluttered -> TECSSE2Expert`, `cluttered_or_multipath_likely -> GBLESE2Expert`,
`rain_or_wet_ground -> GGSRRECandidateSE2Expert`, `wet_ground -> LTGESE2Expert`.
The historical `wet_ground` training cache is deliberately shared with
`rain_or_wet_ground`.

Consequently, an expert called LTGE cannot simply be attached to the current
open-outdoor-weak-return route by name and called a faithful route migration.
Original architecture recovery, current route membership, allowed supervision
and selected parent are separate contracts. A portable dataset adapter must
declare membership explicitly; it must not infer it from a model class name.

The existing private loader already uses the pinned original factory, not a
renamed registered scorer. This audit does not grant new semantic binding or
authorize importing historical expert checkpoints. GG-SRRE remains pending full
production admission; its candidate gain target is not automatically equivalent
to the separate continuous-ROI expected-improvement loss.

## Fixed request-time failure handling

`ProfiledSpecialistBackend.execute` previously allowed ModuleNotFoundError,
ImportError and RuntimeError from native preparation to escape without a failed
tool receipt. Three synthetic tests reproduced this failure.

Those request-time exceptions now return passed=false, the error message and
`native_preflight_error_type`. Existing validation errors continue to fail closed.
No retry, alternate expert, training permission or successful result is fabricated.
The workflow may use its existing failure transition. KeyboardInterrupt and
unrelated exception classes are not blanket-swallowed.

This does not fix an absent Python interpreter or failures importing the Agent
package before Dispatcher starts; environment readiness remains a separate gate.
No fresh real-Qwen dependency-fault run is claimed here. Earlier real-Qwen
bad-profile/hash rollback runs and this unit-level dependency test have different
evidence scopes.

## Verification

- Local dependency/profile/CLOR/registered dispatch regression: 42 passed.
- Server dependency/profile/registered dispatch subset: 31 passed.
- Server release: `human_catalog_padding_audit_20260910`.
- Local XML: `artifacts/pretraining_acceptance/HUMAN_NATIVE_DEPENDENCY_20260910.xml`.

Only synthetic fixtures were used. No sensing training, weights, research
payloads or Test were read; no frozen outputs were modified.

## 中文记录

确认历史wet_ground不是当前空旷室外弱回波路线，不能只按LTGE名字接过去。
修复请求阶段原生依赖异常没有失败回执的问题；未宣称GG-SRRE生产绑定完成。
本地42项、服务器31项范围分别记录，整体goal仍未完成。
