# Human Profile Parent and Recipe Binding Repair

## Scope

This repair is limited to the read-only Human profile resolver and its
corresponding synthetic tests. It does not launch training, call an optimizer,
load a model or historical expert weight, or read a training payload.

The route schema requires `split_role_selectors`, `parent_stage`,
`supervision_recipe`, and `available_modalities` for every route in
`tasks/human/profiles/dataset_schema.json:31-39`.

## Reproduction Before Repair

Before changing the test or resolver, the existing test passed even though its
synthetic route omitted both `parent_stage` and `supervision_recipe`:

```text
PYTHONPATH=H:/Project/AGENT-JSAC;H:/Project/AGENT-JSAC/src;H:/Project/AGENT-JSAC/tests
D:/anaconda3/envs/vlm3b/python.exe -m pytest -q tests/test_portable_profile_preflight.py
.
1 passed in 0.34s
```

The defect was in the route loop at the former
`src/agent_jsac/portable_profile_preflight.py:51-63`: it consumed only split
selectors and modalities. Missing or arbitrary parent and recipe values were
therefore accepted.

After adding the focused missing-value and contract-outside-value tests, but
before the production edit, the expected red result was:

```text
1 passed, 4 failed in 0.29s
```

The four failures were the two missing-field cases and the two invalid-value
cases. No dataset payload or model artifact was involved in this reproduction.

## Repair

`portable_profile_preflight.py:9-71` now reads only the active control-plane
JSON contracts:

- `tasks/human/profiles/dataset_schema.json` supplies the route required fields.
- `tasks/human/supervision/method.json` supplies stage-graph stages and label
  recipe identifiers.
- `tasks/human/supervision/tools.json` supplies tool-intent stages and any
  tool-declared recipe identifiers.

The allowed values are derived from those contract contents at resolution time;
no dataset route or scene name is embedded in the resolver. At
`portable_profile_preflight.py:93-109`, every route is rejected if it is not an
object, lacks a schema-required field, has a non-contract `parent_stage`, or
has a non-contract `supervision_recipe`. This happens before resolving the
dataset root or sequence manifest.

The existing resolver return fields and read-only flags remain unchanged. The
adapter is still hash-checked without importing it, and the result continues
to report `training_started=False`, `mutation_authorized=False`, and
`payload_read=False`.

## Verification After Repair

Targeted synthetic tests, using contract-derived valid values:

```text
D:/anaconda3/envs/vlm3b/python.exe -m pytest -q tests/test_portable_profile_preflight.py
5 passed in 0.37s
```

The independent static contract cross-check also passed without modifying its
test file:

```text
D:/anaconda3/envs/vlm3b/python.exe -m pytest -q tests/test_human_stage_contract_crosscheck.py -k profile_resolver
1 passed, 11 deselected in 0.33s
```

The existing read-only profile adapter tests passed as well:

```text
D:/anaconda3/envs/vlm3b/python.exe -m pytest -q tests/test_profiled_foundation_adapter.py
5 passed in 2.34s
```

## Follow-up Review: Read Provenance

The first repair read the schema, method, and tool contracts to derive the
route checks, but its `read_inputs` receipt omitted those three files. That
left the control-plane reads without hash provenance.

The resolver now appends the absolute path, current `file_sha` digest, and
existing `kind=metadata` marker for all three contract files to `read_inputs`.
The return shape and existing flags are unchanged. The synthetic success test
also checks every returned input against its on-disk hash, including the three
contract files.

Post-review verification:

```text
D:/anaconda3/envs/vlm3b/python.exe -m pytest -q tests/test_portable_profile_preflight.py tests/test_profiled_foundation_adapter.py
10 passed in 2.71s
```
