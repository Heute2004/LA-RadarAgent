# Historical graph preparation

Date: 2026-09-10. This document describes the isolated preparation surface for
the two original registered graph experts. It prepares a fresh model in memory
and checks the original forward/loss contract; it does not train, save, load a
checkpoint, or claim a historical best result.

## New files

- `src/agent_jsac/historical_graph_preparation.py`
- `tests/test_historical_graph_preparation.py`
- `tests/test_graph_prepare_only_integration.py`
- `docs/historical_graph_preparation.md`

The graph-only production entry additions are limited to
`scripts/train_se_branch_route_expert.py` and
`src/agent_jsac/registered_expert_intercept.py`. The library registry,
recovered source files, `multi_hypothesis_path`, and all non-graph dispatch
entries remain unchanged.

## Exact source closure

`prepare_historical_graph_expert()` binds the current library row by every
target field and verifies the entrypoint hash. It then loads the following
recovered files by exact SHA256:

| role | path | SHA256 |
|---|---|---|
| model | `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/registered_route_expert_models.py` | `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486` |
| trainer loss source | `reproduction/reference_sources/server_registered_training_exact_20260829/train_se_branch_route_expert_recorded_aug31.py` | `55c7a9a59fec705f11fc474f9c7ab979545a28212942a7a93206be19d8a6f51f` |
| runtime validator | `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/se_branch_route_runtime.py` | `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3` |

The historical trainer is not imported as an executable module. The module
registers an AST closure containing exactly these trainer nodes:
`Episode`, `validate_generic_trainer_family`, `tensors`,
`intervention_required_from_allowed_set`, `acceptance_target_from_preference`,
`legal_set_mass`, `production_objective_terms`, and `episode_loss`.
Its explicit external closure is `torch`, `numpy`, `math`, and
`torch.nn.functional`. This keeps the original loss while excluding the
historical CLI, `AdamW`, scheduler, optimizer step, checkpoint writer, and
receipt writer.

## Native ABI

The recovered model is `RegisteredDiscreteCandidateExpert` with the original
configuration-specific `_GraphMixer`:

```text
tcbav_temporal_candidate_graph -> candidate_graph_temporal_v1
                                  graph:gru:innovation:delta
candidate_survival_graph        -> candidate_survival_graph_v1
                                  survival:gru:survival:delta
```

The forward contract is:

```text
candidate_feature [B,T,K,F]
candidate_xy_m    [B,T,K,2]
candidate_valid   [B,T,K]
       -> candidate_logits [B,T,K]
       -> acceptance      [B,T]
```

The acceptance output is a frame-level gate, not a per-candidate tensor. The
decoder remains identity-or-one-indexed-observed-candidate; it never emits a
mean or free coordinate. `feature_dim` is derived from the nativeSupport
`candidate_feature.shape[-1]`; `hidden_dim` defaults to 64 and must be at least
16. No temporal algorithm or reset behavior is added by this module.

## NativeSupport contract

The loader requires `ROUTE_RUNTIME_MANIFEST.json` with schema
`agent_jsac_se_branch_route_runtime_manifest_v1`, exact route/role, the five
historical runtime inputs, `SourceBEV_replay_or_sealed_RadarCandidateSet`
supervision, and all six forbidden-read flags set to false. Only `fit`,
`calibration`, and `source_replay` roles are allowed. `development`, `canary`,
and `locked_test` roles fail closed.

Each declared `seq_*.npz` member is SHA256-checked before `np.load(...,
allow_pickle=False)`, then validated by the recovered runtime validator. The
historical Episode fields and shapes are retained:

```text
candidate_xy_m       [frames,K,2]
candidate_valid      [frames,K]
candidate_feature    [frames,K,F]
allowed_weight       [frames,K]
sample_weight        [frames]
radar_training_valid [frames]
```

Candidate zero remains the frozen parent/base identity candidate. The standalone
helper requires one parent branch across a manifest and retains the receipt
parent as a reference default (`cora_se1` for TCBAV and `cora_se2` for
survival). The fresh production entry never uses that default: it requires the
outer verified route-selection result and passes its selected parent explicitly
as `expected_parent_branch`. Parent checkpoint, run, and protocol bindings stay
in the outer selection/runtime contract. It does not open or import the
historical checkpoint.

## Main-entry integration

For these two implementation IDs, `--native-support-manifest` is mandatory;
missing it fails before generic loading and generic current-model/current-loss
fallback is disabled. The supplied manifest must resolve to the outer
`target-fit-root/ROUTE_RUNTIME_MANIFEST.json`. The main entry first performs its
existing parent-selection receipt, EmptyGuard, target/source manifest, member
hash, payload-validator, Support-summary, parent-lineage, role split, and
sequence-disjoint checks. Only after those checks does it call
`prepare_historical_graph_expert()` with the verified selected parent.

The graph branch uses the isolated hash-pinned recovered model and AST loss
closure, then returns a non-promotable JSON report. It does not construct the
current generic model, call the current `episode_loss`, call `train()`, create
an optimizer, call backward, save/load a checkpoint, add temporal reset logic,
or enter Test. The manifest forbidden-read values are retained as declarations
in the report, not treated as independent security proof.

The semantic dispatch additions are exact:

```text
tcbav_temporal_candidate_graph -> temporal_candidate_graph / candidate_graph_temporal_v1
candidate_survival_graph        -> candidate_survival_graph / candidate_survival_graph_v1
```

Dispatch also requires and forwards `--native-support-manifest`; it does not
map either name to `CausalBranchRouter`, `TECSSE2`, `GBLE`, or `PathAssociation`.

## Verification behavior

For every synthetic support member, the module runs the recovered model
forward and the recovered `episode_loss` under `torch.no_grad()`, checks output
shapes/finiteness and loss finiteness, and checks that the model state is
unchanged. The returned audit explicitly reports:

```text
optimizer_created = false
backward_called    = false
checkpoint_loaded  = false
checkpoint_saved   = false
training_started   = false
historical_best_claim = false
```

The main graph entry applies the same recovered `episode_loss` to the outer
hash-verified source-replay episodes with the same in-memory historical model.
The outer current loader still owns route/role, parent-lineage, member-hash,
Support-summary, and sequence-split checks; the native manifest's forbidden-read
declaration is recorded but is not treated as security proof.

The tests use only temporary synthetic `.npz` members and monkeypatch
`torch.load`, `torch.save`, `torch.optim.AdamW`, and `Tensor.backward` to fail.
They cover both original IDs, both native topology signatures, entry field
binding, feature-dimension drift, manifest member hash failure, and forbidden
Support roles. No real model/data payload or Test payload is used by the test
suite.

The old source-coverage catalog hash is intentionally not a gate in this
module. The current target entry is still checked field-by-field and its own
entrypoint hash is verified; a mutable global catalog hash is not treated as a
replacement for that local binding.

This is a preparation receipt surface for the original trainable
implementations, not a production admission, execution-weight, numerical
reproduction, or frozen-best claim.
