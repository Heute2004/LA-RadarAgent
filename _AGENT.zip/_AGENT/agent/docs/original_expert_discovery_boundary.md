# Original Expert Discovery Boundary

The active Human catalog contains 40 retained original identities. An expert's
name does not authorize replacing its historical implementation with a newly
written architecture that happens to match the description more closely.

The `subcell_uncertainty_refiner` semantic row previously exposed a new
`SubcellUncertaintyRefiner` through `native_preparation`, despite explicitly
declaring that historical implementation recovery was false. That discovery
binding is removed. The original catalog row and historical/experimental source
files remain intact. No checkpoint, result, quarantine, or numerical threshold
was changed.

Until the original model/trainer pair and its input/loss contract are bound,
this identity stays unbound. Shared model classes and shared losses are valid
when a hash-matched original training receipt proves that they were used.
Conversely, a same-route prototype or an architecture inferred from a name is
not evidence of original implementation recovery.

Discovery tests also reflect the current 20 preparation-intercept declarations,
including the two original graph preparations. Discovery is not production
authorization or a real-Qwen acceptance result.

Independent local regression: discovery, coverage, quarantine and cardinality,
14 passed in 2.01s. The replacement-discovery test failed before the binding
removal and passed after it. No training or Locked Test access occurred.
