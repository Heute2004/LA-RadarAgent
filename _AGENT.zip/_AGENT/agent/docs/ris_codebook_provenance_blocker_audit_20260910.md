# RIS Codebook Provenance Blocker Audit

Audit date: 2026-09-10. Scope: read-only evidence audit for the current 40-entry pool. No quarantine, Top5, catalog, manifest, packager, source, test, model, or training state was changed.

## Decision

**NO RELEASE.** The current evidence cannot satisfy the new RIS payload provenance gate, so `risecho_codebook_consensus` must remain quarantined. The active catalog has 40 entries and five named RIS entries; after quarantine there are four eligible entries. The selector must refuse a five-entry RIS shortlist. No replacement, alias, rename, or structural substitution is authorized.

The original model identity is not the blocker. The server has a hash-matching `RegisteredDiscreteCandidateExpert` / `_CodebookMixer` pair and the shared registered-candidate `episode_loss`. The blocker is receiver and input provenance.

## Evidence

- Active state: `tasks/human/experts/library.json:1389-1391` reports `pool_size=40`; the five RIS rows are at `:902-972`, `:998-1010`, and `:1380-1386`. `tasks/human/experts/quarantine.json:6-8` forbids retrieval and execution of `risecho_codebook_consensus`. Fail-closed selection is implemented at `src/agent_jsac/adaptive_expert_retrieval.py:466-480` and `src/agent_jsac/registered_route_expert_tools.py:53-60`.
- Gate contract: `src/agent_jsac/ris_protocol_contract.py:117-130` requires model, trainer, geometry, receiver, site, RIS, phase/codebook, label, and canonical payload hashes. `:271-290` computes canonical receipt content after removing only the two self-reference fields. `:293-315` requires trusted caller-supplied hashes; payload self-report is not a trust source. `:458-598` and `:622-668` bind the receipt schema, new label, geometry, receiver, inputs, forbidden reads, and observed-candidate label provenance.
- Original structure: on `lab407`, `/home/hyc/radar+ris/AGENT-JSAC/src/agent_jsac/registered_route_expert_models.py` has SHA-256 `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`; its codebook spec is at `:109`, the 16-slot embedding and candidate-axis ordinal modulo 16 are at `:285-293`, and the registered scorer is at `:462-545`. The matching trainer `/home/hyc/radar+ris/AGENT-JSAC/scripts/train_se_branch_route_expert.py` has SHA-256 `01a7aac1d09a5ec4bbc06b7bf0ae0d5bd739ecc6ffef01daf13ab22be91c02dd`; RIS supervision checks are at `:159-181`, the shared loss is at `:465-574`, and fresh-weight recording is at `:817-842`.
- Historical codebook receipt: `/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/corner_nlos_ris/shadow_pool/corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--03--risecho_codebook_consensus/TRAINING_RECEIPT.json` has measured file SHA-256 `ed6e05c06f4b49de63dbeb168e11d891b7a7d5ad40e26ea5c3f8feaa09fa2fa4`. Its pair and runtime bindings are at `:377-405`; the schema is `agent_jsac_se_branch_route_expert_training_receipt_v2` at `:405`, and `parent_selection_policy_id` / `parent_selection_sha256` are null at `:389-391`. This is a historical training receipt, not the required new payload receipt and not a receiver provenance proof.
- Historical Support manifests: the server fit manifest and source-replay manifest at `/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/runtime/corner_nlos_ris/{fit,source_replay}/ROUTE_RUNTIME_MANIFEST.json` have measured SHA-256 `ae37d914dcd885ec70719da5c2fb7f107be888ea89dba0b7dca8a92f3b6a7468` and `bedab9d724505808f7f8fbb3fcea61a036d9010c76aec651a43aecea102fa648`. Their `:1-120` records bind route, role, sequence, frame counts, origins, and false forbidden-read declarations. They do not bind a new payload receipt, site/phase/codebook/receiver contract hashes, or a trusted per-payload receiver bytes verifier.
- Receiver-side source evidence: the server cache report `/home/hyc/radar+ris/JSAC-AGENT-V4/artifacts/RIS_DualRIS_V21_BidirectionalPeakTeacher_20260815/CACHE_REPORT.json:1-20` has measured SHA-256 `3639cc9993fde425f398cf92be2e71e93f63444562b9a4c7ddb263b90113b5d3` and explicitly states `generator_truth_coupled_virtual_source=true` and permits only an offline teacher claim on generator-truth-coupled virtual data. That is not independent receiver provenance for release.
- The server receiver loader `/home/hyc/radar+ris/JSAC-AGENT-V4/src/brace_v4/ris_response.py:39-74` requires a per-feature `metadata.json`, V21 processing/source semantics, `receiver_label_access=none`, a `DualRISMultiHypothesisV21Final` state, linked `causal_direct_state_contract.json`, linked `receiver_contract.json`, and a non-empty `input_fingerprint.fingerprint_sha256`. On the server, each of the eight fit/source-replay v21 Support roots (`seq_001`, `002`, `004`, `007`, `008`, `010`, `013`, `014`) had zero `metadata.json`, `receiver_contract.json`, and `causal_direct_state_contract.json`; the read-only global contract enumeration also returned zero receiver and causal-state contracts.
- The only nearby direct-equivalent metadata found on the server is the v6 blend085 record `/data_hard_driver/hyc/Radar+RIS/Radar_RIS_VLM_20260724/Data_train/seq_001/RadarRIS/directeq_lcorridor9_v6_blend085_seq_001/ReceivedADCStandardFeaturesV1/metadata.json` (SHA-256 `0670c171ba4e094b5ed8646de3f6dcd901da9d0ced0c4374108c3d649ec8cc7b`). It says `receiver_label_access=none` at `:7`, but its `source_receiver_state` is `DirectEqStatePositionPreservingV1` at `:22` and its condition is v6, not the v21 Support root. It is therefore rejected by the new gate and cannot substitute for missing v21 provenance.

## Missing Assets

1. A new `agent_jsac_ris_payload_provenance_receipt_v1` for the codebook candidate, with canonical-content `receipt_sha256` and `hashes.payload_receipt_sha256`. `expected_hashes` must come from a trusted external manifest or receipt-bytes verifier, not from the payload.
2. A receiver provenance chain for every admitted Support payload: v21 feature metadata, the linked `DualRISMultiHypothesisV21Final` state, causal state contract, receiver contract, real input fingerprint, and hashes tying those bytes to the payload, site, RIS geometry, phase/codebook state, and label receipt.
3. A new label/support receipt that binds sequence and frame membership, fit/calibration role, `offline_bidirectional_RISEcho_observed_candidate_set`, current observed physical candidates, the active task/method/tool contracts, and all forbidden-input audits. Existing false declarations are not sufficient without the missing receiver chain.
4. A current parent-lineage receipt/hash when the current dispatcher or method contract requires one. The historical `cora0` field is not a migration-wide parent rule; the expected parent must be supplied by the current contract.

No codebook-specific physical loss is missing. The recoverable original structure uses the shared `episode_loss` with the `ris_temporal_hard_gate` family weights; a separate physical-codebook loss must not be invented.

## Safe Pretraining Boundary

The only currently legal status is **preparation-only, provenance-blocked**:

- Keep the 40 names and original RIS five-row structure unchanged. Keep `risecho_codebook_consensus` quarantined and do not change the RIS shortlist behavior.
- Do not treat the historical receipt, the generator-truth-coupled cache, or the v6 position-preserving metadata as a valid new payload. Synthetic checks are not evidence for release.
- A future fresh run may use the exact original identity (`risecho_codebook_consensus_v1`, `RegisteredDiscreteCandidateExpert`, `_CodebookMixer`, 16 candidate-axis slots) and the shared `episode_loss` only after a real new receiver/support bundle passes the gate. Parent binding must come from the current method/dispatcher contract; historical receipt values are not permanent defaults.
- The future run must remain fresh-lineage only, keep historical RIS expert-weight import forbidden, use zero-weight source replay, use RISEcho observed-candidate support, keep runtime causal, and keep Final-BEV/RGB/depth/right-camera/manual-anchor/development/locked-test reads forbidden. No training or promotion is authorized by this audit.
- Release requires the trusted hashes, new payload/label receipt, native admission decision, and a separate mainline quarantine decision. This audit itself never grants admission.

## Isolated Qwen Preparation Entry

The follow-up entry `scripts/check_qwen_historical_ris_preparation.py` (SHA-256
`098300de0156481d4cdacde509e71f671ed2013f8930cc15eed0c07e7e602374`) is a
separate profile-bound synthetic preparation harness. It accepts exactly the
four non-quarantine original RIS IDs (`ris_temporal_gate_h32`,
`risecho_path_integrator`, `risecho_dual_path_mixture`, and
`risecho_dual_stream_stability`) and reuses the pinned
`RegisteredDiscreteCandidateExpert` plus the original AST-extracted
`episode_loss` through the existing prepare-only trainer path. It does not
enter the generic checker or normal Agent dispatcher.

The declaration is intentionally `prepare_only_agent_dispatch=false` with
`requires_binding=true`: a future upper layer may bind this entry, but the
current dispatcher cannot call RIS. A successful synthetic run proves only
native structure/ABI/loss preparation. It reports formal training status
`PROVENANCE_BLOCKED`, `production_admission=false`, and an uncalled Banach
receiver gate because the v21 eight-Support roots still lack trusted metadata,
receiver/causal contracts, and external payload hashes. The codebook profile
is rejected at discovery and remains `forbid_retrieval_and_execution`.

The synthetic test entry and the provenance audit therefore have different
meanings: preparation may pass in isolation, while formal RIS training,
retrieval, Top5 admission, and quarantine release remain blocked. No Qwen run
was performed during this update.

## Audit Boundary

Server identity was verified read-only as `lab407`, user `hyc`, address `116.57.87.129`, with strict known-host checking and ED25519 fingerprint `SHA256:BMOqXHKueWbQK4oqvVSQDKBQw6n568BlLJre0NTcP2Q`. No Test data/content, model weights, checkpoints, feature arrays, training, or evaluation was read or run. Only JSON/MD/PY source and receipt metadata plus directory/file metadata were inspected.
