# RIS Canary Measurement Boundary

The coordinate summary measures physical support and temporal continuity only.
It does not execute the deployment branch, inspect model state, or measure
zero-weight logit equality. Accordingly, `state_leakage` and `returned_model`
are unknown (`null`) in this summary. A physical `passed` result must not be
interpreted as runtime isolation or promotion authorization.

Empty timelines are rejected. Nonfinite foundation coordinates, candidate
coordinates, physical targets, and gate probabilities invalidate the audit.
Probabilities outside [0, 1] also invalidate it. The historical `nan_count`
field counts invalid rows, including invalid probability bounds.

Local regression: the new assertions reproduced four failures before repair;
the coordinate and downstream RIS chain tests passed (8 tests) after repair.
No model training, Development/Test read, or frozen result modification occurred.
Actual runtime identity measurements and a new sealed server release remain
required; this repair alone does not complete RIS acceptance.

The production CLI now executes `measure_runtime_identity` on the complete
protocol-declared support Canary dataset before physical scoring. This calls
the native adapter's `final_logits` branch, not an analytic zero-times-delta
surrogate, and checks repeated base outputs plus registered base state.
Synthetic tests reject an adapter returning changed logits even when its
proposal is finite. Actual checkpoint execution of this new path is still
pending; unit-test success is not a measured model receipt.

Before constructing the support dataset, the gate receipt must match the
protocol hash, actual shadow checkpoint hash, Fit/Calibration sequence lists,
and all declared withheld Canary/Development/Test lists. Forbidden-read flags
must be explicit JSON false; base/proposal frozen flags must be explicit true.
A matching protocol hash alone is insufficient when the receipt's actual
partition fields disagree. Twenty local RIS summary/chain tests pass after
this lineage check. This latest change awaits the next sealed server release.
