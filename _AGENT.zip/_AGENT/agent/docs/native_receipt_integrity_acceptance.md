# Native Receipt Integrity Acceptance

## Verified execution

The independent server release is
`/home/hyc/radar+ris/AGENT-JSAC/releases/native_receipt_integrity_20260909`.
Its archive contains 1109 hash-verified files and has SHA256
`126b7548f032b457e4c97caab7d23a6d5d45e067053dbe394c78ed3cce08ea8b`.
The installer verified every file before and after extraction.

On lab407, with CUDA visibility disabled, the installed release ran:

```bash
PYTHONPATH=src:. /home/hyc/.conda/envs/rvmg/bin/python -m pytest tests -q --tb=short
```

Observed result: **551 passed in 28.69 seconds**, process exit code 0.
This is CPU contract testing, not sensing training or numerical reproduction.

## Changed boundary

The integrated preparation adapter no longer overwrites an explicit native
failure with a successful normalized receipt. Native `passed=false`, unsafe
Test-read flags, promotion authorization, and numerical-reproduction claims
are rejected. Boolean fields require actual booleans, not zero or strings.
SE2 retains its existing `training_performed` contract and its dedicated
two-stage interception validator. Other stages require `training_started=false`.
Raw reports remain attached to normalized evidence.

The tests demonstrate these specified cases, not validation of arbitrary
unknown report schemas. Source and Sentinel compiler results remain metadata
checks; they do not prove execution of the compiled commands.

## Release and overall status

## Real Qwen integrated recheck

The same installed release ran `check_qwen_integrated_preparation.py` with the
hash-bound `QWEN_INTEGRATED_HANDOFF_20260909_PROFILE.json` and the verified
`qwen_gate_continuation_20260908` LoRA. Output is archived under
`artifacts/pretraining_acceptance/QWEN_RECEIPT_INTEGRITY_CHAIN_20260909` locally
and the corresponding server artifact directory.

The process exited 0 with `monitor_reached`; native checks ran in order:
source, sentinel, se1, se2, teacher, specialist. The report records
`preparation_checks_passed=true`, `test_read=false`,
`fresh_teacher_output_lineage_verified=false`, and
`numerical_reproduction_verified=false`.

This validates the repaired normalizer through real Qwen dispatch and native
intercepted checks. It does not turn reference-backed post-training fixtures
into fresh generated labels, newly trained experts, or runtime promotion.

## Overall status

This document was written after the tested archive was sealed. It is a local
companion record and is not claimed to be inside that immutable release.
Overall pretraining acceptance remains NO-GO pending the requirements matrix:
semantic/native coverage, prospective artifact handoff, portable stage binding,
method-specific selection integration, and final unified evidence packaging.
