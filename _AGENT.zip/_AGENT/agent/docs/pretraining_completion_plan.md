# Pretraining Completion Plan

## Reading Order and Current Acceptance Authority

This document retains historical checkpoints for provenance. Counts, release
names, and pending statements below are not a single cumulative status report.
Use the active scope immediately below, then the dated evidence for the exact
requirement being checked. Never infer full readiness from a historical test
total or add overlapping test totals.

As of the latest September 10 integration:

- `HUMAN_ACTIVE_CHAIN_ACCEPTANCE_20260910.md` under
  `artifacts/pretraining_acceptance` now proves one actual Qwen integrated
  source/Sentinel/SE1/SE2/teacher/specialist preparation run. Active SE1 binding
  and native SE2 receipt consumption passed with 13 restores. Producer inputs
  remain explicitly synthetic/reference; this is not fresh model production.
- Fourteen additional historical candidate positive Qwen cases have passed;
  their original memories and derived report provenance are indexed in
  `HISTORICAL_CANDIDATE_EVIDENCE_INDEX_20260910.json`. A separate real-Qwen
  missing-Support negative preserves the earlier native-only failed aggregate.
  Do not mistake these positive cases for all-family production authorization.
- The active Human pool contains 40 original IDs. UAV has no experts and uses
  only the adopted September 8 handoff, not later experimental lineages.
- `ORIGINAL_GRAPH_REAL_QWEN_ACCEPTANCE_20260910.md` under
  `artifacts/pretraining_acceptance` records two actual native graph preparation
  successes and a missing-Support rollback. These use synthetic Support and do
  not certify sensing accuracy or production promotion.
- Current-run SE1 preparation receipt consumption by SE2 is distinct from a
  source/SE1 model checkpoint. The integrated handoff checks reject wrong hashes
  and lifecycle contexts; they do not claim that fresh weights were produced.
- Exact source recovery, native forward/loss preparation, Dispatcher discovery,
  and real Qwen behavior are separate acceptance requirements. A recovered file
  pair or a standalone helper test must not be counted as an integrated expert.
- `HUMAN_ACTIVE_BRANCH_EVIDENCE_INDEX_20260910.json` now binds the actual branch
  Qwen positive and missing-Support rollback to raw report/memory hashes.
- Replacement source/Sentinel/teacher data and model paths, wrong-task denial,
  and producer-receipt propagation have focused synthetic behavior evidence in
  `docs/human_external_profile_replacement_readiness.md`.
- Original expert CLI/producer-receipt DAGs and RIS mixed-five preparation have
  behavioral evidence. The task-level RIS selector and public dispatcher passed
  real Qwen positive and missing-H16 rollback cases. See
  `pretraining_requirement_audit_current.md` for the current evidence boundary.
  Final requirement-by-requirement closure is still pending; no unattended
  sensing training or Locked Test access is authorized by this document.

The numbered Gates section remains the full completion scope. Historical
checkpoint text below must not override these boundaries.

## Active Expert Scope (September 10)

The latest user authorization requires five RIS candidates, like every other
Human route. Four eligible original RIS implementations are joined by the
existing native `ris_temporal_gate_h16` capacity variant. The task selector
preserves their original/recipe namespaces. It does not admit the quarantined
codebook implementation. See `ris_native_supplement.json` in the Human expert
directory and `authorized_route_shortlist.md`.

The user retired `risecho_selective_recovery` and
`risecho_geometry_consensus`. The original Human catalog retains 40 records,
39 eligible and one quarantined. Adding the authorized H16 recipe yields 40
eligible candidates across the task namespace. Select five verified compatible
candidates per route. Each non-RIS route has seven original catalog entries.
Do not invent replacements for the retired
entries. Older 42-entry counts below describe historical evidence only.
The retained `expert_pool_42.json` filename is a compatibility locator, not the
active count. Use its declared `pool_size` and validate the actual unique IDs.
Source recovery does not by itself prove input, loss, or executable preparation
equivalence. UAV still has no expert catalog.

## UAV Scope Authority

Follow `uav_original_handoff_authority.md` and the original September 8 handoff.
References below to fresh-lineage work do not require a new UAV experiment or
the unadopted fresh-lineage module. UAV keeps source/coarse-adaptation routing
without experts. Original-method dependency, hash, split and interception checks
remain mandatory. Human preparation scope is unchanged. Historical preparation
audits are not blanket training authorization.

## Current Evidence Addendum

The original gate list below remains authoritative in scope. The following
evidence narrows specific open items; none grants unattended training approval.

- UAV source payload: 16 source sequences, 4,800 native causal windows and
  9,616 files passed independent identity verification. Sanitized truth hashes
  are bound through the original pinned protocol receipt, not substituted.
- Human source recipe: exact pure-human CORA0 checkpoint ancestry recovered;
  native metadata agrees on 10,326 Train and 2,806 source Development samples.
  Full source-window audit subsequently passed all 13,132 eligible clips; see
  HUMAN_SOURCE_NATIVE_PAYLOAD_20260908.json for per-sequence and file evidence.
- Sentinel: recovered original trainer/config and verified configuration hash
  against checkpoint metadata. Native parser and all 2,100 commissioned-empty
  histories passed. Full-site background statistics include all 300 frames;
  tail validation is conditional on commissioning, not unseen-background testing.
- Portable profile file/membership checks now enter actual SE1/SE2 command
  construction. SE1 fit/calibration match external roles; SE2 internally splits
  only adaptation_fit. Other native stages still reject profile-bound requests.
- The real single-tool CLI supports profile+digest and --intercept; it does not
  launch training, claim a nonce or create training output in interception mode.
- The source, Sentinel and expert native training adapters still require full
  portable argument/asset injection. The native foundation loader retains its
  historical hardcoded eligibility, which must not be advertised as portable.
- Top-level real-Qwen lifecycle results remain abstract simulations. Full
  nested source/teacher/SE1/SE2/expert request-chain acceptance is still pending.

All statuses above are scoped evidence, not permission to read Locked Test,
import frozen experts into a fresh lineage, or claim numerical reproduction.

## Latest specialist handoff checkpoint (2026-09-09)

The optional Dispatcher-owned job binding now connects admitted native
route-specialist profiles to the route compiler. Original parser defaults and
all adapter arguments must agree. Missing bindings remain denied; no admission
threshold is weakened. The server release
`specialist_handoff_verified_candidate_20260909` passes 363 regression tests.
See `docs/specialist_handoff_acceptance_zh.md` for evidence and limitations.
This updates the wiring checkpoint, not the pending live method-profile
authorization, other specialist families or complete fresh-lineage acceptance.
Older progress sections below are historical checkpoints, not current totals.

## Scope

The latest independent package is `launch_boundary_candidate_20260909`:
374 regression tests pass, and a real native DAG CLI denies training before
creating its run directory. Source/RIS and candidate payload checkpoints are
documented separately. These do not close the pending admission/profile and
fresh-lineage whole-workflow requirements.

Latest nested scan supersedes the outer-only thirty-candidate command result:
five routes compile and the wet route is denied for reference-label admission.
See `docs/nested_native_preflight_findings.md`. Full regression is 367 passed;
production authorization and full preparation remain NO_GO.

Complete the Human/UAV toolbox preparation without sensing-model training or
Locked Test access. Preserve all frozen results. Simulation receipts are not
numerical reproduction evidence or permission to promote a model.

## Gates

1. [Complete, limited scope] Real Qwen binary lifecycle decisions and top-level
   Human/UAV success, denial and rollback simulations. Evidence:
   `artifacts/pretraining_acceptance/task_lifecycle_smoke_20260908/`.
2. [In progress] Expand native Human source, Sentinel, sparse-anchor SE1,
   candidate-confirmation SE2 and route-specialist dependencies. Verify original
   scripts and manifests before exposing task-bound execution requests.
3. [Pending] Bind dataset/model profiles, newly produced parent receipts and
   fresh output namespaces. Do not silently substitute archived expert weights.
4. [In progress] Verify UAV source/adaptation/routing commands independently with
   UAV metric and split contracts. Never dispatch Human expert tools for UAV.
5. [In progress] Certify payload membership and hashes, label eligibility, internal
   selection roles, selected parent lineage and candidate-training capabilities.
6. [In progress] Exercise nested requests using real Qwen, including missing/stale
   receipts, bad parameters, restart recovery and cross-task attempts. Intercept
   all training launches before subprocess creation.
7. [Pending] Seal server release and local reproduction package. Update English
   operation contracts and Chinese acceptance findings with requirement-specific
   evidence. Retain NO_GO wherever the evidence is incomplete.

## Known Boundaries

- Thirty native expert candidates have interception evidence; forty-two semantic
  entries are not forty-two verified executable trainers.
- Historical Development-best selection is distinct from prospective weak-label
  promotion. Never report simulated metrics as new validation results.
- Top-level `shadow_train` simulation does not verify nested SE1/SE2 training.
- Existing native scripts contain dataset-specific bindings; these require
  explicit profile adaptation, not merely renaming their public tool IDs.

## Current Inspection

The legacy prospective registry provides real SE1 and SE2 entrypoints. SE1
chains sparse-anchor construction, training and internal configuration search.
SE2 wraps the set-mass residual trainer and binds SE1 through an upstream
checkpoint placeholder. A registered filename alone is insufficient: script
hashes, manifest hashes and nested protocol membership must be checked on the
server before accepting a request. Empty support-canary sets must be reported,
not presented as a completed independent canary evaluation.

## Verified Native Preparation

- SE1 shared cache/training command builders are used by the actual runner,
  with AST equivalence evidence for the extracted command construction.
- SE1 native dataset audit loaded 31 Support sequences and 9,300 causal clips:
  315 accepted Fit anchors and 69 Calibration anchors. It checked NPZ hashes,
  membership, all accepted/unknown masks and exact historical windows. No
  position-label accuracy or new trained-model result is claimed.
- SE2 actual native wrapper and main reached both stage entrypoints. Stage A
  received 19 Fit and 4 Calibration sequences; Stage B received all 23 and the
  synthetic Stage-A duration. Both optimization bodies and checkpoint writes
  were intercepted. Source replay metadata contained 11,711 eligible samples;
  its calibration subset contained 512. No source radar iteration was done.
- UAV adaptation arguments are fully explicit and the actual target loader
  accepted 600 frames. Real Qwen handled valid compilation and bad-hash rollback.

Remaining gates are not waived by these results. In particular, fresh receipt
rebinding, portable runtime dataset profiles, source/Sentinel and UAV teacher
subcommands, complete expert payload contracts, and the final real-Qwen nested
run remain required. Current release remains preparation-only / NO_GO for
unattended production training.

## Current Native Admission and Candidate Queue Evidence

Operator-approved native numerical authority is implemented for the
physical-set-mass reference preparation path. It replays the native labels and
support attachment rather than requiring unapproved generic thresholds.
Real Qwen passed the valid-parent monitor and wrong-parent rollback cases.

All six Human routes now compile: 30 candidates, 87 intercepted jobs, including
three wet-route nodes with explicit native admission and reference runtime
mapping. The current server release passed 403 packaged regression tests.
See `native_method_specialist_acceptance.md` and
`bound_native_candidate_dag_acceptance.md` for scope and artifact paths.

This supersedes the earlier wet-route command-compilation blocker only. It does
not waive integrated lifecycle verification or the final requirement-level
acceptance matrix; no model was trained and no Test payload was read.

## Historical Structure And Parent Binding Continuation

The server's 42-entry runtime contract closure has been recovered as 63 pinned
code/config files. Four original registered mechanisms now have real CLI/cache/
model preparation tests on CORA0, SE1 and composite SE2, plus unchanged-loss and
causal-prefix checks. The exporter records actual parent dependency hashes; the
preparation loader rejects mismatched or absent ancestry before array loading.
See `registered_structure_binding_review.md` for exact mechanisms and caveats.

This does not mark 42 structures ready. Parent selection and EmptyGuard content
admission, the remaining structural/input contracts, and actual Qwen invocation
of the new nested paths still require completion. No optimization was started.

The next preparation increment replays the unchanged prospective parent selector
and remeasures the selected parent's Support summary from the exact verified
cache arrays. The other parents' measurements and complete EmptyGuard content
remain open. Server package acceptance reached 943 tests; see
`selection_cache_preparation_acceptance_zh.md` for the release identity, retained
failed package, and the separately verified UAV normalization manifest update.

## Operator Pause: UAV

The user paused UAV work because its models and results are changing. Do not
modify or synchronize UAV assets, evaluate its old results, or include UAV in new
acceptance runs until the user resumes it. Continue Human-only preparation. The
overall Human/UAV objective stays open; the pause is not an acceptance waiver.

Human preparation now additionally covers the original local_shape_consensus
mixer on all three eligible parent branches. No model training was started.

Human temporal-candidate review exposed per-frame brightness-rank state carryover.
Candidate association and reset-aware original GRU/hysteresis operators now have
106 local Human regression checks and 33 isolated server CPU operator checks.
See `human_candidate_state_preparation.md`. Complete cache/trainer wiring and
pooled-context gap handling remain open; no temporal production gate is waived.

Payload alignment now permutes all reviewed candidate evidence and supervision
jointly, rejecting unreviewed fields and preserving raw source indices. Human
regression reached 113 local checks; the isolated server bundle passed 40 checks.
This is preparation-array integration only, not production trainer admission.

The temporal preparation loader now verifies declared parent/member hashes,
requires an independent sequence set, and splits nonconsecutive frames before
forward calls. Local Human checks: 119; isolated server checks: 46. Production
batch integration and real-Qwen invocation remain pending.

Historical semantic audit found non-equivalent subcell and GG-SRRE registered
substitutes. Four original Conv training/loss files were recovered from lab407,
hash-matched and AST-checked (2 checks passed). See
`historical_expert_structure_gaps.md`. This recovers source, not an authorized
weak-label adapter or a new faithful expert binding. Existing 42 names stay fixed.

The exact AURF head is now available through the existing verified private Conv
loader; its two-mode offsets/covariance and zero residual were forward-tested.
Server acceptance passed 12 checks after replacing a rejected out-of-bound
source symlink with an independent package copy. This is original-head readiness
only, not subcell semantic binding or production training authorization.

Recovered E5/E6 losses complete the statically referenced project modules of the
collected Conv entrypoints. Four original loss modules import under the verified
private namespace; synthetic AURF NLL and source/head checks pass locally and on
lab407 (20 each). This does not authorize their coordinate supervision for target
weak learning or count as a complete original training entrypoint acceptance.

Candidate GG-SRRE now constructs through a pinned private source loader; original
acceptance loss is AST-extracted without executing its trainer. Parent-mass
threshold and unknown-frame behavior pass exact-function checks. Local/server
operator suites pass 27 each, after retaining and correcting a package copy
ordering failure. Full production/Agent binding remains pending.

Original candidate acceptance has an identified no-support `-inf * 0` NaN;
the preparation adapter guards this branch with finite differentiable zero.
Local regression: 28 passed, including finite gradients. Server rerun and the
same empty-branch audit for continuity/full episode loss remain pending.

Original candidate episode loss now composes pinned historical functions with
finite-zero guards only for empty branches. Synthetic backward checks preserve
parameters and objective weights; server original-operator suite passes 31.
Actual trainer CLI/verified cache/Agent linkage is still pending.

Human preparation receipt normalization and backend now reject additional unsafe
training authorization, optimizer-step and Locked-Test claims, retaining rejected
receipts. Local receipt suite: 46 passed. See
`human_preparation_receipt_safety.md`; server/Qwen rerun and stage-specific
positive evidence remain pending.

Human stage-specific receipt success evidence is now enforced. The six formerly
accepted empty-success cases are rejected; known native source/Sentinel commands,
SE1 command pairs, teacher parsing and specialist interception are recognized.
Local and isolated lab407 receipt suites pass 61 checks each. See
`human_preparation_receipt_safety.md` for remaining Test-read evidence gaps and
the acceptance receipt. No real Qwen call, sensing training or UAV work occurred.
Full-goal acceptance remains NO-GO; these focused checks do not establish all
42 original expert bindings or an independently runnable full lifecycle.

The original candidate factory now exposes all five of its real model symbols
through the pinned historical `make_model`, preserving route restrictions and
trainer-specific bounds. Four additional native models pass synthetic episode
loss/backward tests without updates. Combined original tests pass 37 locally
and on lab407. LTGE's unused audit evidence head is explicitly documented rather
than misrepresented as trained temporal confidence. This does not yet bind the
five methods into production Pool42 or Qwen dispatch; UAV remains paused.

The 42-row structural audit now resolves actual mixer constructors and rejects
active/legacy catalog divergence (four local tests). Ten descriptors use an
identity candidate mixer despite richer component names; full models still have
shared encoding/context/gates. The report distinguishes this from native recipe
implementations and does not authorize replacements. See
`registered_structure_binding_review.md` for the exact list and JSON receipt.

Recovered and hash-matched the source-only clean CLOR trainer against lab407.
The exact continuous GRU head is available through the verified shared source
loader; server original-operator suite passes 39 checks. Source-only supervision
remains explicit. Its unmasked motion term still requires invalid-frame loss
repair before admission; no target-label substitution or training was permitted.

CLOR numerical preparation now fixes two demonstrated issues explicitly:
zero-init offset gradients and invalid-target motion/regression contamination.
The opt-in repaired subclass keeps original state keys and nonzero outputs;
the source-only masked loss equals the original all-valid objective. Server
operator suite passes 45 tests. Native trainer/admission/Qwen integration remains
pending; these repairs do not constitute training or measured accuracy gains.

Native candidate-specialist request validation now runs before profile imports
and payload reads. Eleven malformed hyperparameter cases reproduced late failure;
the combined local profile/admission/parent/backend suite passes 54 checks after
repair. Valid recipes are unchanged. Server and real-Qwen verification of this
guard remain pending; no sensing optimization or UAV work was performed.

Real-Qwen negative-case verification of the native parameter guard now passes
on lab407 GPU1: invalid learning rate rejected, one native compilation, eleven
state restores, rollback executed, no downstream audit/canary/promotion. Verified
lifecycle LoRA was reused with two hash-pinned Human patch modules over the
read-only reference runtime. See `HUMAN_QWEN_PARAMETER_REJECTION_20260909`.
This is a real tool-choice negative test with simulated surrounding stages,
not independent diagnosis, positive full-chain admission or numerical replay.

Removed missing-field inference for Test-read safety and added the ignored
`test_payload_read` alias to unsafe-claim checking. Local/server receipt suites
pass 63 tests. Positive source/Sentinel/some specialist paths remain blocked by
missing producer-side read evidence; the requirement is explicitly outstanding,
not papered over with false flags. See `human_preparation_receipt_safety.md`.
