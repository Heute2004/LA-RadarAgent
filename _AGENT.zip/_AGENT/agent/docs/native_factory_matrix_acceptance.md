# Native Factory Matrix Acceptance

## Verified scope

The historical candidate trainer's pinned `make_model` factory was exercised
with synthetic CPU inputs, without loading checkpoints or creating optimizers.
Seven valid route/architecture combinations cover five distinct classes:

| Native route | Architecture | Actual class |
| --- | --- | --- |
| cluttered | route_default | TECSSE2Expert |
| cluttered_or_multipath_likely | route_default | GBLESE2Expert |
| rain_or_wet_ground | route_default | GGSRRECandidateSE2Expert |
| wet_ground | route_default | LTGESE2Expert |
| three native outdoor routes above | path_association | PathAssociationSE2Expert |

Checks include finite valid logits, masked invalid candidates, finite acceptance,
and matching prefix outputs after nonzero initialization of linear weights.
Four unsupported route/architecture combinations are rejected. Canonical route
names are not silently translated into historical route names.

Local and server checks: 11 passed each. These are synthetic mechanism checks,
not seven independent expert structures or evidence of detection performance.

## Packaging repair

The server candidate release initially failed collection because it omitted
`original_candidate_expert_loader.py`. The candidate now includes that loader
and its `original_conv_expert_loader.py` dependency. Historical pinned model and
trainer sources were already present. The repaired server run passed all 11
checks; the earlier failed report remains available.

Server candidate: `releases/human_catalog_padding_audit_20260910`.
Successful receipt: `native_factory_route_matrix_repaired.xml`.

## Remaining boundaries

This does not bind all 42 semantic entries or approve their label recipes.
Canonical-to-native route membership, selected-parent provenance, independent
support/calibration roles, native loss and all required dependency pins still
need complete production binding. The current candidate is not a final release.
The portable bundle builder must also include required historical source code;
copying loaders alone is insufficient. No Locked Test or sensing training ran.
