# Native Candidate Route Preparation

This extends the recovered TECS preparation boundary to two explicitly mapped
historical factories. It does not authorize training or promote an expert.

| Semantic route | Original factory route | Actual class |
|---|---|---|
| indoor_clutter | cluttered | TECSSE2Expert |
| outdoor_dry_complex | cluttered_or_multipath_likely | GBLESE2Expert |
| outdoor_wet_return | rain_or_wet_ground | GGSRRECandidateSE2Expert |

Entry: `agent_jsac.native_tecs_preparation.prepare_native_candidate_route`.
The existing TECS entry delegates to this function without changing its contract.
The factory and loss are loaded from hash-pinned historical sources. The returned
class must match the explicit binding. Other routes fail closed, including the
open-outdoor route; a similar LTGE name is not sufficient evidence for a binding.

Fit and internal calibration must contain disjoint complete sequence owners,
one selected parent, matching feature dimensions and the same Support route.
Frame gaps split episodes and reset recurrent state. Each segment runs the
original joint candidate loss on CPU without gradients or optimizer creation:

`set_mass_loss + 0.10 * acceptance_bce + 0.02 * continuity`

No checkpoint is loaded or saved. No parameter is updated. Source replay is not
silently inserted into the original target-candidate loss. Original covariance
outputs are not represented as covariance supervision when the loss omits them.
The returned receipt explicitly sets training authorization, numerical
reproduction and native recipe admission to false.

GBLE additionally checks the original model's reachability mask against each
supervised candidate set. If all positive-mass candidates in a supervised frame
are unreachable, preparation fails with sequence/frame identifiers. The
historical set-mass objective uses a numerical floor, so a finite loss alone
does not prove usable supervision. This check does not relabel samples, loosen
the original motion threshold or authorize silent sample removal.

Synthetic backward verification covers the native residual and acceptance heads
of TECS/GBLE/GG-SRRE, and the separate GG-SRRE gain head. Each receives a finite,
nonzero gradient while all state-dict tensors remain unchanged. The covariance
head receives no gradient under the historical objective and must not be called
trained or calibrated. These checks use distinct random candidate features;
identical candidate features would conceal ranking-gradient defects.

## Remaining Integration

GBLE and GG-SRRE now have explicit registry/CLI preparation bindings and native
class receipts. Direct generic training is rejected before optimizer creation.
They still need fresh runtime profiles, packaged server tests and actual Qwen
preparation calls. Passing this
helper's synthetic tests does not complete those requirements or demonstrate
historical numerical results. Production training remains intercepted.
# Support Calibration And Readout Closure

## Selection And Refit Order

The registered interception path also executes the hash-pinned historical
`main` function with its two training calls replaced by non-numerical sentinels.
Both first-epoch and maximum-epoch selection cases must reach this order:

1. Seed the selection stage, fit on Support-fit and evaluate on Support-calibration.
2. Select the gate from selection-stage calibration output.
3. Reset the same seed; start a fresh refit on the union of those Support partitions.
4. Refit for the selected epoch budget, with patience equal to that budget plus one.

`--epochs`, `--learning-rate`, `--weight-decay`, `--hidden-dim`, `--seed` and
`--native-patience` propagate to this check. Native patience defaults to the
original value 10 and is rejected for non-native heads. The CLI epoch default
remains 24, distinct from the historical standalone default 60; the compiled
receipt records the actual requested budget rather than claiming default parity.

These traces test dependency order only. Synthetic selected epochs are explicitly
marked and are not a result of optimization. The source `train_stage` returns its
best calibration state, including during refit; do not describe the final state
as necessarily the terminal epoch. In the historical refit the evaluation pool is
the training union, not an independent validation set. The fixed gate comes from
the earlier selection state, so actual post-refit safety still requires a separate
admission check. No simulated gate receipt authorizes deployment.

The registered TECS, GBLE and GG-SRRE preparation path now calls the original
`select_acceptance_threshold` extracted from the hash-pinned training source.
It uses only the disjoint Support-internal calibration partition. Frame gaps
remain separate causal segments; they are concatenated only for the scalar
calibration statistics, not recurrent state propagation.

The original threshold grid is 0.10 through 0.90 in increments of 0.10. Selection
maximizes weighted weak-set membership after discrete dispatch; ties prefer the
larger threshold. This is NOT distance AP and is NOT proof of correct localization.
The gate means permission to correct candidate zero, not person presence.

Readout selects one discrete candidate by argmax when acceptance reaches the
threshold; otherwise it selects the parent at slot zero. No weighted coordinate
average or additional smooth trajectory is introduced. Invalid physical winners
fail admission. Parent fallback coordinates must match exactly. A calibration
partition with no positive supported frames cannot yield a gate.

The calibration receipt is generated from an untrained head for contract testing
only: deployment_authorized=false and numerical_reproduction_verified=false.
No optimizer, checkpoint import or model update occurs. A real trained checkpoint
and its matching calibration partition must later traverse this same path before
runtime use. The historical fit/calibrate/refit epoch-selection procedure and
full native production admission remain separate pending obligations; this
closure does not certify all 42 expert recipes.

## Restored artifact shadow inference

The registered preparation additionally executes the original main function
through its artifact-writing tail. Both training stages return explicit
control-flow sentinels. All directory creation, checkpoint saves, report writes
and checkpoint hashing are intercepted in memory. The resulting artifact map
must contain `best.pt`, `training_contract.json`, `history_stage_a.json` and
`history_stage_b.json`. It verifies that saved weights come from refit, while
the epoch budget, acceptance threshold and calibration report come from stage A.
The sentinel checkpoint hash is deliberately not a valid SHA256. This is an
orchestration test, not a trained checkpoint or a promotion receipt.

`shadow_candidate_readout` accepts only measured candidate features, candidate
coordinates, validity, explicit frame IDs and the selected parent's coordinates.
Supervision fields are rejected. An independently admitted artifact identity is
required; parent hash, task, recipe and Support provenance must match before
state restoration. Each frame gap starts a separate invocation of the original
causal head. The hash-pinned original discrete dispatch is reused unchanged.

The registered preparation path restores the in-memory artifact and executes
this interface without labels. It reports shadow coordinates separately from
runtime coordinates: because preparation never authorizes deployment, runtime
coordinates remain exactly the parent output. This CPU acceptance adapter is
not a production online executor, and does not certify numerical reproduction.
