# Native Pool Selection and Safety Evidence

Development prediction freezing proves neither zero-weight identity nor Canary
safety. The legacy pool selection adapter returns diagnostic evidence only:

- `evidence_scope: development_selection_only`
- `canary_status: not_measured`
- `identity_fallback_canary_passed: false`
- `promotion_authorized: false`

New selection receipts must bind the prediction-freeze SHA256 and use
`single_prediction_distance_ap_v1`. The loader verifies the freeze schema,
route, five unique candidate IDs, permitted read declarations, and prediction
file hash. The winner must be one of those candidates or an explicitly frozen
identity parent. The producer records parent variants before scoring and adds
the freeze hash to the metric report. Legacy unbound reports are rejected, not
silently relabeled or rewritten. This integrity check does not recompute AP or
prove a scientific improvement.

The Dispatcher must keep the parent active even if a diagnostic receipt also
contains a positive Canary flag. Do not solve this by editing the flag, inventing
measurements, or treating a prediction-freeze file as a safety receipt.

A separate current-run audit must bind the chosen candidate, its parent,
checkpoint hashes, protocol, and independent permitted safety scope to actual
measurements before deployment. Wiring all native families into that production
audit remains unfinished. Existing injected-provider lifecycle tests cover
control behavior, not authenticity of externally supplied safety assertions.

Regression evidence: both incorrect success paths were reproduced before the
fix. The native receipt and Dispatcher tests then passed (23 tests, local CPU).
No sensing training, Development payload evaluation, or Locked Test read was
performed for this change. Historical selection files and weights are unchanged.
