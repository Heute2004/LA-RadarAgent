# Native TECS Binding

## Identity

The Human `tecs_candidate_attention` preparation entry now constructs the
recovered `TECSSE2Expert` through the historical `make_model` factory for
`cluttered`. Its semantic route remains `indoor_clutter`. The catalog name and
original entry remain preserved; the preparation receipt explicitly reports the
native class and factory digest instead of presenting the generic registered
candidate scorer as the original TECS network.

The original source contains current-frame candidate attention, pooled causal
GRU state, candidate logits, acceptance and covariance heads. It is the recovered
candidate-space variant, not the separate dense Polar/BEV Conv-wrapper variant.

## Source and supervision

Factory and native loss:
`reproduction/sources/JSAC-AGENT-V4/scripts/train_cora_se2_route_specialists.py`

Factory SHA256:
`a1edb0fb3c99b94b2fdebd8f2779e8ab1289a1b8463384407c65b4940ca65b9e`

Model source SHA256:
`fc1e38759a9eb26fcc2fc704074664ee3d2ba05b59fd7b9f41e6b5dfc7e2fa97`

Native training functions are loaded by verified AST extraction. Trainer
top-level data loading is not executed. The original joint association objective
is used: set-mass loss plus 0.10 acceptance BCE and 0.02 continuity. Existing
finite-zero guards for unsupported/one-frame segments remain explicit repairs.

This is not the generic registered route-family objective. The covariance head
is not supervised by this historical loss; do not claim calibrated uncertainty.
Source replay is verified as an input dependency but is not silently added to
the historical target-only optimization recipe.

## Preparation behavior

The shared dispatcher verifies selected parent, Support digest, EmptyGuard and
fit/internal-calibration membership before entering the native probe. CORA0,
CORA-SE1 and CORA-SE2 are accepted only through their independent parent pins.
Whole-sequence partitions are kept disjoint; frame gaps create separate GRU
calls without candidate interpolation. Original candidate preferences remain
unchanged. The native fit and calibration losses are both evaluated on CPU with
no gradients, optimizer, checkpoint read or saved weights.

Modified helper and original source dependencies are included in profile code
pins. A stale or modified code/catalog binding fails rather than substituting
another expert. Caller model text cannot replace fixed profile parameters.

## Admission boundary

This completes the native TECS model/loss preparation binding, not final production
recipe admission or numerical reproduction. The direct CLI and generic train
function cannot launch this semantic implementation. Original stage selection,
resource-specific weak-label provenance and final recipe integration remain to
be admitted before any optimization may start. No frozen weights are imported.
