# Cross-Anchor Pretraining Boundary

This acceptance change does not alter the frozen anchor selection thresholds,
optimization recipe, checkpoint selection policy, or inference architecture.

Before materializing the support-only label directory, the native SE1 runner
requires explicit boolean declarations for the registered offline teacher:
`future_frame_read=true`; `depth_read`, `right_rgb_read`, `final_bev_read`, and
`locked_test_read=false`. Missing fields and numeric/string substitutes fail.
These are manifest attestations, not independent proof of historical file access.

Sequence and record identities must be unique. Fit and calibration membership
must be disjoint, and neither may overlap the reserved support canary membership.
Existing Development, Locked Test, exclusion, and exact support coverage checks
remain active. Validation and source-file existence checks precede output creation.

Regression evidence: `artifacts/pretraining_acceptance/cross_anchor_fail_closed.xml`.
The failing-first test run reproduced 13 accepted-invalid cases; after repair,
the new boundary tests and original workflow tests passed together (31 tests).

This is preparation evidence only. It does not certify payload-level label
quality, numerical reproduction, successful training, or production promotion.
