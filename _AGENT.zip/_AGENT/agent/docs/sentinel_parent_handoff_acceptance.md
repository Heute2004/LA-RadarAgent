# Sentinel Parent Handoff and Candidate Check

The Sentinel compiler supports a separate `fresh_source_intercept_fixture` mode.
It reuses prospective-result digest verification and checks exact run, protocol,
producer, candidate, source roles, forbidden-read declarations and checkpoint
identity. An intercepted fixture must explicitly declare no training and no
promotion authority. The compiler substitutes its checkpoint into the native
command rather than silently retaining the historical reference parent.

These content digests ensure consistency, not cryptographic producer trust or
scientific validity. A fixture is never accepted as a real trained foundation.
The production source-receipt issuer and full lifecycle remain unfinished.

Local tests: 17 passed across parent receipt, Sentinel compiler and dispatch.
Cases include wrong run/task/stage/status, changed weights, illegal data roles,
false claims of training or promotion, and native argument parent substitution.

Server native candidate smoke: 42 windows spanning all seven empty sites and
both train/development partitions. Cached and direct top-4 candidates matched
exactly. The source remained eval/frozen, accumulated no gradients, and its file
hash did not change. No Sentinel training or Test read took place.

Report: `artifacts/pretraining_acceptance/SENTINEL_CANDIDATE_SMOKE_20260908.json`.
Script: `scripts/audit_pretraining_sentinel_candidates.py`.

This is sampled registered-parent extraction evidence, not full fresh-parent
cache certification. Full integration acceptance remains required.
