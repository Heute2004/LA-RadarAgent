# Native specialist DAG handoff

The route compiler previously always emitted the legacy route-specialist audit
argument. Its reference-label admission guard correctly rejected that command,
but the separately implemented reference-free interception adapter had no path
from this compiler.

The Dispatcher may now supply a hash-pinned `specialist_bindings` JSON mapping
native job IDs to hash-pinned specialist profiles. The CLI requires both
`--specialist-bindings` and `--specialist-bindings-sha256`. Unknown job IDs and
bindings for another native script fail. Unbound legacy jobs retain the original
rejection; no audit is renamed or bypassed.

For the supported route-specialist family, the profile must pass existing weak
admission and parent/cache checks. The trusted native parser resolves the old
command, including its defaults, without reading its audit or invoking training.
Every adapter argument must match that parsed command. Only then is the command
replaced with the registered no-training interception entry. The original command
is retained in the plan as provenance, not executed. An interception report is
written beside, not inside, the future training output directory.

This does not invent an active metric profile, grant promotion, execute model
training or automatically adapt other specialist families. Positive production
acceptance still needs actual approved admission bindings. Regression fixtures
prove wiring and reject script/argument drift; they are not real metric evidence.
