# 训练前逐项验收矩阵

本表区分“已验证的准备工作”和“正式训练授权”。当前总体结论：**NO-GO，尚未完成全部训练前验收**。
测试通过、模拟监控状态和历史成绩均不能代替缺失的生产链证据。

## 已取得证据

| 要求 | 当前结论 | 对应证据及范围 |
|---|---|---|
| Human / UAV 使用独立工作流和指标 | 已有验证 | `tasks/human`、`tasks/uav`；控制路径测试及 UAV 三种真实 Qwen 回放；UAV 不进入专家库 |
| 复用实际 Qwen 与已验证 LoRA | 已验证调用 | `QWEN_INTEGRATED_HANDOFF_20260909/REPORT.json` 的 adapter 哈希与六阶段调用记录 |
| Human 源基座输入与监督 | 已有载荷审计 | `HUMAN_SOURCE_NATIVE_PAYLOAD_20260908.json`，源域样本及因果窗口；不是新训练结果 |
| Sentinel 空场景输入 | 已有载荷审计 | `SENTINEL_NATIVE_PAYLOAD_20260908.json`；全场地 commissioning 条件下检查，不声称未见背景泛化 |
| SE1 小样本标签及训练参数 | 已有载荷与命令审计 | `HUMAN_SE1_PAYLOAD_PREFLIGHT_20260908.json`、集成预检 `native/se1.json`；315 Fit、69 Calibration 锚点 |
| SE1 内部续行权限 | 已校验且不可直接上线 | 既有内部续行合同与交接测试；本轮只修过期脚本哈希，未修改阈值 |
| SE2 两阶段原生入口 | 已验证拦截 | 集成预检 `native/se2/REPORT.json`；19 Fit / 4 Calibration 后合并 23 Support；轮数为明确模拟值 |
| 教师父权重与分折 | 命令和身份已验证 | `TEACHER_EXPERT_CHAIN_IDENTITY_20260909`；旧父权重拒绝，匹配父权重通过；未生成新教师标签 |
| 专家原生标签消费 | 指定方法已验证 | `NATIVE_METHOD_SPECIALIST_INTERCEPTION_20260909`；按原生集合监督及支持权重规则重算，不使用通用虚构阈值 |
| 六路线原生候选依赖 | 编译通过 | `QWEN_NATIVE_SELECTION_DAG_BINDING_20260909.json`；30 候选、87 拦截任务；禁止启动 |
| Qwen 选取原生候选 | ID 一致性通过 | `QWEN_NATIVE_RECIPE_SELECTION_20260909.json`；每路线只有五个可执行候选，因此当前验证的是排序，不是从更大集合择优 |
| UAV 源域与目标缓存 | 已有独立审计 | `UAV_SOURCE_FULL_PAYLOAD_ACCEPTANCE.json`、`UAV_TARGET_PAYLOAD_PREFLIGHT_20260908.json` |
| UAV 教师到适配入口 | 参考输出回放通过 | `QWEN_UAV_PRODUCER_BOUND_20260909/SUMMARY.json`；正常、错误标签哈希、错误教师哈希三例；不等于新教师推理 |
| 记忆恢复 | 集成回放通过 | Human 六阶段恢复 13 次；UAV 正常及失败路径各自有回执链；未证明任意实时部署场景 |
| 缺失/错误身份的失败处理 | 已有负例 | 错误父权重回退、SE1 旧哈希回退、UAV 错误生产者回退；不允许用成功模拟值覆盖失败 |
| 禁止感知训练及 Test 读取 | 当前执行保持 | 全部训练前拦截；`NATIVE_LAUNCH_BOUNDARY_20260909.json` 另验证真实启动入口拒绝预检包 |
| 发布包完整性 | 新包服务器验收通过，后续文档仍需最终收口 | `ris_lineage_guard_20260909` 独立安装 1098 文件，整包 528 tests passed；26 项注册审计资产哈希匹配；并不证明所有原生训练结果已接通晋级 |

证据默认位于 `artifacts/pretraining_acceptance/`；集成结果及新 DAG 也保留服务器原件。
上述旧文件证明各自记录时点和指定范围，不自动证明当前全部文件仍匹配。

## 最新补充验收

- 原生 Conv 专家代码依赖已追回：19 个显式源文件展开为 41 个 Python 文件，源码哈希全部校验，已保存在 `reproduction/reference_sources`。服务器独立 CPU 合成测试 **27 passed，5.75 s**；禁止检查点/数据加载及优化器更新。修复收集器固定项目名和包初始化文件遗漏，4 项回归通过。这证明找回的原生头可以独立导入和执行指定测试，不证明 42 项结构绑定、当前弱标签训练或晋级已经完成。详见 `conv_native_dependency_acceptance.md`。

- 历史代码与训练回执追溯：42 个入口均找回源码；41/42 有训练完成元数据，其中 30 项有成功启动回执配对。`risecho_geometry_consensus` 的完成记录尚未找到。这不等于原语义结构已确认：例如旧池 CLOR 实际为离散候选评分器，而原生 CLOR 为连续偏移。详见 `historical_expert_training_provenance_followup.md`，不得将训练留痕当作结构等价或当前晋级依据。

- 源场景策略绑定修复：禁止把其他检查点的策略重标为当前检查点；固定/搜索策略都校验有限数值与范围。Canary 支持签名回执中的候选策略 pin，校验路线、检查点与文件哈希并执行实际坐标策略，不再默用默认配置。新增坏路径先复现后修复，相关本地 38 tests passed。完整共享检查点 DAG 的候选回执接入仍未完成，未做真实模型 Canary 或训练；见 `source_tail_policy_canary_contract.md`。

- 新包真实 Qwen 复验 `QWEN_TASK_AUTHORITY_CHAIN_20260909`：12/12 生命周期选择通过、编译拒绝 0、六路线候选 ID/顺序与执行回执一致，检索哈希已指向 Human 任务目录。必须区分：生命周期选择使用 LoRA，候选排序 trace 的 `adapter_active=false`（基模排序）；输入证据仍为模拟且每路线五选五，因此不能称 42 库择优或数值复现。未启动训练、未读 Test。报告已同步本地。

- 42 个语义入口已逐个校验哈希并实际执行 `--describe`：42/42 成功返回描述，但 **0/42 声明 train 模式，全部走 archive-only 包装器**。报告 `EXPERT_42_ENTRYPOINT_DESCRIPTIONS_20260909.json`。这修正了此前“部分旧入口不可训练”的不精确描述；独立的 30 个原生配方不能被算成这 42 个入口已经可训练。下一步须替换/绑定真实执行实现，而不是解除 archive 限制。

- `task_expert_authority_20260909` 服务器独立安装 1134 文件，CPU 全包 **607 passed，19.36 s**。包 SHA256 `2c489254ad08bc7545f47ddaa698f3ef3f2bcb01a719370f619706691074397c`。包含原生安全接入清单、源场景 Canary CLI 和任务级专家检索修复。检索现在只读 Human 任务内的语义/训练目录，不依赖顶层旧镜像；没有据此解除未绑定入口的训练限制。42 个真实训练配方与完整安全 DAG 仍未完成。

- 源场景 Canary 新增可调用 CLI `run_native_source_canary.py`，复用已有生产者；外部 episode 配置须明确 Human、五类数据角色及独立 Canary。默认只验证元数据，执行审计才调用模型。相关新增测试 9 passed、CLI help 通过。尚未插入完整 DAG，也未产生当前新训练候选的实测回执；不据此宣称十个候选已完成晋级验收。

- 原生安全接入静态清单已生成：`NATIVE_SAFETY_BINDING_GAPS_20260909.json`。以任务内实际 recipes 为准，30 个候选均未在 DAG 显式声明 audit/Canary 阶段；不代表各训练器内部没有检查。按 8 个训练入口归并接入工作，源场景复用现有 Canary producer，RIS 复用专属运行时审计，其余不能按路线名称套用旧 wrapper 回执。见 `native_safety_integration_map.md`；新增静态审计测试 2 passed，接入本身尚未完成。

- `native_selection_integrity_20260909` 服务器独立安装 1125 文件，CPU 回归 **597 passed，24.74 s**，包 SHA256 `d6e7cfef54c9f4cc4b48b59a466b07ea7d48bf96b2679e4246333ac4ccca9a6f`。新增指标合同、预测封存哈希、路线和五候选成员关系验证；六类错误放行均先复现后修复。历史无绑定选优报告仅拒绝接入，不改原件。生产者同时写出父变体与封存哈希；真实新训练结果及 Canary 接入仍未完成。

- `native_selection_safety_20260909` 已在服务器独立安装并核验 1125 文件，完整 CPU 回归 **590 passed，25.50 s**。压缩包 SHA256：`65f3eccc476da9a59a365375c834ca9096326b2e67bf8660fbbd0e09a3f7a1cd`。此包含下述选优/Canary 隔离修复；不代表待完成的真实原生安全回执链已闭合。

- 修复旧 native pool 回执将预测封存误认作 Canary 通过的路径。Development 选优现在明确为 diagnostic-only，Dispatcher 不允许据此晋级，即使混入正值 Canary 字段也保留父基座。两个错误路径均先复现再修复，本地相关回归 23 passed；尚未封入新服务器发布包。各原生族的独立安全审计接入仍待完成，见 `native_pool_selection_safety_boundary.md`。

- `lineage_freeze_closure_20260909` 独立安装 1122 文件，服务器 CPU 回归 **585 passed，23.69 s**。严格 SE2 布尔类型校验也已对现有哈希绑定 SE2 检查点进行只读核验，合同通过；没有模型前向或 Test 读取。

- 新 `--rank-native` 真实 Qwen 联调已完成：`QWEN_RANKED_NATIVE_CHAIN_20260909` 为 12/12，六路线编译拒绝数 0；Qwen 选中 ID 及顺序与执行回执完全一致。仍是每路线五选五的排序，不证明大库择优或真实标签质量；详见 `qwen_ranked_native_dispatch_acceptance.md`。

- `native_selection_profile_bound_20260909` 服务器独立安装 1116 文件，完整 CPU 测试 **569 passed，24.65 s**。库存大小与每次 Top-5 分离，显式候选 ID 接入依赖展开；未选候选不进入该路线 DAG。新 `--rank-native` 真 Qwen 联调尚待执行，不套用旧二选一验收结论。

- `native_receipt_integrity_20260909` 在服务器独立安装 1109 个文件并核验哈希，CPU 完整测试 **551 passed，28.69 s**。修复集成层把原生失败或越界声明包装为成功的问题；SE2 保留原生双阶段回执合同。
- 真实 Qwen 的 `QWEN_NATIVE_ADMISSION_BOUND_20260909` 请求测试 **12/12**，编译拒绝数 **0**。这是六路线准备/等待的二选一测试，使用明确的参考绑定，不证明自主最优专家排序或新标签生成。
- 详细边界见 `native_receipt_integrity_acceptance.md`。补充记录形成于发布包封存之后，不声称已包含在该不可变包中。
- 最新修复包上的真实 Qwen 六阶段集成重跑已完成：`QWEN_RECEIPT_INTEGRITY_CHAIN_20260909`，源基座→Sentinel→SE1→SE2→教师→专家均执行原生预检，退出码 0、`monitor_reached`。训练后产物仍为参考模拟；新教师产物谱系与数值复现两项仍明确为 false。

## 未完成项，不能由上表替代

1. **42 条语义描述与真实执行绑定未完整闭合。** 原生 30 候选是已验证生产线；不能将同路线旧别名强行映射过来。语义 Top-5 中仍有未绑定与隔离项，必须在可执行筛选前排除并记录不足，不能静默换模型。
2. **新产物交接仍是参考回放。** 集成使用历史父权重/标签，并明确记录模拟返回。已匹配的教师命令没有产生现有专家标签。教师参考原件的哈希、身份与证据范围现已复核，真实 Qwen 在错误原件哈希时回退且未调用专家；参见 `teacher_reference_origin_acceptance.md`。其余未来产物回执的重绑定仍需验证，不能改历史缓存的来源说明。
3. **全部阶段的可迁移配置尚未统一。** 源入口已有 profile 绑定证据；部分原生阶段仍受历史协议和数据布局约束。应保留方法规则，把数据角色、路径和成员映射放到外部 profile；不能声称任意换数据/模型即可运行。
4. **晋级与候选最佳选择需逐原生方法回执接入。** 当前综合生命周期的训练后结果仍是模拟。源场景尾部专家已接入 Dispatcher 管理的实际 Canary 生产与消费，绑定当前运行、父权重、候选、完整外部 episode 范围；历史四帧参考检查不授予新候选晋级。RIS 已实现原生 final_logits 回退分支测量与 gate/parent/split 校验，NaN 和未测量的状态隔离不再冒充通过。尚未用当前协议候选完成真实模型回执，也未完成所有候选族的综合最佳选择验收，不能把“进入 monitor”解释成已按真实指标选出最优专家。
5. **最终最小包与文档需统一封存。** 最新代码、英文操作合同、中文验收矩阵、证据索引及安装入口必须在同一个新发布包中验证；已有旧包不自动包含后续修复。

## 不属于本轮验收目标

- 新训练的 AP、数值重现和真实收敛速度：本轮禁止训练，不能验证也不伪称完成。
- Locked Test：继续封存。
- 修改冻结专家权重或用历史权重冒充从零训练：禁止。
- 将模拟许可写成真实部署/晋级授权：禁止。
