# Evidence-Gated Lifecycle LoRA: Scoped Acceptance

## What Changed

The runtime strips answer-bearing goal/target metadata. Registered binary lifecycle choices receive explicit typed authorization gates, rather than a long mixture of radio and visual observations. Qwen still chooses an option. The Dispatcher independently validates real receipts before any side effect. No scientific threshold was relaxed.

This contract applies only to the registered lifecycle action set and hold. Other action sets retain their existing prompts. This Adapter is activated only for that lifecycle choice set; it is not a replacement for the branch-routing adapter or the base language model.

## Training

Only synthetic authorization examples were used. No radar, RGB, human annotations, sensing Development or Locked Test data were read. Six lifecycle stages supplied training examples. Promotion and rollback were held out from fitting, but used for checkpoint selection; they are contract development cases, not a blind Test.

The compact-input run used 432 balanced records, batch size 2, accumulation 4, seed 3407, rank 8, alpha 16, dropout 0.05, learning rate 0.0002, BF16, and frozen Qwen base weights. Prompt truncation is forbidden. The first four epochs were insufficient. An isolated continuation warm-started from its best Adapter with a fresh optimizer; it stopped after one further epoch at the registered 98% class-recall diagnostic criterion. That criterion is not expert promotion authority.

Warm-start provenance and manifests are in the training reports. The earlier long-input repair remains a recorded negative result and was not deployed.

## Results

| Check | Result |
|---|---|
| Training-time held-out stage execute recall | 8/8 |
| Training-time held-out stage hold recall | 71/72 |
| Independent reload, actual rotated-choice scorer, same 80 development cases | 80/80 |
| Six-route native training request interception, synthetic readiness | 12/12 |
| Qwen-related code regression | 71 passed |

The difference between 79/80 during training and 80/80 at reload follows the scoring contract: training diagnostics used a single option ordering; the deployed scorer averages rotated option orders. It is not evidence of a new sensor accuracy gain. The independent process reload is an integrity/behavior check, not a new independent data split.

Each ready native request resolves a real five-candidate native recipe DAG with resource/hash checks, but is intercepted before launching. Negative cases request hold. This does not test autonomous selection of the best five experts.

## Artifacts

- Candidate binding: `configs/qwen_lifecycle_repair_candidate.json`.
- Local evidence: `artifacts/pretraining_acceptance/qwen_lifecycle_repair_results/`.
- Server candidate: `/home/hyc/radar+ris/AGENT-JSAC/artifacts/qwen_gate_continuation_20260908/`.
- Model SHA256: `1c7455567685cc423482b4f068a894d7999257d1dc800d259c79a610c07bf4e2`.
- Trainer: `scripts/train_qwen_precondition_repair.py`.
- Behavioral audits: `scripts/check_qwen_clean_contract.py`, `scripts/check_qwen_native_requests.py`.

Reproduction: run the trainer without `--init-adapter` for four epochs, then use that output's verified `adapter` as `--init-adapter` in a separate output directory for up to eight epochs. Both calls use `--variants 4 --batch-size 2`. The script preserves prior outputs and never saves modified base weights. Full floating-point training reproducibility is not asserted across different hardware/software.

## Remaining Boundary

The candidate is not automatically enabled in production. Full Human/UAV autonomous replay, all stage receipts, scientific admission decisions, and expert ranking remain separate acceptance tasks. Historical sensor results are untouched. Semantic expert entries without executable bindings remain unavailable. Do not call this complete Agent reproducibility or unconditional safety.
