# Post-training audit boundary review

## Verified scope

The registered legacy route-pool adapter consumes
`agent_jsac_prospective_route_pool_training_v1`. It checks pinned parent,
checkpoint and shadow-audit artifacts and returns a zero-execution-weight
shadow receipt. This is not evidence that every native recipe output has
been translated into this schema or that deployment promotion is complete.

Native execution separately contains calibration stages, prediction freezing
and Development runtime commands. Do not substitute those for Support-only
Canary checks, or feed Development metrics into a Support-only receipt.

## Repair

The adapter previously used `bool(selected.get("safety_eligible"))`, which
accepts the string `"false"` as true. It now requires an actual boolean,
rejects missing or malformed values before creating the output directory,
and preserves both genuine boolean values. The five active registrations
of this script have updated SHA256 pins. No scientific threshold changed.

Ten focused local cases pass. The native per-method result-to-audit mapping
remains an open acceptance item. The repair is installed in the independent
server release `post_training_audit_guard_20260909`: 1084 files, 484 packaged
tests passed in 17.18 seconds. All 24 registered asset checks match, using
explicit `agent` and `v4` roots. This proves file identity, not scientific
audit execution. Previous sealed evidence remains unchanged.

Archive SHA256:
`d24b28bd4cb3de09574657bcba37883626f4c30eccc2330de68282128311d295`.
The corrected root-bound asset receipt is
`artifacts/pretraining_acceptance/POST_TRAINING_REGISTRY_BOUND_ROOTS_20260909.json`.
An initial ad-hoc check omitted the `v4` root and reported two unresolved
paths; the explicit root-bound check resolves both without changing assets.
This acceptance update and the checker postdate that sealed archive and must
be included in the final combined release.

No sensing training or Locked Test payload access was performed.

## Source-tail execution evidence gap

Inspection of the actual source-tail adapter found an unsupported claim:
it constructed a successful zero-weight Canary with all-zero errors without
executing the runtime. Source calibration and source harm-budget selection
are real native steps, but they cannot prove target runtime state isolation.

The adapter now returns `pending_canary` after safe source calibration,
`safety_eligible=false`, `executed=false`, and null unmeasured quantities.
An unsafe source calibration still returns `rejected`. The native harm
budget and source-calibration metrics are unchanged. Both registry hashes
were updated. A fixture executing the real adapter reproduced the false
claim before the repair and passes after the repair. This fixture uses no
model or dataset and is not a measured runtime Canary.

Remaining integration: produce a current-candidate, parent-bound runtime
Canary receipt from the actual zero-weight executor, including the exact
Support partition and state-isolation evidence. Only then may the lifecycle
accept it. Do not restore an unconditional pass to make simulation green.
## RIS evidence semantics correction

The RIS adapter also previously translated a no-data analytic identity
statement into successful measured execution. No-data reports now remain
`pending_canary` with `executed=false` and null unmeasured values. Data-driven
physical-support audits remain distinct from runtime logit/state isolation;
their results cannot fill absent identity measurements with zero. The RIS
runtime measurement producer still needs integration. No RIS checkpoint,
label, prediction or frozen scientific result was changed.
