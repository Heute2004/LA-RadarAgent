# Real Qwen Native Specialist Rejection

The verified lifecycle LoRA was used on server GPU2 for an explicit negative
case. The legacy Train runtime and its file hashes were read, but its missing
parent map was not reconstructed or asserted as valid provenance. A separate
negative-case profile references it without modifying the original artifacts.

Result: `rollback_executed`, one native profile compilation, eleven persistent
state restores. The actual failure receipt was:

```text
runtime parent dependencies are missing or differ from admission
```

The workflow reached `shadow_train`, received failure, and executed rollback.
It never reached expert audit, canary or promotion. This was real Qwen tool
selection and the actual profile/admission verifier, not a mocked Qwen scorer.
All unrelated lifecycle evidence remained explicitly simulated. No optimizer,
native episode loader or Locked Test payload was entered for this rejection.

Evidence is in
`artifacts/pretraining_acceptance/QWEN_SPECIALIST_LEGACY_REJECTION_20260909/`.
The case does not prove a successful full Human run or trained-model quality.
Positive native-data admission and full source-to-expert lineage remain open.
