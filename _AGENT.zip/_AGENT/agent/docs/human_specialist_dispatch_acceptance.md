# Native Specialist Dispatch Interception

`HumanSpecialistInterceptBackend` connects the existing task workflow's
`shadow_train` and `replay_shadow_train` requests to `run_admitted_route`.
The Dispatcher supplies the native module, fixed arguments and artifact-bound
authorizer. The language model cannot submit callbacks, optimizer arguments or
an admission verdict. This adapter always sets `intercept=True`.

The native episode loader is reached only after route, parent, membership and
file checks. Optimization and model writes are not entered. Missing artifacts
or admission failures become failed receipts and the workflow selects rollback.
Other lifecycle stages remain explicitly simulated, not certified by this test.

## Evidence

Five tests cover native-loader dispatch, missing provenance, UAV rejection and
persisted workflow recovery on both success and failure. Fixtures use synthetic
files and a synthetic native loader. The workflow and training adapter are real;
these tests do not establish native-data numerical reproduction or real-Qwen
decision performance. All receipts remain `SIMULATED_NOT_PROMOTABLE`.

## Pinned command entry

`scripts/intercept_admitted_specialist.py` accepts `--profile`,
`--profile-sha256` and `--report`. It has no training-enable argument. The
profile has exactly `task`, `mode`, `native_script`, `protocol`, `admission`
and `arguments`; the first two must be `human` and `intercept`. Each artifact
pin contains an absolute `path` and `sha256`. Arguments explicitly supply the
native route, runtime root, fresh output, protocol, architecture, hidden size,
epoch/patience, learning rate, weight decay, seed and device. No implicit
optimization defaults or extra arguments are accepted.

The entry verifies admission before native import and rechecks bound artifacts
on each request. Native Python must come from the separately verified release;
a user-provided hash alone is not a code sandbox or approval of arbitrary code.
The native module's `main` is never called. The existing admitted adapter loads
episodes and returns before `train_stage`.

Six synthetic profile tests cover valid invocation, task/hash/protocol/argument
rejection and post-construction file changes. This is not yet evidence of a
real-Qwen request against a production native admission bundle.

## Remaining integration

## Native dependency recovery

The server native entry imported successfully without calling `main` or any
training function. Inspection found three missing reproduction files:
`route_specialists_se2_training.py`, `route_specialists_se2_models.py` and
`route_specialists_se2_cache_data.py`. They were copied unchanged from the
server's native source. Their SHA256 digests are respectively:

```text
6dec8e903327f6a31f8f7f9c37eaed3f75e7a4b17970399e083a69dc726badee
fc1e38759a9eb26fcc2fc704074664ee3d2ba05b59fd7b9f41e6b5dfc7e2fa97
082d5874f0d4d5ab1353adce2b16cdd356c42cf2b9236964622b9aba1ca92c4e
```

An isolated-process import test verifies that every loaded `brace_v4.*` and
`scripts.*` module comes from the bundled reproduction roots rather than a
legacy workspace. This verifies import closure, not training or label quality.

## Outstanding integration

Bind the verified native module and admission profile in the server launch
entry, run real-Qwen acceptance, and integrate source/SE1/SE2 receipts into the
same lineage. This adapter covers the admitted two-stage specialist family,
not every expert in the semantic library. Do not substitute it for incompatible
source-tail or RIS recipes.
