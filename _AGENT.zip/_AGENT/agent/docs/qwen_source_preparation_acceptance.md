# Qwen Source Preparation Dispatch

The existing Human lifecycle begins with an externally supplied foundation.
Source preparation is therefore bound to its `verify_preflight` tool, not
misrepresented as a route-expert `shadow_train` operation.

`HumanNativeInterceptBackend` verifies the external source-tool profile and
compiles the previously audited native source-entry check. It neither launches
that command nor produces a trained-parent receipt. It reuses SimulationBackend
and TaskWorkflowRuntime so task/state checks and memory recovery remain shared.

The tool profile pins the native script, recipe, frame manifest, dataset adapter,
binding module, audit script and required locator environment. Qwen does not
provide shell arguments or alter the recipe. UAV requests are rejected.

## Server Acceptance

Real Qwen2.5-0.5B with verified lifecycle LoRA was run on lab407 GPU3.

- Valid source profile: verified command receipt; monitor reached, 13 restores.
- Wrong source-profile hash: failed preflight receipt; rollback, 2 restores.
- Two dispatch unit tests passed locally.
- No sensing training, native subprocess or Test payload read occurred.

Evidence: `artifacts/pretraining_acceptance/QWEN_SOURCE_PREPARATION_20260908/`.
Driver: `scripts/check_qwen_human_source_preparation.py`.

This is narrow source-preparation dispatch evidence. Remaining lifecycle stages
use synthetic receipts and cannot authorize real promotion. Sentinel, full
SE1/SE2 and expert-native requests plus fresh-parent receipts still require a
combined real-Qwen acceptance run. Overall production readiness remains NO_GO.
