# Registered Mechanism Preparation

## Purpose

Check the real candidate trainer up to, but excluding, optimization. This is a
preparation boundary, not an alternate expert architecture or a training ticket.
It currently covers `angular_consistency_associator`, `echo_extent_disambiguator`,
`range_conditioned_tcn`, `tecs_candidate_attention`, and `local_shape_consensus`, whose original mixers
have been checked separately.
Other semantic entries remain unavailable through this preparation path until
their structural contracts have been reviewed.

## Execution Boundary

The existing `scripts/train_se_branch_route_expert.py` now accepts
`--prepare-only --device cpu`. All its normal required arguments still apply.
Preparation additionally requires `--parent-checkpoint-hash BRANCH=SHA256` for
all three competing parents, supplied from the independently pinned run profile.
Cache lineage itself has one dependency for CORA0/SE1, and three for composite
SE2. These arguments are hashes, not permission to load model files.
It also requires `--parent-selection-receipt`, its existing
`--parent-selection-sha256`, and independent `--support-scope-sha256`.
The mode validates semantic identifier, implementation identifier and route;
checks and loads manifest-declared cache members; splits Support by complete
sequence; checks replay disjointness and parent-branch agreement; constructs
the original registered model and resolves its application contract.

It then prints a JSON receipt and returns **before** the `train` call. It does
not create the requested training output directory, load historical weights,
perform an optimizer step, or save a checkpoint. Its authority is always
`PREPARATION_ONLY_NOT_PROMOTABLE` and `training_authorized=false`.

The original functions `episode_loss`, `production_objective_terms`,
`acceptance_target_from_preference`, `tensors`, `train`, and
`split_fit_calibration_episodes` remain AST-identical to the recovered historical
trainer. No loss, threshold, training schedule or model architecture was changed.

## Parent And Supervision Checks

Fifteen synthetic-cache tests cover the five reviewed mechanisms on each of
`cora0`, `cora_se1`, and `cora_se2`. The requested parent must agree with both
target Support and source replay payloads. The mode does not force SE2 as parent.
The tests exercise the actual CLI parser, cache loader, split helper and model
construction, with the optimization function prohibited.

Application-contract lookup in preparation mode explicitly uses the recovered
`reproduction/reference_sources/agent_expert_runtime_contracts` directory. It is
not a fallback search and does not restore old top-level execution authority.
Model and training functions still come from the current package. The first
independent-server check caught the former accidental dependency on local
top-level legacy configs (six failures); that failed release is retained.

Target Support carries candidate-set preferences; source replay carries
SourceBEV replay. No test reads actual source, target, Development or Locked Test
sensor data. Generated toy labels are not scientific evidence.

Four additional tests deny a mismatched implementation, unreviewed primitive,
wrong route, or GPU request before cache reads.

The real runtime exporter now captures hashes of all actual parent dependencies
before loading models, checks them again after export, and refuses to seal a
manifest if they changed. The manifest preserves this lineage. Preparation
compares both Support and replay manifest lineages with the independently passed
hashes before loading arrays. Missing ancestry, the wrong branch or a changed
SE1 dependency in composite SE2 are rejected. Old cache manifests without lineage
cannot pass this preparation check; do not backfill ancestry by guessing.

This is content identity checking, not proof that a caller's hashes are authorized.
The Dispatcher still has to bind those hashes to its current-run resource profile
and parent-selection receipt. `parent_cache_binding_verified=true` does not imply
`parent_selection_content_verified=true`.

## Open Security/Admission Boundary

The historical training path only checks the *format* of a parent-selection
digest and the *existence* of the EmptyGuard manifest. The new preparation path
replays the unchanged prospective selector and remeasures the selected parent's
Support summary from the exact hash-verified arrays it loads. It reports
`parent_selection_content_verified=true` and `selected_parent_support_recomputed=true`
only after those checks succeed. It does not remeasure the two unselected parents
or the empty-scene predictions; `empty_guard_content_verified=false` remains.

Do not convert this receipt to a production training ticket or interpret a
successful process exit as complete readiness. The Dispatcher still needs the
external, hash-bound parent/cache/label admission and EmptyGuard content checks.
The archive-only semantic wrappers and native Top-5 training guard remain
unchanged. A new real-Qwen invocation of this nested preparation boundary has
not yet been verified.

## Reproduce

```text
python -m pytest tests/test_registered_training_preparation.py tests/test_registered_mechanism_training_contract.py tests/test_route_runtime_manifest_loading.py -q
```

Scoped tests must include `tests/test_route_runtime_parentage.py` for the exporter
and cache-binding checks. This is a code/preparation result, not a
trained model result and not complete 42-expert readiness.
