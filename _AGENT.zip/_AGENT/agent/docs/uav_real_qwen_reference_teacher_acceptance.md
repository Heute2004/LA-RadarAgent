# Real Qwen Reference Teacher Command Acceptance

## Verified scope

Server inference used the existing Qwen2.5-0.5B model and verified lifecycle LoRA.
The adapter-model SHA256 is
`1c7455567685cc423482b4f068a894d7999257d1dc800d259c79a610c07bf4e2`.

The reference U0 prediction caches for 24 permitted sequences (7,200 frames)
were verified against the source/target frozen report hashes. Only frame ID,
predicted range, predicted angle, prediction score and radar health were copied
to the new caches. No truth arrays were loaded. Two newly inferred source
sequences were cross-checked: maximum range difference was 0.000000954 m,
angle difference 0.000006676 degrees, and health difference 0.000047386.
These comparisons do not establish fresh-training lineage.

| Real Qwen case | Observed outcome | Disk memory restores |
| --- | --- | ---: |
| Valid teacher and adaptation command preflight | Monitor reached | 12 |
| Invalid adaptation pseudo-label hash | Rollback at shadow_train | 10 |
| Invalid teacher command-profile hash | Rollback at weak_evidence, before shadow_train | 8 |

The valid weak_evidence receipt includes three native teacher commands with
`UAV_TEACHER_COMMANDS_INTERCEPTED`. No commands were launched. The LoRA manifest
and exact error messages were inspected after retrieving the reports locally.

Evidence: `artifacts/pretraining_acceptance/QWEN_UAV_TEACHER_REFERENCE_ACCEPTANCE/`.
Server reference index SHA256:
`b96cdb70b7c01b917247c9e8211dfa0afe05770f2e823c1a883b49a3e14c5109`.

## Not yet established

- This is reference-parent command verification, not a newly trained U0 handoff.
- Adaptation preflight still checks the registered historical pseudo-label CSV.
  It does NOT yet consume a teacher output produced by this run. The combined
  lifecycle therefore does not prove dynamic teacher-to-adaptation dataflow.
- Teacher source truth-loader interception and complete Doppler payload binding
  remain pending. Some unrecorded gate inputs were taken from pinned native
  parser defaults; they are documented, not claimed as recovered run arguments.
- Other scientific receipts remain explicitly simulated and non-promotable.
- Numerical reproduction, sensing training and Locked Test access were not run.

The two interrupted full-reference inference attempts are retained as partial
audit directories without a completed index. They must not be consumed as
complete teacher caches. Reuse of the hash-pinned original predictions avoided
unnecessary repeated inference; the successful two-sequence cross-check is
retained separately.

Overall pretraining acceptance remains incomplete. Next bind the intercepted
teacher output receipt to the adaptation input, then verify that missing or
foreign-run teacher outputs are rejected before training.
