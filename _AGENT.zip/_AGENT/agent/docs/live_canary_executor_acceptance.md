# Measured zero-weight Canary executor

The existing shadow-adaptation module now offers
`execute_model_zero_weight_canary`. It performs parent inference, candidate
inference and repeated parent inference using disposable evaluation models.
Registered parent parameters and buffers are compared before and after;
zero-weight logit/coordinate differences are measured by the existing array
executor. Nonfinite candidate outputs cannot be hidden by an assumed zero
weight. Empty samples are rejected.

Isolation is limited to registered parent state and repeated output. This
does not claim to audit arbitrary external files, services or hidden Python
state. Use disposable model instances, not deployment instances.

## Server reference execution

`scripts/check_source_tail_live_canary.py` reuses the existing native model
loader and raw radar dataset. It requires pinned parent, candidate and
source protocol and permits only source-calibration sequence membership.

On `lab407`, the pinned historical source-tail and its matched SE1 completed
four actual frames from `seq_042` (300 available). The test measured zero
coordinate/logit differences, unchanged registered parent state and repeated
output, and zero nonfinite outputs. This was CPU inference, not training.
The receipt is `artifacts/pretraining_acceptance/LIVE_SOURCE_CANARY_REFERENCE_20260909.json`.

Authority remains `REFERENCE_EXECUTION_NOT_PROMOTABLE`. The run read no
human labels, Development payload or Locked Test. Four frames do not prove
full-sequence or current-run candidate acceptance. A current-candidate,
complete-Support, production receipt consumer is still required before
changing the source-tail adapter from `pending_canary`.

The server release is `releases/live_canary_executor_20260909`, 1089 files.
Archive SHA256: `b82e82b00f075fcf4baa6b09f2380ef0cdc03a0b0c0e5c04b343c134c7d101d9`.
This documentation and the execution receipt were produced after packaging;
the final combined package must include them.

## Current-run receipt consumption

Source-tail audit now accepts an optional runtime Canary context from the
verified signed training result. The registered executor binds run, candidate,
route, native result and checkpoint, restricts scope/receipt files to the
candidate output directory, and verifies their hashes before dispatch.
Context-specific audit directories prevent a previous pending result from
being reused after new evidence arrives. The consumer additionally binds
parent hash and source policy, requires exact Support sequence/frame coverage,
and rejects reference authority, non-boolean guards and nonzero/nonfinite
identity measurements. The consumer code itself is pinned in both source
audit registrations.

Synthetic tests of this interface are explicitly contract tests, not observed
scientific results. The reference four-frame check is deliberately rejected
as admission evidence. No current candidate was promoted by these changes.

## Dispatcher producer integration

The registered Agent launcher now supplies `SourceTailCanaryProducer` using
the episode manifest's per-route Canary membership. For a source-tail result
without existing Canary context, the executor requests this producer before
invoking the native audit script. Qwen does not supply its measurements.

The producer verifies the signed training result, current candidate directory
and file hashes, recovers the parent from the exact signed
`--se1-checkpoint` argument, reuses the native model loader, and evaluates
every paired raw radar frame in the declared Support scope. It saves immutable
SCOPE, RECEIPT and CONTEXT files. Recovery checks original artifacts; partial
output cannot silently become success. Simulated training is rejected.

Tests cover complete producer execution with small substitute models,
recovery, wrong scope, simulated-training rejection and automatic dispatch.
These are workflow tests, not new-expert performance. No newly trained native
candidate is generated under this preparation-only goal. The source producer
is implemented; other native expert families still require equivalent
per-method integration and the full Qwen acceptance run remains pending.

## Episode-bound membership correction

The legacy indoor audit specified `seq_050`, whereas the active default
episode manifest declares `seq_042`. Both source audit registrations now
render their Support membership from the producer's validated episode map,
rather than embedding sequence IDs. The producer independently checks exact
membership before loading radar data. Missing episode resolution fails closed.
