# RIS H32 Catalog / Native Binding Audit

## Scope and Verdict

Audit date: 2026-09-10. Scope is the Human `corner_nlos_ris` entry
`ris_temporal_gate_h32` only. This audit read source, configuration, and
existing receipts on the local workspace and current server isolation at
`/home/hyc/radar+ris/AGENT-JSAC/releases/parallel_preparation_candidate_20260910`.
It did not load models, datasets, payloads, Locked Test material, or historical
weights; it did not run training or tests.

**Verdict: the catalog and native records have the same candidate ID, but the
native line is an explicit replacement, not an exact recovery of the registered
`risecho_temporal_gate_v1` implementation.** A source-only native directory can
be materialized from a fresh CORA0 parent when separately authorized, because
the recipe forbids historical checkpoint import. That would create a new native
candidate directory, not restore the original registered expert or establish
structure/loss/parameter equivalence.

## Identity and Source Recovery

| Item | Evidence | Result |
| --- | --- | --- |
| Catalog identity | `tasks/human/experts/library.json`: `expert_id=ris_temporal_gate_h32`, `primitive=risecho_temporal_gate`, `implementation_id=risecho_temporal_gate_v1`, route `corner_nlos_ris`, parent `cora0`, and `historical_checkpoint_import=false` | Exact catalog identity established. |
| Native identity | `configs/native_expert_production_lines_v1.json`: `candidate_id=ris_temporal_gate_h32`, `pipeline_family=ris_temporal_hard_gate_h32`, `parent_policy=fresh_cora0`, `status=active_search_candidate`, and `runtime_weight_before_promotion=0.0` | Literal candidate-ID match only. The native configuration does not carry the catalog primitive or implementation ID. |
| Recovered original source pair | `artifacts/pretraining_acceptance/EXPERT_EXACT_SOURCE_COVERAGE_20260910.json` records one matched receipt and no missing roles for H32: model `agent_expert_runtime_contracts/src/agent_jsac/registered_route_expert_models.py` SHA256 `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`; trainer `agent_expert_runtime_contracts/scripts/train_se_branch_route_expert.py` SHA256 `01a7aac1d09a5ec4bbc06b7bf0ae0d5bd739ecc6ffef01daf13ab22be91c02dd` | Source recovery pair is matched for the registered implementation. |
| Server confirmation | The same two recovered-source hashes were observed under the current server isolation. The original wrapper `scripts/route_experts/risecho_temporal_gate.py` is SHA256 `2feda021013baa21b501f1fe0d893572effd0c7f96686acc50e1cb7c9eced170` both locally and on that server release. | The registered wrapper and recovered source pair are preserved; this does not make the native implementation equal. |

`HUMAN_POOL_READINESS_CURRENT_20260909.json` labels the H32 native relation
`explicit_native_replacement`, records `historical_mixer_ast_equal=true`, and
does not authorize training. `EXPERT_CAPABILITIES.json` also prohibits automatic
substitution. These are the correct current relationship labels.

## Structure and Input Contract

The recovered registered model specifies H32 as
`_spec("risecho_temporal_gate_v1", "risecho", "gru", "codebook", "polar")`.
Its actual `RegisteredDiscreteCandidateExpert` accepts candidate tensors
`[batch, time, candidate, feature]`, candidate XY coordinates, and validity
masks. It builds token and polar-coordinate encoders, a shared GRU temporal
context, a `risecho` mixer, candidate score head, and acceptance head, returning
`candidate_logits` plus `acceptance`.

The source lookup resolves the declared `risecho` mixer to `_IdentityMixer`;
`codebook` is instead the gate-input branch. This agrees with
`HUMAN_ACTIVE_SEMANTIC_MIXER_INVENTORY_20260909.json`: actual mixer
`_IdentityMixer`, declared components `risecho/gru/codebook/polar`, and
`equivalence_verified=false`. As documented in
`docs/registered_structure_binding_review.md`, an identity mixer component is
not a claim that the complete registered network is identity.

The native H32 gate is `TemporalRISHardGate` from the V4 source. It accepts a
causal `[batch, time, feature]` sequence, applies a GRU and a LayerNorm/Linear
head, and emits one proposal-use logit per frame. Its architecture ID is
`V21-RIS-Temporal-HardGate-GRU-V1`. It requires a separately trained RIS shadow
adapter and later prediction freeze. It has neither the registered model's
candidate dimension nor its candidate logits/acceptance output contract.

**Structure verdict: not the same structure or input/output contract.** The
common words `RIS`, `temporal`, `GRU`, and the H32 candidate ID are not evidence
of equivalence.

## Script, Loss, Parent, and Parameters

| Aspect | Registered H32 evidence | Native H32 evidence | Comparison |
| --- | --- | --- | --- |
| Script | Catalog wrapper SHA256 `2feda...ed170`; recovered trainer SHA256 `01a7...c02dd` | V4 stages: shadow `2959d697...e9b71aa`, temporal gate `17c617b0...6d41e5`, freeze `2000ea4d...c2b9b2`; server V4 files match all three configured hashes | Not the original wrapper/trainer. |
| Loss | Recovered generic trainer's `ris_temporal_hard_gate` objective is legal set mass plus weighted preference CE (0.35), acceptance BCE (0.75), continuity (0.10), and identity regret (0.75). | `train_v21_ris_temporal_hard_gate.py` uses `binary_cross_entropy_with_logits` on a per-frame target. | Not the same loss. |
| Parent | Historical receipt records `parent_branch=cora0`; recovered trainer rejects RIS candidates unless their episodes bind the frozen CORA0 parent. Receipt parent-selection hash and policy are null. | Recipe uses `fresh_cora0` and consumes `fresh_cora0_checkpoint`; later stages also consume a newly created shadow checkpoint. | CORA0 policy name agrees, but exact parent artifact equality is unproven. |
| Parameters | Recovered trainer defaults: 24 epochs, hidden dim 64, LR 0.0003, weight decay 0.0001, replay weight 0.35, calibration fraction 0.25, harm budget 0.02, seed 3407. Historical receipt history begins near LR 0.0003 and ends at 0.0, but does not itself supply a sealed full command line. | Shadow stage fixes 20 epochs, batch 4, LR 0.0002, anchor confidence 0.45, stride 1, clip 16, hidden channels 32, recurrent channels 64, max delta logit 3.0, patience 5. Gate stage fixes hidden dim 32; its script defaults to 100 epochs, LR 0.001, batch 4, patience 15, seed 3407. | Not parameter-equivalent; exact legacy invocation remains unproven. |

The configured native `script_root` is `v4`. The server canonical V4 freeze
script has the configured `2000ea4d...c2b9b2` hash. The local convenience copy
`scripts/freeze_v21_ris_temporal_hard_gate_predictions.py` is instead
`dcd826ae...47ae2c`; it must not be substituted for the configured V4 stage.

## Qwen Evidence Boundary

The following reports contain H32-specific Qwen-assisted evidence:

| Receipt | H32 observation | What passed | Boundary |
| --- | --- | --- | --- |
| `QWEN_NATIVE_SELECTION_DAG_BINDING_20260909.json` | Selected-ID DAG includes H32; report `passed=true` | Candidate identity and intercepted scheduling | Scope says no live training; `legacy_42_pool_fully_bound=false`. |
| `QWEN_TYPED_NATIVE_REQUESTS.json` | H32 gate and freeze jobs compiled | Matching lifecycle row passed with real Qwen inference | Both jobs are `intercepted_not_executed`; `training_started=false`. |
| `QWEN_NATIVE_ADMISSION_BOUND_20260909/REPORT.json` | Same H32 jobs are present | 12 request cases passed compilation | `preparation_complete=false`, wrapper execution is not permitted, and no training occurred. |
| `QWEN_QUARANTINE_SELECTION_20260909.json` and `QWEN_NATIVE_RECIPE_SELECTION_20260909.json` | Catalog candidate with exact primitive and implementation ID was semantically retrieved | Semantic retrieval/selection | Reports explicitly deny executable-shortlist verification and promotion. |

Thus there is passed Qwen evidence for catalog selection, exact native candidate
ID handling, and command interception. There is no Qwen evidence that the V4
gate equals the registered architecture, loss, parent artifact, or training
parameters, and no successful preparation or model result may be inferred.

## Safe Mapping and Remaining Gaps

The only accurate mapping currently supported is:

```
ris_temporal_gate_h32 catalog entry
  -> explicit_native_replacement
  -> ris_temporal_gate_h32 native candidate
```

It is not an `exact_structure_recovery` mapping. The native directory layout may
be re-materialized without old H32 weights because both catalog and native recipe
set `historical_checkpoint_import=false`; however, the operation must remain a
fresh-CORA0 native candidate flow, with zero runtime weight until separate
admission. The historical native H32 run is reference-only: the existing server
acceptance note says its Fit/Selection split contains current support Canary
sequences, so it cannot supply a current-protocol success receipt.

Remaining blockers for any stronger claim:

1. No explicit cross-registry field binds catalog `implementation_id` plus
   `primitive` to the V4 candidate beyond the shared ID. Do not mark an exact
   recovery in `tasks/human/experts/library.json` or
   `configs/native_expert_production_lines_v1.json` without a source-bound
   transition contract.
2. The registered composite loss and V4 BCE loss differ. A replacement may be
   documented, but it cannot inherit registered-loss equivalence.
3. The historical receipt has no parent selection hash/policy and no sealed full
   legacy CLI. Do not infer exact parent artifact or effective legacy parameters;
   compare only after a source receipt explicitly records those values.
4. Qwen receipts are preparation/selection evidence only. Keep
   `runtime_weight_before_promotion=0.0`, `training_authorized=false`, and
   `preparation_complete=false` as the controlling boundary.
5. Resolve all native execution paths against the V4 script root and configured
   hashes, especially the freeze stage; do not silently use the divergent local
   convenience script.
