# UAV Original Handoff Authority

The user's clarification on 2026-09-10 fixes UAV preparation to the successful
route in `docs/handoffs/2026-09-08_UAV_TO_HUMAN_LINE_HANDOFF.md`.
Handoff SHA-256:
`c2ed621e549c46c786ecaaf4bd088acf2725eaae0bdaf0d8f8e67984d81c9efc`.
This clarification does not change Human scope or frozen numerical results.

## Authorized Method

- Source and unknown conditions use CORA-U0.
- A registered target condition with valid evidence uses the frozen-method
  coarse-set adaptation branch, initialized from CORA-U0.
- Missing evidence or runtime audit failure returns exactly to CORA-U0.
- UAV runtime contains no expert pool. The handoff records twenty expert
  candidates failing promotion; it does not say all later experiments failed.
- Inputs remain horizontal RA and RA-MTI, sixteen causal frames. Output is
  slant-polar state, not Human ground-plane BEV.
- Target supervision is radar-only candidate-set mass within a 1.5 m disk,
  with source supervised replay. The frozen evidence uses 600 target labels.
- Checkpoint selection uses support_dev OLS mAP@0.30:0.70. Development Query is
  postfit reporting only. Locked Test remains excluded.

## Existing Toolbox Binding

`tasks/uav/training.json` points to `scripts/train_cora_u_coarse_set.py`, not
the older `train_cora_u_se.py`. Its frozen parameter evidence and
`tasks/uav/provenance/frozen_route.json` preserve the original source checkpoint,
manifest, target pseudo-label hashes, supervision, selection and routing.
The active parser excludes Test postfit roles; no training was run to establish
that parser check.

The previously accepted reference-input tool interception remains valid within
its recorded scope. Reproduction preparation checks original scripts and their
dependencies; it must not invent a different evolution protocol or demand a
new experiment as a prerequisite for this handoff.

## Withdrawn Addition

The new `uav_fresh_lineage_preflight` module, its CLI, test and documentation
were not adopted by the user. Development was stopped. They remain on disk for
traceability but are explicitly excluded from the official package by
`EXCLUDED_UNADOPTED_UAV_LINEAGE`; they are not registered as UAV tools.
Any earlier audit describing this addition as mandatory is superseded by this
scope decision. This is not permission to fabricate missing files or receipts:
the existing original-method preflights still reject invalid assets.

Preparation and simulated execution do not prove a new trained-model result.
No model weights, sensor dataset, Test payload or revised result is introduced
by this authority note.
