# Native Source Completion Handoff

## Ownership and Boundary

Qwen requests the next workflow action. Dispatcher resolves paths, hashes and
run identity and invokes the registered tools. Qwen does not manufacture a
training receipt or edit native completion files. UAV never enters this path.

No action in this handoff starts training. An intercepted command is not a
completed training job. Simulated exercise results must stay on the simulation
path and cannot be normalized as actual training through this tool.

## Dispatcher Procedure

1. Obtain the current Human native execution plan and DAG state. Pin both
   complete JSON files, and the current native expert registry, by SHA256.
2. Select the completed `shared--source-tail--<route>` job for the current run.
   Require successful process completion evidence; do not infer completion
   from `best.pt` or a log message alone.
3. Invoke `scripts/collect_native_source_handoff.py` with the pinned files,
   exact job ID, current run ID and an unused output path inside that job's
   native output directory.
4. The collector checks job/command/completion hashes, registered trainer hash,
   exact parent hash, output containment and native completion contents.
   It creates an integrity-sealed handoff. It never imports a model, loads
   sensor samples, starts inference or grants promotion.
5. Materialize each selected candidate's policy using the existing policy tool.
   Bind it with `scripts/bind_source_policy_candidate.py`, pinning both the
   shared handoff and policy. Each candidate keeps the unchanged shared
   training evidence; do not copy or relabel weights as independently trained.
   For the completed five-policy DAG, prefer the batch collector
   `scripts/collect_source_policy_pool.py`. Supply pinned `--training-result`,
   `--execution`, `--dag-state` files with their corresponding `--*-sha256`
   arguments, five explicit `--candidate-id` arguments from the approved roster,
   and a fresh `--output` inside the run root. It verifies every policy job and
   the exact declared variant, and returns five candidate handoffs. Each entry
   contains `candidate_root` and `training_result`; pass that inner result to
   the existing Canary consumer. Do not pass the outer pool report as a model
   training receipt. Five policies remain one trained head, not five structures.
6. Pass the candidate-specific handoff and pinned external episode profile to
   `scripts/run_native_source_canary.py`. Metadata preflight is not a Canary
   pass. Real runtime evidence additionally requires `--execute-audit` and
   the declared Support-only raw radar scope.
7. Apply the existing label-free audit and promotion contracts. Neither the
   completion handoff nor a prediction freeze is a promotion receipt.

## Collector Arguments

Required pairs:

- `--execution`, `--execution-sha256`
- `--dag-state`, `--dag-state-sha256`
- `--registry`, `--registry-sha256`

Other required arguments: `--job-id`, `--run-id`, `--output`.

The trainer hash is resolved from the pinned native registry. It is not a
free Qwen argument. Existing outputs are not overwritten. Missing, pending,
failed, unbound, intercepted or simulated evidence stops the handoff; the
Dispatcher must retain the current parent and record the unresolved stage.

## Evidence and Limitations

Thirteen tests cover conversion, a synthetic Canary consumer, independent CLI
invocation outside the repository directory, and rejection paths. Fixtures
contain no trained model and use a stub executor. No sensing training, real
inference or Test reading was performed to verify this handoff.

This adds the missing callable converter. Automatic scheduling of these steps
inside the complete Agent DAG remains unverified; the tool contract deliberately
retains `automatic_dag_attachment_verified: false`. Completion-file checks and
process records are integrity evidence, not an independent proof of label
quality, actual numerical performance, or all input semantics. Existing label
and split admission checks remain mandatory.
