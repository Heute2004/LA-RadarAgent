# Native Label Recipe Replay Acceptance

## Verified scope

The server replayed the frozen native physical-candidate label recipe for 23
Train sequences (6,900 frames). The saved inputs, native builder, protocol,
manifest and split were hash checked. No training or target reference label
access was requested. The report records `test_read=false` and
`target_reference_labels_read=false`.

Evidence: `artifacts/pretraining_acceptance/NATIVE_LABEL_RECIPE_REPLAY_20260909.json`.

All sequences matched all ten fields: candidate posterior, allowed weight,
sample weight, selected index, selected coordinates, tier, identity mass,
forward/backward agreement, posterior margin and anchor index. Categorical
fields require exact equality; floating fields use atol=1e-6, rtol=0 with
equal NaNs. Input archives are rehashed after replay.

## Operational meaning

This verifies deterministic construction from saved teacher inputs. It does
not verify a newly trained teacher, new cross-fit predictions, geometric
accuracy, or a newly trained expert. `label_quality_verified` stays false.
The replay report is not a promotion receipt.

The native tier recipe uses probability, posterior margin and bidirectional
agreement. Historical Hit@0.30 admission thresholds require reference labels.
They must remain research audit criteria, not become label-free runtime gates.
Do not relax or silently replace them with coverage or recipe parity.

## Reproduction entry

Run `scripts/audit_native_label_recipe_replay.py --help` for pinned manifest,
protocol, native builder, split and fresh-output arguments. Execute on the
server with the preserved native dependency source available. This entry
performs label math only and never invokes the builder's training main.

## Remaining preparation

Bind fresh teacher/cross-fit output lineage to the current run; validate the
method-specific observable metric producers and approved admission profile;
then test the complete positive Qwen-to-native-trainer interception. Existing
real-Qwen legacy rejection and recipe parity are separate subchecks, not full
end-to-end numerical reproduction. Human and UAV retain separate contracts;
UAV must not request expert training.

## Cross-fit metadata audit

`REFERENCE_CROSSFIT_LINEAGE_AUDIT_20260909.json` verifies all four preserved
checkpoint contracts, fold membership, source replay exclusion declarations,
and teacher hashes for the 21 sequences using cross-fit teachers. Two clean
sequences use SE1 directly and are not counted as cross-fit predictions.
The four holdouts jointly cover 23 sequences without duplicate membership.
No test sensor data was read; test identifiers were read as exclusion metadata.

The preserved teachers record SE1 hash
`cbdb64eacae9d3e33b1345f26fb0dbed97a3aca46dc35c7a4f73cab257b065b3`.
This differs from the newly bound reference feature export's SE1 hash
`063401c71039b7664537febfc0517c2fb575fb4835ae81fda7cbd651b971b9f7`.
These are separate teacher and student/feature-export lineages, not evidence
of a single newly generated run. Their use together requires explicit declared
roles; they must never be silently relabelled as fresh teacher outputs.

The recovered native cross-fit trainer loads CORA0 and SE1 and passes them to
`stage_b`. Inspection of `train_cora_se2_r11_setmass.py` confirms that stage_b
creates `initial_adapter(device)`, which constructs a new adapter. It does not
load the parent SE2 state. `target_setmass_loss` nevertheless reads the shared
SE1 logits for consistency supervision. Thus this is adapter-level cross-fit
with a shared upstream weak teacher, not fully out-of-fold teacher ancestry.

The actual preserved SE1 checkpoint hash matches the four fold contracts. Its
metadata records 6,900 target fit frames / 315 accepted anchors, 2,400 internal
calibration frames / 69 accepted anchors, source replay and empty negatives.
Target Final-BEV, depth and Locked Test reads are recorded false. Its weight
soup additionally records `selection_scope=development_only_after_frozen_training`.
That historical selection must remain visible: this asset is a reference
reproduction teacher, not a new prospectively selected teacher. These metadata
checks cannot prove all historical reads; the referenced target_fit manifest
at its original server path is currently absent. No missing manifest was
fabricated or silently substituted.

For a fresh prospective run, bind that run's SE1 output and newly built label
inputs. Preserve the same adapter-level algorithm and explicitly declare the
shared teacher. Do not claim full out-of-fold independence, automatically
promote based on historical Development selection, or change the old result.
