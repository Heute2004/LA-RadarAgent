# Nested native preflight findings

## Evidence and correction

The first all-route scan compiled six routes and thirty candidate requests.
That result checked only outer commands. Several jobs call
`dispatch_native_expert_stage.py`, which constructs their actual trainer
commands later. It was not evidence that those internal trainers passed label
admission. Retain the original report as a scoped negative control.

The preflight now resolves each registered Dispatcher job using the verified
candidate plan and rebound run context, without executing the Dispatcher. It
validates the unique candidate, stage bounds, context identity and output
containment, then checks every resulting native command. Optional specialist
bindings apply to the resolved command, not the wrapper name. Wrappers remain
non-executable provenance in this interception report.

## Server results

- Release: `nested_route_preflight_candidate_20260909`.
- ZIP SHA256: `0efea06f5f83b087ff43bea99b5d6c5d427dc5473bee41d96ebb3121ae4acf78`.
- Full regression: 367 passed in 13.41 seconds.
- Native command scan: five routes compiled, one rejected; overall NO_GO.
- Rejected route: `outdoor_wet_return`.
- Reason: `reference-label postfreeze admission cannot authorize prospective expert training`.
- Evidence: `artifacts/pretraining_acceptance/NESTED_ROUTE_NATIVE_PREFLIGHT_20260909.json`.

Five successful command plans do not prove their training datasets, quality
gates or optimization bodies are accepted. This remains a pretraining command
audit, using verified reference parents, not a fresh trained lineage. No
training processes were launched and no Locked Test payload was read.

## Next work

### Native argument declaration audit

`scripts/audit_native_argument_declarations.py` statically parses trainer source
without importing it. A sentinel regression script that raises immediately is
parsed successfully, demonstrating that the auditor does not execute it.
On the server, 67 resolved commands from the five compiled routes have zero
unknown statically declared flags. Each inspected script and the input report
are SHA256-bound in `NATIVE_ARGUMENT_DECLARATIONS_REPRODUCIBLE_20260909.json`.
The rejected wet route is explicitly excluded, not counted as accepted. This
does not verify dynamic defaults, dataset contents, optimizer behavior or
promotion quality. Further trainer-family payload interception remains needed.

### Executable Dispatcher checkpoint

The executable Dispatcher now resolves and guards native commands before
consulting any historical admission boolean or creating output/receipts.
Regression cases with both admitted=true and admitted=false reference audits
fail before the old decision helper or subprocess runner is called. Negative
stage indices are also rejected explicitly.

Independent packaging exposed a missing Dispatcher script: prior command plans
named an entry absent from the release. The Dispatcher, source-tail policy
materializer and physical-runtime exporter are now included. The first package
failure is retained; the corrected server package passes 369 tests in 13.29s.
All 12 outer script paths referenced by the 87-job reference plan exist in the
current server/source roots. This existence check is not a nested payload audit.

Corrected release: `dispatcher_admission_complete_candidate_20260909`.
ZIP SHA256: `6b1b674b835f5fe5f65375187c0e15d5cfbd9364bb2ff3034f8b758434596226`.
Regression receipt:
`artifacts/pretraining_acceptance/DISPATCHER_ADMISSION_COMPLETE_REGRESSION_20260909.json`.
The original numerical protocols and frozen artifacts are unchanged. The
prospective wet-route admission remains pending, not implicitly approved.

Bind the wet route's native specialist job to an approved reference-free
admission bundle; preserve its original arguments and set-valued supervision.
Also inspect the executable Dispatcher path before making production claims:
preflight protection alone is not proof that every launch path is guarded.
Do not copy historical reference-label admission booleans into a new weak-label
receipt or silently invent pending quality thresholds.
