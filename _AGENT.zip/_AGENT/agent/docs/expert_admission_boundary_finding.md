# Reference-Audit Admission Boundary

Status: unresolved production adapter requirement; historical results unchanged.

Inspection of the actual lab407 source confirmed that
`audit_r31_postfreeze_labels.py` computes route admission using Hit@0.30 against
Train reference labels, after pseudo-label freezing. The native
`train_r31_route_specialist.py` requires that audit schema and its
`admitted_for_expert_training` flag before training.

Verified server source identities:

- Audit: `5194c07fb31397c9e553b508b3c950adbb3281321834ca7228f33e5f691228ad`.
- Trainer: `a07dda3cab46930f28654d909c983ac3f82490f95f8ced2d56953e624efd370f`.

This does not prove pseudo-label construction used target labels or that Test
was read. It does prove this particular training-admission decision is not
target-reference-free. Command compilation alone had not exposed this semantic
dependency. Previous compilation evidence must not be treated as autonomous
label-free expert training acceptance.

The new Human preflight calls `guard_expert_training_admission` and rejects that
native path. Renaming the audit schema is also rejected because the unchanged
trainer cannot consume a verified weak-only admission contract. Three local
tests cover the known audit, renamed audit and unrelated-tool preservation.

Scope: this guard protects the no-training native preflight entry. The legacy
direct executor is NOT thereby certified safe; it must remain disabled for the
new workflow until its admission adapter is actually implemented and tested.

Required repair: separate diagnostic reference audit from the operational
training authorization; bind the latter to existing predeclared weak evidence,
source replay and empty-safety checks. Keep the same label payloads, candidate
models and training recipe where compatible. Do not fabricate passing Hit@0.30
or silently lower thresholds. Test both accepted and rejected tool requests and
record the method difference from the historical supervised admission gate.
