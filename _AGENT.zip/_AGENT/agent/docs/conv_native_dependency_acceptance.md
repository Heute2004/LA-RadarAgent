# Native Conv Dependency Acceptance

## Changes

The source collector now accepts explicit project roots rather than only two
hard-coded directory names. It traverses local Python imports and package
initializers without importing or executing them. Paths resolved outside the
declared root are rejected or excluded; duplicate root archive names fail.
Archive paths under explicit roots are canonical rather than inherited aliases.

Two new tests failed before the repair and passed after it. Together with the
existing subprocess-script-reference tests: **4 passed** locally.

## Recovered Closure

- Original server project: `/home/hyc/radar+ris/code_radar_cbpr_v1_20260805`.
- Explicit requests: 19 Python files.
- Local source closure: 41 Python files, zero missing requested files.
- Archive: `CONV_EXPERT_SOURCE_CLOSURE_20260909.zip`.
- SHA256: `b7ac29afbe4eec0fa38bce2dc93178e62a0e7afb44c3d67beb5a3c8f1ed7765c`.
- Source copies: `reproduction/reference_sources/code_radar_cbpr_v1_20260805`.
- Provenance: `reproduction/reference_sources/CONV_SOURCE_COLLECTION_MANIFEST.json`.

The closure includes imported backbone and trainer dependencies; 41 files do
not mean 41 independent experts. Code only: no weights, sensor arrays or results
are imported as expert assets. Historical filenames remain intact for provenance.

## Independent Server Check

`artifacts/pretraining_acceptance/verify_conv_source_closure.py` pins the archive
hash, verifies every source hash, extracts into a new directory and runs seven
recovered test files. It disables CUDA, external pytest plugins, checkpoint
load/save, NumPy array loading, DataLoader iteration and optimizer updates.

Server output: **27 passed in 5.75 seconds**.
Local receipt: `artifacts/pretraining_acceptance/CONV_NATIVE_HEAD_ACCEPTANCE_20260909.xml`.
Server directory:
`/home/hyc/radar+ris/AGENT-JSAC/artifacts/CONV_NATIVE_HEAD_ACCEPTANCE_20260909`.

Tests use synthetic tensors only. They cover native head output shapes, zero
initial residuals, mixture normalization, recovery/gain parameter freezing,
candidate layout and helper behavior. A few archived tests exercise synthetic
RD helpers; this does not authorize adding RD to the production input contract.

## Not Proven

- End-to-end training, accuracy, convergence or frozen-result reproduction.
- Native structure equivalence for all 42 current semantic IDs.
- Current weak-label contract compatibility of old trainers.
- Executable Top-5 bindings or promotion authorization.

These sources remain references outside the executable catalog. Overall
pretraining acceptance is still NO-GO. The next required step is source-level
structure binding and explicit weak-supervision adapters, not immediate training.
