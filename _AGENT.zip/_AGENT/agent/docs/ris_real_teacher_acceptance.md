# RIS Reference Teacher Compatibility

The native H16/H32 shadow teacher interface was checked on the current
prospective support split, not the earlier 11-sequence training partition.
Fit contains six sequences; internal calibration contains two. The audit read
all 2,400 native causal clips and all 4,800 RA/RA-MTI arrays. Selected candidate
indices, observed-candidate masks, confidence, finite values, dimensions and
cache hashes passed. The native Python sources and CORA0 file hash matched.
No model was loaded and no optimizer or training loop was invoked.

Evidence: `artifacts/pretraining_acceptance/RIS_CURRENT_TEACHER_TENSOR_AUDIT_20260910.json`.
The reproducible runner is `scripts/audit_ris_native_teacher_preparation.py`.
Its NumPy read guard permits only current Fit/Calibration cache and feature
paths. Development, canary and Locked Test payloads are not admitted.

## Recovered provenance sidecars

The server feature folders omit source metadata JSON. Existing local feature,
state and receiver JSON were recovered for exactly the same eight sequences.
All 4,800 local feature hashes matched the server audit before packaging.
The 24 original JSON files are preserved byte-for-byte in the independent
`RIS_SUPPORT_SOURCE_SIDECARS_20260910.zip` archive. Server verification checked
every member hash and the parent audit report hash. Neither source datasets
nor metadata path strings were rewritten.

Archive SHA256:
`b7bc94dc8c97210b871a3de0f14361e478c8d69553d39e4f4a7d71f50ba02c50`.

These records describe virtual, generator-truth-coupled, direct-equivalent
receiver data. They do not prove new physical hardware measurements, recreate
ADC propagation or remove the codebook expert quarantine. The historical
post-freeze aggregate audit was inspected during discovery but is not used
as selection evidence or a new performance result. No Test payload was opened.

## Remaining integration boundary

The real compatibility evidence complements, rather than changes, the Qwen
synthetic batch receipt. That receipt remains non-promotable. The public
`bind_semantic_shortlist` dispatcher now accepts the exact five authorized RIS
IDs and dispatches their distinct profile bindings. A missing or substituted
ID is rejected. The mixed Qwen backend uses this public entry. Final package
acceptance must verify this updated entry and retain the native data and
simulation scope distinctions.

The public-entry server regression passed 22 tests. Real Qwen again reached
monitor for the complete batch and rollback for missing H16. The raw evidence
is indexed in `artifacts/pretraining_acceptance/ris_public_qwen_actual_20260910/EVIDENCE_INDEX.json`.
The later task-selection run also exercised real Qwen selection before public
dispatch; all five IDs were returned, prepared, and preserved in memory. Its
complete request reached monitor and missing H16 reached rollback. Evidence:
`artifacts/pretraining_acceptance/ris_task_selection_standalone_actual_20260910/EVIDENCE_INDEX.json`.
This adds selection-to-dispatch evidence, not scientific ranking accuracy.
