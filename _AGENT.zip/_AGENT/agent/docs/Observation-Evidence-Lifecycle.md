# Observation-Evidence Lifecycle

## Scope

The UAV lifecycle is an executable observer-to-tool workflow. InternVL supplies
only its trained scene-condition fields. Qwen requests registered tools; the
dispatcher validates identities, evaluates authorized evidence, writes typed
memory and applies the numeric promotion policy. No UAV expert library is used.

The current acceptance used cached real InternVL observations and actual Qwen
CPU inference on the server. Previously completed real training was reused.
Human protocols, model weights, datasets and Python environments are not changed
by this acceptance. All external resources must be explicitly bound by hashes.

## Evidence and Reproduction

The executable entry point is `extensions/uav_observer/run_observer_agent.py`.
It requires `--config`, `--config-sha256` and a new `--output` directory. The
configuration pins the external manifest, observer responses, source and adapted
weights, native training receipt, teacher receipt, Support-dev metrics, shadow
receipt and authorized promotion policy. Do not change paths without rebuilding
and verifying the corresponding bindings. Never reuse an existing output path.

The successful execution is recorded under the external artifact root at
`artifacts/observer_decision_workspace/numeric_policy_qwen_acceptance_canary_bound`.
Its `closure_receipt.json`, `tool_receipts`, `qwen_traces`, `memory` and
`runtime_route.json` jointly establish the execution. The earlier failed attempt
at `numeric_policy_qwen_acceptance_20260911` is retained, not overwritten.

The ready configuration is pinned by SHA256
`c8cea6f7315477f17a575c89d3d970eea78534a41b67acc8206b3f4e8323d36a`.
The resulting isolated registry is pinned by SHA256
`8ad752bb97cf4c8fb7e711e18502b18fabd040c3e67efe3c06c9f2eafcca377b`.
The registry selects the trained candidate with SHA256
`5b7421d4fbe4d58682e51bee3169941acb08a874b86d6f176cf4ec3b2d8e1844`.

## Numeric Decision

Compare parent and candidate on the same 900 Support-dev frames with the native
UAV evaluator. The authorized development amendment requires OLS mAP over
thresholds 0.30-0.70 to increase by at least 0.01, with no decrease in OLS mAP
over 0.20-0.50 or Hit at 1.5 m. This amendment is not a historical threshold or
retrospective preregistration. The policy cannot be edited by Qwen.

The recorded values are:

| Metric | Parent | Candidate |
|---|---:|---:|
| OLS mAP 0.30-0.70 | 0.4179595381852417 | 0.5767114295937303 |
| OLS mAP 0.20-0.50 | 0.6491605827343259 | 0.8136016165081007 |
| Hit at 1.5 m | 0.62 | 0.6466666666666666 |

These are development selection values from an existing trained model, not
Locked Test values or gains caused by rerunning the decision controller.
The selection set pools Support-dev sequences 44, 70 and 79 from the two
registered target sites. It is not a per-site improvement estimate. The current
single invocation writes only the `site_scut14` registry; other target sites
require their own authorized registration, not a global reuse of that entry.

## Guards and Limitations

- Support-dev sequences 44, 70, and 79 are aggregated across two target sites;
  they are not evidence of a site-specific uplift for either site. The current
  successful invocation registers the adapted model only for `site_scut14`.
  That single-site registration is not global authorization and must not be
  transferred to other sites.
- Promotion applies only to the authorized target site; source and unknown
  sites must retain Source fallback. Do not apply this single-site registry
  globally without a task-aware resolver.
- Shadow checking reads saved prediction arrays only and keeps candidate weight
  at zero. It is not a live deployment safety trial.
- The terminal monitor verifies registry identity, not radar inference quality.
- Missing or mismatched evidence must reject execution, not weaken the gate.
- Target RTK is not admitted to pseudo-label generation or training. Only the
  authorized Support-dev evaluator uses its permitted evaluation truth.
- Cached observations and reused training receipts cannot establish online VLM
  latency, fresh-training GPU-hours, independent adaptation, or memory benefit.
- Functional acceptance and scientific attribution are separate. Preserve
  neutral results and missing evidence in the experiment delivery.

The immutable historical release remains unchanged.

## Registered Model Execution Check

After registration, the adapted checkpoint was loaded with a strict state-dict
check and executed on three Support-train frames of sequence 43 on the server
CPU. All prediction fields were finite. This check used no truth, performed no
training, and changed neither the registry nor the promotion decision.
The receipt is `numeric_policy_registered_runtime_smoke_adapted_seq043/receipt.json`
under the external observer-decision evidence workspace. It records the
checkpoint, manifest, registry hashes and the registering tool-run identity.
The measured inference section took 6.785864 seconds for three frames; this is
a bounded CPU smoke measurement, not deployment FPS or end-to-end Agent latency.
It establishes executable registered-model routing, not detection accuracy.
