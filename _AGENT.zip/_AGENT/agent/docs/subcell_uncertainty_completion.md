# Subcell Uncertainty Refiner Completion

## Provenance and intent

The catalog promises sub-cell correction with covariance, but its historical
registered wrapper returns a discrete candidate and token-variance gate. The
new `agent_jsac.subcell_uncertainty.SubcellUncertaintyRefiner` completes the
promised mechanism. It is not claimed to be a recovered frozen architecture.
It preserves the registered temporal-convolution design, rather than renaming
the historical continuous GRU model as this expert.

## Input and outputs

- Contiguous local parent-peak features `[B,T,D]` and parent position `[B,T,2]`.
- Positive metric cell sizes `(dx, dy)` from the selected parent's BEV geometry,
  never assumed constant across datasets.
- Left-padded temporal convolution; independent calls reset history.
- `offset_m = (cell_size_m / 2) * tanh(offset_head)`.
- Positive diagonal variance `[B,T,2]`, separate acceptance and shadow proposal.
- `final_xy` remains the exact parent position. No promotion API is exposed.

## Supervision

Reuse the existing audited `source_clor_masked_loss` for authorized Source
coordinates: SmoothL1, Gaussian NLL, acceptance and valid-pair motion terms.
Synthetic backward tests verify nonzero finite gradients for offset and
covariance heads without any optimizer or parameter update. Invalid or target
coordinate-supervision roles are not admitted by this objective.

## Outstanding integration

`source_subcell_uncertainty` now dispatches a preparation-only profile through
the same specialist entry. It reuses source frame/hash/partition validation and
independent parent-selection replay, not the CLOR model or its trainer. The
profile has exact keys `task`, `mode`, `native_method`, `source_inputs`, `geometry`.
Geometry is a separately SHA-bound JSON with Human task, selected parent branch,
parent checkpoint hash and two metric `cell_size_m` values. Invalid geometry
fails before source label reads. Features are the existing parent slot-zero
features; this is not evidence of a new dense ROI extractor.

Only CPU initial fit/calibration forwards and source loss are evaluated. The
receipt records inherited source-input validation separately; its original CLOR
training metadata is not authorization to run a CLOR optimizer for this expert.
Model-provided arguments cannot override the fixed Dispatcher profile.

`shadow_subcell_readout` now provides the explicit continuous shadow contract:
validate all proposal coordinates (including rejected ones), probability range,
shape/device agreement and per-axis half-cell bounds; choose the proposal only
above a supplied source-calibration threshold. The returned `final_xy` is always
bitwise parent identity. `is_observed_radar_candidate=false` prevents describing
the interpolated output as a measured RA peak. Preparation tests threshold 0.5
only as an initialization diagnostic, not as a selected deployment threshold.
Floating-point roundoff tolerance scales with coordinate magnitude and dtype;
it is not a physical motion-budget relaxation.

The catalog's old `exact_observed_candidate` application contract cannot apply
to a continuous sub-cell refiner. Do not wire this module into that readout.
Production admission requires a profile-bound source feature/geometry loader,
continuous bounded application contract, source/empty safety evidence, and
server/Qwen preparation acceptance. Registry name/count and frozen results are
unchanged until those bindings are complete. No result metrics are claimed.
