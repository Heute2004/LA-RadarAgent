# Native candidate payload acceptance

## Verified scope

On 2026-09-09 the hash-registered native `train_r11_pca_specialist.py`
`require_protocol` and `load_record` functions were called directly, without
calling `main`, constructing an optimizer or running backward. Reference caches
were read from `native_agent_base_expert_reselection_20260831/shared` on the
server. These are explicitly historical reference caches, not new outputs.

Four mechanisms passed native payload checks over their 21 Train sequences
each: physical candidate association, echo morphology, factor graph and N-scan.
This is 84 mechanism-sequence checks, NOT 84 unique sequences. Each uses its
own unchanged registered protocol and Fit/Calibration membership.

Checks included:

- Native schema, sequence and route validation;
- Per-file SHA256 before and after loading against the cache manifest;
- Disjoint protocol Fit and Calibration lists;
- Finite nonnegative sample and target weights;
- Zero target mass on invalid candidates;
- Unit target mass for positively weighted frames;
- Native echo patch shape and N-scan bidirectional agreement requirements.

The PCA manifest's CORA0/SE1/SE2 hashes match the verified reference execution
context. The N-scan manifest points to that exact PCA manifest. This is a
manifest dependency match, not independently recomputed features or a fresh
training ancestry claim.

## Evidence

- `artifacts/pretraining_acceptance/PCA_NATIVE_PAYLOAD_AUDIT_20260909.json`:
  63 successful checks; one echo configuration-path lookup error.
- `artifacts/pretraining_acceptance/ECHO_NATIVE_PAYLOAD_AUDIT_20260909.json`:
  21 successful checks using the actual registered echo protocol name.

The lookup error remains in the first report. It was not a training failure or
bad dataset and must not be erased from the audit trail.

## Outstanding scope

No target accuracy was computed and no promotion authorized. This does not
certify fresh cache generation, all other specialist families, quality-profile
authorization, or a complete autonomous training trajectory. No Development or
Locked Test payload, target Final-BEV, depth or RGB was opened by this check.
