# Native Safety Integration Map

Use `tasks/human/experts/native_training_recipes.json` as the task inventory.
The top-level legacy production configuration is not interchangeable with it.
Run `scripts/audit_native_safety_coverage.py` with `PYTHONPATH=src` to regenerate
the pinned inventory. The script imports no trainers and reads no data payload.

The current 30 candidate recipes contain training, calibration and prediction
freezing stages, but no explicit audit/Canary stages. This is a wiring gap, not
proof that the training scripts contain no internal quality checks. Existing
same-route registered audits are references only: schema compatibility and
candidate/parent binding must be established before reuse.

| Native training family | Candidate occurrences | Required integration |
|---|---:|---|
| Physical candidate association | 8 | Native result and parent binding; candidate selection safety |
| Branch stability | 1 | Branch and teacher lineage; selected-parent identity |
| Route specialist | 3 | Native set supervision receipt and runtime residual safety |
| Source tail | 10 | Reuse SourceTailCanaryProducer with each candidate's signed result and episode scope |
| Branch router | 1 | Upstream branch results and runtime selection identity |
| Route set-mass | 3 | Training plus calibration result binding and gate identity |
| RIS shadow adapter | 5 | Bind shadow checkpoint into the following hard-gate stage |
| RIS temporal hard gate | 5 | Reuse RIS runtime audit with exact current parent, protocol and disjoint scope |

Occurrences exceed 30 because a candidate may contain multiple training stages.
No row is an authorization to substitute one family's audit for another's.

Each candidate must have: signed native training result; fresh checkpoint and
selected-parent hashes; permitted independent scope; method-specific admission;
actual zero-weight runtime measurement; and auditable final selection. During
pretraining acceptance, intercepted fixtures may exercise this chain, but must
remain simulation-scoped and cannot authorize numerical or deployment claims.

The pool Development selection adapter is diagnostic-only. It must not be used
as the missing safety audit. The active remaining task is connecting these
families to the existing Dispatcher audit lifecycle, not changing thresholds.

## Source Tail Bridge

`scripts/run_native_source_canary.py` now exposes the existing
`SourceTailCanaryProducer` as a native tool. Default mode is metadata-only.
`--execute-audit` performs model inference, never training, and requires the
producer's signed actual current-run training result. Input JSON hashes are
mandatory. The external episode profile has `task: human` and `routes`, with
`support_fit`, `support_calibration`, `support_canary`, `development`, and
`locked_test` lists per route. Canary must be nonempty and disjoint from the
other roles. No sequence IDs are hardcoded in the bridge.

This is a callable adapter, not yet an automatically inserted DAG stage. The
native result must first be wrapped by the signed-result authority and its
output path bound to the current candidate. Do not pass a raw training JSON or
rewrite historical identities to satisfy that requirement. Pretraining fixtures
and producer-spy tests do not establish model-level Canary performance.
