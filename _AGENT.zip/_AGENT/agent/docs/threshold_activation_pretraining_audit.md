# Threshold activation pretraining audit

## Verified scope

The threshold loader now rejects an explicit activation status other than
`active`, including `alignment_pending`, `draft`, `disabled`, empty and null.
Five negative tests failed before the repair and pass afterwards. Existing
profiles without this optional field remain compatible; absence is not a new
authorization. Dispatcher binding, scope and required-metric checks still apply.
No metric value or promotion tolerance was changed.

## Unresolved production binding

The Human task still declares `external_human_threshold_profile_required`.
Its promotion reference is explicitly `alignment_pending`. The calibrated
profile template contains placeholders; the other packaged profile is for
historical replay integrity, not weak-label acceptance or expert promotion.

Do not activate the reference by renaming its status, infer route-level gates
from per-frame teacher tiers, or use reference-label Hit scores as live weak
supervision gates. Recover the approved operational profile and bind its exact
scope and evidence producers before granting production readiness.

## Evidence boundaries

The server native joint/set loss check passed for 23 Train sequences without
backward or optimization. This verifies consumption, not label accuracy or
promotion. No Locked Test payload was read. The broader preparation goal is
still open; these checks alone do not authorize training.
