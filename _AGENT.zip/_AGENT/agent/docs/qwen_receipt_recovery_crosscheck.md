# Qwen Receipt Recovery Crosscheck

## Scope

This is a control-plane-only acceptance cross-check rooted at
`H:/Project/AGENT-JSAC`. The test reuses the existing
`TaskWorkflowRuntime`/`SimulationBackend` fixture and the current
`ToolDispatcher`/`TypedMemory` persistence and lifecycle logic.

The test does not call real Qwen, start a subprocess, read `models/` or dataset
data, load a checkpoint, or train anything. The registered backend in the new
test is an in-memory synthetic double. Human-stage packaging is outside this
cross-check.

## Safety Cases

| Case | Synthetic fault | Required outcome |
| --- | --- | --- |
| Wrong task | A UAV simulation receipt changes `task` while claiming success. | Reject the receipt; append no runtime record and do not advance state. |
| Old receipt | A restarted Dispatcher receives a receipt carrying a different, old `tool_run_id`. | Reject it; keep the stale pending record unchanged and do not adopt it. |
| Wrong hash | A recovery receipt carries a non-SHA256 `result_json_sha256`. | Reject it; do not attach `verified_recovery_result_sha256`. |
| Explicit restart recovery | After a synthetic lifecycle-commit crash, a new `TypedMemory`/`ToolDispatcher` explicitly recovers the persisted result and retries the training action. | Adopt the verified result, pass `recover_existing=True` on continuation, complete the lifecycle, and clear the pending execution. |
| Adopted digest drift | After adoption, the backend returns a different but still valid lowercase 64-hex `result_json_sha256`. | Reject it; preserve the pending record and the originally adopted digest. |
| Unverified recovered flag | The backend ignores `recover_existing=False` and returns a valid receipt with `recovered_existing_result=true`. | Reject it; do not advance the candidate or attach a verified recovery digest. |
| Same-session duplicate recovery | A synthetic tool result exists after a lifecycle commit crash, then the same session retries while the backend requires explicit recovery for the existing result. | It must not become a successful lifecycle commit; the candidate stays Shadow and the pending execution remains. |

The target cross-check contains seven cases: one positive restart-and-continue
path and six fail-closed paths. The explicit recovery call is the only path
that may adopt a stale registered result; continuation is accepted only when
the receipt remains bound to the pending run and the adopted digest.

## Verification

Target-only command run from the repository root:

```powershell
$env:PYTHONPATH = "H:\Project\AGENT-JSAC;H:\Project\AGENT-JSAC\src;H:\Project\AGENT-JSAC\tests"
& D:\anaconda3\envs\vlm3b\python.exe -m pytest -q tests/test_qwen_receipt_recovery_crosscheck.py
```

Observed result:

```text
7 passed in 1.74s
```

The registered backend is synthetic and no `registered_training_smoke` test
was run. No production file was edited by this cross-check.

The requested broader four-file command was also run. It produced `21 passed,
14 failed in 4.04s`; all 14 failures stop in Human-stage preflight at the
existing `Asset drift: tasks/human/supervision/tools.json` check before their
workflow assertions. The target cross-check plus the Memory/Dispatcher tests
alone produced `19 passed in 2.76s`.
