# 42 专家历史训练溯源补充查证

查证日期：2026-09-09。性质：有界、只读、元数据级追溯；不是训练验收、结构等价验收或部署批准。

## 结论与计数

- 原 42 个 identifier 全部保留，未改名、未改结构、未重写或替换任何生产脚本。
- **41/42 有历史训练完成留痕**：依据小型 TRAINING_RECEIPT.json 的 completed_utc、模型/primitive 字段和部分启动回执，而不是同名代码。共读到 42 份用于逐项计数的回执，state_consistent_local_refiner 两路线去重后计 1。
- **30/42 有本次逐路线核对的成功启动回执 + 完成回执**：expert_pool_42_training_20260901 六路线各 5 项。每路线 LAUNCH_RECEIPT.json:2 均为 all_succeeded=true，各 job returncode=0。
- 另外 **11/42** 从 20260826 的旧池（7 项）及 20260828 扩展批次（4 个唯一 identifier）补齐完成留痕；不把所有这些项一概称为本次逐 job 核验了启动命令。
- **1/42 未确认训练留痕**：risecho_geometry_consensus。在下述有界位置没找到，不等于证明从未训练。
- 在选用的 41 个证据链中，**33 项回执标识 registered 家族，7 项只有旧 local/attention/temporal/graph 家族，1 项 GBLE 为 branch_router recipe**。因此“所有历史训练都统一为 RegisteredDiscreteCandidateExpert”也不能直接成立。
- **原名称 + 原结构 + 历史训练入口的完整等价闭环：本次确认 0/42**。这不是说 42 项都没有原实现，而是元数据不够证明逐项结构等价。41 项完成留痕不能转换成“41 个原生结构全部训练完成”。
- V4 另外确认 **5 个原生 SE2 专家家族的历史完成合同**（CLOR、TECS、LTGE、GBLE、GG-SRRE），可作为优先复用线索，但没有把它们自动替代当前 42 项。
- **明确的合同级语义冲突至少 1 项：clor_local_offset**。它在 42 池的实际回执是 exact_observed_candidate，不是连续局部偏移合同。其他项逐项仍须结构验证，不因都输出候选就一律判错。

## 边界与方法

控制 workflow：C:/Users/Lenovo/.codex/workflows/remote-lab-task.md。任务最新要求优先：仅写本报告，不新增 workflow 状态或远程任务日志。

远端身份实测：hostname=lab407，whoami=hyc，hostname -I=116.57.87.129，pwd=/home/hyc。使用用户指定 SSH config、ProxyJump=none、BatchMode=yes。目标根目录存在。

本次仅对远端 JSON/MD/SH 小文件读取内容；代码结构信息使用已存在的本地 JSON 索引。对 PY 文件只枚举名称，没有远端读取其内容。没有读任何数据、权重、预测文件或 Test 内容；元数据中出现的数据/权重路径和哈希只作为文本证据，没有跟随打开。未执行任何查到的 SH/PY 训练入口，未调用 GPU 程序，未训练、未推理、未更改冻结结果。未处理独立源 Canary 政策绑定。

索引输入：H:/Project/AGENT-JSAC/artifacts/pretraining_acceptance/HISTORICAL_EXPERT_CODE_SEARCH_20260909.json，files_scanned=8154，expert_count=42，scope=code_only_discovery_not_structure_equivalence。它只作定位，不作“已经训练”的依据。

检索有界：
- V4 artifacts 合同/完成元数据：maxdepth 4、单文件 <128 KiB，限定 training_contract.json、run_contract.json、TRAINING_COMPLETE.json、training_complete.json，排除路径含 test/pred/cache；没有读取整个 artifacts 的任意 JSON。
- 42 池：routes 下 maxdepth 5 的 TRAINING_RECEIPT.json 和各路线 shadow_pool/LAUNCH_RECEIPT.json；排除 failed_attempts。先前目录名枚举不代表读过目录内数据。
- 历史补查：route_expert_search、route_expert_execution_library、parallel_adaptive_expert_extensions_20260828 及 _b、expert_expansion_v2_20260828 / v2b / v2c、frozen_parent_30_expert_control_20260831；maxdepth 6、<128 KiB、仅启动/训练回执。
- 未确认项另查 expert_expansion_formal_top5_20260828、两处 parallel_adaptive 扩展、adaptive_expert_library 的小型合同/回执/SH，并做 artifacts maxdepth 5 的同名 TRAINING_RECEIPT 路径查找，均未补到 risecho_geometry_consensus。
- V4 scripts/server/ops 小型 SH，以及 docs 内小型 MD/SH，只查明确专家/训练关键词。不全盘扫描，不读大日志、数据缓存或权重。部分初期终端输出被截断，最终逐项计数只使用后续重新获取的未截断、定字段摘录。

## 强证据：42 池实际启动了什么

公共原始路径前缀：
`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/`

以 open_indoor_los/shadow_pool/LAUNCH_RECEIPT.json 为例：
- :13-24 将 subcell_uncertainty_refiner 绑定到 scripts/train_se_branch_route_expert.py 和 subcell_uncertainty_refiner_v1。
- :35-46 记录 epochs=24、seed=3407、device=cuda、production-trainer-family=source_tail_refinement；:51 为 returncode=0。
- 同文件 :54-92 是 local_shape_consensus 的独立 job；:95 起是 polar_bev_cross_refiner。不是只有计划文件或待执行命令。
- 六路线 all_succeeded 在各自 LAUNCH_RECEIPT.json:2。除 corner_nlos_ris 外五路线 job returncode 行为 51/92/133/174/215；corner_nlos_ris 为 47/84/121/158/195。
- open_indoor_los/training_complete.json:302-328 记录上层 launch_se_branch_route_candidates.py、24 epochs、3407 seed 及 returncode=0；:429-446 同时记录 selected_checkpoint=null、selected_candidate_safety_eligible=false、training_outcome=identity_fallback。**训练发生与最终获准采用是两回事。**

旧入口实例：
`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/open_indoor_los/LAUNCH_RECEIPT.json`
:145-175 明确 temporal_precision_tail 的命令为 scripts/train_se_branch_route_expert.py，parent=cora_se1，epochs=24，seed=3407，returncode=0。不能把这个旧 family-only 训练强行解释为后来带 implementation_id 的新结构。

## 具体冲突与例外

### CLOR：离散候选合同并非原生局部连续偏移

原始回执：
`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_indoor_los/shadow_pool/open_indoor_los--expert-pool-42-reselect-open_indoor_los-20260901--04--clor_local_offset/TRAINING_RECEIPT.json`

- :3-7 application_contract.mode=exact_observed_candidate，maximum_correction_m=null。
- :54-62 绑定 clor_local_offset candidate，completed_utc=2026-08-31T17:53:17+00:00，family=registered:local_offset_gru_v1:local:gru:local:cartesian。
- :377-387 明确实际 model 为 src/agent_jsac/registered_route_expert_models.py，model SHA256=a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486；实际 trainer 为 scripts/train_se_branch_route_expert.py，SHA256=e56929325354f290c7ec7829dd2f9929f0ba9b59eb6a02623398b80b2b021e88。
- :392-406 primitive=local_offset_gru，production_trainer_family=source_tail_refinement，selected_epoch=24。
- 与之对照，V4 docs/research/2026-08-22-expert-semantic-library-r4-index.md:28 明确 CLOR 类别是有界局部/亚网格偏移；:43 将 open_indoor_los 的 CLOR 定义为精定位用途。
- V4 原生完成合同见下一节；本地已有代码索引指向 src/brace_v4/route_specialists_se2_models.py:25 的 CLORSE2Expert。此处是索引行号，不宣称本轮重新审过其 PY 实现。
- 结论：已能证明 42 池 CLOR 历史训练绑定的是另一份模型文件与离散动作合同，不能仅凭原名称交付为 CLORSE2Expert。保持原名称，优先追原生入口与训练时源码快照；不重写替代结构。

### GBLE：不是“42 项实际都同一注册模型”的证据

原始回执：
`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_dry_complex/shadow_pool/outdoor_dry_complex--expert-pool-42-reselect-outdoor_dry_complex-20260901--01--gble_branch_linker/TRAINING_RECEIPT.json`

:13 有完成时间；:203 implementation_id=graph_branch_linker_v1；:273 primitive=graph_branch_linker；:274 recipe_type=branch_router。这项应单列 recipe 路线，不能把其他 29 个注册模型的回执结论外推到它。它是否等同 V4 GBLESE2Expert 尚未确认。

### 版本时间差

state_consistent_local_refiner 的扩展回执（下面 E31）:527-537 记录 model SHA256=3b379ea9955f23183b38b4368a096836f0cc50667943993ae58156e9a81ea9b8，trainer SHA256=c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70；与 CLOR 的 20260831 回执不同。当前同路径脚本不能不经哈希核对就充当所有历史运行的原脚本。上述哈希均来自元数据，未读取或重算权重。

## V4 原生合同：优先复用线索

以下前缀均为：
`/home/hyc/radar+ris/JSAC-AGENT-V4/artifacts/ROUTE_SPECIALISTS_SE2_V1_20260822/experts/`

| 家族 | 原始合同 | 确认证据行 | 结论边界 |
|---|---|---|---|
| CLOR | clean_clor_r2/training_contract.json | 2 schema；3 完成时间；4 source_only；11 selected_epoch=1；15 checkpoint_sha256 | 已完成原生 CLOR 合同；未绑定到当前 clor_local_offset 的原结构合同 |
| TECS | cluttered_tecs/training_contract.json | 2-5 schema/完成/expert_id=tecs_se2；46 epoch=60；60 checkpoint_sha256 | 已完成家族合同，不等于 candidate_attention_set_v1 |
| LTGE | wet_ltge_r2/training_contract.json | 2-5 schema/完成/expert_id=ltge_se2；42 epoch=60；56 checkpoint_sha256 | 已完成家族合同，不自动映射 ltge_path_integrator |
| GBLE | dry_gble_r2/training_contract.json | 2-5 schema/完成/expert_id=gble_dcmd_se2；41 epoch=60；55 checkpoint_sha256 | 已完成家族合同，不自动映射 graph_branch_linker_v1 |
| GG-SRRE | rain_gg_srre/training_contract.json | 2-5 schema/完成/expert_id=gg_srre_se2；42 epoch=60；56 checkpoint_sha256 | 已完成家族合同，不自动映射 risk_controlled_recovery_v1 |

服务器已存在以下真实脚本路径（本次只枚举名称，未读取 PY；没有伪造启动参数）：
- /home/hyc/radar+ris/JSAC-AGENT-V4/scripts/train_cora_se2_clean_clor.py
- /home/hyc/radar+ris/JSAC-AGENT-V4/scripts/train_cora_se2_route_specialists.py

这些是优先进一步核对的入口候选，**合同中没有 argv/训练时脚本哈希，故本次不将脚本文件名提升为“已逐参数证实的原启动命令”**。现有本地索引还定位 route_specialists_se2_models.py:25 CLORSE2Expert、:72 TECSSE2Expert、:197 GBLESE2Expert、:335 GGSRRESE2Expert、:438 LTGESE2Expert；仅作为定位线索。

另有可直接阅读的真实历史 SH：
- /home/hyc/radar+ris/JSAC-AGENT-V4/scripts/launch_r31_expert_server.sh:49-57 调用 train_r31_route_specialist.py，architecture 为入参，epochs=60，patience=10。仅证明脚本存在；R31_ROUTE_EXPERTS_V1_20260822 的限定深度未找到训练完成合同，不计为 42 项训练证据。
- /home/hyc/radar+ris/JSAC-AGENT-V4/server/run_cora_se2_rawpolar_allroutes_experts_v2.sh:49-65 为 5 路线 train_self_evolving_route_expert.py、epochs=80、independent-acceptance。它没有 42 identifier/原结构绑定，不能据此补齐 42。
- V4 docs/research/2026-08-22-expert-semantic-library-r4-index.md:16 说的是 5 个历史 CPB 结构模板；:61 明确研究条目需过训练/冻结/审计后才升级部署。语义卡计数不是训练计数。

## 42 项逐项台账

“有回执”仅表示相应 identifier 对应候选有历史完成元数据；所有项的原结构等价状态均仍未闭环。E 编号在下一节对应精确原文件与字段行。

| 序号 | 原 identifier（不改名） | 历史完成留痕 | 回执中的实现/家族 |
|---|---|---|---|
| 1 | clor_local_offset | 有，E1 | local_offset_gru_v1 |
| 2 | polar_bev_cross_refiner | 有，E2 | polar_bev_cross_refiner_v1 |
| 3 | subcell_uncertainty_refiner | 有，E3 | subcell_uncertainty_refiner_v1 |
| 4 | innovation_gated_offset | 有，E4 | innovation_gated_offset_v1 |
| 5 | temporal_precision_tail | 有，E5 | temporal |
| 6 | tecs_candidate_attention | 有，E6 | candidate_attention_set_v1 |
| 7 | tcbav_temporal_candidate_graph | 有，E7 | candidate_graph_temporal_v1 |
| 8 | dual_domain_set_mixer | 有，E8 | dual_domain_set_mixer_v1 |
| 9 | echo_extent_disambiguator | 有，E9 | echo_extent_disambiguator_v1 |
| 10 | branch_persistence_selector | 有，E10 | temporal |
| 11 | ltge_path_integrator | 有，E11 | path_temporal_integrator_v1 |
| 12 | track_before_detect | 有，E12 | graph |
| 13 | range_conditioned_tcn | 有，E13 | temporal |
| 14 | weak_return_mixture | 有，E14 | weak_return_mixture_v1 |
| 15 | polar_evidence_gate | 有，E15 | polar_evidence_gate_v1 |
| 16 | gble_branch_linker | 有，E16 | graph_branch_linker_v1 |
| 17 | multi_hypothesis_path | 有，E17 | multi_hypothesis_path_v1 |
| 18 | mti_agreement_rescuer | 有，E18 | mti_agreement_rescuer_v1 |
| 19 | candidate_survival_graph | 有，E19 | candidate_survival_graph_v1 |
| 20 | selective_branch_recovery | 有，E20 | local |
| 21 | gg_srre_recovery | 有，E21 | risk_controlled_recovery_v1 |
| 22 | robust_quantile_recovery | 有，E22 | robust_quantile_recovery_v1 |
| 23 | wet_temporal_integrator | 有，E23 | wet_temporal_integrator_v1 |
| 24 | weather_risk_selector | 有，E24 | attention |
| 25 | anisotropic_wet_mixture | 有，E25 | anisotropic_wet_mixture_v1 |
| 26 | ris_temporal_gate_h32 | 有，E26 | risecho_temporal_gate_v1 |
| 27 | risecho_path_integrator | 有，E27 | risecho_path_integrator_v1 |
| 28 | risecho_codebook_consensus | 有，E28 | risecho_codebook_consensus_v1 |
| 29 | risecho_selective_recovery | 有，E29 | attention |
| 30 | risecho_dual_path_mixture | 有，E30 | risecho_dual_path_mixture_v1 |
| 31 | state_consistent_local_refiner | 有，E31 | state_consistent_local_refiner_v1 |
| 32 | local_shape_consensus | 有，E32 | local_shape_consensus_v1 |
| 33 | empty_guard_constrained_disambiguator | 有，E33 | empty_guard_constrained_disambiguator_v1 |
| 34 | causal_tracklet_consensus | 有，E34 | causal_tracklet_consensus_v1 |
| 35 | adaptive_threshold_tracklet | 有，E35 | adaptive_threshold_tracklet_v1 |
| 36 | evidence_hysteresis_selector | 有，E36 | evidence_hysteresis_selector_v1 |
| 37 | angular_consistency_associator | 有，E37 | angular_consistency_associator_v1 |
| 38 | background_guard_branch_pruner | 有，E38 | background_guard_branch_pruner_v1 |
| 39 | wet_guard_contrast_recovery | 有，E39 | wet_guard_contrast_recovery_v1 |
| 40 | anomaly_hysteresis_gate | 有，E40 | anomaly_hysteresis_gate_v1 |
| 41 | risecho_geometry_consensus | 未确认 | 本次未找到合同/完成回执 |
| 42 | risecho_dual_stream_stability | 有，E42 | risecho_dual_stream_stability_v1 |

## 原始文件与行号索引

以下均为本次远端实际读取的回执字段行；路径指向 JSON，不指向数据或权重。行号按原文件，不是重新序列化后的编号。

### E1 clor_local_offset

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_indoor_los/shadow_pool/open_indoor_los--expert-pool-42-reselect-open_indoor_los-20260901--04--clor_local_offset/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:53:17+00:00`；`family` :62 = `registered:local_offset_gru_v1:local:gru:local:cartesian`；`implementation_id` :387 = `local_offset_gru_v1`；`primitive` :392 = `local_offset_gru`；`production_trainer_family` :393 = `source_tail_refinement`。

### E2 polar_bev_cross_refiner

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_indoor_los/shadow_pool/open_indoor_los--expert-pool-42-reselect-open_indoor_los-20260901--03--polar_bev_cross_refiner/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:53:12+00:00`；`family` :62 = `registered:polar_bev_cross_refiner_v1:cross:gru:confidence:polar`；`implementation_id` :387 = `polar_bev_cross_refiner_v1`；`primitive` :392 = `polar_bev_cross_refiner`；`production_trainer_family` :393 = `source_tail_refinement`。

### E3 subcell_uncertainty_refiner

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_indoor_los/shadow_pool/open_indoor_los--expert-pool-42-reselect-open_indoor_los-20260901--01--subcell_uncertainty_refiner/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:53:12+00:00`；`family` :62 = `registered:subcell_uncertainty_refiner_v1:uncertainty:conv:uncertainty:cartesian`；`implementation_id` :387 = `subcell_uncertainty_refiner_v1`；`primitive` :392 = `subcell_uncertainty_refiner`；`production_trainer_family` :393 = `source_tail_refinement`。

### E4 innovation_gated_offset

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_indoor_los/shadow_pool/open_indoor_los--expert-pool-42-reselect-open_indoor_los-20260901--05--innovation_gated_offset/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:53:18+00:00`；`family` :62 = `registered:innovation_gated_offset_v1:innovation:gru:innovation:delta`；`implementation_id` :387 = `innovation_gated_offset_v1`；`primitive` :392 = `innovation_gated_offset`；`production_trainer_family` :393 = `source_tail_refinement`。

### E5 temporal_precision_tail

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/open_indoor_los/open_indoor_los--05--temporal_precision_tail/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:27:07+00:00`；`family` :10 = `temporal`；`primitive` :159 = `temporal_precision_tail`。

### E6 tecs_candidate_attention

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/indoor_clutter/shadow_pool/indoor_clutter--expert-pool-42-reselect-indoor-clutter-20260901--02--tecs_candidate_attention/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:41:28+00:00`；`family` :62 = `registered:candidate_attention_set_v1:attention:none:confidence:cartesian`；`implementation_id` :387 = `candidate_attention_set_v1`；`primitive` :392 = `candidate_attention`；`production_trainer_family` :393 = `selective_candidate_composite`。

### E7 tcbav_temporal_candidate_graph

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/indoor_clutter/shadow_pool/indoor_clutter--expert-pool-42-reselect-indoor-clutter-20260901--05--tcbav_temporal_candidate_graph/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:41:39+00:00`；`family` :62 = `registered:candidate_graph_temporal_v1:graph:gru:innovation:delta`；`implementation_id` :387 = `candidate_graph_temporal_v1`；`primitive` :392 = `temporal_candidate_graph`；`production_trainer_family` :393 = `selective_candidate_composite`。

### E8 dual_domain_set_mixer

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/indoor_clutter/shadow_pool/indoor_clutter--expert-pool-42-reselect-indoor-clutter-20260901--03--dual_domain_set_mixer/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:41:37+00:00`；`family` :62 = `registered:dual_domain_set_mixer_v1:set:conv:agreement:polar`；`implementation_id` :387 = `dual_domain_set_mixer_v1`；`primitive` :392 = `dual_domain_set_mixer`；`production_trainer_family` :393 = `selective_candidate_composite`。

### E9 echo_extent_disambiguator

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/indoor_clutter/shadow_pool/indoor_clutter--expert-pool-42-reselect-indoor-clutter-20260901--01--echo_extent_disambiguator/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:41:28+00:00`；`family` :62 = `registered:echo_extent_disambiguator_v1:extent:none:extent:cartesian`；`implementation_id` :387 = `echo_extent_disambiguator_v1`；`primitive` :392 = `echo_extent_disambiguator`；`production_trainer_family` :393 = `selective_candidate_composite`。

### E10 branch_persistence_selector

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/indoor_clutter/indoor_clutter--05--branch_persistence_selector/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:15:48+00:00`；`family` :10 = `temporal`；`primitive` :159 = `branch_persistence_selector`。

### E11 ltge_path_integrator

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_outdoor_weak_return/shadow_pool/open_outdoor_weak_return--expert-pool-42-reselect-open_outdoor_weak_return-20260901--03--ltge_path_integrator/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:49:13+00:00`；`family` :62 = `registered:path_temporal_integrator_v1:path:gru:persistence:polar`；`implementation_id` :387 = `path_temporal_integrator_v1`；`primitive` :392 = `path_temporal_integrator`；`production_trainer_family` :393 = `source_tail_refinement`。

### E12 track_before_detect

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/open_outdoor_weak_return/open_outdoor_weak_return--02--track_before_detect/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:30:14+00:00`；`family` :10 = `graph`；`primitive` :159 = `track_before_detect`。

### E13 range_conditioned_tcn

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/open_outdoor_weak_return/open_outdoor_weak_return--03--range_conditioned_tcn/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:30:20+00:00`；`family` :10 = `temporal`；`primitive` :159 = `range_conditioned_tcn`。

### E14 weak_return_mixture

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_outdoor_weak_return/shadow_pool/open_outdoor_weak_return--expert-pool-42-reselect-open_outdoor_weak_return-20260901--01--weak_return_mixture/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:49:12+00:00`；`family` :62 = `registered:weak_return_mixture_v1:mixture:gru:uncertainty:cartesian`；`implementation_id` :387 = `weak_return_mixture_v1`；`primitive` :392 = `weak_return_mixture`；`production_trainer_family` :393 = `source_tail_refinement`。

### E15 polar_evidence_gate

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_outdoor_weak_return/shadow_pool/open_outdoor_weak_return--expert-pool-42-reselect-open_outdoor_weak_return-20260901--05--polar_evidence_gate/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:49:26+00:00`；`family` :62 = `registered:polar_evidence_gate_v1:polar_gate:none:agreement:polar`；`implementation_id` :387 = `polar_evidence_gate_v1`；`primitive` :392 = `polar_evidence_gate`；`production_trainer_family` :393 = `source_tail_refinement`。

### E16 gble_branch_linker

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_dry_complex/shadow_pool/outdoor_dry_complex--expert-pool-42-reselect-outdoor_dry_complex-20260901--01--gble_branch_linker/TRAINING_RECEIPT.json`

`completed_utc` :13 = `2026-08-31T17:59:19+00:00`；`implementation_id` :203 = `graph_branch_linker_v1`；`primitive` :273 = `graph_branch_linker`；`recipe_type` :274 = `branch_router`。

### E17 multi_hypothesis_path

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_dry_complex/shadow_pool/outdoor_dry_complex--expert-pool-42-reselect-outdoor_dry_complex-20260901--04--multi_hypothesis_path/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:59:25+00:00`；`family` :62 = `registered:multi_hypothesis_path_v1:path:tail:uncertainty:cartesian`；`implementation_id` :387 = `multi_hypothesis_path_v1`；`primitive` :392 = `multi_hypothesis_path`；`production_trainer_family` :393 = `branch_stability_router`。

### E18 mti_agreement_rescuer

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_dry_complex/shadow_pool/outdoor_dry_complex--expert-pool-42-reselect-outdoor_dry_complex-20260901--02--mti_agreement_rescuer/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:59:16+00:00`；`family` :62 = `registered:mti_agreement_rescuer_v1:agreement:none:agreement:polar`；`implementation_id` :387 = `mti_agreement_rescuer_v1`；`primitive` :392 = `mti_agreement_rescuer`；`production_trainer_family` :393 = `branch_stability_router`。

### E19 candidate_survival_graph

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_dry_complex/shadow_pool/outdoor_dry_complex--expert-pool-42-reselect-outdoor_dry_complex-20260901--05--candidate_survival_graph/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:59:28+00:00`；`family` :62 = `registered:candidate_survival_graph_v1:survival:gru:survival:delta`；`implementation_id` :387 = `candidate_survival_graph_v1`；`primitive` :392 = `candidate_survival_graph`；`production_trainer_family` :393 = `branch_stability_router`。

### E20 selective_branch_recovery

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/outdoor_dry_complex/outdoor_dry_complex--05--selective_branch_recovery/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:15:45+00:00`；`family` :10 = `local`；`primitive` :159 = `selective_branch_recovery`。

### E21 gg_srre_recovery

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_wet_return/shadow_pool/outdoor_wet_return--expert-pool-42-reselect-outdoor_wet_return-20260901--05--gg_srre_recovery/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:14+00:00`；`family` :62 = `registered:risk_controlled_recovery_v1:risk:gru:risk:polar`；`implementation_id` :387 = `risk_controlled_recovery_v1`；`primitive` :392 = `risk_controlled_recovery`；`production_trainer_family` :393 = `bounded_wet_return_router`。

### E22 robust_quantile_recovery

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_wet_return/shadow_pool/outdoor_wet_return--expert-pool-42-reselect-outdoor_wet_return-20260901--01--robust_quantile_recovery/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:11:52+00:00`；`family` :62 = `registered:robust_quantile_recovery_v1:uncertainty:tail:quantile:cartesian`；`implementation_id` :387 = `robust_quantile_recovery_v1`；`primitive` :392 = `robust_quantile_recovery`；`production_trainer_family` :393 = `bounded_wet_return_router`。

### E23 wet_temporal_integrator

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_wet_return/shadow_pool/outdoor_wet_return--expert-pool-42-reselect-outdoor_wet_return-20260901--03--wet_temporal_integrator/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:01+00:00`；`family` :62 = `registered:wet_temporal_integrator_v1:wet:gru:wet:polar`；`implementation_id` :387 = `wet_temporal_integrator_v1`；`primitive` :392 = `wet_temporal_integrator`；`production_trainer_family` :393 = `bounded_wet_return_router`。

### E24 weather_risk_selector

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/outdoor_wet_return/outdoor_wet_return--04--weather_risk_selector/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:15:40+00:00`；`family` :10 = `attention`；`primitive` :159 = `weather_risk_selector`。

### E25 anisotropic_wet_mixture

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_wet_return/shadow_pool/outdoor_wet_return--expert-pool-42-reselect-outdoor_wet_return-20260901--04--anisotropic_wet_mixture/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:08+00:00`；`family` :62 = `registered:anisotropic_wet_mixture_v1:mixture:conv:anisotropic:polar`；`implementation_id` :387 = `anisotropic_wet_mixture_v1`；`primitive` :392 = `anisotropic_wet_mixture`；`production_trainer_family` :393 = `bounded_wet_return_router`。

### E26 ris_temporal_gate_h32

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/corner_nlos_ris/shadow_pool/corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--04--ris_temporal_gate_h32/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:01+00:00`；`family` :62 = `registered:risecho_temporal_gate_v1:risecho:gru:codebook:polar`；`implementation_id` :387 = `risecho_temporal_gate_v1`；`primitive` :392 = `risecho_temporal_gate`；`production_trainer_family` :393 = `ris_temporal_hard_gate`。

### E27 risecho_path_integrator

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/corner_nlos_ris/shadow_pool/corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--01--risecho_path_integrator/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:11:52+00:00`；`family` :62 = `registered:risecho_path_integrator_v1:path:tail:codebook:polar`；`implementation_id` :387 = `risecho_path_integrator_v1`；`primitive` :392 = `risecho_path_integrator`；`production_trainer_family` :393 = `ris_temporal_hard_gate`。

### E28 risecho_codebook_consensus

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/corner_nlos_ris/shadow_pool/corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--03--risecho_codebook_consensus/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:00+00:00`；`family` :62 = `registered:risecho_codebook_consensus_v1:codebook:none:consensus:polar`；`implementation_id` :387 = `risecho_codebook_consensus_v1`；`primitive` :392 = `risecho_codebook_consensus`；`production_trainer_family` :393 = `ris_temporal_hard_gate`。

### E29 risecho_selective_recovery

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/corner_nlos_ris/corner_nlos_ris--04--risecho_selective_recovery/TRAINING_RECEIPT.json`

`completed_utc` :5 = `2026-08-26T10:52:37+00:00`；`family` :10 = `attention`；`primitive` :159 = `risecho_selective_recovery`。

### E30 risecho_dual_path_mixture

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/corner_nlos_ris/shadow_pool/corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--02--risecho_dual_path_mixture/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:11:52+00:00`；`family` :62 = `registered:risecho_dual_path_mixture_v1:dual_path:conv:receiver:polar`；`implementation_id` :387 = `risecho_dual_path_mixture_v1`；`primitive` :392 = `risecho_dual_path_mixture`；`production_trainer_family` :393 = `ris_temporal_hard_gate`。

### E31 state_consistent_local_refiner

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_expansion_v2c_20260828/indoor_clutter--expv2c--state_consistent_local_refiner/TRAINING_RECEIPT.json`

`completed_utc` :51 = `2026-08-28T11:14:25+00:00`；`family` :56 = `registered:state_consistent_local_refiner_v1:state_space:gru:persistence:cartesian`；`implementation_id` :537 = `state_consistent_local_refiner_v1`；`primitive` :540 = `state_consistent_local_refiner`。

### E32 local_shape_consensus

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_indoor_los/shadow_pool/open_indoor_los--expert-pool-42-reselect-open_indoor_los-20260901--02--local_shape_consensus/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:53:12+00:00`；`family` :62 = `registered:local_shape_consensus_v1:shape_consensus:conv:extent:cartesian`；`implementation_id` :387 = `local_shape_consensus_v1`；`primitive` :392 = `local_shape_consensus`；`production_trainer_family` :393 = `source_tail_refinement`。

### E33 empty_guard_constrained_disambiguator

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/indoor_clutter/shadow_pool/indoor_clutter--expert-pool-42-reselect-indoor-clutter-20260901--04--empty_guard_constrained_disambiguator/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:47:55+00:00`；`family` :62 = `registered:empty_guard_constrained_disambiguator_v1:contrast:gru:agreement:polar`；`implementation_id` :387 = `empty_guard_constrained_disambiguator_v1`；`primitive` :392 = `empty_guard_constrained_disambiguator`；`production_trainer_family` :393 = `selective_candidate_composite`。

### E34 causal_tracklet_consensus

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_expansion_v2_20260828/indoor_clutter--expv2--causal_tracklet_consensus/TRAINING_RECEIPT.json`

`completed_utc` :51 = `2026-08-28T11:12:03+00:00`；`family` :56 = `registered:causal_tracklet_consensus_v1:state_space:tail:persistence:delta`；`implementation_id` :537 = `causal_tracklet_consensus_v1`；`primitive` :540 = `causal_tracklet_consensus`。

### E35 adaptive_threshold_tracklet

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_outdoor_weak_return/shadow_pool/open_outdoor_weak_return--expert-pool-42-reselect-open_outdoor_weak_return-20260901--04--adaptive_threshold_tracklet/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:49:25+00:00`；`family` :62 = `registered:adaptive_threshold_tracklet_v1:adaptive_range:tail:range:polar`；`implementation_id` :387 = `adaptive_threshold_tracklet_v1`；`primitive` :392 = `adaptive_threshold_tracklet`；`production_trainer_family` :393 = `source_tail_refinement`。

### E36 evidence_hysteresis_selector

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/open_outdoor_weak_return/shadow_pool/open_outdoor_weak_return--expert-pool-42-reselect-open_outdoor_weak_return-20260901--02--evidence_hysteresis_selector/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:49:45+00:00`；`family` :62 = `registered:evidence_hysteresis_selector_v1:hysteresis:gru:persistence:polar`；`implementation_id` :387 = `evidence_hysteresis_selector_v1`；`primitive` :392 = `evidence_hysteresis_selector`；`production_trainer_family` :393 = `source_tail_refinement`。

### E37 angular_consistency_associator

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_dry_complex/shadow_pool/outdoor_dry_complex--expert-pool-42-reselect-outdoor_dry_complex-20260901--03--angular_consistency_associator/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T17:59:23+00:00`；`family` :62 = `registered:angular_consistency_associator_v1:angular:conv:innovation:polar`；`implementation_id` :387 = `angular_consistency_associator_v1`；`primitive` :392 = `angular_consistency_associator`；`production_trainer_family` :393 = `branch_stability_router`。

### E38 background_guard_branch_pruner

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_expansion_v2b_20260828/indoor_clutter--expv2b--background_guard_branch_pruner/TRAINING_RECEIPT.json`

`completed_utc` :51 = `2026-08-28T11:13:12+00:00`；`family` :56 = `registered:background_guard_branch_pruner_v1:residual:none:risk:cartesian`；`implementation_id` :537 = `background_guard_branch_pruner_v1`；`primitive` :540 = `background_guard_branch_pruner`。

### E39 wet_guard_contrast_recovery

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_expansion_v2_20260828/outdoor_wet_return--expv2--wet_guard_contrast_recovery/TRAINING_RECEIPT.json`

`completed_utc` :51 = `2026-08-28T11:12:03+00:00`；`family` :56 = `registered:wet_guard_contrast_recovery_v1:contrast:gru:wet:polar`；`implementation_id` :537 = `wet_guard_contrast_recovery_v1`；`primitive` :540 = `wet_guard_contrast_recovery`。

### E40 anomaly_hysteresis_gate

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/outdoor_wet_return/shadow_pool/outdoor_wet_return--expert-pool-42-reselect-outdoor_wet_return-20260901--02--anomaly_hysteresis_gate/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:07+00:00`；`family` :62 = `registered:anomaly_hysteresis_gate_v1:hysteresis:tail:weather:polar`；`implementation_id` :387 = `anomaly_hysteresis_gate_v1`；`primitive` :392 = `anomaly_hysteresis_gate`；`production_trainer_family` :393 = `bounded_wet_return_router`。

### E42 risecho_dual_stream_stability

原文件：`/home/hyc/radar+ris/AGENT-JSAC/artifacts/expert_pool_42_training_20260901/routes/corner_nlos_ris/shadow_pool/corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--05--risecho_dual_stream_stability/TRAINING_RECEIPT.json`

`completed_utc` :57 = `2026-08-31T18:12:08+00:00`；`family` :62 = `registered:risecho_dual_stream_stability_v1:dual_stream:conv:consensus:polar`；`implementation_id` :387 = `risecho_dual_stream_stability_v1`；`primitive` :392 = `risecho_dual_stream_stability`；`production_trainer_family` :393 = `ris_temporal_hard_gate`。

## 未确认与下一步边界

- risecho_geometry_consensus：没有在本报告限定检索范围发现训练完成留痕，保留 identifier 和结构要求；不以相近 risecho 名称替代。
- 原结构一一对应的 42 项闭环尚未完成。优先从上述现存 V4 原生入口及 receipt.model/trainer 哈希恢复当时实现，再比对输入、模块、输出、损失、训练参数与原语义合同。不得先重写一个同名实现后倒推为历史原结构。
- 所有已训练数量均为元数据证据级结论；未读权重，因此没有验证参数张量、权重内 architecture 或文件现存哈希。历史 receipt 自报 completed_utc 不等于本轮重新训练验收。
- 未将旧运行的元数据政策声明用于主任务的独立源 Canary 政策绑定，也未依据旧训练产生任何新晋级。
- 唯一写入文件为本报告；生产代码、42 名称/结构、冻结文件均未改动。
