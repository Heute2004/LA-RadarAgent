# UAV 到 Human 线交接包

日期：2026-09-08  
状态：已冻结，供 Human 线 Agent/论文主线接管  
范围：停止 UAV 专家搜索；不改动既有 Human 冻结结果、权重或协议。

## 0. 本次决定

1. UAV 的 24 个雷达-only 专家原语及 20 个预注册筛选任务均保留为可复现研发资产。
2. 20 个候选全部未达到预注册晋升条件，因此 **UAV 运行时不加载任何新专家**。
3. UAV 仅保留两个冻结雷达分支：`CORA-U0` 与路线注册的 `CORA-U-SE-Coarse-V3`。
4. Human 线既有的 `CORA0 / CORA-SE1 / CORA-SE2 / CSS-V3 / 五条直接路线专家 / RIS V21` 继续是权威结果，完全不被 UAV 负筛选结果覆盖。
5. 两条线可以共用 Agent 的安全生命周期和物理候选接口，但当前没有“Human-UAV 共享权重优于独立权重”的实验结果，不能把它写成既成事实。

这是一份 **控制面与证据接口交接**，不是把 UAV checkpoint 混入 Human 训练，也不是把两类指标平均成一个数字。

## 1. 交接后的总架构

```text
固定基础设施雷达
  -> RA + RA-MTI, 16 帧因果窗口
  -> 目标无关的物理候选: p(r, theta), Top-K, covariance, persistence
  -> Observability Health / Memory / Safety Dispatcher
  -> 已注册、经过审计的运行时分支

Human 分支:
  CORA0 / CORA-SE1 / CORA-SE2
  + CSS-V3 空场景安全缓冲
  + 已晋级机制专家或 RIS V21

UAV 分支:
  CORA-U0
  + 已注册目标场地时的 CORA-U-SE-Coarse-V3
  + exact fallback 到 CORA-U0
```

统一的是物理观测、候选、健康度、缓存、影子训练、审计、晋级和回滚合同；不统一的是目标标签、坐标渲染、精度阈值和实验指标。

## 2. Human 线：冻结权威事实

Human 线的正式事实源为：

```text
artifacts/frozen_result_agent_v3/FROZEN_RESULT_MATRIX.json
artifacts/frozen_result_agent_v3/FROZEN_AGENT_CONFIGURATION.json
docs/contracts/cora_evolabel_lineage_contract_zh.md
```

### 2.1 CORA 主干与演化分支

| 分支 | AP@0.30 | AP@0.50 | P90 | 运行含义 |
|---|---:|---:|---:|---|
| `CORA0` | 0.7174 | 0.9135 | 1.053 m | 冻结源基座与总回退点 |
| `CORA-SE1` | 0.7523 | 0.9134 | 1.053 m | CrossAnchor 驱动的适配分支 |
| `CORA-SE2` | 0.7858 | 0.9052 | 0.883 m | 物理候选与路线后验驱动的适配分支 |

必须区分证据演进与参数拓扑：

```text
证据：CrossAnchor -> RadarCandidateSet -> RoutePosterior
参数：CORA0 -> SE1，以及 CORA0 -> SE2
```

`SE2` 可以使用 `SE1` 的审核轨迹作为证据，但不是从 `SE1` checkpoint 继续串行微调。后续 Human 线不得把原始预测直接回灌为自身标签。

### 2.2 已晋级的 Human 专家

| 路线 | 冻结专家 | AP@0.30 变化 | 运行规则 |
|---|---|---:|---|
| `open_indoor_los` | `r39_open_indoor_tail_refiner_v1` | +0.000 pp | 保留，主要约束尾部风险 |
| `indoor_clutter` | `r34c_selective_composite_indoor_clutter_v1` | +4.067 pp | 已晋级 |
| `open_outdoor_weak_return` | `r39_open_outdoor_tail_refiner_v1` | +0.279 pp | 已晋级，但保留 P95 限制声明 |
| `outdoor_dry_complex` | `r24_frozen_branch_stability_router_multipath_v2` | +3.465 pp | 已晋级 |
| `outdoor_wet_return` | `r55_r31_r49_half_scale_wet_router_v1` | +0.059 pp | 已晋级，低接受率的保守修正 |
| `corner_nlos_ris` | `ris_v21_temporal_hard_gate_r1` | +18.333 pp | 仅 RIS 合同匹配时启用 |

Human 安全边界：

* CSS-V3 只给出空背景风险、背景变化与候选保留约束，不改坐标或检测 logit。
* `seq106` 固定 `CORA-SE2 + Identity`，不能加载 R55。
* RIS 几何、码本或接收机合同不匹配时，固定回退到 `CORA0 + radar-only + no expert`。
* Human 的 Final-BEV 只属于离线评测和冻结监督资产，不得进入目标场景在线适配。

## 3. UAV 线：保留的最小可用结果

### 3.1 坐标与输入合同

UAV 正式状态是水平雷达的斜距极坐标：

```text
UAVPolarState = (r_slant, theta_H)
x = r * sin(theta)
y = r * cos(theta)
```

`x, y` 只用于 OLS 计算和可视化；UAV 正式输出不是地面 BEV。模型仅输入水平 `RA + RA-MTI` 的 16 帧因果窗口。垂直雷达未证明逐帧同步，不能加入正式二维主干、训练标签或评价。

### 3.2 冻结模型与自适应结果

| 模型 | 训练用途 | OLS mAP@0.50:0.90 | OLS mAP@0.30:0.70 | OLS mAP@0.20:0.50 | Hit@1.5 m | P90 |
|---|---|---:|---:|---:|---:|---:|
| `CORA-U0` | 源场景冻结基座 | 0.2884 | 0.6113 | 0.8410 | 0.8692 | 1.585 m |
| `CORA-U-SE-Coarse-V3` | 目标场景粗定位适配 | 0.3929 | 0.7269 | 0.9194 | 0.9133 | 1.452 m |
| `CORA-U-All` | 全监督上界，仅对照 | 0.7708 | 0.9407 | 0.9866 | 0.9808 | 1.065 m |

`CORA-U-SE-Coarse-V3` 的合法主张是：在不读取目标 RTK、RGB、深度或 VLM 的条件下，使用 600 个 radar-only 集合值候选进行 **粗定位目标场地适配**。它在 OLS mAP@0.20:0.50 上达到全监督上界的 93.19%，在 Hit@1.5 m 上达到 93.12%。

它不能被描述为精确定位恢复、通用基座替换，或全监督等价模型。

### 3.3 运行时路由

```text
source / unknown UAV condition
  -> CORA-U0

registered target condition with valid Support evidence
  -> CORA-U-SE-Coarse-V3

missing evidence / runtime audit failed / any anomaly
  -> exact CORA-U0 fallback
```

UAV 目标适配训练时只允许：

```text
SourceFrozenSlantPolar replay
+ RadarCandidateSet
+ complete-support-episode temporal association
```

禁止：目标 RTK、target Development/Locked Query 真值、RGB、深度、垂直雷达、Human Final-BEV 与 Human checkpoint 作为训练输入。

## 4. 已停止的 UAV 专家线

本轮建成了 24 个可复现的 radar-only 专家原语，20 个预注册任务按四种条件各筛选 5 个：

```text
source_day / source_night / target_day / target_night
```

所有任务均完成，零执行错误，且目标侧训练/伪标签路径未读取 RTK、RGB、深度、Development Query 或 Locked Test。

| 条件 | 结果最好的候选 | 相对父模型结果 | 决定 |
|---|---|---:|---|
| `source_day` | 局部偏移 GRU | 指标已饱和，无增益 | 不需要专家 |
| `source_night` | PATEI-ConvLSTM | +0.072 pp | 不足以晋级 |
| `target_day` | TCGA-Sinkhorn | -0.303 pp | 负迁移，淘汰 |
| `target_night` | Change-Point Affine | +0.427 pp，P90 -0.017 m | 接近但未达到 +0.5 pp 门槛 |

**正式政策：**这 20 个 checkpoint 一律不进入 UAV 或 Human 的运行时专家池。它们可作为论文/附录的严格负筛选记录，以及未来重新设计标签或任务时的候选结构来源。

## 5. 交给 Human Agent 的公共接口

Human 线接管时，建议只复用以下类别无关接口：

```text
RadarObservation
  sensor_profile_id
  RA / RA-MTI
  frame_timestamp
  physical_range_grid
  physical_azimuth_grid

CandidateState
  Top-K physical candidates
  covariance
  peak persistence
  RA/RA-MTI agreement
  tracker innovation
  background-risk / observability health

LifecycleState
  support buffer status
  parent checkpoint ID
  route evidence hash
  shadow/canary/promotion/rollback status
```

在 Agent 控制面中，Qwen 或其他 LLM 只能请求受限动作，例如：

```text
keep_parent
retrieve_memory
buffer_support_episode
shadow_train_adapter
canary_audit
promote
rollback
```

真正读写文件、训练、评估、晋级和回滚的主体必须是确定性 Dispatcher 与 Safety Shield。LLM 不能直接写 checkpoint、生成网络代码、设定阈值或输出坐标。

## 6. 不能混合的边界

| 事项 | 规则 |
|---|---|
| 模型权重 | 当前不做 Human/UAV 权重合并或跨任务迁移主张 |
| backbone 输入 | 不注入 `human/uav` 文本 ID；仅输入传感器物理坐标、观测与 capability |
| expert router | 不按“Human/UAV”类别决定专家；只能依据候选歧义、弱回波、背景风险、时序创新等机制证据 |
| 坐标 | Human 是 Radar-H 地面 BEV；UAV 是水平斜距极坐标；不能直接对齐或平均 |
| 指标 | Human 报告 AP@0.20/0.25/0.30/0.50、P90；UAV 报告 OLS operating points、Hit@1.5 m、P90 |
| 视觉 | Human 可依合同使用视觉离线 CrossAnchor；UAV 当前正式自适应为 radar-only |
| 垂直雷达 | UAV H/V 未证明同步，禁止进入正式 2D 主线 |
| RIS | 仅 Human L 走廊有冻结 RIS 合同；UAV 不可声称 RIS 能力 |

因此论文层面可以讲“同一固定基础设施雷达 Agent 面对 ground-person 与 low-altitude UAV 两种运行域，采用同一安全演化生命周期”，但不能讲“同一个网络已经在两类数据上共享训练成功”。

## 7. 标签谱系的对应关系

Human 使用 `CORA-EvoLabel`：

```text
SourceBEV + EmptyGuard -> CORA0 -> BaseSeed
SourceBEV replay + CrossAnchor -> CORA-SE1 -> AdaptedTrack
SourceBEV replay + RadarCandidateSet -> CORA-SE2 -> EvolvedPosterior
RoutePosterior -> Human route experts
RISEcho -> conditional RIS expert
```

UAV 对应的最小安全谱系：

```text
SourceFrozenSlantPolar -> CORA-U0 -> BasePolar
RadarCandidateSet + complete-episode association
  -> CORA-U-SE-Coarse-V3 -> registered target coarse route
```

公共原则保持不变：

```text
raw prediction != next-stage label
raw prediction + independent physical/temporal/split audit = promotable evidence
```

## 8. 接管清单

Human 线接管前后应完成以下核对：

1. 保持 `artifacts/frozen_result_agent_v3` 为 Human 结果唯一权威源。
2. 将 UAV 的 `CORA-U0` 和 `CORA-U-SE-Coarse-V3` 注册为独立的 radar-only task adapters，不覆盖 Human CORA0/SE1/SE2。
3. 将 UAV 专家筛选 `SCREEN_D` 标记为 `negative_screening_not_runtime`。
4. Agent 的 Memory 记录 sensor profile、物理坐标网格、capability 和机制健康度；不以目标类别文本作为学习特征或检索键。
5. 任何未来共享基座、跨目标专家复用或混合训练都必须另起冻结 manifest、独立 Development/Locked Test，并先证明对照收益。
6. 论文中分别报告 Human 与 UAV 的 source/support/development/locked 结果，不合并为一个总 mAP。

## 9. 可复现资产索引

### 9.1 Human 权威资产

| 文件 | SHA256 |
|---|---|
| `artifacts/frozen_result_agent_v3/FROZEN_RESULT_MATRIX.json` | `0E71E7E07B3F39EE2ED26F2E7701830DEBB82E697F24C54CB58609BDFE5922A4` |
| `artifacts/frozen_result_agent_v3/FROZEN_AGENT_CONFIGURATION.json` | `751C19D086C83FF84F3092EBB5E289A5EBB4D0D8C437F74D824FA1496F208F63` |
| `docs/contracts/cora_evolabel_lineage_contract_zh.md` | `8EFDA00924867EE6315C93C09A85D6390ECF1FA4B8C2DC479DF65CCE2AD80168` |

### 9.2 UAV 权威资产

| 文件或 checkpoint | SHA256 / 记录值 |
|---|---|
| `configs/UAV_AGENT_PROTOCOL_V1_20260906.json` | `751DD8DD507364468A56CFCE116A21649D190ECD6D8CADEBE12FE9C71C73938D` |
| `configs/UAV_CORA_TARGET_COARSE_ROUTE_V3_20260907.json` | `980663B2786840146E6D4E3BF189D57499220E42B7B4E637137BA6FBF983F588` |
| `artifacts/UAV_TARGET_COARSE_SET_STRICT_V3_20260907/UAV_COARSE_SELF_EVOLUTION_V3_REPORT.md` | `DB5703A7BA8D523E60BFEF2DF0F8647C7402E264EB92C574C5600866AD446513` |
| `CORA-U0` server checkpoint | `cda324817f9519dfc8eeecc2d9f45ec359f77213a86789a058b488ab86a36a98` |
| `CORA-U-SE-Coarse-V3` server checkpoint | `6dec7c5216d5a4b7a68f96cfa97457c79b5d5ad9f4d43b8826a1c431792c9632` |
| `artifacts/UAV_RADAR_ONLY_EXPERT_POOL_V1_20260908_SCREEN_D/POOL_SCREENING_RECEIPT.json` | `314231EF05CCDC38235CEFD805A7B342075323584631E14EA513273E9FDE3660` |

### 9.3 专家研发资产

```text
configs/uav_radar_only_expert_library_v1.json
configs/uav_radar_only_expert_screening_v1.json
configs/uav_radar_only_expert_recipes/
src/agent_jsac/uav_radar_only_expert_library.py
src/agent_jsac/uav_radar_only_expert_models.py
src/agent_jsac/uav_radar_only_expert_training.py
scripts/train_uav_radar_only_expert.py
scripts/evaluate_uav_radar_only_expert.py
scripts/launch_uav_radar_only_expert_pool.py
scripts/audit_uav_radar_only_expert_pool.py
```

这些结构和脚本只保留为研究记忆，不自动注册给 Human 运行时。

## 10. 冻结结论

Human 线是当前主结果线：它已经完成由证据逐级升级、CSS 安全缓冲、机制专家、RIS 条件专家与精确回退构成的闭环。UAV 线提供一个更窄、但证据干净的低空雷达-only 自适应案例：源基座到注册目标粗定位适配的显著提升。

下一阶段应围绕 Human 冻结 Agent 做统一控制面、审计口径和论文叙事整合；不要再让 UAV 专家搜索占用主线，也不要把未晋级候选包装成运行时能力。
