# Native Adaptation Preparation Acceptance

## Authority

This document records pretraining checks, not new trained results. All sensing
optimization is prohibited during this acceptance run. Locked Test payloads
remain unavailable. Existing checkpoints are read only as explicitly identified
reference inputs to verify loading, not substituted for future fresh lineage.

## Sparse Anchor Adaptation

The actual `V29AnchorRadarDataset` is the legacy implementation of the public
CrossAnchor contract. Its positional weak supervision is:

`trajectory_anchor AND radar_training_valid AND finite(target_xy)`.

Interpolated trajectory availability alone does not enable positional loss.
An unaccepted sample receives `pseudo_accepted=false` and confidence zero. This
does not mean the sample contains no person. The frozen-source consistency and
source replay loss are separate training mechanisms, not pseudo background labels.

The native-loader audit used the reference run declared in the existing native
execution context. It verified all 9,300 16-frame clips across 31 Support episodes,
including exact causal histories, finite network inputs, declared NPZ SHA256,
manifest anchor counts and acceptance flags. The actual population is:

| Internal role | Episodes | Frames | Accepted position anchors |
|---|---:|---:|---:|
| Fit | 23 | 6,900 | 315 |
| Calibration | 8 | 2,400 | 69 |

File auditing observed 18,631 radar/quality files under admitted Support roots.
No denied payload was accessed. This is runtime access evidence for this audit,
not a proof about all earlier cache construction. Checksums and per-episode
details are in `HUMAN_SE1_PAYLOAD_PREFLIGHT_20260908.json`.

## Candidate Set Confirmation

The SE2 audit invokes the original prospective wrapper and its native main.
Only the training bodies and checkpoint saves are replaced by explicit test
interceptors. Frozen parents are loaded on CPU; actual candidate datasets and
source replay metadata are constructed. Audit-only overrides are CPU, zero
workers, and no preload. Production arguments remain separately recorded.

Stage A receives 19 Fit and 4 Calibration episodes. A synthetic return value of
three selected epochs tests dataflow only; it is not a recommended epoch count.
Stage B receives all 23 Support episodes and exactly that returned duration.
The audit stops before entering its optimizer. No checkpoint is created.

The candidate cache contains 6,900 frames, of which 6,336 have positive sample
weight. This number is not 6,336 exact point labels or a label-quality estimate:
SE2 learns weighted physical candidate sets. Candidate coordinates and weights
were checked for finite, valid ranges at stage entry.

The source replay dataset exposes 11,711 eligible source/background samples and
a deterministic 512-sample source calibration subset. Only its metadata was
loaded here; complete source radar I/O remains a separate acceptance gate.

## Depth Provenance Must Not Be Misreported

SE1 CrossAnchor has no depth input. SE2's registered physical candidate set has
upstream calibrated-depth evidence in its provenance. The SE2 training loader
does not read raw depth or supply it to the deployed radar network. Therefore,
`depth_read=false` at the training stage must not be described as "the entire
SE2 supervision pipeline never used depth." Manual calibration provenance and
target-label exclusion remain independently auditable.

## Boundaries Still Open

- Fresh output receipts must replace the reference parent binding before a new run.
- Portable dataset profiles and concrete native loaders must share a verified mapping.
- No independent canary is claimed when the protocol's canary membership is empty.
- These checks do not establish expert ranking, promotion gains, or accuracy reproduction.
- Real Qwen end-to-end nested dispatch and final package acceptance remain pending.
