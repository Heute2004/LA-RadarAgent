# Native UAV Parent Cache Smoke Acceptance

The server successfully exported a new prediction cache for source-training
sequence 2 using the frozen reference U0 checkpoint and the original `_load_u0`,
`FrozenUavGlobalPolarInferenceDataset`, and `predict_cora_u_global_model` functions.
Inference used causal 16-frame windows, checkpoint normalization and batch 4.
No fitting or sensing-model optimization was performed.

Parent SHA256: `cda324817f9519dfc8eeecc2d9f45ec359f77213a86789a058b488ab86a36a98`.
New cache-index SHA256: `8bbf2e9cf48ed78651768cf0b3ff828d7dba46b1b6c9a03327ce16d21addd1c4`.

The existing ParentCacheIndex reader resolved the exported source sequence and
verified its file hash and parent identity. The reference checkpoint and manifest
were rehashed after inference. The audit did not open a truth root or Test data.

The first attempt exposed a packaging omission: `scripts/train_cora_u_se.py` was
missing. Its existing implementation was included, and the package manifest was
updated. The successful retry did not replace the model loader with a new one.

Evidence: `artifacts/pretraining_acceptance/UAV_PARENT_CACHE_SMOKE_20260908.json`.
Server payload: `artifacts/UAV_PARENT_CACHE_SMOKE_20260908/cache/`.

Limitations: reference-parent inference only; this does not validate a newly
trained parent's receipt issuer, all source/support cache exports, teacher
fitting, autonomous promotion or numerical reproduction.
