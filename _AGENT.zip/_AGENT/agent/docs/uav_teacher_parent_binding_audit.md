# UAV Teacher Parent Binding Audit

## Confirmed implementation gap

The native source candidate teacher resolves U0 caches using historical folder
globs in `resolve_u0_cache`. It also writes a constant `U0_SHA256` to its report.
The temporal source teacher imports that constant and requires equality before
processing its source report. Target application imports the same historical
cache resolver. These are usable historical reproduction interfaces, not fresh
lineage interfaces.

The explicit UAV source compiler does not by itself repair this chain. A new
source checkpoint must not inherit the historical checkpoint identity merely
because the teacher can open a same-shaped cache. No fresh end-to-end readiness
claim is authorized until the following binding is implemented and tested.

## Required execution boundary

- Export a hash-bound cache index from the newly completed source parent.
- Bind index to task, run, protocol, parent receipt and checkpoint hash.
- Map sequence IDs to exact cache paths and hashes, without directory search.
- Use source training and source Development only for ranker fitting and temporal
  calibration. Apply the frozen learned policy to Support radar without truth.
- Derive report checkpoint identity from the verified index, not a constant.
- Temporal and target stages must check the same parent/index lineage.
- Keep historical recipes immutable and explicitly labeled historical replay.
- Tests must reject mixed parents, missing sequences, altered caches, forbidden
  roles and old report hashes presented as newly produced results.

This is a preparation defect, not evidence that the frozen model metrics are
incorrect. No trainer or teacher fitting was started during this inspection.
