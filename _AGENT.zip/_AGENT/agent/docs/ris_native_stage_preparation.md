# RIS Native Stage Preparation

The Human RIS shortlist combines four eligible original structures with the
registered `ris_temporal_gate_h16` capacity variant. The quarantined codebook
candidate remains excluded. UAV never enters this path.

The per-stage dispatcher now maps the registered shadow-training and hard-gate
stages, in addition to prediction freezing. All three commands consume the same
current CORA0 foundation and RIS teacher. The gate consumes the shared shadow
checkpoint; freezing consumes that shadow and the candidate-specific gate.
This follows the existing native batch DAG rather than importing a historical
expert checkpoint.

Before execution, the prospective command binder must attach the explicit RIS
support protocol. Source presence/hash validation, current-parent verification,
teacher provenance and disjoint split validation remain separate required gates.
Command compilation is not permission to train.

## Current acceptance scope

`tests/test_ris_native_stage_commands.py` checks dependency paths, shared parent
and teacher arguments, H16 width, cross-route rejection, and the actual bundled
prospective script parsers without importing training code. No model training or
Locked Test access is involved.

Five-candidate integrated RIS preparation and real Qwen behavioral acceptance
remain outstanding. These parser checks do not establish either result.
