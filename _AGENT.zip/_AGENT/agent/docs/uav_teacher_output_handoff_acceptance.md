# UAV Intercepted Teacher Output Handoff

## Contract

In combined teacher/adaptation mode the backend recompiles and validates the
pinned teacher profile at the adaptation boundary. It then requires an explicit
`teacher_output` receipt binding. No receipt means rejection, even when a
historical CSV is available. Adaptation-only compatibility checks remain
available, but are not combined-chain acceptance.

The receipt must bind the same task, run, teacher profile, manifest, parent
checkpoint and exact label path/hash as the compiled adaptation request.
The producer preflight itself must also carry matching task, run, manifest and
parent checkpoint identities. A correct output receipt cannot compensate for
a preflight from a different producer. These fields are emitted from verified
teacher inputs and compared again at adaptation admission.
Interception fixtures require `simulation=true`, `training_performed=false`,
`promotion_authorized=false`, and explicit forbidden-read flags. Canonical
SHA256 validation checks integrity; it is not producer authentication.

For this no-training acceptance run, the fixture builder copies the registered
historical label payload into a separate, explicitly named fixture file. Its
source is recorded and `generated_by_current_teacher=false`. This is intentional
simulation of a tool output, not a claim that teacher fitting ran or that new
pseudo-label quality has been reproduced.

## Evidence

- Local and server focused regression selection: 28 passed each.
- Real Qwen + verified lifecycle LoRA: valid combined path reached monitor;
  corrupt CSV and corrupt teacher-profile cases rolled back correctly.
- Memory restored from disk 12, 10 and 8 times respectively.
- The normal shadow_train receipt actually contains the handoff and points to
  `UAV_TEACHER_OUTPUT_HANDOFF_FIXTURE/intercepted_teacher_labels.csv`.
- Receipt digest:
  `717fe222631fc3526e4d5ed8ccb745ecd529b7fef56cfaf08768eaae8e7a606c`.
- Reports: `artifacts/pretraining_acceptance/QWEN_UAV_TEACHER_HANDOFF_ACCEPTANCE/`.

No sensing training, runtime promotion, numerical-reproduction claim or Test
access occurred. The next acceptance work remains fresh-source receipt
integration, source truth-loader/Doppler eligibility attestation and Human's
native expert handoff. The full toolbox is not yet declared ready.

## Producer identity follow-up

Four negative tests exposed acceptance of a foreign task/run/manifest/parent
producer preflight. After repair, the focused suite passes 23 tests and the
independent server release passes 354 tests.

The first real-Qwen rerun correctly rejected an old profile bound to another
run directory (`QWEN_UAV_PRODUCER_IDENTITY_20260909`). It remains a negative
acceptance result. A new reference-only fixture was built with the existing
audited scripts for the new run, rechecking 24 sequences / 7,200 prediction
frames and compiling all three teacher commands. No fresh inference or teacher
fitting occurred; the fixture is not a new scientific result.

`QWEN_UAV_PRODUCER_BOUND_20260909` passes all three cases: normal compilation
reaches monitor; corrupt labels and a corrupt teacher profile cause rollback.
Memory restores are 12 / 10 / 8. Production commands are intercepted and other
scientific receipts remain simulated. Task scripts and runtime in this rerun
come from `teacher_identity_candidate_20260909`; model/data remain external.
