# Weak-Evidence Expert Admission

The admission evaluator reuses the Human workflow's existing `weak_evidence`
required metrics, plus `forbidden_read_count`. It does not introduce new numeric
thresholds. A Dispatcher-provided, hash-bound threshold profile remains the
authority; every claimed pass is recomputed against its rule.

Required bindings include route, parent baseline, permitted support sequences,
fit/calibration split roles and independently verified evidence hashes. Missing
or duplicate metrics, wrong parents, foreign sequence denominators, Development
roles and unverified evidence are rejected. Exact evidence payload verification
must be performed by the caller; a matching hash alone does not prove quality.

The return value certifies only those evidence gates. It does not authorize
model promotion or launch native training. The historical route trainer remains
blocked until a real adapter consumes this authorization without reading its
reference-label admission audit. No synthetic passing audit may be substituted.

## Shared Validator Repairs

Thresholds and measured values must be finite numbers, not booleans. Denominator
counts must be positive integers, not booleans. All forbidden-read fields must
be explicitly false; absent fields are not evidence of zero reads.

Regression before repair: 12 of 14 safety cases failed. After repair, lab407 ran
30 tests successfully across threshold rules, operating contracts, bad metrics
and weak-evidence admission. Test-only threshold values are not production
calibration or evidence of label quality.

Evidence: `artifacts/pretraining_acceptance/weak_expert_admission_server.xml`.
Overall pretraining completion remains unproven and production is not released.
