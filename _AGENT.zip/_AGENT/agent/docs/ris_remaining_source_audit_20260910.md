# RIS Remaining Source Audit 2026-09-10

## Scope

This is a read-only server source recovery for `risecho_selective_recovery` and `risecho_geometry_consensus`. No sensing training, checkpoint opening, Locked Test read, label-payload read, frozen-result change, registry change, production change, or release change was performed. Server writes were not performed.

The remote identity was verified as `hostname=lab407`, `user=hyc`, `pwd=/home/hyc`. The requested remote release exists at `/home/hyc/radar+ris/AGENT-JSAC/releases/control_endpoint_preparation_20260910`. The same release path was not present in the local H: mount during preflight, so the audit uses the server path as the source of truth.

## Receipt Evidence

The copied receipt is:

`H:/Project/AGENT-JSAC/reproduction/reference_sources/ris_remaining_recovery_20260910/receipt/TRAINING_RECEIPT.json`

Remote source:

`/home/hyc/radar+ris/AGENT-JSAC/artifacts/route_expert_search/SE_BRANCH_FRESH_PLAN_20260826/shadow/corner_nlos_ris/corner_nlos_ris--04--risecho_selective_recovery/TRAINING_RECEIPT.json`

Receipt SHA-256: `75d3abf398adf17cbc46caddf015998bca41a2d57b83ee138e320a2122c7b2f5`.

The receipt records `route=corner_nlos_ris`, `primitive=risecho_selective_recovery`, `family=attention`, `selected_epoch=24`, and `implementation_id=null`. It records `development_read=false`, `locked_test_read=false`, and `support_canary_read=false`. Its checkpoint SHA-256 is recorded as metadata only; the checkpoint was not opened or copied.

## Selective Recovery

The strongest recovered source evidence is the pre-receipt structure from:

`/home/hyc/radar+ris/AGENT-JSAC-TOOLBOX_CANDIDATE_20260827_R2`

Copied under `recovered_pre_receipt`:

- `src/agent_jsac/se_branch_expert_models.py`, SHA-256 `c2e38ba99edb38b3e54a0ec642f8793f42a8613011a78e69d1777bff77fedd3b`, remote mtime `2026-08-26 18:27:42 +08:00`. Its primitive table maps `risecho_selective_recovery` to the `attention` family.
- `src/agent_jsac/se_branch_route_runtime.py`, SHA-256 `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3`, remote mtime `2026-08-26 17:51:57 +08:00`.
- `scripts/build_se_branch_route_runtime.py`, SHA-256 `b21d893d08a3016ec54443b3aeeb1213567b0ad3785765172599081b0f60195c`, remote mtime `2026-08-26 18:21:47 +08:00`.
- `configs/se_branch_route_expert_runtime_protocol_v1.json`, SHA-256 `9f6ea8d03abf7f9178c8251edaf96184681c4a04a4dac83c4ea3a652db0a0da5`, remote mtime `2026-08-26 18:06:13 +08:00`.

These files provide historical attention-family/runtime structure whose recorded mtimes are earlier than the receipt completion time. Mtime alone cannot prove file-generation order or establish that a file generated the receipt. Accordingly, `recovered_pre_receipt` means only "recorded mtime earlier than the receipt"; it is not conclusive receipt-code provenance. The receipt has no trainer or model source hashes, and the coverage record still reports zero matched source receipts for this expert. The exact trainer found in the historical toolbox was timestamped `2026-08-26 20:18:41 +08:00`, after the receipt, and is therefore copied only under `not_receipt_bound`.

Conclusion for selective recovery: **partial structural recovery only; exact receipt-bound source provenance remains insufficient**.

## Geometry Consensus

No `risecho_geometry_consensus` training receipt was found in the searched server roots. The named wrapper and explicit registered topology exist, and their mtimes are recorded in the manifest, but mtime is not used to prove generation order or receipt provenance. In particular, the `risecho_selective_recovery` receipt time is not evidence against geometry and is not used as a temporal exclusion. The only supported conclusion is that geometry has no receipt binding of its own; the available named files are copied under `not_receipt_bound` and are not treated as the original geometry implementation.

The registry's historical references to `train_v21_ris_temporal_hard_gate.py` and related route scripts are algorithmic-structure references only and do not bind weights, results, or an exact `risecho_geometry_consensus` training run. They were not used as a substitute source.

Conclusion for geometry consensus: **no exact source or training receipt recovered; evidence is insufficient**.

## Latest Release Check

The isolated release `/home/hyc/radar+ris/AGENT-JSAC/releases/control_endpoint_preparation_20260910` contains a later source closure, not the historical receipt-bound source. Its registered training closure has `se_branch_expert_models.py` SHA-256 `f5bacb5d2d18205939be5be2ce6e2d7028d2c0558120f03672af3b61fe47e665` and trainer SHA-256 `c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70`, both different from the pre-receipt toolbox source hashes above. The release closure has no `build_se_branch_route_runtime.py`. Its named wrappers are still post-receipt 456-byte wrappers. Therefore the latest release was inspected for comparison but was not used to backfill the old receipt.

## Coverage Context

`H:/Project/AGENT-JSAC/artifacts/pretraining_acceptance/EXPERT_SOURCE_COVERAGE_WITH_LEGACY_HINTS_20260910.json` records `experts_with_records=40`, `experts_with_matched_pair=40`, and leaves these two IDs without matched pairs. It also records `production_admission_granted=false`, `training_started=false`, `checkpoints_opened=false`, and `label_payloads_opened=false`.

## Verification

- Local SHA-256 values match the server values recorded in `PROVENANCE_MANIFEST.json`.
- `D:/anaconda3/envs/vlm3b/python.exe -m py_compile` passed for the copied Python files.
- The copied training receipt and local coverage JSON parsed successfully.
- No training or inference command was run. No checkpoint or model/label payload was opened.

Full per-file paths, hashes, mtimes, classifications, and verification flags are in:

`H:/Project/AGENT-JSAC/reproduction/reference_sources/ris_remaining_recovery_20260910/PROVENANCE_MANIFEST.json`
