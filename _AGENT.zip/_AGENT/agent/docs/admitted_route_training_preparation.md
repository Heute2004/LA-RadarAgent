# Native Route Training Admission Preparation

Status: partial acceptance only. The production Dispatcher integration is not complete.

The native route loader, optimization function, threshold selector and two-stage
fit/calibration recipe are retained. A separate authorization callback must verify
the weak-evidence receipt, route, parent branch and exact episode roles. The
adapter checks the identities of episodes actually returned by the native loader.
The default invocation intercepts before training, seeding or checkpoint writes.

The historical target-reference audit must not be substituted for this admission.
This does not invalidate historical results or imply Locked Test access. It means
that historical reference-dependent admission is not an autonomous label-free gate.

On 2026-09-08, local and server CPU regression suites each passed 37 tests covering
source profile binding, route admission, weak evidence and metric safety. The
two-stage test uses synthetic stub outputs, not sensing model training. These
tests do not establish numerical reproduction or scientific label quality.

The source adapter now also compares its bound data root with the signed profile
root. A regression test reproduced the previously accepted root mismatch before
the fix. Both environments reject it after the fix.

Remaining work:
- Bind authorization to verified on-disk metric, label and parent artifacts.
- Integrate the native route adapter into the Dispatcher and command compiler.
- Intercept the complete real-Qwen task flow with actual eligible data bindings.
- Seal and hash the final local/server package only after full acceptance.

No sensing training was run and no Locked Test was opened for these checks.
# Association Mode Binding

For this recovered native two-stage entry, association is explicitly `joint`,
matching the original entry's omitted argument and native train_stage default.
The interceptor verifies that default and records the mode; both stage calls
receive it explicitly. A changed or missing default fails before episode
loading. This does not change other expert families or globally force their
association mode. `physical_only` remains a distinct recipe, not a silent
substitution for this one.
