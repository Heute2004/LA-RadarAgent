# Approved native numerical authority

## Verified current state

Before operator approval, `tasks/human/task.json` required an external Human threshold profile. The
generic calibrated template contains ten unresolved numeric rules:

1. weak_evidence_physical_support_rate
2. forward_backward_path_agreement
3. trajectory_reachability_rate
4. weak_evidence_coverage
5. weak_label_agreement_delta
6. source_forgetting_delta
7. identity_regret_rate
8. empty_false_positive_delta
9. applied_post_shield_p99_shift_m
10. applied_post_shield_max_shift_m

These placeholders are not an authorized prospective profile. Structural task
inspection and passing code tests do not activate them. The native wet-route
reference-label audit likewise cannot replace a prospective authorization.

## Operator decision

The operator approved native frozen-method label, training, calibration and
promotion rules as numerical authority. The shared workflow enforces identity,
role, receipt and safety boundaries. The ten unresolved generic numerical
thresholds are not additional admission conditions. This decision is recorded
in `tasks/human/metrics/native_method_authority.json` and validated when loading
the Human operating contract. UAV retains its separate contract.

This does not remove native safety rules or extend the existing scoped SE1
continuation authorization. No values may be derived from target reference
labels or silently converted from per-frame rules to route averages.

## Implementation boundary

Authority selection is now explicit; method-specific admission binding is still
required. The existing generic receipt evaluator remains available for explicit
legacy tests/profiles, not as the newly selected default numerical authority.
The physical-set-mass reference preparation path now binds a native replay and
support-attachment verifier; see `native_method_specialist_acceptance.md`.
Unbound paths remain denied. Do not accept a cached reference-audit boolean,
or mark all families ready because this policy validator passes.

## Work following the decision

- Bind the selected method/profile authority to the exact parent and dataset.
- Produce scoped admission receipts using the corresponding evidence producer.
- Exercise native specialist interception through real Qwen, including denial,
  recovery and the complete source-to-expert request chain.
- Re-run the requirement-level acceptance matrix before a final readiness claim.

No production authorization is granted by this document. Training remains
disabled and Locked Test closed. The preparation goal remains incomplete.
