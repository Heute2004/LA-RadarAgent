# Historical candidate preparation

日期：2026-09-10。此模块为 Pair A 的 8 个 Human candidate expert 提供
CPU-only、prepare-only 的 original-native 检查面。它只证明源码 receipt lineage
和 synthetic/nativeSupport contract 可被加载、forward 和计算原始 loss；不声称
复现 2026-09-01 pool 的数值结果，也不读取 checkpoint、历史专家权重、Test 或
真实 payload。

## Exact source closure

Pair A 的固定 pins：

| role | path | SHA256 |
| --- | --- | --- |
| model | `reproduction/reference_sources/server_registered_training_dependency_closure_20260910/src/agent_jsac/registered_route_expert_models.py` | `3b379ea9955f23183b38b4368a096836f0cc50667943993ae58156e9a81ea9b8` |
| trainer | `reproduction/reference_sources/server_registered_training_dependency_closure_20260910/scripts/train_se_branch_route_expert.py` | `c3def5c3cf770faf1dcc4fc85c5b257160f7cabdc5c08c53d4f450e3c6144e70` |
| runtime validator | `reproduction/reference_sources/server_registered_training_dependency_closure_20260910/src/agent_jsac/se_branch_route_runtime.py` | `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3` |

`resolve_historical_candidate_binding()` 采用表驱动的 8-ID 白名单，逐字段核对
Human catalog 的 route、primitive、implementation、parent contract、application
contract 和 entrypoint hash。随后从 pinned model 实例的
`architecture_signature` 核对实际 spec；没有按名字猜测额外网络。

当前 8 个精确 spec 为：

```text
clor_local_offset                  -> local_offset_gru_v1:local:gru:local:cartesian
weak_return_mixture                -> weak_return_mixture_v1:mixture:gru:uncertainty:cartesian
polar_evidence_gate                -> polar_evidence_gate_v1:polar_gate:none:agreement:polar
wet_temporal_integrator            -> wet_temporal_integrator_v1:wet:gru:wet:polar
empty_guard_constrained_disambiguator -> empty_guard_constrained_disambiguator_v1:contrast:gru:agreement:polar
background_guard_branch_pruner    -> background_guard_branch_pruner_v1:residual:none:risk:cartesian
wet_guard_contrast_recovery        -> wet_guard_contrast_recovery_v1:contrast:gru:wet:polar
anomaly_hysteresis_gate            -> anomaly_hysteresis_gate_v1:hysteresis:tail:weather:polar
```

`branch_persistence_selector` 不在本 helper 中；它保留独立的
`CausalBranchRouter + train_branch_router_recipe` Pair B。

## NativeSupport contract

`load_native_support_manifest()` 要求 manifest schema
`agent_jsac_se_branch_route_runtime_manifest_v1`，并校验：

- exact `route`/allowed Support role，以及固定 `runtime_inputs` 和 train-only supervision；
- 六个 forbidden-read 字段均为明确的 `false`；
- `records` 中每个 `seq_[0-9]+` 的 frames、supervision origin、64 位 SHA256；
- manifest directory 与 `seq_*.npz` 成员集合完全相同；每个成员在 `np.load` 前先验 hash；
- pinned runtime validator、payload route/role/sequence、candidate arrays 的 shape/dtype/finite；
- 所有成员使用同一个 `parent_branch`，并可由调用方传入
  `expected_parent_branch` 做 outer verified parent pin；manifest 若声明顶层 parent 也必须一致。

candidate zero 必须是 frozen parent/base candidate。helper 只使用
`candidate_feature`、`candidate_xy_m`、`candidate_valid` 做 original model forward，
loss closure 另读取原 trainer 的 set-valued supervision 字段。

## Original loss closure

trainer 只通过 AST 选取以下顶层节点：`Episode`、`tensors`、
`intervention_required_from_allowed_set`、`legal_set_mass`、`episode_loss`。
不导入 trainer 的 CLI、`train()`、optimizer、scheduler、checkpoint 或 receipt writer。

原始目标为：

```text
supervised = sample_weight > 0 AND radar_training_valid AND sum(allowed_weight) > 0
P = softmax(candidate_logits)
L_set = weighted_mean(-log(legal candidate probability mass))
L_preference = weighted_mean(-sum(allowed_weight * log(P)))
L_acceptance = weighted BCE(acceptance, allowed_weight[..., 0] <= 0)
L_continuity = mean(relu(||E_t - E_(t-1)||_2 - 0.75)^2)
L = L_set + 0.10 L_preference + 0.50 L_acceptance + 0.02 L_continuity
```

## Preparation boundary

`prepare_historical_candidate_expert()` 在 `torch.no_grad()` 中对每个 nativeSupport
member 做 forward 和 loss finite check，核对输出 ABI：

```text
candidate_feature [B,T,K,F], candidate_xy_m [B,T,K,2], candidate_valid [B,T,K]
    -> candidate_logits [B,T,K], acceptance [B,T]
```

它只在内存中构造 fresh model，检查 state 未改变，并在 audit 中固定报告
`optimizer_created=false`、`backward_called=false`、`checkpoint_loaded=false`、
`checkpoint_saved=false`、`training_started=false`。代码不调用 optimizer、backward、
`torch.save` 或 `torch.load`。

## Main-entry integration note

本次没有修改 `scripts/train_se_branch_route_expert.py`、
`src/agent_jsac/registered_expert_intercept.py` 或 packager。后续主入口若接入，顺序
应是：先由现有 outer contract 完成 expert/route/parent/receipt、manifest/member hash、
EmptyGuard 与 Support role 检查，再调用本 helper，并把 outer verified parent 作为
`expected_parent_branch` 传入。helper 返回的 source hashes 和 audit 只能作为
non-promotable preparation evidence，不能直接触发训练或生产晋级。

表驱动结构预留后续把同一 `3b379/c3def` receipt lineage 扩到另外 6 个 catalog ID；
本次不添加它们，也不把早期 R39/R51 algorithmic reference 当作 source。

## Synthetic verification

`tests/test_historical_candidate_preparation.py` 仅生成临时 synthetic `.npz` arrays，
覆盖 8 个 ID 的 spec/source pins、forward/loss finite、route/parent/feature drift、
locked role、malformed parent 和 member hash-before-decode。测试会把
`torch.load`、`torch.save`、`torch.optim.AdamW`、`Tensor.backward` 替换为失败钩子，
确保 preparation 路径不进入训练或 checkpoint 行为。
