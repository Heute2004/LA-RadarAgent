# Selected Original Expert Batch Preparation

The public `bind_semantic_shortlist` function now accepts `original_profiles`.
It delegates to existing profile-pinned original Dispatcher adapters, rather
than substituting same-route native recipe IDs. The legacy recipe-only call
remains separate and does not acquire implicit original-structure authority.

CLI: `scripts/prepare_selected_expert_batch.py --request <absolute-json>
--request-sha256 <digest> --output <fresh-json>`.
The request has exactly `task`, `route`, `expert_ids`, and `profiles`.
`profiles` maps every selected ID to its absolute JSON path and SHA256.

Before any preparation the binder requires exact cardinality, unique IDs,
route membership, quarantine exclusion, mechanism diversity, complete profile
coverage, matching profile identity and interception mode. It then invokes
each existing adapter. All native reports must declare original-DAG readiness,
no execution and no training authorization. Branch receipts retain their
original `training_executed` field; other families use `executed`.

Five non-RIS routes, each with five synthetic profiles, passed batch tests.
Missing profiles and one profile impersonating two IDs were rejected.
Tests forbade checkpoint load/save, optimizer construction and backward.
Local focused regression: 37 passed in 8.49 seconds.
Server focused regression: 37 passed in 7.47 seconds.
These are overlapping tests, not 74 independent checks.

Verified server release: `original_batch_binding_preparation_20260910`.
ZIP SHA256: `6f247e6d750c4e69ecadb2f3a54559fcf55ba637b21a5757825ea9c8c12a3756`.

Actual frozen-LoRA Qwen batch-request behavior subsequently passed on all five
direct routes: each compiled five candidate profiles in one batch, reached
monitor and restored state 13 times. A missing-profile request rolled back
with 11 restores. Raw report/memory files are indexed in
`artifacts/pretraining_acceptance/qwen_batch_bound_actual_20260910/EVIDENCE_INDEX.json`.
The initial attempt failed on an outdated Human integration-manifest catalog
hash, before any batch ran. The corrected run used a fresh release and output
namespace; the failed run was not overwritten.

Remaining: the RIS mixed batch of
four isolated original profiles plus the native H16 stage DAG. RIS is explicitly
rejected by this direct-route batch function until that separate integration
passes; the five-entry RIS inventory alone does not certify batch execution.
No sensing training, Locked Test access or numerical reproduction occurred.
