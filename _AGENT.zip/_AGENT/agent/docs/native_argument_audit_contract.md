# Native Argument Declaration Audit

## Purpose

Run `scripts/audit_native_argument_declarations.py` against the resolved native
commands in a nested preflight report. This is a code-only prerequisite, not a
training authorization, structural expert binding, or numerical reproduction.
The inspector parses source ASTs without importing or executing trainers.

## Checks

- Record each inspected script SHA256 and the input report SHA256.
- Reject undeclared long options, missing statically required options, missing
  scalar values, and values outside statically resolved choices.
- Recognize declared short aliases when checking required options and values.
  A following declared short option cannot serve as the previous option's value.
  Negative numeric values remain permitted by this structural check.
- Resolve literal choice containers, including a single top-level literal
  dictionary assignment used through `tuple`, `list`, or `sorted`.
- Report unresolved dynamic declarations instead of executing source code.
- Create the output exclusively; never overwrite an existing audit receipt.

## Deliberate Limits

This is not a complete argparse emulator. Runtime parser selection, subparsers,
positional arguments, arbitrary nargs, custom actions, type conversion, dynamic
mutation or name shadowing, and runtime argument dependencies require separate
validation. A zero unresolved count is limited to the static checks above.
The report does not authenticate datasets, label provenance, selected parents,
split boundaries, checkpoint dependencies, promotion gates, or available GPU
capacity. It must never grant training authority by itself.

Commands containing an AGENT-JSAC release path are inspected against the supplied
agent root's scripts directory. Historical external script paths are inspected
in place. Always retain the resolved script path and hash in the receipt.

## Acceptance Evidence

On 2026-09-10 the six CPU unit tests passed locally. A server code-only audit of
67 commands from an existing nested preflight record returned zero unresolved
static declarations. This was not a fresh Qwen selection or a sensing run.
Server receipt: `artifacts/NATIVE_SHORT_ALIAS_ARGUMENT_AUDIT_20260910.json`.
Training remained intercepted; no dataset or model payload was opened by this
inspector, and no Locked Test or frozen result was modified.
