# Authorized Route Shortlist Policy

Latest authorization supersedes the four-only final shortlist: add the existing
native `ris_temporal_gate_h16` recipe to the four eligible original descriptors.
The final RIS candidate set is five. The four-entry selector below now selects
only the original-descriptor subset; it is not the final assembled shortlist.
`scripts/prepare_ris_five_candidates.py` verifies the three native source hashes
and emits the combined set. `tasks/human/experts/ris_native_supplement.json` is
the explicit supplement authority. H16 is a capacity variant, not a new model
architecture. It keeps the original native label and parent contracts; these
must be bound before dispatch. The current task selector is
`ConstrainedQwenTriLoopPolicy.propose_task_expert_shortlist`. Its exact returned
IDs go to `bind_semantic_shortlist` with matching profile pins. Real Qwen passed
the five-candidate preparation and missing-H16 rollback; training remains
intercepted and no trained-winner or performance claim follows.

The earlier four-candidate authorization applies only to the original-ID
subset after the latest addition. Other Human routes retain five candidates.
UAV has no expert search.

The authoritative setting is `selection.route_shortlist_sizes` in
`tasks/human/experts/library.json`. Its only override is `corner_nlos_ris: 4`.
The generic selector reads this mapping; no sequence IDs or dataset paths are
embedded in selection logic. The default remains five, and three distinct
mechanism families remain required. A shortage below the configured count
still fails closed. The existing function name is retained for compatibility.

Forty original catalog entries remain recorded. The quarantined
`risecho_codebook_consensus` remains forbidden for retrieval and execution.
It is not a finalist and is not reinstated by the four-candidate policy.

A shortlist is a set of training recipes, not trained winners. Parent
compatibility, label admission, actual training receipts and promotion metrics
remain separate mandatory gates. No training or Locked Test permission is
granted by this policy. Historical NO-GO reports remain historical evidence;
their missing-fifth-candidate finding is closed by the explicit H16 supplement,
not by removing provenance checks.
