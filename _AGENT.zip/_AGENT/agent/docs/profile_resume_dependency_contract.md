# Profile Resume Dependency Contract

An enabled dataset-profile binding persists `verified_dependencies` from the
read-only resolver. Every dependency contains its resolved path, SHA256 and
kind. This includes the profile, sequence metadata, adapter code, profile
schema, supervision method and training-tool contract.

On resume, `restore_profile` resolves and hashes the dependencies again and
compares the complete binding with the saved record. A contract edit must not
be accepted merely because its route names and membership still validate.
Missing files, changed hashes and removed dependency evidence fail closed.

Old enabled bindings without these dependency records cannot silently resume.
They require an explicit new preparation run under the current contracts;
do not rewrite an old run's receipt or claim that it used the new methods.
Disabled historical profile mode remains explicitly disabled and does not
provide portable-profile or fresh-lineage acceptance.

Verification uses only temporary metadata and adapter stubs. No adapter is
imported by the resolver. No sensor payload, model weights or Test data are
required for this check.

Regression evidence: four failures before the repair (three contract changes
were silently accepted, and dependencies were absent); 17 selected tests passed
after repair, including profile restoration and synthetic foundation-adapter
compatibility. This is not full lifecycle or numerical reproduction evidence.
