# Recovered Risk Candidate Preparation

Date: 2026-09-10

## Preserved Behavior

Two original catalog entries were connected to the preparation-only trainer:
`selective_branch_recovery` and `weather_risk_selector`. Neither adds new
network layers. Their original non-dual-path RiskMixer was compared with an
isolated historical class under identical parameters and partial validity
masks. The unrelated dual-path padding correction was not mistaken for a change
to these candidates. Original loss and calibration functions remain checked
against recovered source.

Dry selective recovery retains exact observed-candidate output. Weather risk
retains its bounded convex update, posterior scale 0.5 and maximum correction
0.5 m. Tests assert the actual preparation receipt, not just catalog text.
All three parent choices are checked. Direct training remains denied.

## Verification

Initial focused tests failed on missing admission, missing training guards and
the whole-class AST difference. After scoped binding and the branch-specific
historical comparison, the three suites passed locally: 166 tests in 14.10 s.
The same suites passed in the isolated server release: 166 tests in 9.09 s.

Release: `/home/hyc/radar+ris/AGENT-JSAC/releases/risk_preparation_candidate_20260910`.
ZIP: `artifacts/pretraining_acceptance/RISK_PREPARATION_CANDIDATE_20260910.zip`.
Files verified at installation: 1,782.
ZIP SHA-256: `7604b36669b63510ebc91c3c014e68020f25b0f6d91bcae20fbaa6faa6f0e11b`.

Actual Qwen with the existing LoRA reached `monitor_reached` for each new
candidate, with 13 memory restores and one preparation request. Weather risk
used SE2; selective recovery used SE1. Reports were retrieved as
`WEATHER_RISK_QWEN_VALID_20260910.json` and
`SELECTIVE_RISK_QWEN_VALID_20260910.json` under `artifacts/pretraining_acceptance`.
These checks use synthetic caches, real CLI preparation, and simulated receipts
for unrelated lifecycle stages. They perform no sensing training and confer no
production promotion authority.

The fresh coverage report `EXPERT_PREPARATION_COVERAGE_RISK_20260910.json`
records 42 entries, 16 reviewed preparation entries, and 16 exact-matched Qwen
positive preparation records. The remaining 26 entries and whole-lineage
readiness are not certified by this increment. No Locked Test was read and no
frozen numerical result was modified.
