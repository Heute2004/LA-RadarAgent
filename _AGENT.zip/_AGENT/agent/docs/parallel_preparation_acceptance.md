# Parallel Preparation Acceptance

Date: 2026-09-10

## Scope

This increment verifies preparation and interception only. It does not authorize
sensing training, import expert weights, read Locked Test, or reproduce frozen
numerical results. Human and UAV remain separate task contracts; UAV has no
expert stage.

## Main-Line Checks

The local focused suite passed 146 tests in 13.17 seconds:

- `tests/test_registered_training_preparation.py`
- `tests/test_registered_mechanism_training_contract.py`
- `tests/test_registered_profile_dispatch.py`

The positive preparation matrix now covers 14 reviewed entries and all three
eligible parent branches. Matrix equality is checked explicitly. The two new
entries preserve the recovered SetMixer and AgreementMixer mechanisms. Separate
tests ensure their preparation admission does not authorize production training.

The UAV compilation-accounting correction was independently rerun with its
associated gate, dispatch, preflight and task tests: 26 passed in 1.34 seconds.
The package closure suite passed 3 tests in 3.32 seconds. These are local results,
not validation of a newly installed server release.

## Actual Qwen Endpoint Check

The immutable server release `control_endpoint_preparation_20260910` was used
for the following checks, before the additional two local candidate bindings:

| Fixture | Outcome | Meaning |
| --- | --- | --- |
| LTGE with explicit 16-frame history | `monitor_reached` | Actual preparation CLI verified endpoint execution |
| Same fixture without history-window argument | `rollback_executed` | Missing temporal contract rejected before training |

Receipts are `artifacts/pretraining_acceptance/LTGE_ENDPOINT_QWEN_VALID_20260910.json`
and `LTGE_ENDPOINT_QWEN_MISSING_WINDOW_20260910.json` in the same directory.
Qwen requests are real. Other lifecycle-stage results in those fixtures are
simulated, non-promotable receipts. Neither outcome proves learned accuracy,
numerical reproduction, or a live production promotion.

## Isolated Server Candidate

The new immutable server candidate is
`/home/hyc/radar+ris/AGENT-JSAC/releases/parallel_preparation_candidate_20260910`.
It contains 1,764 manifest-verified files; the local ZIP SHA-256 is
`fef9f7758e7616e1973a83a7c9f572b3d155a0b403a6320ee1512fe75298f838`.
It is an incremental snapshot, not a final toolbox release.

The three main-line suites above plus UAV compilation accounting passed
147 tests in 9.40 seconds on the server. The first invocation omitted the
release root from PYTHONPATH and failed collection; adding the release root,
`src`, and `tests` resolved the invocation error without changing code.

Real Qwen on this release handled the new `dual_domain_set_mixer` entry:
the valid fixture reached `monitor` with 13 memory restores and one preparation
request; the code-hash fault reached `rollback` with 11 restores and one rejected
preparation request. Receipts are `SETMIXER_QWEN_VALID_20260910.json` and
`SETMIXER_QWEN_BAD_CODE_20260910.json` under `artifacts/pretraining_acceptance`.
This is actual tool-call acceptance with synthetic caches and intercepted
training, not learned performance evidence.

## Parallel Integration Boundary

Separate workers inspect UAV readiness, recover remaining original RIS sources,
and construct the per-expert preparation coverage matrix. Their artifacts require
main-line review before release. A source-hash match is not evidence of completed
training-contract admission. Missing original structures must remain unresolved;
similar modules cannot silently replace them.

No complete-toolbox GO is issued by this receipt.
