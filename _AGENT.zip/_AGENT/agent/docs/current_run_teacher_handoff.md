# Current-Run Teacher Parent Handoff

The Dispatcher pins an SE1 internal-stage receipt and its file digest. The
compiler calls `bind_teacher_parent` with the current run ID, protocol digest
and selected candidate ID. Existing internal-stage verification checks result
integrity, checkpoint hash, zero execution weight and qualified status.

The additional binding requires task `human` and producer
`cora_se1_universal_shadow`. It rejects a different run/protocol/candidate,
historical imports and changed checkpoint bytes. Only `se1_checkpoint` is
rebound in a copied native argument dictionary. Optimizer settings and label
recipes are not modified.

This is preparation-only parameter binding, not a promotion rule, digital
signature authority or proof of training. A fixture may exercise it only as
explicit simulation under the existing training interceptor. The current seven
unit tests do not establish an actual Qwen-to-crossfit training command chain.
The native compiler is now available through
`scripts/pretraining_human_teacher_commands.py`: provide a pinned Dispatcher
profile and a fresh report path. It verifies all native input pins, binds the
SE1 receipt, compiles all folds, invokes the native argument parser, checks
label scope and the parent SE2 label-manifest identity, and builds the native
fold manifest in memory. It never calls native main or creates training outputs.
Server native metadata preflight passed for four folds and 23 sequences using
an explicitly reference-backed SE1 fixture. Real Qwen with the previously
verified LoRA requested this entry once and reached monitor after 13 state
restores. Supplying a wrong profile digest led to rollback after 11 restores;
the native preflight result was absent on that failure path.

Evidence is in `artifacts/pretraining_acceptance/QWEN_TEACHER_PREFLIGHT_20260909.json`
and `QWEN_TEACHER_PREFLIGHT_REJECT_20260909.json`. The fixture records its
original audit pin and simulation flags; parent handoff carries that origin
into the report. No training, Test sensor data or newly produced teacher
predictions are involved. Other lifecycle stages remain simulated. This is
real Qwen tool-request acceptance, not a complete fresh-stage pipeline.

Execution used the complete candidate release with explicit source dependencies,
not the older top-level server source directory, which lacked a preflight
dependency. The candidate directory has newer overlays than its original ZIP;
it must be rebuilt and hash-sealed again before final release.

Profiles contain `task=human`, `mode=intercept`, current run/protocol/candidate,
the pinned SE1 receipt, exact native file pins, input/output directories and
execution-only settings. The original native manifest filename is required.
Fold count and epochs come exclusively from the pinned recipe. Four-fold argv
construction, fresh-output protection and invalid task/mode/run/hash/settings
are tested. These tests use fixtures, not new trained models.

Do not relabel an archived Development-selected SE1 as a current producer.
Reference replay must retain its explicit historical asset identity. This does
not invalidate reuse of the frozen algorithm or require retraining during
preparation. Future real training must produce a new, correctly bound receipt.
