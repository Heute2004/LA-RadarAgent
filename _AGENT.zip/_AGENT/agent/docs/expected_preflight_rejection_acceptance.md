# Expected Preflight Rejection Acceptance

## Purpose

A missing-input test must prove a rejected training request and a completed
rollback. It must not require the successful native preparation report that
the missing input prevents. This is an acceptance-checker distinction, not
a change to the Agent's production authorization, thresholds, or trainer.

The default positive/native validation is unchanged. A negative case must
explicitly supply both `--expected-outcome rollback_executed` and
`--expected-preflight-error` with a nonempty, preregistered exact error string.
Do not derive that expected string from a failed run merely to make it pass.

## Required Evidence

- The run is Human, ends in rollback, and records one native preparation attempt.
- All receipts are non-promotable; training, Test access, and numerical
  reproduction flags are explicitly false.
- Exactly one `shadow_train` receipt is failed, has the exact expected
  `native_preflight_error`, and transitions to rollback.
- There is no successful native specialist report and no deployment action.
- Every receipt retains `SIMULATED_NOT_PROMOTABLE`, disallows model mutation,
  and belongs to the same Human task. Unrelated failed steps are rejected.
- The terminal rollback receipt is present and successful.

An incorrect error, duplicate failure, missing rollback, successful native
report, cross-task receipt, or any training/Test/mutation flag fails acceptance.
A PASS here means the negative test behaved correctly; the candidate receipt
remains failed and the candidate remains unauthorized.

## Reproduction

Use `scripts/prepare_qwen_original_dag_acceptance_fixture.py` in an isolated
verified package. It emits the pinned positive and negative profiles and
commands for the existing `scripts/check_qwen_specialist_preparation.py`.
Use the existing frozen Qwen and LoRA paths supplied through CLI arguments.
Choose a fresh output directory; do not overwrite a previous report.

The missing source-replay case preregisters this exact error:

```text
Original branch DAG binding requires exactly: empty_guard_manifest,output_dir,parent_selection,source_replay_root,target_fit_root
```

## Observed Verification

The earlier server run correctly rolled back but its legacy checker demanded
a successful branch report. That original report remains `passed=false`.
The corrected checker was independently rerun with the same invalid profile
and a new output directory:

```text
outcome=rollback_executed
passed=true
restores=11
native_compilations=1
process_exit_code=0
```

Server output: `/home/hyc/radar+ris/AGENT-JSAC/artifacts/qwen_expected_rejection_verified_20260910_2105`.
The isolated release was `expected_rejection_candidate_20260910_2105`, with
archive SHA256 `01184c6b290b2f24c205ff88f38eb7fa4adf4e766827e5040a50238fa27cb060`.
The related checker/fixture regression passed 58 tests on that Linux release.
No sensing training, Locked Test evaluation, or numerical reproduction was performed.
