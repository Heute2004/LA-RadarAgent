# RIS Native / Prospective Dispatch Gap

## Confirmed source-level discrepancy

`src/agent_jsac/native_expert_execution.py` compiles the shared RIS shadow job
using `train_stageb_v11_small_sample_shadow.py`, followed by
`train_v21_ris_temporal_hard_gate.py`. The matching native recipe registry
declares these legacy entries and does not supply the current support protocol.

The native gate script in JSAC-AGENT-V4 explicitly requires calibration
`seq_014, seq_017`. The active prospective protocol requires `seq_007, seq_014`
and reserves `seq_016, seq_017, seq_019` for Canary. Therefore the old compiled
RIS DAG is not equivalent to the active prospective protocol, even if every
script hash and argument parser check passes.

`scripts/train_prospective_ris_v21_chain.py` instead invokes the protocol-aware
`train_ris_echo_shadow_prospective.py` and
`train_ris_echo_temporal_gate_prospective.py` entries. Those are the current
partition-aware path. The two dispatch paths must not be treated interchangeably.

## Required repair

1. Bind the RIS native candidate compiler to external current-protocol roles,
   preserving the validated adapter method and five gate-width candidates.
2. Use protocol-aware shadow/gate producers with hash-bound assets. Retain the
   original historical commands as reference only, not current training jobs.
3. Align output schemas and checkpoint filenames with the existing audit
   consumer; preserve parent/protocol identity and candidate IDs.
4. Test the complete compiled DAG against actual parsers and declared split
   roles, intercepting all subprocess training launches. Include a legacy
   calibration negative case.
5. Re-run real Qwen candidate dispatch and failure/recovery on the corrected
   sealed package before reporting current-protocol readiness.

No training was executed while locating this discrepancy. Existing frozen
results and historical protocols are unchanged. Current acceptance stays NO-GO.

## Implementation progress

`bind_ris_training_command` now translates the two historical training
entrypoints to the protocol-aware tools, preserving scientific parameters and
gate width. The shadow adapter receives external native-root/protocol arguments;
legacy `v11-root` becomes `data-root`, and only the verified direct-equivalent
feature condition is allowed. Conflicting protocol arguments are rejected.
Three command-level tests pass after an observed missing-function failure.
The complete DAG now invokes this helper for all six RIS training jobs (one
shared adapter plus five gates) when both external context symbols
`toolbox_root` and `ris_support_protocol` are supplied. Supplying only one is
rejected. The emitted `ris_partition_binding` distinguishes prospective jobs
from a historical reference plan. Eighteen compiler/binding tests pass.

Production context, script-hash registry and output-freeze/audit integration
still require alignment before enabling this path. The existing global
pretraining intercept remains mandatory; the binding marker is not launch
authorization. Do not claim the dispatch gap is fully resolved yet.

Prediction freezing now also receives the explicit protocol through the DAG.
With `--protocol`, the toolbox freeze entry validates the gate/parent binding
before dataset construction and takes Development membership from that same
protocol. It records the protocol hash; without the argument it remains an
explicit historical reference path. This change does not authorize opening
Development or Test. Nineteen command/compiler tests pass; actual native parser
and registry hash closure are still pending. No prediction data was read.

The real DAG launch boundary now rejects any plan containing RIS jobs unless
it declares the explicit prospective partition binding. This is an additional
guard, not authorization: pretraining sealed releases and intercepted plans
remain unlaunchable. Historical native plans are reference-only. Seventeen
launch/compiler tests pass after two tests reproduced the missing rejection.
Command-level asset hashes and protocol equality still require validation;
the plan marker alone must not be presented as full production certification.

The compiler now records SHA256 pins for each transformed RIS script from its
own bundled source and for the externally bound protocol when present. Missing
protocol files remain unresolved, not fabricated. At launch, every RIS command
must reference one of those pinned scripts and the same single `--protocol`
argument, and actual file hashes must match. Twenty launch/compiler tests pass,
including missing pins and tampered scripts. These pins provide consistency,
not an independent signature or training authorization. The sealed pretraining
release still unconditionally denies launch.

## Actual Parser Verification

The three prospective RIS scripts' real named argparse functions are now checked
without importing or executing their modules. All eleven generated RIS commands
parse and preserve the explicit protocol, teacher and parent paths. Local related
regression: 37 passed; server focused regression: 16 passed. The server needed a
standard `src/agent_jsac` layout because the compiler resolves bundled scripts
relative to its file. See `human_ris_actual_parser_acceptance.md` for commands,
receipts and limitations. This resolves parser compatibility, not data authority,
parent suitability, output validation, full Pool42 binding or real Qwen replay.

## Shadow Foundation Binding

The RIS consumers now require the shadow parent's foundation SHA256 to match
the requested foundation, along with explicit frozen/causal and no-read fields.
Missing fields are no longer silently considered clean. Local and server suites
both pass 77 tests. See `human_ris_parent_evidence_acceptance.md`. This repairs a
parent-content consistency gap; it does not authenticate a self-reported receipt
or authorize training, and full integrated acceptance is still outstanding.
