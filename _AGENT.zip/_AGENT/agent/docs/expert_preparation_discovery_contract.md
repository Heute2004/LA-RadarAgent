# Expert Preparation Discovery Contract

Date: 2026-09-10.

## Separate capabilities

The Human capability audit now exposes `registered_preparation` for the six
individually reviewed original-structure entries. It reads static declarations
from the requested release using Python AST literals; it does not import trainers
or execute model code. Each descriptor includes the fixed Human native method,
expert identity, intercepted Qwen entry, training family and current code hashes.

This resolves a discovery gap: an expert may have a verified preparation tool
while its production binding is still incomplete. The descriptor therefore has:

```json
{
  "task": "human",
  "mode": "intercept",
  "native_method": "registered_original_structure",
  "training_authorized": false,
  "production_binding_complete": false,
  "requires_dispatcher_resource_binding": true,
  "numerical_reproduction_verified": false
}
```

The existing production `status`, native recipe identity and automatic
substitution prohibition are unchanged. `bind_semantic_shortlist` still refuses
an unbound production shortlist. Do not feed preparation entries into a training
queue or treat six cross-route preparation entries as five candidates per route.

Discovery hashes identify current bytes, not a signed release or scientific
approval. Dispatcher must independently authorize resources and recheck pins at
execution. The earlier real-Qwen results were synthetic preparation runs; this
catalog change does not turn them into actual training or performance evidence.

## Current discovered entries

- angular_consistency_associator
- echo_extent_disambiguator
- range_conditioned_tcn
- local_shape_consensus
- state_consistent_local_refiner
- evidence_hysteresis_selector

MTI agreement, dual-domain mixture and polar-evidence entries with unresolved
mechanism contracts remain unbound and do not receive this descriptor.

## Verification

Local and standalone server discovery, retrieval, capability-authority and
shortlist tests: **13 passed**. Tests explicitly assert that discovery does not
grant production permission, allow cross-route aliases or admit missing methods.
No training, research data, model weights or Test reads occurred.

Server release:
`/home/hyc/radar+ris/AGENT-JSAC/releases/human_catalog_padding_audit_20260910`.
Server receipt: `preparation_discovery_acceptance.xml`.

## 中文记录

修复了“已有准备工具但能力清单发现不了”的集成缺口。六个入口现在可查询，
但仍明确不可训练、不可晋级；没有放宽原生生产绑定或五候选限制。
42专家整体和完整端到端验收仍未完成。
