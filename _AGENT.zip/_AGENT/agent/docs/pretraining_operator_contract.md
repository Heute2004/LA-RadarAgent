# Pretraining Operator Contract

## Authority and execution boundary

This is the preparation/interception contract for the separate Human and UAV
tasks. It does not grant sensing training, model promotion, or Locked Test
access. Read this document and `pretraining_acceptance_matrix.md` before older
dated progress reports. Historical reports retain their original scope.

Use the installed immutable release as `AGENT_TOOLBOX_ROOT`, not an older
working-directory copy. Model weights, datasets and the Python environment stay
outside this directory. A new dataset/model requires new explicit profiles and
hashes; never rewrite an old receipt to fit a new input.

## Entry and task isolation

1. Select `human` or `uav` explicitly. Inspect the matching task contract:
   `python scripts/inspect_agent_task.py --task human --state preflight`
   or the same command with `--task uav`.
2. Load that task's system prompt, workflow, skills and tool registry. Do not
   carry metric thresholds, memory or candidate IDs across task namespaces.
3. Resolve dataset/model/runtime profiles before loading payloads. Pin the
   current manifest, parent checkpoint, method and threshold authority.
4. The Qwen LoRA chooses legal tool requests. Dispatcher binds arguments and
   executes preparation checks; the model never authors trainer code.

The structural inspector is not a server runtime or numerical performance
test. Its `server_runtime_verified=false` field is intentionally scoped to that
inspector, not a statement that the recorded server behavioral runs failed.

## Human dependency and supervision chain

| Stage | Required inputs and label role | Handoff |
| --- | --- | --- |
| Source CORA | Source-only human annotations and native causal RA/RA-MTI windows | New source receipt/checkpoint in a fresh namespace |
| Sentinel | Declared empty-scene measurements, with separate fit/check roles | Coordinate-neutral empty-background guard |
| CORA-SE1 | Sparse cross-modal anchors, source replay, unknown-frame consistency | Current-run parent-bound preparation/training receipt |
| CORA-SE2 | Candidate-confirmed trajectory evidence and the permitted current foundation/SE1 parent | Independent routed branch, not a mandatory serial deployment stack |
| Teacher confirmation | Observed radar candidates, sealed evidence tiers, optional allowed calibrated-depth likelihood | Candidate/weight/membership provenance, not raw model predictions relabeled as truth |
| Route specialist | Exactly bound route parent, native label recipe and original training DAG | Fresh specialist candidate and native audit receipt |

The exact methods live in `tasks/human/supervision/method.json`,
`label_lineage.json`, the task training contract and hash-bound native recipes.
SE1 remains small-sample learning: unconfirmed frames are not empty targets.
Target Final-BEV, target manual radar anchors and Development/Test labels do
not enter weak-label construction or promotion. Offline teachers may use both
temporal directions; deployed radar windows remain causal and radar-only.

Parent selection is per route and must follow the profile and native recipe.
Do not attach every expert to SE2 automatically. RIS H16 retains its native
CORA0 parent contract; do not silently replace it with a different branch.

## Expert selection and preparation

Call `ConstrainedQwenTriLoopPolicy.propose_task_expert_shortlist` for Human.
Pass its exact returned IDs to `bind_semantic_shortlist` with matching pinned
profiles. The current eligible pool is 39 original implementations plus the
authorized H16 capacity recipe. Every route selects five. RIS uses four
original IDs and H16; the quarantined codebook candidate stays excluded.
Namespaces and hashes remain in every receipt. A recipe is not a trained winner.

Each original C3, Graph, Branch and RIS DAG preserves its own native input,
loss, schedule, calibration and inference contracts. Do not substitute a
generic head or import historical expert checkpoints. Preparation may check
native forward/loss interfaces, but must not instantiate an optimizer or call
backward. H16's synthetic profile validates commands, not real teacher tensors;
the separate real loader audit covers the current Fit/Calibration payloads.

RIS source data is virtual/generator-truth-coupled direct-equivalent data. Its
recovered JSON provenance does not establish new physical hardware observations.
The separately pinned source-sidecar archive is data provenance, not model code.

## UAV

Use only the adopted September 8 handoff: source foundation, source candidate
association/temporal teacher, coarse-set self-adaptation and source/adapted
routing. There is no UAV expert catalog, expert search or RIS tool.
UAV OLS and selection roles are defined in `tasks/uav`; Human distance AP and
Human promotion thresholds must never substitute for them.
The current teacher receipt must bind task, run, manifest, parent and output
hash. Reference-label copies used by interception are explicitly not freshly
generated labels. Missing producer/output receipt pairs must roll back.

## Audit, promotion and memory

Use `tasks/human/metrics/native_method_authority.json` for Human native gates
and `tasks/uav/metrics/selection.json` for UAV. Do not invent generic thresholds
or optimize on post-freeze Development scores. Preserve native calibration,
source retention, empty-scene safety and zero-weight canary semantics. A scoped
SE1 continuation is not permission for runtime deployment.

Memory is stored under `runtime/{task}/{site_id}/{run_id}` in normal operation.
Interception fixtures use their explicit fresh output directory and
`simulation_memory.json`. Hash-linked records bind state transitions and the
task contract. Resume only with matching task, contract and receipt hashes.
Wrong-task, missing, stale or inconsistent receipts must reject; no fallback
may fabricate a successful metric. A simulated promote state never deploys a
model: all simulation receipts are non-promotable.

## Repeating the accepted checks

- `scripts/prepare_human_integrated_active_fixture.py` creates a separate pinned
  fixture from the registered reference profile and emits the exact checker
  command. `check_qwen_integrated_preparation.py` exercises six native stages.
- `scripts/prepare_qwen_batch_fixtures.py` and
  `check_qwen_selected_expert_batch.py` exercise direct-route exact-ID batches.
- `scripts/prepare_ris_mixed_batch_fixture.py` creates complete and missing-H16
  requests. Run the checker with `--batch-kind ris-mixed --select-before-prepare`.
- `scripts/check_pretraining_qwen_uav_native.py` requires explicit model,
  adapter, teacher and measurement pins. Its reference-only flag must not be
  used to claim measurement-backed acceptance.
- `scripts/report_expert_pretraining_readiness.py` separates current exact-ID
  preparation coverage from the legacy native-replacement namespace. Neither
  registry declaration alone nor a historical success authorizes training.

Use fresh output paths for every repetition. Keep failed runs. Do not overwrite
release archives or their evidence. Verify `RELEASE_MANIFEST.json` hashes after
installation. This preparation package contains code/contracts/results, not
datasets or trained model payloads. Launching real training requires a separate
authorization and another current resource/profile check; Test remains locked.
