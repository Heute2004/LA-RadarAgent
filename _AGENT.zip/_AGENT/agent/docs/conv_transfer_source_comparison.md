# Historical Conv Expert Source Comparison

## Scope

Date: 2026-09-09. Code-only recovery from the verified lab407/hyc server.
No checkpoint, prediction, dataset, Development payload or Locked Test was read.
No training, model inference, deployment, or promotion was performed.

Compared projects:

- `code_radar_cbpr_v1_20260805`
- `code_radar_convlstm_expert_transfer_20260805`

The second project was explicitly collected with the existing static import
collector. Imports were parsed, not executed. Its archive contains 31 Python
files plus a collection manifest, with zero missing requested dependencies.
All 31 recorded file hashes were verified and all Python files parsed as AST.

Archive: `artifacts/pretraining_acceptance/CONV_TRANSFER_SOURCE_CLOSURE_20260909.zip`

SHA256: `b877502a223d38a570bf784f52e87848bf402430ad96ec10e4683778e5fc0b22`

Comparison archive:
`artifacts/pretraining_acceptance/CONV_EXPERT_SOURCE_CLOSURE_20260909.zip`

SHA256: `b7ac29afbe4eec0fa38bce2dc93178e62a0e7afb44c3d67beb5a3c8f1ed7765c`

## Verified Findings

Of the 31 recovered transfer files, 29 are byte-identical to the corresponding
CBPR files. No file in this transfer dependency closure is absent from the CBPR
closure. This is evidence about these collected files, not entire repositories.

Two files differ:

| File | Difference | Consequence |
|---|---|---|
| `radar_bev/geometry.py` | CBPR materializes contiguous input and expanded sampling grid before `grid_sample` | Sampling coordinates are unchanged in source; numerical/runtime equivalence was not newly executed in this comparison |
| `radar_bev/models/convlstm_expert_wrappers.py` | CBPR adds imports and DPBR/CBGAR classes | Do not replace the larger file with the older transfer file |

The AST of each common wrapper class is identical, ignoring source positions:

- `_FrozenConvLSTMExpert`
- `ConvLSTMHeterogeneousExpertBEV`
- `ConvLSTME3RouteExpertBEV`
- `ConvLSTMTECSEchoExpertBEV`
- `ConvLSTMPBMHBRStage1BEV`

CBPR-only wrapper classes in this comparison are `ConvLSTMDPBRBEV` and
`ConvLSTMCBGARBEV`. Their presence does not authorize adding or substituting
catalog entries, RD input, training labels, or production bindings.

## Original Family Source Map

These are source-family references, NOT automatic bindings to the 42-entry pool.

| Original family | Head source | Conv wrapper | Remaining binding check |
|---|---|---|---|
| CLOR | `heterogeneous_experts.py:CLOREXpert` | `ConvLSTMHeterogeneousExpertBEV` | Continuous local offset must not silently become exact candidate selection |
| TECS | `e7_experts.py:TECSEchoCandidateSelector` | `ConvLSTMTECSEchoExpertBEV` | Preserve physical candidate construction, token inputs and selection loss |
| LTGE | `e3_experts.py:LTGEExpert` | `ConvLSTME3RouteExpertBEV` | Preserve temporal candidate/graph behavior and approved label consumption |
| GG-SRRE | `e3_experts.py:GGSRREExpert` | `ConvLSTME3RouteExpertBEV` | Preserve recovery/gain phases and parameter freezing |
| PB-MHBR | `e9_pbm_hbr.py:PBMHBRStage1CandidateReranker` | `ConvLSTMPBMHBRStage1BEV` | Preserve candidate types and parent feature compatibility |

The two collected historical training entrypoints are byte-identical across
these projects. They retain their historical supervised data/evaluation
contracts. Source recovery does NOT authorize their unmodified use in the
current target weak-supervision workflow.

## Decision

Keep both immutable recovery archives for provenance. Reuse the already
recovered CBPR dependency closure as the working reference, without copying
duplicate families into the expert count. Preserve the original 42 names and
structures. No new executable capability is granted by this comparison.

The principal remaining work is the per-entry original implementation and
current training-contract binding, not further counting mirrored files.
Pretraining acceptance remains NO-GO until those bindings and the remaining
end-to-end tool handoffs are verified.
