# Sentinel Preparation Tool

The Human interception backend binds `commission_background` to a Sentinel
command preflight when a Sentinel profile and its hash are supplied together.
This reuses the existing lifecycle dispatcher; it is not a new Agent or a live
training backend. Profiles declaring UAV or pretending to have a fresh parent
are rejected by this reference-parent path.

The compiler verifies native trainer/loader, frozen recipe, source checkpoint,
empty payload audit and every file listed by that audit. Paths are explicit,
output must be fresh, and no model-authored training arguments are accepted.
The resulting command is evidence only and is never launched by this backend.

Server result: SENTINEL_REFERENCE_COMMAND_VERIFIED; all 4,207 commissioned-empty
payload/statistics files matched their hashes. The recovered recipe remains
25 epochs, batch 8, 16-frame history, top-4 CORA candidates and 100-frame tails.
Six compiler/backend CPU tests passed locally. No sensing training occurred.

Evidence: `artifacts/pretraining_acceptance/SENTINEL_TOOL_BINDING_20260908/`.

The background statistics use the full commissioned empty capture. Tail-set
validation is conditional on that commissioning, not an independent unseen-site
test. This is the preserved historical contract, not a new scientific claim.

Outstanding: bind a newly trained source receipt and recomputed candidate cache,
verify actual Sentinel invocation with that parent, then exercise combined
Qwen source/Sentinel/SE1/SE2/expert requests. This report does not certify those
steps; overall readiness remains NO_GO.
