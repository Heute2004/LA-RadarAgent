# UAV Qwen Teacher-Command Interception

The existing `scripts/check_pretraining_qwen_uav_native.py` accepts the optional
pair `--teacher-command-profile` and `--teacher-command-sha256`. With this pair,
the valid case requests the native source-ranker, temporal-calibration and
target-teacher command preflight before adaptation-command preflight. All
commands remain intercepted; the other scientific receipts are simulated.

The teacher input profile and cache index must bind the run identifier to the
absolute `OUTPUT_DIR/valid_compile` directory used by TaskWorkflowRuntime.
Do not relabel an old cache as a new run. Missing one member of the CLI pair is
rejected before the Qwen model is loaded.

Three cases are checked when the pair is supplied:

| Case | Scope | Required outcome |
| --- | --- | --- |
| valid_compile | Teacher + adaptation command checks | Monitor; one teacher and one adaptation compilation |
| bad_label_hash | Adaptation only | Rollback after one adaptation compilation |
| bad_teacher_hash | Teacher command digest rejection | Rollback; one teacher attempt, no adaptation compilation |

The label fault case deliberately does not reuse a teacher cache from another
run. The teacher fault fails at its outer digest before accessing its bound run.
Compilation counts are checked as well as the terminal state, so a rollback at
an earlier unrelated stage cannot satisfy the expected adaptation fault result.

## Current evidence and limits

Local regression selection: 11 passed, including command-entry wiring,
teacher binding, and the persistent workflow's adaptation success/failure cases.
The command-entry unit tests stub Qwen and the case runner. They are NOT evidence
that real Qwen has completed the combined native teacher chain. That server run
still requires the complete current-parent cache and a pinned command profile.

During the persistent workflow test, the UAV integration manifest still pinned
the pre-repair `prospective_tools.py`. Its diff was reviewed: the changes add
native stage protocol and data-root validation plus a preflight-only entry.
Only this stale asset pin was updated to the current shared implementation,
already pinned by Human. Integrity checking remains enabled.

No model training, target truth access, Test access, or numerical reproduction
is authorized by this preparation entry.
