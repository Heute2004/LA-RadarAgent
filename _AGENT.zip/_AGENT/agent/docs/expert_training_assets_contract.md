# Expert Training Assets Contract

The Human toolbox expert pool must contain exactly 42 training recipe entries.
Each entry must resolve to a callable training script and its necessary model
implementation/configuration. Shared implementation dependencies may be reused;
42 entrypoint files alone do not establish 42 valid training recipes.

Do not embed expert checkpoints, prediction caches, historical performance
tables, or frozen numerical outputs in the expert asset directory. Models and
datasets remain external and are bound by the run profile. Shared label builders,
audit tools, workflows and skills remain in the common toolbox layer, not as
pretrained expert assets. Minimal IDs, mechanism descriptions and input/output
metadata belong in the registry so the Agent can select five suitable recipes.

UAV has no expert pool. Do not attach the Human expert lifecycle to UAV.

No archived generic wrapper may be silently re-enabled or renamed to satisfy
the count. A recipe is ready only when its implementation, arguments, label
contract, allowed parent and from-scratch initialization have been validated
against the intended method. The pretraining release must still intercept all
training requests. Numerical reproduction remains outside this acceptance run.

Current inventory inspection: the Human library has 42 entries and 42 existing
unique entrypoint paths. Some dispatch through archive-only wrappers, so the
42-callable-training-recipes requirement remains incomplete. Existing frozen
weights and results were not edited or imported during this inspection.

Capability retrieval reads `tasks/human/experts/library.json` and
`tasks/human/experts/native_training_recipes.json`, not top-level legacy copies.
Quarantine evidence remains separate from the training assets. A regression
test corrupts both legacy mirrors and verifies that task-scoped retrieval still
works and records the task files' hashes. This does not re-enable archived
wrappers or establish missing method equivalence.

Describe-only behavioral audit of all 42 hash-matched entrypoints returned
42 valid descriptions and zero entries declaring train mode. All currently
delegate to the archive-only wrapper. Evidence:
`artifacts/pretraining_acceptance/EXPERT_42_ENTRYPOINT_DESCRIPTIONS_20260909.json`.
This supersedes the earlier imprecise statement that only some entrypoints were
archive-only. The 30 native recipes are a separate execution inventory; their
presence does not make these 42 wrappers trainable. Do not remove the archive
guard to manufacture acceptance.
