# Historical RIS Candidate Preparation

Date: 2026-09-10. This is an isolated, synthetic-only preparation surface
for the five RIS entries in the authorized exact-source coverage record. It is
not a production-admission result, a quarantine decision, or a historical-best
claim.

## Scope and Evidence

Only these new files belong to this change:

- `src/agent_jsac/historical_ris_candidate_preparation.py`
- `tests/test_historical_ris_candidate_preparation.py`
- `docs/historical_ris_candidate_preparation.md`

The exact-source evidence used by the helper is:

| Evidence | SHA-256 / role |
|---|---|
| `artifacts/pretraining_acceptance/EXPERT_EXACT_SOURCE_COVERAGE_20260910.json` | `4260f9f51d6dc6f454577a8cec59f7935e49f7935b3926ffd2ba23375f461011` |
| `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/registered_route_expert_models.py` | `a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486` |
| `reproduction/reference_sources/agent_expert_runtime_contracts/scripts/train_se_branch_route_expert.py` | `01a7aac1d09a5ec4bbc06b7bf0ae0d5bd739ecc6ffef01daf13ab22be91c02dd` |
| `reproduction/reference_sources/agent_expert_runtime_contracts/src/agent_jsac/se_branch_route_runtime.py` | `d022535a84fa8227682652361c21f513592e7a218f40c1e11050c9042aae25e3` |

The coverage artifact is pinned as provenance evidence and is checked for the
five exact `corner_nlos_ris` records. Each record must contain exactly one
matched source pair, no missing role, the model/trainer hashes above, and the
following server receipt reference:

| Expert ID | Registered implementation | Receipt reference |
|---|---|---|
| `ris_temporal_gate_h32` | `risecho_temporal_gate_v1` | `.../corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--04--ris_temporal_gate_h32/TRAINING_RECEIPT.json` |
| `risecho_path_integrator` | `risecho_path_integrator_v1` | `.../corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--01--risecho_path_integrator/TRAINING_RECEIPT.json` |
| `risecho_codebook_consensus` | `risecho_codebook_consensus_v1` | `.../corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--03--risecho_codebook_consensus/TRAINING_RECEIPT.json` |
| `risecho_dual_path_mixture` | `risecho_dual_path_mixture_v1` | `.../corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--02--risecho_dual_path_mixture/TRAINING_RECEIPT.json` |
| `risecho_dual_stream_stability` | `risecho_dual_stream_stability_v1` | `.../corner_nlos_ris--expert-pool-42-reselect-corner_nlos_ris-20260901--05--risecho_dual_stream_stability/TRAINING_RECEIPT.json` |

The receipt references are bound through the exact coverage record. The helper
does not open a historical receipt payload or a historical checkpoint. The
mutable global catalog hash is not used as a substitute for this pair-wise,
field-level binding.

Each library row is compared field by field with `tasks/human/experts/library.json`.
The resulting canonical entry hashes are:

| Expert ID | Library entry SHA-256 | Entrypoint SHA-256 |
|---|---|---|
| `ris_temporal_gate_h32` | `13bc6dd17d9293c59819edee258469f75779245d9764cf5a01c1010feb90a96c` | `2feda021013baa21b501f1fe0d893572effd0c7f96686acc50e1cb7c9eced170` |
| `risecho_path_integrator` | `d14887b6e7e993c55f8a6614b45dadf99f0825702a9a565a2d08448ef8889323` | `58548b255a688788641a2437dd992aa80e825d73f425454b81bfb0ae4986aeed` |
| `risecho_codebook_consensus` | `07047912547919f4340da6de2f4be69cd211a4446be6a6481de8b0611a91bde7` | `84c949a85540c8277b2533335097926e433b82469053ee2433f0e4b2f8a6f647` |
| `risecho_dual_path_mixture` | `df174a9956bd9c44645f1688f25cd89ba44d444f52612271e65ad71078fe2583` | `a38c3b1279f38607c1577a3f205d1647a3654d198e4e2e699116067fd0c7b511` |
| `risecho_dual_stream_stability` | `7565bd59f1bac84de3573490108680b3114f138d04428a58b38caee8250f67d1` | `a00166ea4d18da4300a628583469a12e2e681a3c96cfb3e6469ff3404434ddce` |

## Native Model ABI

All five rows use the original `RegisteredDiscreteCandidateExpert` factory.
The registered model source gives each row an explicit topology signature and
factory-selected mixer:

| Expert ID | Topology signature | Actual mixer from the factory |
|---|---|---|
| `ris_temporal_gate_h32` | `risecho:gru:codebook:polar` | `_IdentityMixer` |
| `risecho_path_integrator` | `path:tail:codebook:polar` | `_PathMixer` |
| `risecho_codebook_consensus` | `codebook:none:consensus:polar` | `_CodebookMixer` |
| `risecho_dual_path_mixture` | `dual_path:conv:receiver:polar` | `_RiskMixer(dual_path=True)` |
| `risecho_dual_stream_stability` | `dual_stream:conv:consensus:polar` | `_DualStreamMixer` |

These are observed source structures, not names inferred from a paper or
primitive label. In particular, the first RIS temporal model maps `risecho`
to `_IdentityMixer`; the dual-path model maps `dual_path` to `_RiskMixer` with
the `dual_path` flag; and the fifth model uses `_DualStreamMixer`. No generic
router or renamed architecture is substituted.

The exact forward contract is the original three-input scorer:

```text
candidate_feature [B,T,K,F]
candidate_xy_m    [B,T,K,2]
candidate_valid   [B,T,K]
    -> RegisteredCandidateExpertOutput
       candidate_logits [B,T,K]
       acceptance      [B,T]
```

`feature_dim` is derived from the Support archive's final feature axis. The
helper accepts only CPU preparation and requires `hidden_dim >= 16`. It checks
the full model architecture signature (`implementation_id:topology`) and the
actual mixer class after construction. No weights are imported.

The `risecho_codebook_consensus` model retains its original
`nn.Embedding(16, hidden_dim)` and candidate-axis ordinal modulo-16 slot
source. This is structure preparation only. The current static quarantine
(`forbid_retrieval_and_execution`) is unchanged; no codebook retrieval or
execution is released. The other four models are not forced to pretend they
have a codebook-specific mixer or input.

## Original RIS Data Contract

The helper requires two native Support manifests because the recovered trainer
has separate target Support and source-replay roots:

- fit manifest role: `fit`, with origin
  `offline_bidirectional_RISEcho_observed_candidate_set`;
- source-replay manifest role: `source_replay`, with origin
  `zero_weight_ris_canary_or_identity_replay` and every `sample_weight` exactly
  zero;
- both roles: route `corner_nlos_ris`, schema
  `agent_jsac_se_branch_route_runtime_manifest_v1`, the five historical
  runtime inputs, the declared train-only supervision, and all six forbidden
  read flags false;
- each archive: `candidate_xy_m [frames,K,2]`, `candidate_valid [frames,K]`,
  `candidate_feature [frames,K,F]`, `allowed_weight [frames,K]`,
  `sample_weight [frames]`, and `radar_training_valid [frames]`;
- candidate zero is the frozen `cora0` identity/base candidate; nonzero
  actions remain observed physical current-frame candidates.

Every `seq_*.npz` member is SHA-256 checked before `np.load(...,
allow_pickle=False)`, then passed to the hash-pinned runtime validator. The
hash and membership checks are real checks; a manifest's self-reported
`forbidden_reads` values are only declarations and are not treated as a
security proof.

The original trainer's `validate_route_supervision_contract` is compiled and
called from the exact trainer AST closure. It requires the RIS pair to be
nonempty, to use parent `cora0`, to use the two exact origins above, and to keep
source replay zero-weight. The helper also requires the caller to provide
`expected_parent_branch`; it never silently defaults a fresh request from a
historical receipt. The exact trainer's own `cora0` rule is therefore an
observed historical data-contract requirement, not a new authorization or a
permanent parent selection rule.

## Original Loss Closure

The helper parses the exact trainer source and executes only this AST closure:

```text
_PRODUCTION_FAMILY_BY_ROUTE
validate_production_trainer_family
validate_generic_trainer_family
Episode
validate_route_supervision_contract
tensors
intervention_required_from_allowed_set
acceptance_target_from_preference
assert_disjoint_optimization_roles
legal_set_mass
production_objective_terms
episode_loss
```

The loss function is the recovered shared `episode_loss`, not a codebook-only
replacement. For `ris_temporal_hard_gate`, its complete family weighting is:

```text
L = L_set
  + 0.35 L_preference
  + 0.75 L_acceptance
  + 0.10 L_continuity
  + 0.75 L_identity_regret
  + 0.00 L_coordinate
  + 0.00 L_bound
```

The terms are the exact AST operations: legal-set probability mass, allowed-set
preference cross-entropy, preference-derived acceptance BCE, temporal expected
step penalty above `0.75`, and identity regret. Coordinate and bound terms are
zero for this family. The synthetic run calls this same closure under
`torch.no_grad()` for fit and zero-weight replay members and records the
original stats shape, including the source replay early-return shape.

The model's `gate_kind="receiver"` for `risecho_dual_path_mixture` is an
internal registered model configuration. Physical receiver provenance and
payload acceptance remain Banach's responsibility; this helper does not
implement or infer a physical receiver gate.

## Banach Provenance Boundary

`RISProvenanceRequest` mirrors the real Banach interface:

```text
validate_ris_payload_provenance(
    payload,
    protocol=...,
    training_contract=...,
    training_tool_contract=...,
    method_contract=...,
    label_contract=...,
    expected_hashes=trusted_hashes,
    expected_identity=original_identity,
    expected_supervision_origin=...,
    expected_parent_branch=...,
)
```

When a complete request is explicitly supplied, the helper calls this gate
before loading the recovered model and requires its real result to be
`validated=true`, `production_admission=false`, and `quarantine_changed=false`.
The trusted hashes must come from the caller's trusted manifest or external
receipt-bytes verifier; payload self-report is not accepted as trust.

When no request is supplied, the helper does not call a pure provenance gate
and reports exactly:

```text
provenance_gate.status               = not_run_structure_only
provenance_gate.validated            = false
provenance_gate.production_admission = false
provenance_gate.quarantine_changed   = false
```

Thus a synthetic forward/loss pass is never reported as payload provenance
validation. In both paths, the helper reports `production_admission=false`,
`quarantine_changed=false`, and `codebook_quarantine.released=false`. A future
conditional review of `risecho_codebook_consensus` requires a new trusted RIS
receiver and label receipt to pass Banach's gate; this helper neither creates
that receipt nor unlocks the old quarantine.

## Verification

The new synthetic suite passes:

```text
PYTHONPATH=src D:\anaconda3\envs\vlm3b\python.exe -m pytest -q \
  tests\test_historical_ris_candidate_preparation.py
12 passed
```

The tests cover all five exact IDs and actual mixer classes, source/library/
entrypoint hash binding, member hash-before-decode, both RIS provenance
origins, zero-weight replay, explicit current-parent binding, original loss
stats, no-grad forward/loss, Banach call wiring, and rejection of a
self-reported admission result. `torch.load`, `torch.save`, `AdamW`, and
`Tensor.backward` are monkeypatched to fail. No training, Test split, model
data, checkpoint, or historical weights are read.

This is an original trainable-implementation preparation report, not a claim
that any of the five is a frozen best model or ready for production execution.
