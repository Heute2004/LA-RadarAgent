# Pretraining launch boundary

The native DAG runner rejects an execution containing intercepted jobs or
`wrapper_execution_permitted=false`. A release whose manifest declares
`training_enabled=false` also rejects legacy plans without interception marks.
Validation happens before log directories, state files or child processes.
This protects against accidentally passing a compiled preflight plan to the
training runner. It is not a sandbox against manually editing trusted code.

The native Dispatcher independently guards resolved specialist commands before
historical audit-driven decisions. These checks serve different boundaries:
the runner denies preparation-release launches; the Dispatcher denies the
reference-label admission path.

Server evidence, 2026-09-09:

- Release `launch_boundary_candidate_20260909` contains 1,030 files.
- ZIP SHA256 `970a07fb50b74f2d211e78347e78982cefa2c8e86ab841597c3f362f84662e47`.
- Packaged regression: 374 passed in 13.68 seconds.
- Actual CLI received a synthetic empty plan and rejected it before its run
  directory was created. No optimizer or training subprocess was started.
- Receipt: `artifacts/pretraining_acceptance/NATIVE_LAUNCH_BOUNDARY_20260909.json`.

This does not authorize production training, numerically reproduce a frozen
model, or complete missing method-specific admission/profile bindings. Do not
remove the release lock merely to make a pretraining test appear successful.
