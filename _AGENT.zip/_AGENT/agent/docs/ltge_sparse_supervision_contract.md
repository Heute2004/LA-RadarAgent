# Original LTGE Sparse Supervision Boundary

## Purpose

Preserve the recovered `LTGEExpert` network and original edge objective while
preventing missing historical labels from becoming negative edges. This is an
explicit loss-call compatibility repair, not a new expert architecture or a
claim of historical numerical reproduction.

Toolbox callable:
`agent_jsac.native_ltge_supervision.sparse_ltge_edge_loss`.

## Caller Requirements

The Dispatcher must first admit the parent checkpoint, task, source/support
split, label provenance, independent calibration ownership and aligned history
frame IDs. Tensor validation alone cannot establish those facts. Do not use
target Final-BEV, manual RA anchors, Development or Locked Test as supervision.

The callable accepts the original graph tensors, current coordinates, historical
coordinates and explicit boolean validity masks. Validity means an authorized
label exists; it must not be inferred from zero coordinates or person absence.
No label creation or interpolation is performed here.

Unknown historical columns are masked out before the original BCE feasibility
selection. They contribute neither positive nor negative labels. Current frames
without authorized labels also contribute no edges. Missing coordinates may be
NaN only where explicitly invalid. Valid labels and graph observations must be
finite, dimensionally aligned tensors on one device. An entirely unobserved
graph produces a differentiable zero, not fabricated supervision.

## Provenance And Deployment

Original loss definitions are loaded through the existing hash-verified Conv
source/supplement loader. No recovered source file is overwritten.
The helper is not yet an admitted 42-pool production recipe. It does not start
training, grant promotion, bind a semantic identifier or select a parent.

Before integration into a full loss, the caller must ensure the repaired edge
term replaces the original edge term exactly once, not add both. All other loss
terms retain their separate label-validity requirements. The full E3 loss and
historical trainer must not be described as weak-label safe solely because this
edge helper passes its tests.

## Behavioral Acceptance

- All-valid records give exactly the original edge-loss value.
- Unknown historical coordinates cannot affect loss.
- Gradients on unknown graph columns are exactly zero.
- No-authorized-edge cases return differentiable zero.
- Wrong task, nonboolean masks, invalid axes and nonfinite valid labels fail.
- Original network and gradients are checked separately; no optimizer is used.

Local verification: 36 passed across sparse supervision, original Conv factory,
original candidate gradient and native factory tests. These are synthetic
pretraining checks, not model evaluation. Server verification is recorded in the
release acceptance receipt; do not infer it from the local result.
