# Dataset Profile Run and Recovery Binding

The registered Human lifecycle CLI accepts paired `--dataset-profile` and
`--dataset-profile-sha256` arguments. The existing single-tool interceptor remains
the no-training entrypoint; the full lifecycle CLI is NOT a dry-run command.

Before writing run state, the CLI verifies the profile, metadata and adapter file
hashes, membership boundaries and requested radar data root. It saves the profile
identity and only the environment variables named by its path locators in both
POLICY.json and MODEL_MANIFEST.json. No unrelated environment secrets are copied.

Resume requires these two records to agree and revalidates the saved binding.
The runner receives the same profile path, digest and bound locator environment;
native stage command construction rechecks them before launch. Missing paired
arguments, changed profile contents and differing data roots fail closed.

Legacy runs without either profile record remain explicit historical mode, not
portable-profile certification. Resume expects the concrete data root that was
bound at launch. A profile does not automatically make every native trainer
portable: unsupported stages still fail the native stage guard.

## Evidence and Remaining Scope

Local and lab407 CPU tests: 22 passed (binding and registered CLI regression).
The initial server candidate lacked a CLI test dependency and recovery shell
script; both were added and the full test selection rerun successfully. Packaging
now explicitly includes these dependencies.

Server candidate: `releases/profile_run_binding_candidate_20260908`. This is an
overlaid validation candidate, not a new hash-sealed production release. The full
Qwen lifecycle was not executed by these tests; no sensing training or Test read
occurred. Fresh source/Sentinel trainer bindings, full native expert contracts and
real-Qwen nested acceptance remain open.
