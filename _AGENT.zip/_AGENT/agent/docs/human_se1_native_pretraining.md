# Human SE1 Native Command Preflight

The original sparse-anchor runner now exposes two pure command builders:
`build_cache_command` and `build_training_command`. Its real `main` calls these
same functions. Preflight imports the runner but does not invoke `main`, cache
construction, model training, search, or checkpoint writes.

The extracted statement ASTs match the archived main-body command statements
exactly. This proves command-generation equivalence, not complete program or
numerical equivalence. The original file and its hash remain preserved.

## Dependency Order

1. Build cross-modal anchors using source-calibrated visual direction and radar
   candidates from permitted training data.
2. `materialize_support_only_cross_anchor` selects the fit/calibration support
   defined by the bound protocol; raw cache is not the training input.
3. Train sparse-anchor adaptation from the foundation checkpoint and sealed
   support cache, with source replay and unknown-target consistency.
4. Run the registered internal configuration search.
5. Produce the authorized internal-stage handoff, not an automatic runtime promotion.

The current interception verifies steps 1 and 3 as executable command plans and
registered input identities. It does not pretend steps 2, 4 or 5 have run.

## Evidence

- Server: `HUMAN_SE1_NATIVE_COMMANDS_20260908.json`; two commands, zero asset mismatches.
- Command equivalence: `SE1_COMMAND_EQUIVALENCE_20260908.json`; both AST blocks equal.
- Regression: `human_se1_native_regression.xml`; 57 passed.
- Isolated release: `/home/hyc/radar+ris/AGENT-JSAC/releases/human_se1_native_commands_20260908`.
- No training output directory, dataset cache or model checkpoint was created.

Registered legacy paths are still dataset-specific compatibility bindings. Full
runtime DatasetProfile rebinding and new-parent lineage receipts remain necessary.
