# Temporal Training Path Gap

## Verified discrepancy

The reviewed preparation path aligns measured candidates into causal slots,
reorders candidate supervision with those slots, splits frame gaps and forwards
candidate reset flags. The archived optimization path still takes plain Episode
objects; its tensor conversion and loss do not carry the reset flags. A successful
preparation receipt is therefore not evidence of equivalent optimization inputs.

## Immediate containment

The actual `train` function rejects the five reviewed temporal implementations
before creating an optimizer. This also covers direct Python calls that bypass
Dispatcher and CLI checks. Non-temporal training mathematics and the historical
reference source remain unchanged. No historical checkpoint is replaced.

## Required closure before admission

1. Use one hash-bound episode adapter for preparation, fit and internal calibration.
2. Reorder candidate features, physical coordinates and supervision together;
   preserve the exact identity slot and reject mismatched parent bindings.
3. Split sequence/frame gaps and forward candidate reset metadata in loss and
   calibration, not only in the preparation forward.
4. Test gradient reachability without optimization, label permutation equivalence,
   sequence isolation and direct-call interception before allowing any training.
5. Independently validate real resource scope and EmptyGuard provenance. Synthetic
   tests cannot certify data quality, expert gains or numerical reproduction.

This is an unresolved implementation gap, not a missing user authorization.
Do not remove the guard merely because preparation, packaging or Qwen routing
tests pass. Locked Test stays closed and sensing training stays intercepted.
