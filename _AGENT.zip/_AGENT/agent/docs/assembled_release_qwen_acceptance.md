# Assembled Release Qwen Acceptance

The code archive `CONTROL_RUNTIME_ASSEMBLED_20260910.zip` was installed with
per-file hash verification into a fresh server directory:
`/home/hyc/radar+ris/AGENT-JSAC/releases/control_runtime_assembled_20260910`.
No manual dependency additions were needed after this installation.

Archive SHA256:
`12ee150ef150f0e4f124812dcad9c48dc6e4e1bde50776abdcd3826a70707207`.

## Actual policy inference

The existing Qwen2.5-0.5B-Instruct model and verified lifecycle LoRA were loaded
from external server model directories. Qwen selected from constrained choices;
it did not generate executable code. Dispatcher used a fixed synthetic profile
for `state_consistent_local_refiner` with parent `cora_se1`.

| Case | Outcome | State restores | Native preparation calls |
| --- | --- | ---: | ---: |
| Valid profile | monitor_reached | 13 | 1 |
| Wrong native code hash | rollback_executed | 11 | 1 |

Both processes exited successfully. The fixture's `NEVER_TRAIN` output directory
remained absent. Local receipts are in `artifacts/pretraining_acceptance/`:
`ASSEMBLED_QWEN_VALID_20260910.json` and
`ASSEMBLED_QWEN_BAD_CODE_20260910.json`.

## Limits

These are real Qwen decisions with synthetic sensor fixtures and a real
intercepted specialist-preparation call. Remaining stages are explicitly
simulated. Receipts cannot authorize promotion. No detector training, checkpoint
reproduction, expert ranking, real-label quality, or Locked Test result is
established by this check. Full 42-entry native binding remains incomplete.
