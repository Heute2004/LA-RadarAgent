# Source-tail and RIS native preparation

## Source-tail experts

The registered native source-tail script was imported without calling main.
Its FoundationRadarDataset loaded the authorized source Train manifest with
radar caching disabled. Native SequenceSubset selected the protocol lists:

| Route | Fit samples | Calibration samples | Parent |
|---|---:|---:|---|
| open_indoor_los | 600 | 300 | SE1 |
| open_outdoor_weak_return | 7070 | 2356 | SE1 |

Fit, calibration and Development sequence lists are disjoint. No radar item
was iterated during this membership check. Source supervision is permitted;
this must not be described as a target pseudo-label-only expert. The native
calibration selector uses source-label Hit@0.30, then P90/P95, Hit@0.25 and
coverage under its original 1% harmful-rate budget. These are native source
calibration rules, not the canonical research AP metric or a new global gate.

Evidence: `SOURCE_TAIL_NATIVE_MEMBERSHIP_20260909.json` in
`artifacts/pretraining_acceptance`, including protocol/script/manifest hashes.

## RIS experts

The registered native RIS shadow dataset loaded eleven Train sequences with
3,300 teacher frames. The original whole-sequence split uses seed 3407 and two
Train-internal calibration sequences. Under the existing explicit 0.45 anchor
threshold, all 3,300 frames are anchors. This is eligibility, not measured
label accuracy. All selected candidate coordinates and confidence values are
finite and valid. Native frame manifests match the teacher length.

Thirty-three sampled first/middle/last-frame clips have shape
`[16,2,128,128]`, finite normalized radar values and no future-frame indices.
This is not an exhaustive raw radar numeric audit. The loader uses the
registered direct-equivalent RIS condition, not an ordinary direct-path alias.

The reproducible check is `scripts/audit_native_ris_teacher_payload.py`.
The first dynamic-import attempt lacked the native scripts directory; the
standalone auditor restores the same sibling-import search path as native CLI
execution. No native scientific code was changed.

Evidence: `RIS_NATIVE_TEACHER_PAYLOAD_20260909.json` in
`artifacts/pretraining_acceptance`, including teacher hashes, sampled frames,
feature roots and Fit/Calibration lists.

## Limits

No optimization, checkpoint writing, historical expert import or Locked Test
payload access occurred. Parent source-tail selection is fixed by this native
recipe to SE1; this audit does not certify an arbitrary-parent adapter. Fresh
parent/cache lineage generation and live promotion remain separate gates.
