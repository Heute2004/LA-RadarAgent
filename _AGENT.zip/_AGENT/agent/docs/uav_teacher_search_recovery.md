# UAV Temporal Teacher Search Recovery

The recovered `source_temporal_report.json` has SHA256
`1244000dca875d7bd462eef916672d20d884d39796ab3717df399a2c09e0529c`.
This exactly matches `source_temporal_report_sha256` in the frozen teacher receipt.
The report is stored in `artifacts/reproduction_inventory/evidence/uav/`.

The native method searches 48 combinations on source development:
- Source motion percentile: 99.
- Step factors: 0.9, 1.1, 1.3, 1.6 times the source-derived base step.
- Transition weights: 0.25, 0.5, 1.0, 1.5.
- Restart penalties: 1.0, 2.0, 3.0.

For the historical data, the source base step was 1.1061765861374275 m.
The selected step was 0.9955589275236848 m, transition weight 0.25 and
restart penalty 3.0. These selected values are historical outputs, not universal
constants to impose on another dataset or freshly generated parent cache.

The teacher uses full-episode median residual background and a global physical
candidate search (48 peaks/view; range/angle half widths 4 m/12 degrees; NMS
radius 2 bins in both axes). This is offline supervision construction, not a
claim of causal deployed model inputs. No UAV route expert is introduced.

Next binding requirements: recover source ranker policy with matching digest,
compile the full source search explicitly, bind fresh parent caches and Doppler
inputs, and intercept before fitting. This recovery alone is not full teacher
pipeline acceptance and authorizes no training or Test access.
