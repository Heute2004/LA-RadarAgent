# UAV Measurement Fault Acceptance

This contract governs pretraining interception tests, not scientific reproduction.
The task remains UAV evolution and routing; no Human expert is eligible.

## Isolation

Each measurement fault uses a freshly sealed reference fixture, a unique output
root, and its own `valid_compile` logical runtime. Use the runner's `--case`
argument to run exactly one case. Never change a production run identifier to
make an unrelated teacher receipt pass. Never overwrite a completed run.

The isolated orchestration script is
`scripts/check_uav_isolated_measurement_cases.py`. It calls existing reference
cache, teacher-command, label-handoff and measurement-audit tools, then the real
Qwen runner. It does not launch the compiled sensing-training commands.

## Required observations

| Case | Required evidence |
| --- | --- |
| Normal | Teacher and adaptation commands compile; lifecycle reaches monitor |
| Missing measurement report | Missing-file error names the injected measurement report; rollback executes; adaptation compilation count is zero |
| Changed measurement report hash | Exact measurement report hash mismatch; rollback executes; adaptation compilation count is zero |

A foreign-runtime rejection is correct security behavior, but is NOT evidence
that a measurement fault was tested. A rollback outcome alone cannot pass these
fault cases. Store the failure reason and the lifecycle memory restore count.

The package task inspector must pass after any change to a pinned runner. Unit
tests alone do not establish task-manifest integrity. Installed releases are
immutable; change the local source, update its reviewed hash, and publish a new
release instead of editing an installed release in place.

## Evidence boundaries

Reference predictions and labels are historical test fixtures, not newly trained
teacher outputs. Other scientific lifecycle receipts remain simulated and
non-promotable. Passing these tests proves request routing, input verification,
fault handling and memory continuation only. It does not prove new label quality,
metric reproduction, free-form planning, or full Human/UAV readiness.

No sensing model optimizer is run. Locked Test and Development Query payloads
remain closed. Models and datasets remain outside the control package.
