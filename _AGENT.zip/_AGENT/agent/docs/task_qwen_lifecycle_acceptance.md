# Human and UAV: Qwen Workflow Simulation Acceptance

## Execution Boundary

The server executed the real Qwen model with the verified Evidence-Gated Lifecycle LoRA. Tools used the existing `TaskWorkflowRuntime` and `SimulationBackend`. Receipts were synthetic and explicitly non-promotable. No radar/visual training, sensing data evaluation, or Locked Test access occurred. Production activation was not changed.

The previous simulation entry did not load this Adapter. The new entry, `scripts/check_task_qwen_lifecycle.py`, maps registered lifecycle requests to task-permitted tool names and applies the same typed evidence prompt used by the repaired model. It does not substitute a new workflow for the task contracts.

## Results

| Task | Scenario | Outcome | Requests | Memory restores |
|---|---|---|---:|---:|
| Human | Normal path | Monitor reached | 13 | 13 |
| Human | Training unauthorized | Held before dispatch | 10 | 9 |
| Human | Audit failure | Rollback executed | 12 | 12 |
| Human | Canary failure | Rollback executed | 13 | 13 |
| UAV | Normal path | Monitor reached | 12 | 12 |
| UAV | Training unauthorized | Held before dispatch | 9 | 8 |
| UAV | Audit failure | Rollback executed | 11 | 11 |
| UAV | Canary failure | Rollback executed | 12 | 12 |

All eight cases passed. Across 92 requests, 44 were binary lifecycle choices with the Adapter active, while 48 had exactly one legal workflow tool. Singleton requests are not evidence of autonomous planning. Both unauthorized cases stopped before backend dispatch. All 90 committed receipts were `SIMULATED_NOT_PROMOTABLE`; each commit was followed by a fresh runtime restore.

Human used `tasks/human/metrics/lifecycle.json`; UAV used `tasks/uav/metrics/selection.json`. UAV did not enter expert selection. Human requested the expert-selection tool, but this simulation did not rank or train its candidates. Mode resolution maps the normal training request to `shadow_train`, not a frozen-checkpoint replay. Failure transitions remain owned by the existing workflow runtime.

Local regression for task simulation, state/memory protection and native preflight: 23 passed. Tests also reject forged task/state fields, malformed receipts, cross-task memory restoration and stale writers.

## Evidence

- Local: `artifacts/pretraining_acceptance/task_lifecycle_smoke_20260908/`
- Server: `/home/hyc/radar+ris/AGENT-JSAC/artifacts/task_lifecycle_smoke_20260908/`
- Model binding: `configs/qwen_lifecycle_repair_candidate.json`
- Per-case `REPORT.json`: decisions and complete simulated receipts.
- Per-case `simulation_memory.json`: hash-chained task-bound state history.
- `SUMMARY.json`: expected terminal outcomes, observed results, Adapter integrity record.

## What Is Not Yet Proven

This is an abstract workflow path test. It does not expand `shadow_train` into the complete source/SE1/SE2/native-expert subgraph, compute label admission metrics, select the best parent or five experts, reproduce frozen numerical results, or exercise continuous monitoring after reaching the monitor state. The runtime uses synthetic permission fixtures, not live authorization attestations.

Next acceptance must bind these nested operations to their real recipes and dependency receipts while still intercepting actual training. Overall training readiness remains conditional; this report must not be cited as full autonomous scientific reproduction.
