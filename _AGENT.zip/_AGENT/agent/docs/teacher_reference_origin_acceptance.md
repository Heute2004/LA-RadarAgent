# Teacher reference-origin acceptance

The native teacher parent handoff now reopens the pinned original audit for a
reference-backed simulated SE1 receipt. It verifies the original audit digest,
sealed result digest, accepted status, harm-budget outcome, candidate ID,
producer tool, protocol, checkpoint path/hash, runtime eligibility and complete
evidence scope. A simulated parent must explicitly deny training and promotion.
Nested simulated origins and non-boolean simulation flags are rejected.

This does not turn the historical audit into a newly trained SE1 result. The
handoff explicitly reports `reference_origin_verified` and keeps
`fresh_training_verified=false`. Historical files are not rewritten.

## Verification

- Six new tests failed before repair: missing origin, changed origin, wrong
  candidate, changed evidence scope, false training claim, and missing origin
  verification evidence on a valid fixture.
- Focused handoff and chain tests: 17 passed locally.
- Server actual four-fold teacher metadata preflight passed with the original
  pinned reference receipt: `artifacts/TEACHER_ORIGIN_VERIFIED_20260909.json`.
- Real Qwen integrated negative: `artifacts/QWEN_TEACHER_ORIGIN_NEGATIVE_20260909`.
  The deliberately wrong origin digest caused `rollback_executed`, 11 memory
  restores, and no specialist log or invocation. Source, Sentinel, SE1 and SE2
  preparation had completed before the teacher-origin rejection.
- Server release `releases/teacher_origin_verified_20260909`: 466 packaged
  tests passed in 15.50 seconds.
- Archive SHA256: `82cec2f73a958576bf9c26a8e0bf447647ac372851e51dc0d9e5cb933c80c7e2`.

All sensing training remained intercepted and Locked Test stayed unread.
The negative audit runner exits nonzero because its default positive criterion
is monitor; the stored outcome and exact hash failure were independently
checked as the expected negative behavior.

The broader fresh-output chain, candidate binding and final readiness matrix
remain open. This document and the new audit receipts postdate the tested ZIP.
