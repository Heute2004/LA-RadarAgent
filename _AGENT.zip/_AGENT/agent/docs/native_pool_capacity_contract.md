# Native Pool Capacity and Request Selection

The catalog and the requested shortlist are different objects.

- Every Human route declares the actual integer number of registered native
  candidates; the count must match its records and be at least five.
- Qwen selects exactly five distinct native IDs per request, without replacement.
- Adding inventory entries does not authorize their training. Script identity,
  label recipe, parent policy, stage dependencies and admission checks still apply.
- This change registers no new model and imports no checkpoint. The active
  catalog still has 30 candidates. The seven-entry test is a synthetic fixture,
  not a claim that two additional historical implementations were recovered.
- UAV does not use this Human expert catalog.

The previous loader rejected any route containing more than five candidates and
also rejected any total other than thirty. That incorrectly prevented the
requested larger-pool Top-5 search. Those inventory-size restrictions are removed;
the request-level five-choice constraint remains in the existing Qwen policy.

Verification: malformed declared counts fail; a seven-entry fixture loads;
the Qwen policy with a deterministic test scorer offers 7, 6, 5, 4, 3 choices
and returns only five unique IDs. This is a control-path test, not measured
scientific ranking quality or a new real-Qwen acceptance run.

## Explicit execution selection

The Human preflight request now accepts `recipe_ids`, a list of five distinct
registered native IDs belonging to the requested route. The route DAG builder
validates these IDs and filters that route before expanding dependencies.
Unselected candidate jobs never enter the resulting route DAG. Receipt field
`selected_native_recipe_ids` preserves the requested selection order.

Omitting IDs is supported only when the route already has exactly five entries;
larger inventories require explicit selection and never silently choose the
first five. Existing five-entry catalogs remain unchanged. The materializer
checks its declared candidate count against actual records rather than requiring
the global inventory to contain exactly thirty.

The seven-entry fixture exercises dependency closure and absence of unselected
jobs. It does not establish that Qwen ranks scientific mechanisms correctly.
Real-Qwen ranking-to-dispatch acceptance for an expanded, structurally verified
catalog remains pending.

## Independent server package check

`native_selection_profile_bound_20260909` installed 1116 verified files on
lab407. Archive SHA256:
`97f6e54d72ce3ed6ca542375fdb470eacc6011427ff44bda62d90f310f0343d2`.
CPU package tests: **569 passed in 24.65 seconds**, exit code 0.
Two earlier candidate packages failed because a test helper and then its
external context profile were absent; neither is an accepted release.

`check_qwen_native_requests.py --rank-native` now obtains the actual policy
shortlist and forwards it through a task/route/namespace-checked request.
Tests cover this boundary; a fresh real-Qwen run of that new option is pending.
The previous 12/12 binary decision run is not evidence for the new option.
