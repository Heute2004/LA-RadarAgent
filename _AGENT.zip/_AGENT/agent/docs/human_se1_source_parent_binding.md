# Human SE1 Source-Parent and Active-Profile Crosscheck

This note records the read-only compiler boundary in
`scripts/pretraining_human_se1_commands.py`. It does not launch a native
command, load a model or tensor, read training data, read Development or
Locked-Test payloads, or change a frozen method or shared configuration.

## Separate Modes

`--parent-mode reference` is the historical inspection branch. It alone may
load `configs/prospective_registered_tools_v1.json` and compile the unchanged
legacy command shape. Its metadata is explicit:

```text
parent_mode=historical_reference
source_mode=registered_reference_parent
fresh_lineage=false
source_handoff_verified=false
producer_binding_mode=historical_reference
legacy_registry_role=historical_reference_parent
```

`--parent-mode fresh` is a separate branch. It requires the existing source
producer handoff fields and the active profile triplet:

```text
--source-parent-binding <outer binding JSON>
--source-parent-binding-sha256 <binding SHA256>
--source-checkpoint <source checkpoint path>
--dataset-profile <runtime profile path>
--dataset-profile-sha256 <profile SHA256>
--profile-environ <JSON locator environment>
```

The source handoff still uses
`agent_jsac.se1_source_handoff.bind_source_parent`; no new receipt format is
introduced. The existing simulated-source verifier checks the outer binding,
signed producer receipt, current run, task/stage, candidate, source roles,
forbidden-read flags, and checkpoint identity. The resulting metadata remains
`fresh_lineage=false`, `source_handoff_verified=true`, and
`producer_binding_mode=simulated_current_run`: it does not claim newly trained
source weights.

The fresh profile path then loads the active Human
`training.json`, method contract, supervision tools contract, task tools
contract, workflow contract, and dataset selector. It
loads the explicit locator environment, calls `bind_profile`, and round-trips
the returned record through `restore_profile`. The profile record therefore
retains the current `verified_dependencies` evidence. The profile resolver
checks the runtime profile hash, membership, route parent/recipe, adapters,
and evaluation boundary before native command construction.

Fresh code has no call to `ProspectiveToolRegistry.load`. It cannot satisfy an
active request by reading the historical registry. The active mapping is sent
through the existing `ProspectiveToolRunner._build_command` path, including
the resolver and `validate_native_stage_command` checks. It additionally
requires the compiled SE1 command to contain a `--protocol` partition binding
and a `--foundation-checkpoint` equal to the verified source checkpoint.

## Active Mapping

The active package now supplies the five required native mapping items in
`tasks/human/supervision/se1_stage_binding.json`, referenced by
`tasks/human/supervision/tools.json`. The binding SHA256 is
`a9e2f17ec002b32b352fc030d4195dd3a487947dce2c6be7216710e58d66eb1c`; the
supervision-tools destination SHA256 recorded in
`tasks/human/integration_manifest.json` is
`714078c978b109963d4b8e24a40147d60588a1dcb76424614052d4ca21881060`.

The active mapping binds:

1. The current source-scene entrypoint and SHA256.
2. The current source-scene support protocol and hash-bound input manifests.
3. `source_train`, `source_internal_validation`, `adaptation_fit`, and
   `adaptation_calibration` to the native protocol fields, with native
   `--split train`.
4. `--foundation-checkpoint` to the verified producer handoff checkpoint and
   its receipt hash; historical checkpoint import is false.
5. The canonical `cora_se1` / `cross_modal_anchor_trajectory` recipe and its
   existing optimization values, including disabled frozen-reference caching.

The runtime profile supplies `--data-root`, Sentinel checkpoint and Sentinel
calibration through existing `bind_profile`/`restore_profile` and runner
placeholder APIs. The compiler calls the existing registered-asset audit,
`resolve_profile`, `validate_native_stage_command`, and then the original
`build_cache_command` and `build_training_command` functions. The produced
argv therefore carries the profile-resolved partition and verified source
parent, rather than merely mentioning them in metadata.

The `runtime_assets` list is classified explicitly. The three V4 scripts are
`immutable_native_script` entries. The V4 split, foundation manifest, candidate
cache manifest, and anchor-cache manifest are
`replaceable_runtime_data` entries. Their hashes describe the current runtime
data binding; they are not part of the portable method lock and do not require
the same historical frame set for a different Dataset Profile. A later
profile-specific runtime may substitute those manifests/caches (and its
runtime asset root) only after the same hash audit, profile membership
resolution, and native-stage validator pass. The immutable boundary remains
the entrypoint/script code and canonical recipe; a historical cache is never a
fresh source producer artifact.

No hyperparameter values were invented. The parameter evidence pointer and
the reusable implementation sources are:

```text
src/agent_jsac/prospective_tools.py:1115-1182
src/agent_jsac/profile_run_binding.py:9-48
src/agent_jsac/stage_protocol_preflight.py:8-143
scripts/run_source_scene_cora_anchor_small_sample.py:242,782-846
configs/prospective_registered_tools_v1.json:cora_se1_universal_shadow (reference only)
```

The active `tasks/human/supervision/tools.json` supplies the existing
`construct_cross_modal_anchor_trajectory` and `train_cora_se1` intents and
points to this native binding. `tasks/human/training.json` continues to bind
the method/tools/selector paths. The task-package integration manifest records
the current destination hash for the supervision-tools package and does not
turn a runtime cache into a source checkpoint. Current tests read the active
contracts and do not assume the retired 42/route-7 scope.

## Synthetic Command Evidence

The regression test loads the active JSON binding from disk and parses it with
`RegisteredProspectiveTool.from_raw`. It binds a temporary runtime profile and
locator environment, uses a temporary byte checkpoint and Sentinel path
fixtures, validates the repository's actual anchor protocol through the real
profile-aware runner, and calls the original cache/trainer builders. The
returned argv has the current entrypoint, profile-resolved `--data-root`,
`--protocol`, `--foundation-checkpoint`, Sentinel placeholders, and output
root. A monkeypatch proves that loading the legacy registry would be an
unexpected call in fresh mode.

This is command-construction evidence only. It does not execute a native
process, load a model/checkpoint/data payload, start an optimizer, read
Development or Locked-Test data, or authorize promotion. The V4 runtime asset
paths and hashes remain explicit inputs to be mounted by a later operational
run; the synthetic test uses temporary roots and does not read them.

## Fixture Entry

The minimal active-fresh behavior fixture is the test entry
`tests/test_human_se1_source_parent_binding.py::test_fresh_preflight_compiles_the_hash_bound_active_native_mapping`.
It creates a signed synthetic source-producer receipt, a temporary runtime
Dataset Profile, locator environment, Sentinel path fixtures, and a byte-only
parent input, then calls `_compile_fresh_preflight` and emits the three argv
records in memory. Run it with:

```text
$env:PYTHONPATH='H:/Project/AGENT-JSAC;H:/Project/AGENT-JSAC/src;H:/Project/AGENT-JSAC/tests'
& 'D:/anaconda3/envs/vlm3b/python.exe' -m pytest -q tests/test_human_se1_source_parent_binding.py::test_fresh_preflight_compiles_the_hash_bound_active_native_mapping
```

The fixture's source preparation is receipt-only and is not a checkpoint
producer. The byte parent exists only to exercise the required handoff path and
SHA256 fields. The report explicitly records
`fresh_weight_produced=false`; no fresh source or SE1 weights are claimed.
The real Qwen/server path must use the active `--parent-mode fresh` branch and
its verified producer receipt, not the historical reference command.

## Evidence

During implementation, one real compiler-interface failure was reproduced:

```text
25 passed, 2 failed
TypeError: ProspectiveToolRunner.__init__() got an unexpected keyword argument 'sentinel_checkpoint'
```

The failure was fixed by using the existing runner `roots` mapping. Current
evidence is:

```text
tests/test_human_se1_source_parent_binding.py +
tests/test_human_stage_contract_crosscheck.py
27 passed

tests/test_human_task_package.py + the two files above
37 passed

inspect_agent_task.py --task human --state preflight
structural_pass=true, training_started=false, locked_test_read=false
```

`py_compile` also passed for the compiler and both owned test files. These
checks establish contract and command readiness for integration testing; they
are not a training result or a numerical reproduction.
