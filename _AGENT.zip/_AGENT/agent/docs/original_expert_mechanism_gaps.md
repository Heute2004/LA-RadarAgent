# Historical Mechanism Recovery Findings

## Search scope

Code-only inspection covered the local reproduction tree and targeted source and
backup paths under server `AGENT-JSAC` and `JSAC-AGENT-V4`. Compressed historical
archives were not exhaustively unpacked. Therefore a missing result means not
found in the inspected history, not proof that a method never existed.

## Unresolved original-name mappings

| Catalog name | Actual recovered registered behavior | Missing mechanism evidence |
|---|---|---|
| polar_bev_cross_refiner | Candidate query attends to one pooled context token | Separate polar/BEV local streams and bounded continuous refinement |
| subcell_uncertainty_refiner | Identity mixer, temporal convolution, token-variance gate | Subcell offset head, predicted covariance and its loss |
| innovation_gated_offset | Identity mixer, GRU, context-difference gate | Explicit tracker prediction/innovation and continuous offset |
| temporal_precision_tail | Convolution modifies the last quarter of context | Risk-defined tail selection and bounded precision residual |
| robust_quantile_recovery | Identity mixer, tail convolution, token-variance gate | Quantile prediction and pinball objective |
| anisotropic_wet_mixture | Identity mixer, temporal convolution, polar encoding | Range/cross-range mixture parameters and mixture NLL |

These names are retained as requested but are not certified native mechanisms.
Their historical wrappers resolve to the shared registered candidate trainer.
The existing set-mass/preference/acceptance/continuity objective does not supply
the missing method-specific losses merely through a route-family name.

## Reusable real components, not automatic replacements

The recovered AURFLiteExpert has dual local evidence, mixture offsets and
covariances with an E4 mixture NLL. RHEMExpert has quantile truncation, not quantile
regression. Native CLOR has continuous offset/covariance behavior. These can inform
explicit implementations, but none is an established one-to-one historical
binding to the six names above. Do not rename these components or report them as
restored frozen experts without further evidence and explicit implementation work.

Model sources are under
`reproduction/reference_sources/code_radar_cbpr_v1_20260805/radar_bev/models/`;
loss supplements are under `reproduction/reference_sources/conv_training_supplement/`.
No datasets, checkpoints or Test payloads were required for this audit.

## Selected compressed-history audit

Five explicitly selected server archives from August 26 and August 31 were
inspected without extracting or importing members (32 Python members). The
August 31 `registered_route_expert_models.py` has SHA256
`a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`,
matching the already inspected loose historical source. Its lines 509-511 map
`quantile` and `anisotropic` gates to token variance, not quantile regression or
an anisotropic mixture likelihood. The August 26 model has SHA256
`1c35a0e692cd77f1445539725b3c334d7540855ac262125358de1a0254512fbb`;
it also registers these names as generic scorer specifications.

This narrows the recovery search but is not an exhaustive archive search. None
of these five archives supplies a newly verified native implementation for the
six unresolved mappings above. Preserve names; do not convert name hits into
structural admission or silently rename a different model. Further completion
must supply the missing mechanism and its training objective explicitly.

The user's subsequent source-recovery instruction takes precedence: search and
collect original implementations first. Do not invent a missing mechanism or
silently substitute a similar architecture to complete the catalog.

## Additional native-source recovery on 2026-09-10

Ten further historical training entrypoints and their 48-file Python closure,
plus five hash-verified original protocol files, are preserved under
`reproduction/reference_sources/server_native_expert_expansion_20260910`.
The source-supervised tail adapter training/test closure (16 files) and its
prediction/audit closure (14 files) are separately preserved under
`server_source_tail_recovery_20260910` and
`server_source_tail_readout_recovery_20260910` in the same reference directory.
Counts include overlapping dependencies and are not counts of distinct experts.

The tail trainer requires SE1 and source supervision. It is not evidence that the
catalog's similarly named `temporal_precision_tail` has the same structure.
These recovered sources refine the search inventory, not the production admission
status of the 42 catalog entries. No sensing training was started.

## Pool and parent archive follow-up

Four additional explicit archives were audited on the server on 2026-09-10:

- `backups/expert_pool_contract_fix_pre_20260831_124832.tar.gz`
- `backups/frozen_parent_control_pre_20260831.tar.gz`
- `pipeline_expert_fix_20260831.tar.gz`
- `../backups/AGENT-JSAC_20260824_before_qwen_scaa_domain_v2.tar.gz`

The receipt `HISTORICAL_POOL_PARENT_ARCHIVE_AUDIT_20260910.json` records 81 Python
members, archive/member hashes, definitions and identifier matches. Source was
parsed without importing or extracting archive members. The registered model
in the pipeline-fix archive has the same previously inspected SHA256
`a6e64474c68addd0571ff43a69858cd22715305d7b6b0f8c9b501c3f55415486`.
The quantile/anisotropic name hits in the other relevant members are recipe
registry and registry-test references, not newly recovered dedicated heads or
losses. This search does not close those native-mechanism gaps.

The current decision remains to preserve original names and recover original
implementations. No similar model was renamed, admitted or trained as a result
of this archive audit. This is a bounded search result, not proof of absence
across every server directory or compressed archive.

Reproduce with `scripts/audit_historical_expert_archives.py`, an explicit archive
allowlist and the Human catalog. The report records archive/member SHA256,
definitions and identifier lines. Discovery never authorizes training.
