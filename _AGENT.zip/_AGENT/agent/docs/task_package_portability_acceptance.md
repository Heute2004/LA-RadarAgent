# Task Package Portability Acceptance

Date: 2026-09-10
Root: `H:/Project/AGENT-JSAC`

## Scope

This sidecar checks only the current task-control package:

- ZIP and release-manifest completeness;
- model, dataset, checkpoint, expert-weight, and other materialized-asset externalization;
- Human/UAV contract and runtime namespace isolation;
- extracted-package memory restore and cross-task resume rejection;
- task dependency closure after resolving declared root contexts.

The UAV boundary is the original 2026-09-08 handoff. No fresh UAV lineage,
UAV expert library, training, optimizer, checkpoint generation, payload run,
LockedTest run, Qwen run, or test-data read is part of this acceptance.
The reference archive
`artifacts/pretraining_acceptance/ADAPTIVE_AND_NATIVE_AUDITS_20260910.zip`
was inspected read-only.

## Commands And Evidence

The current packager was executed into pytest temporary storage. The ZIP was
extracted and checked from the extracted tree, then only the synthetic
`SimulationBackend` runtime was exercised:

```powershell
$env:PYTHONPATH = 'H:/Project/AGENT-JSAC/src;H:/Project/AGENT-JSAC/tests'
& 'D:/anaconda3/envs/vlm3b/python.exe' -m pytest -q tests/test_task_package_portability_acceptance.py
```

Observed result: `7 passed`.

The selected existing source-only and synthetic tests were also run with the
same interpreter and path setup:

```powershell
& 'D:/anaconda3/envs/vlm3b/python.exe' -m pytest -q `
  tests/test_pretraining_package_closure.py `
  tests/test_uav_task_package.py `
  tests/test_task_workflow_runtime.py `
  tests/test_uav_original_handoff_binding.py
```

Observed result: `30 passed`.

No trainer, optimizer, model, dataset, checkpoint, payload, LockedTest, or
Qwen command was run by this acceptance.

## Gate Results

| Gate | Result | Evidence |
| --- | --- | --- |
| ZIP and release manifest | PASS | No duplicate members; release members equal the extracted payload; every declared SHA-256 matches; `training_enabled` is `false`. |
| Model and data externalization | PASS | No materialized model, checkpoint, dataset, expert-weight, database, image, audio, or archive payload suffixes; Human profiles use `external/`; UAV assets are declared as external bindings. |
| Human/UAV isolation | PASS | Human and UAV runtime namespaces differ; no active cross-task contract references; UAV expert and RIS controls are disabled. |
| Original UAV handoff | PASS | Original implementation is `scripts/train_cora_u_coarse_set.py`; fresh training authorization is `false`; the authority and 2026-09-08 handoff documents are packaged; no fresh-lineage or UAV expert directory is packaged. |
| Memory lifecycle | PASS | Extracted Human and UAV runtimes each restore one synthetic commissioning record; a UAV resume from a Human run directory is rejected. |
| Active dependency closure | PASS | All package-local references are present after the mainline 29-path addition; native V4 references resolve through the declared external root. |

## Root Mapping

The same relative basename is not treated as the same implementation across
roots.

| Root context | Meaning | Acceptance rule |
| --- | --- | --- |
| `package` | Files resolved from the portable ZIP itself | Must be a ZIP member and pass the release-manifest hash check. |
| `v4` | Active Human native source root | `native_training_recipes.json` declares `source_root_contract.root_id = v4`; every native stage declares `script_root = v4`; the preflight declares `native_source_root`; the host binding is `JSAC_V4_ROOT`. The package-root copy is not used as a substitute. |
| `reproduction/sources/JSAC-AGENT-V4` | Reproduction/evidence copy of the V4 root | Optional. If present, its physical hash must match a real V4 `COLLECTION_MANIFEST` record or a packaged `SOURCE_MANIFEST.json` whose `source_root` is V4 and whose `files` map contains the path. The active expected hash must also be present in that V4 provenance. |
| `reproduction/sources/AGENT-JSAC` | Separate historical Agent source copy | Optional. If present, its physical hash is checked only against its own `SUBPROCESS_MANIFEST` record under `sources/AGENT-JSAC`. It is not compared to the active V4 hash merely because the basename matches. |

The execution-manifest root reader accepts the explicit `srcroot`,
`source_root`, `source_root_id`, and `root_id` forms. When a snapshot omits the
field at the execution-manifest top level, the test uses the paired native
source-root contract rather than guessing that the package root is V4.

## Real Provenance For The Reported Failure

For
`reproduction/sources/JSAC-AGENT-V4/scripts/train_cora_se2_route_specialists.py`:

- `reproduction/COLLECTION_MANIFEST.json` has no matching V4 `collected.name`;
- `reproduction/reference_sources/native_physical_set_closure/SOURCE_MANIFEST.json`
  records `source_root = /home/hyc/radar+ris/JSAC-AGENT-V4` and the file hash
  `a1edb0fb3c99b94b2fdebd8f2779e8ab1289a1b8463384407c65b4940ca65b9e`;
- the physical V4 reproduction copy matches that hash;
- `reproduction/SUBPROCESS_MANIFEST.json` independently records the
  `sources/AGENT-JSAC/...` copy with the same observed hash.

The test therefore does not invent a missing `COLLECTION_MANIFEST` record and
does not skip the hash check. It searches the real packaged source manifests
for the matching declared root and validates the physical copy against that
manifest. The fact that two current copies happen to have equal bytes does
not merge their namespaces.

The namespace distinction is also visible for
`scripts/freeze_v21_ris_temporal_hard_gate_predictions.py`:

- package-root/current implementation: `dcd826aea709b0fc0d5934cfa6895b6de6b019c2cd1d2d7534ab34c9d047ae2c`;
- V4 reproduction copy: `2000ea4df347030cf81295d7d1ed2f508d1d34baf7d29bc9aa30801120c2b9b2`.

The active V4 hash remains checked when the V4 reproduction copy is present;
the package-root implementation is checked only in its own package namespace.

## Dependency Classification

The former 29-ref report was a package-root scan. With root mapping, the
paths classify as follows.

### Package-local paths that must be in the ZIP

These are the three concrete package-local additions. They are now present:

- `configs/registered_route_expert_execution_library.json`
- `scripts/build_expert_execution_assets_manifest.py`
- `scripts/build_native_expert_production_lines.py`

### Active V4 external inputs

The full active native catalog is 23 hash-bound scripts plus four fixed
protocol config paths. Their runtime root is `v4`, not the package root.
The 22 scripts below were part of the former 29-path package supplement;
`scripts/freeze_v21_ris_temporal_hard_gate_predictions.py` was already
present in the package:

- `configs/R11_PCA_SPECIALISTS_PROTOCOL_V2.json`
- `configs/R13_ECHO_MORPHOLOGY_SPECIALISTS_PROTOCOL_V1.json`
- `configs/R14_FACTOR_GRAPH_SPECIALISTS_PROTOCOL_V1.json`
- `configs/R16_NSCAN_MHT_SPECIALISTS_PROTOCOL_V1.json`
- `scripts/build_r49_partial_set_actions.py`
- `scripts/calibrate_r52_branch_risk_gate.py`
- `scripts/calibrate_route_setmass_gate.py`
- `scripts/freeze_cora_se2_r11_predictions.py`
- `scripts/freeze_r11_pca_specialist_predictions.py`
- `scripts/freeze_r24_branch_stability_predictions.py`
- `scripts/freeze_r31_route_expert_predictions.py`
- `scripts/freeze_r39_source_tail_predictions.py`
- `scripts/freeze_r51_branch_router_predictions.py`
- `scripts/freeze_route_setmass_specialist_predictions.py`
- `scripts/freeze_single_cora_se2_route_specialist_predictions.py`
- `scripts/freeze_wet_return_radar_setmass_predictions.py`
- `scripts/train_cora_se2_route_specialists.py`
- `scripts/train_r11_pca_specialist.py`
- `scripts/train_r24_branch_stability_router.py`
- `scripts/train_r31_route_specialist.py`
- `scripts/train_r39_source_tail_adapter.py`
- `scripts/train_r51_r31_r49_branch_router.py`
- `scripts/train_route_setmass_specialist.py`
- `scripts/train_stageb_v11_small_sample_shadow.py`
- `scripts/train_v21_ris_temporal_hard_gate.py`
- `scripts/train_wet_return_radar_setmass_expert.py`

The four protocol configs and 22 listed scripts were all present in the
current fresh package. Their package presence does not change the active V4
root resolution or permit a different package-root hash to satisfy a V4
binding.

### Historical UAV evidence, not package omissions

These five paths remain provenance-only references from the original UAV
handoff. They are intentionally not required as package payloads:

- `artifacts/UAV_EASY53_HIT15_PROTOCOL_V6_CONDITION_BALANCED_20260906/server_bundle/uav_agent_nonlockbox_manifest.csv`
- `artifacts/UAV_HONLY_TARGET_TEMPORAL_PSEUDOLABELS_V1G_BACKGROUND_GLOBAL_20260907/TARGET_PSEUDOLABELS.csv`
- `artifacts/UAV_TARGET_COARSE_SET_STRICT_V3_20260907/best.pt`
- `artifacts/UAV_V6_CORA_GLOBAL_20260906T104649Z/u0_global_polar/best.pt`
- `artifacts/UAV_CUMULATIVE_HYBRID_SE_ALL_GUARDED_20260907`

They are referenced only by UAV provenance receipts. The test recognizes
exactly this set; a new non-historical UAV reference still fails closure.

## Remaining Missing List And Mainline Action

Remaining true missing package paths: **none**.

The minimal mainline addition set was the 29 paths represented above: three
package-local paths, four V4 protocol paths, and 22 absent V4 catalog scripts.
The sidecar made no production, packager, configuration, or source edits.
No UAV evidence artifact, model, dataset, checkpoint, payload, UAV expert
directory, or fresh-lineage file needs to be added for this acceptance.

## Boundary

This is a source-only package and synthetic lifecycle acceptance. It verifies
the declared external binding and the hash/provenance rules available inside
the package; it does not claim that an external V4 host is mounted or that a
native training or numerical reproduction run succeeded.

Decision: **PASS for the four requested portability gates, with no remaining
true missing package path.**
