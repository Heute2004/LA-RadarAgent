# LTGE Original Structure and Supervision Audit

Two historical implementations exist. Their shared name does not make them
interchangeable. No source code in either historical implementation was changed.

## Candidate Implementation

`reproduction/sources/JSAC-AGENT-V4/src/brace_v4/route_specialists_se2_models.py`
defines `LTGESE2Expert`. The original factory selects it for `wet_ground`.
It wraps `TECSSE2Expert` and exposes a cumulative `path_evidence` diagnostic.

The original `episode_loss` reads candidate logits and acceptance, plus a
continuity term. It does not use `path_evidence`. A synthetic no-optimizer audit
confirmed that the scorer's residual head receives gradients, but the evidence
head has no gradient. Perturbing only evidence bias changes `path_evidence`
without changing candidate logits, acceptance or covariance. Weights were then
restored exactly. This is not a trained trajectory-graph branch and must not be
advertised as such.

## ConvLSTM-Compatible Original Graph

`reproduction/reference_sources/code_radar_cbpr_v1_20260805/radar_bev/models/e3_experts.py`
defines `LTGEExpert`. The existing hash-verified original Conv loader exposes
this exact class, not the candidate substitute above.

- Extracts local RA/RA-MTI crops around low-threshold polar candidates.
- Forms current/history tokens with explicit metric positions and time.
- Uses query/key attention with physical reachability masks.
- Produces a candidate mixture, bounded continuous proposal, covariance and a
  zero-initialized BEV residual scale.
- Original `e3_training._graph_edge_loss` supervises current-to-history edges.

A synthetic four-frame/six-candidate forward produced a 6-by-24 graph.
The original edge loss generated nonzero gradients in query and key weights.
The initialized BEV residual remained exactly zero. No optimizer was created,
no checkpoint was loaded and no parameter update was performed.

## Label Contract Is Not Interchangeable

The candidate version consumes weak allowed-set weights. The original graph loss
expects current and historical target coordinates and historical validity.
Source supervision can supply those records under the source protocol. Target
adaptation must use only authorized weak records and explicitly handle unknown
history, not fetch target Final-BEV or treat unconfirmed frames as negative.

In particular, the recovered graph loss combines validity into positive-edge
targets but its BCE feasibility mask is based on geometry. This source behavior
requires review before sparse weak-supervision admission: missing historical
labels must not silently become supervised negative edges.

Do not automatically map the semantic `ltge_path_integrator` entry to either
implementation without checking its launcher, label recipe and output contract.
Keep the 42 original identifiers and historical source bytes intact.

## Verification

Local tests: 28 passed across original Conv loader, original candidate gradients
and native factory route matrix. Tests use synthetic inputs only. This proves
the stated mechanism differences, not numerical superiority or production
readiness. Full 42-expert admission remains incomplete. UAV has no expert pool.
