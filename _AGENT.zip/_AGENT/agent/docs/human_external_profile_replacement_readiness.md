# Human External Profile Replacement Readiness

Date: 2026-09-10

## Scope

This is a synthetic, read-only readiness check for the Human source,
Sentinel, and teacher preparation compilers. It uses temporary JSON files,
directories, and byte placeholders only. It does not train, load a model,
create a fresh checkpoint, read Development or Locked-Test data, or launch a
native process.

## Behavioral Evidence

`tests/test_human_external_profile_replacement_readiness.py` calls the current
production modules directly:

- Source accepts a replacement dataset root and emits that profile path/hash
  and `--data-root` in the command. A cross-task source profile is rejected.
- Sentinel accepts a replacement empty root and model-parent placeholder,
  verifies the source producer receipt, and emits both replacement paths. A
  wrong source producer is rejected before command acceptance.
- Teacher accepts distinct replacement data/empty roots and parent checkpoint
  placeholders. The SE1 receipt's producer result SHA and checkpoint SHA are
  propagated into the returned parent handoff and the command. Cross-task and
  wrong-producer receipts are rejected.

All positive paths retain `training_started=false`, no subprocess launch, and
fresh output directories. Sentinel's required empty-audit hash is over a
synthetic byte payload; no production dataset or model payload is loaded.

## Results

```text
tests/test_human_external_profile_replacement_readiness.py
7 passed in 0.73s

New tests plus related profile/receipt/preflight tests
87 passed, 2 failed
```

The two failures are pre-existing fixture drift in
`tests/test_human_source_compiler.py`: its synthetic `indoor` route omits the
current contract's required `parent_stage` and `supervision_recipe`, so
`resolve_profile` rejects before the test's intended success/hash assertions.
The new tests use the current route contract and pass. No existing test was
edited.

### Subsequent integration verification

The main integration pass reproduced both fixture failures, then updated only
the source fixture to declare `foundation` / `source_human_supervision` and to
include the three schema/method/tool contracts in its exact input-hash set.
Production guards were unchanged. The following combined rerun passed:

```text
test_human_source_compiler.py
test_human_external_profile_replacement_readiness.py
test_portable_profile_preflight.py
test_profile_dependency_restore.py
18 passed in 1.06s
```

The earlier failure result remains recorded above; it is not the current fixture
status. The cases exercise compiled commands and synthetic receipts, not model
training or numerical reproduction.

## Remaining Boundary

No additional callable defect was found in the tested replacement-root or
producer-receipt paths. The review remains preparation-only: native source,
Sentinel loader/recipe, and teacher recipe assets are still hash-bound to the
selected implementation root, while compilers return commands and receipt
evidence without native execution or fresh artifacts. Arbitrary implementation
root substitution and the future exact-pair training DAG remain outside this
readiness check, consistent with `docs/pretraining_final_gap_review.md`.
