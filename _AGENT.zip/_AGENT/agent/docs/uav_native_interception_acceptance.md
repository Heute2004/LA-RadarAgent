# UAV Native Interception Acceptance

## Real Payload Check

`audit_pretraining_uav_target_payload.py` reused `TargetPseudoLabelDataset` on
lab407, with CUDA disabled. It loaded every one of the 600 admitted target
windows from sequences 40 and 75. All windows were finite and had shape
`[16,2,512,128]`, with current-frame query index 15. The audit observed and hashed
1,200 original radar files. A Python open-audit hook rejected truth-root and
non-admitted manifest radar paths. Packed aliases were not allowed in this run.

Evidence: `artifacts/pretraining_acceptance/UAV_TARGET_PAYLOAD_PREFLIGHT_20260908.json`.
This verifies target loader inputs, not the accuracy or original generation
provenance of the pseudo labels, nor source replay.

## Real Qwen Check

The verified Qwen LoRA requested tools through the existing task workflow. A
`UAVNativeInterceptBackend` replaced only the training receipt provider. On a
shadow-training request it called the actual native command compiler and hash
verifier, but never imported the trainer or launched its returned command.

| Case | Actual native result | Workflow result | Memory restores |
| --- | --- | --- | ---: |
| Registered inputs | Command and input identities verified | Monitor reached | 12 |
| Injected wrong pseudo-label hash | Verification rejected | Rollback executed | 10 |

Each case attempted native compilation exactly once. All lifecycle receipts
remain `SIMULATED_NOT_PROMOTABLE`; non-training scientific receipts are simulated.
The second case changed an isolated copy of the profile, not the original labels.
This demonstrates handling a real tool failure, not numerical reproduction or
independent scientific promotion judgment.

Evidence: `artifacts/pretraining_acceptance/QWEN_UAV_NATIVE_INTERCEPT_20260908/`.
Local regression: 58 passed in `qwen_uav_native_regression.xml`.

## Remaining Preparation

Human source/SE1/SE2 and expert nested execution still require their complete
profile/lineage binding. UAV source training and teacher construction still need
the same native interception coverage. A new-parent receipt cannot be replaced
by a historical source checkpoint merely because the file hash is valid.
Full preparation remains incomplete; training and Locked Test stay disabled.
