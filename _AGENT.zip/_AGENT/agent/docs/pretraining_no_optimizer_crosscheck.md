# Pretraining No-Optimizer Cross-Check

日期：2026-09-10

## 范围

本验收只检查 Human 注册专家的训练前拦截边界，修改范围仅为：

- `tests/test_pretraining_no_optimizer_crosscheck.py`
- `docs/pretraining_no_optimizer_crosscheck.md`

测试只创建 `tmp_path` 下的合成 `Episode`、空 runtime manifest 和空 guard 文件。没有读取仓库中的 Test/Locked Test 数据、雷达数据、checkpoint、模型权重或历史专家权重；没有调用 optimizer，也没有启动训练。

运行环境：

```powershell
$env:PYTHONPATH = 'H:/Project/AGENT-JSAC;H:/Project/AGENT-JSAC/src;H:/Project/AGENT-JSAC/tests'
& 'D:/anaconda3/envs/vlm3b/python.exe' -m pytest -q tests/test_pretraining_no_optimizer_crosscheck.py
```

相关回归：同一环境下运行 `tests/test_registered_expert_intercept.py` 与 `tests/test_registered_training_preparation.py`，结果为 `95 passed`。

## 修复前首轮证据（保留）

`src/agent_jsac/registered_expert_intercept.py:91-111` 会把 semantic 请求固定转成 `--prepare-only`，并拒绝不在 `OPTIONS` 中的 `--optimizer`、`--train`、`--mode`、`--prepare-only` 等参数。这条 semantic 入口的参数边界有效。

但它不是 `scripts/train_se_branch_route_expert.py` 的唯一入口。trainer 的准备校验位于 `scripts/train_se_branch_route_expert.py:852-895`，包括 parent-selection receipt、三份 parent checkpoint hash、Support scope 和 EmptyGuard/Sentinel。校验结束后，runtime cache 在 `:925-933` 被加载，真正的 `train()` 调用在 `:1072-1087`；`train()` 会在 `:703-704` 创建 AdamW，在 `:717-728` 执行 optimizer 更新。

当前 `main()` 没有在 `--prepare-only` 为 false 时的无条件拒绝。于是直接调用 trainer 时，可以跳过 `:852-895` 的 receipt/Support scope/EmptyGuard/Sentinel 准备校验，进入 runtime loading，最后到达 `train()`。`require_admitted_training_inputs()`（`:769-782`）只覆盖部分 implementation；例如 `echo_extent_disambiguator_v1` 不在该阻断集合中，因此它构成可复现的直接绕过样例。该问题是训练入口边界漏洞，不是 receipt 内容校验漏洞。

## 首轮验收结果（修复前）

| 检查 | 断言 | 当前结果 |
|---|---|---|
| semantic entry 强制 `--prepare-only` | 固定 CPU preparation；不暴露 optimizer/train 参数 | 通过 |
| 缺少 parent-selection receipt | 必须在 synthetic loader 前抛出 `ValueError` | 通过 |
| 非法 semantic 参数 | 必须在 trainer 前抛出 `ValueError` | 通过 |
| 直接呼叫 trainer | 不带 `--prepare-only` 必须在任何 runtime/optimizer 前拒绝 | 失败：当前路径到达 `train()` 哨兵 |
| AST 入口门 | `main()` 必须有早于 runtime boundary 的显式非 preparation 拒绝 | 失败：未找到该门 |

后两项失败是本轮验收的真实阻断结果；测试没有改成断言“允许训练”，也没有用 `xfail` 隐藏漏洞。由于用户要求本轮不改生产代码，本文档只记录定位和证据，不宣称训练前拦截已通过。

## 修复前结论

注册 semantic 入口本身能够 fail-closed，但整个 trainer 仍不能通过训练前安全验收。后续生产修复必须让任何绕过 semantic preparation 的直接 trainer 调用在读取 runtime、构造 optimizer 或进入 `train()` 之前拒绝；修复后重跑上述命令，并保持 receipt、Support scope、EmptyGuard/Sentinel 和参数断言不放宽。

## 修复后复验

主线随后在 `scripts/train_se_branch_route_expert.py:828-830` 的 `parse_args()` 后加入统一门：`args.prepare_only` 为 false 时立即抛出 `ValueError`。该修复不改变 objective，本任务没有修改测试或生产代码。

复跑新 cross-check 与 `registered_training_preparation`、`registered_mechanism_training_contract` 的结果为：

```text
130 passed in 8.08s
```

修复后，直呼 trainer 的合成测试在 runtime loader、checkpoint/array IO、`train()` 和 AdamW 哨兵之前被拒绝；AST 测试也确认统一拒绝门早于 runtime boundary。receipt 缺失、非法 semantic 参数和 semantic entry 的 preparation-only 断言继续通过。服务器同步验收不在本地证据范围内。

## 当前结论

本地训练前安全拦截验收已通过；本轮只负责拦截证据，未启动训练、未调用真实 optimizer、未读取 Test/模型数据或历史专家权重。主线服务器验收仍按其同步结果为准。
