# CLOR Catalog-Native Binding Audit

## Result

`CLORSE2Expert` in the original clean-CORA-SE2 source and the 42-catalog entry
`clor_local_offset` / `local_offset_gru_v1` are **different models**.  They do
not have a path, hash, model ABI, checkpoint ABI, or receipt that binds one to
the other.  The 42 registration must not be used as a catalog identity for the
native CLOR forward evidence.

## Native CLOR Evidence

The local receipt
`artifacts/pretraining_acceptance/CLOR_NATIVE_QWEN_20260910.json` has SHA256
`8650afb72cfc52898ef11c67f73737ec186967aeae8bb09f67ada8d40678c1d1`.
Its shadow-train interception identifies:

- trainer: `releases/control_native_clor_20260910/reproduction/sources/JSAC-AGENT-V4/scripts/train_cora_se2_clean_clor.py`, SHA256 `360fe76ca9ba850329644a1851ce9d29b65b73765b0fdb9c8490bb19c9c9162a`;
- model source: `src/brace_v4/route_specialists_se2_models.py`, SHA256 `fc1e38759a9eb26fcc2fc704074664ee3d2ba05b59fd7b9f41e6b5dfc7e2fa97`;
- original symbol: `CLORSE2Expert`, with fit and calibration forward checks;
- scope: simulation/non-promotable, no optimizer construction or training.

lab407 read-only SHA checks of the `control_native_clor_20260910` release match
both source hashes.  The two local reproduction copies also match each other.

Static source inspection shows that `CLORSE2Expert` takes
`(base_xy_m, feature)`, runs an encoder plus sequence GRU, bounds a 2-D offset,
and returns `offset_m`, continuous `proposal_xy`, `acceptance`, and
`covariance`.  The native trainer saves a
`brace_v4_cora_se2_clean_clor_v1` checkpoint containing `model_kwargs` and
`model_state`; it uses protocol route `clean` and the protocol's own
`route["expert_id"]`.

The related checkpoint-valid receipt remains evidence of a non-training forward
probe only: it records an in-memory initialization, `checkpoint_loaded: false`,
`weights_saved: false`, and `training_performed: false`.  It supplies no real
native checkpoint that could be used to claim equivalence with the 42 discrete
model; that absence does not block preparation of a from-scratch native CLOR
training entrypoint.

## 42-Catalog Evidence

The current `configs/expert_pool_42.json` has SHA256
`5234f70ca347da1f98eacf08575ed33baebfb54a8083c342afe0aa13b3cb5768`.
Its `clor_local_offset` entry points to
`scripts/route_experts/clor_local_offset.py` (SHA256
`f3d20da26321a0b7ee06c20404e9f81a8fb5432831b338c6569191de2f2aa8fe`),
fixes `implementation_id: local_offset_gru_v1`, and describes route
`open_indoor_los` with `exact_observed_candidate` output.

That wrapper imports `registered_route_expert_entrypoint`, not the original
CLOR trainer or `brace_v4` module.  The release-pinned registered model source is
SHA256 `0ee7980699b964e67ab1574cba6aadc6aa03aa7977f4421df482364b18a7d013`:
for `local_offset_gru_v1` it selects `mixer_kind: local`, and `_mixer` returns
`_IdentityMixer`.  Its `RegisteredDiscreteCandidateExpert` accepts
`(candidate_feature, candidate_xy_m, candidate_valid)` and returns discrete
`candidate_logits` plus `acceptance`; its decoder selects an observed candidate
or exact identity.  This is not the continuous-offset native CLOR ABI.

The 42 wrapper's release-pinned entrypoint source has SHA256
`b6054b1453b051ff96b6532324f0845d6f797a5bfcfb1ee157300a59f15342a4` and
allows only `describe`; train/audit exit with an archive-only error.  The
replacement `configs/native_expert_production_lines_v1.json` (SHA256
`9cc6be9132f7fe17112dbc7d1b81fb9c664023800a025bc759ffcd1596c2f664`) contains
no literal native CLOR trainer/model/checkpoint-schema entry.  Therefore it
does not close this binding gap either.

The local worktree's shared registered-model file changed concurrently during
this read-only audit to SHA256
`41fa197a5161a48fd0a19cc3dd73429091983a4ac96899d0c4c7f3c818a0c018`.
It still statically contains the same `local_offset_gru_v1` specification and
`local -> _IdentityMixer` branch, but it is not substituted for the immutable
release hash above.

## Binding Decision

The identical *semantic wording* "local offset" is insufficient.  There is no
matching file digest, direct import, shared checkpoint schema, input/output
contract, or signed receipt declaring that a native CLOR `model_state` loads
into `local_offset_gru_v1`.  Reusing that ID, wrapper, or 42 catalog row would
misrepresent the native forward evidence.  This audit records
`NOT_ONE_TO_ONE_DISTINCT_MODELS_NO_BOUND_ADAPTER`.

## Minimum From-Scratch Native Entry

No integration change is authorized by this audit.  The stored original trainer,
model source, protocol binding, and ABI above are sufficient to prepare a
from-scratch native CLOR training entrypoint.  The smallest future,
evidence-backed path is:

1. Keep the existing original trainer/model/protocol pins and instantiate the
   original `CLORSE2Expert` structure from scratch, preserving continuous
   `proposal_xy`, acceptance, covariance, and the supplied-base offset bound.
2. Keep the original method/route identity from the protocol and source
   checkpoint schema; do not relabel the method as `local_offset_gru_v1` or
   route it through the 42 discrete-candidate wrapper.
3. When a future authorized from-scratch run creates an output, bind that new
   output to its own trainer/model/protocol receipts.  A historical checkpoint
   may be inspected as optional provenance, but loading it, reusing its state
   dict, or proving a state-dict bridge is not a precondition for the new run.

This audit did not load a model or checkpoint, read payload data or Locked Test,
run Qwen, execute a trainer, or modify shared source code.
