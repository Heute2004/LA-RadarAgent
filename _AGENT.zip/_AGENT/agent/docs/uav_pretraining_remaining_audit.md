# UAV Pretraining Remaining Audit

## Scope Correction

The user's subsequent 2026-09-10 clarification makes
`docs/uav_original_handoff_authority.md` authoritative. The fresh-lineage
extension described below is not adopted and is not a required new experiment.
Its implementation is excluded from the package. Existing original-method
reference interception and asset checks remain in force. The corresponding
fresh-lineage gap section below is retained only as historical audit context.

Date: 2026-09-10

## Scope and Evidence

This audit covers the UAV task package and its intercepted pretraining control
path only. It does not launch Qwen, sensing training, model inference, or any
evaluation, and it does not read Locked Test payloads or frozen results.

The inspected isolated-release evidence is
`/home/hyc/radar+ris/AGENT-JSAC/releases/control_endpoint_preparation_20260910`.
Its `artifacts/pretraining_acceptance/UAV_ISOLATED_FAULT_SUMMARY_20260910.json`
has SHA-256 `b9bd7999c09241b8841c325709a3f4d6bc6ddcd391a396abcbdf133f9e6f5c1c`.
That artifact records intercepted Qwen fault acceptance only; it explicitly
does not establish training, numerical reproduction, or Test access.

The relevant contracts are `tasks/uav/task.json`, `workflow.json`,
`tools.json`, `training.json`, `supervision.json`, `routing.json`, and
`metrics/{selection,evaluation}.json`, plus
`docs/uav_fault_acceptance_contract.md`, `docs/uav_native_pretraining.md`, and
`docs/uav_source_pretraining_contract.md` in the isolated release.

## Task Separation

- UAV declares `expert_search_enabled: false`, `expert_stage_enabled: false`,
  and `experts_enabled: false`; it exposes no Human expert or RIS tool.
- The task routes registered, receipt-verified target conditions to the coarse
  adaptation branch and sends source, unknown, failed-audit, or missing-evidence
  conditions to the source foundation. It cannot replace that source branch.
- Selection is UAV-specific: `support_dev` with `ols_mid_map_30_70`. Target
  truth is selection-only, and not permitted for training loss or pseudo-labels.
  Development Query is postfit reporting only; Locked Test is disabled.
- The source entry is `u0` using `ols_map_50_90`; it is distinct from both the
  target adaptation metric and Human distance-AP contracts.

## Fixed UAV Bug

`UAVNativeInterceptBackend.execute` previously increased `compilation_count`
before rechecking the teacher and measurement snapshot for `shadow_train`.
Consequently, a measurement-rejected request could be reported as one native
compilation despite never reaching `compile_request`.

The counter now increases only after the relevant teacher and measurement gates
have passed, immediately before native command compilation. The focused
regression test `tests/test_uav_compilation_accounting.py` verifies that a
changed measurement leaves `compilation_count == 0` and never calls
`compile_request`.

`tasks/uav/integration_manifest.json` was updated only with the resulting
source/destination SHA-256 for this already-declared backend asset. No task
asset, package dependency, shared lifecycle module, trainer, model, or result
was changed.

## Executed Static Acceptance

Using `D:/anaconda3/envs/vlm3b/python.exe` with `PYTHONPATH=src`:

```text
26 passed in 1.30s
```

The focused suite was `test_uav_compilation_accounting.py`,
`test_uav_backend_measurement_gate.py`, `test_uav_measurement_fault_cases.py`,
`test_uav_teacher_dispatch.py`, `test_uav_training_preflight.py`, and
`test_uav_task_package.py`. It uses fixture files and interception/mocking; no
training subprocess, Qwen model, sensor input, or locked payload is used.

`scripts/inspect_agent_task.py --task uav --state shadow_train` also passed:
`expert_count=0`, `legal_tools=[shadow_train]`, `structural_pass=true`,
`training_started=false`, `server_runtime_verified=false`, and
`locked_test_read=false`.

## Current Training-Preparation Interception

This round requires intercepted command preparation, not sensing training.
`UAVNativeInterceptBackend` is a `SimulationBackend` subclass so that lifecycle
memory remains non-promotable, but it actually invokes
`compile_teacher_commands` and `compile_request` after its task, hash, teacher,
and measurement gates pass. It never starts the returned commands. Therefore,
the shared `simulation-only` restriction is not evidence that this round's
interception acceptance failed.

The server evidence binds, rather than merely describes, the required reference
interception inputs:

- The real server profile
  `artifacts/pretraining_acceptance/uav_adaptation_server_profile.json`
  (SHA-256 `ca79646f925c9c255a7041a8a6cd655f039de284f57c96144bfeb10f43055ecd`)
  pins the nonlockbox manifest, truth root, U0 checkpoint, target label CSV,
  device, Python, parameters, and native trainer. Its preflight receipt
  `UAV_ADAPTATION_COMMAND_PREFLIGHT_20260908.json`
  (SHA-256 `7ee8cf676a16f9320ecda6bc2745aa2f7942401db0d18def9996ef77fe1e6815`)
  verifies all five hash-pinned files and compiles the argv without training.
- The later measurement-bound Qwen fixture has an extant adaptation profile
  (SHA-256 `16c9d4d7704dafbcc938c6a3bcaddc12f4ac9de74c8830943cc05746f2fd12c0`),
  teacher command profile (SHA-256
  `779b728ec6ac5c6faa0fe03c246500f2a4f4f7d8b0e6054a0f85fd3c9c1fb1a0`),
  measurement report (SHA-256
  `ec0a2ede0cf9febe818db70142073ae62569f4a1ad12fdf5787beb3b3224b019`),
  and inventory (SHA-256
  `628b95a81d8a12f34912f364759c3c13bbef7e0e6d972412f45bdb597dc6c517`).
  They are all still present under
  `/home/hyc/radar+ris/AGENT-JSAC/artifacts/UAV_MEASUREMENT_QWEN_FIXTURE_20260910/`.
- `QWEN_UAV_MEASUREMENT_BOUND_20260910_VALID.json` records that the bound
  teacher chain reached `UAV_TEACHER_COMMANDS_INTERCEPTED`, the measurement
  content recheck verified 36,000 files, and the adaptation command compiled
  with the bound profile. Its companion summary records one teacher and one
  native compilation for `valid_compile`; the missing/changed-measurement
  cases roll back with zero native compilations.
- Source payload admission is already recorded as
  `PASS_FULL_SOURCE_PAYLOAD` in `UAV_SOURCE_FULL_PAYLOAD_ACCEPTANCE.json`.
  The target-payload preflight binds 600 labels and reports no truth or Test
  read in `UAV_TARGET_PAYLOAD_PREFLIGHT_20260908.json`.

Therefore, no missing external profile, teacher measurement, or reference
payload binding is a current blocker for the evidence-bound training-preparation
interception already accepted above. The precise paths, receipt hashes, and
remaining gaps are recorded in
`artifacts/pretraining_acceptance/UAV_BINDING_EVIDENCE_AUDIT_20260910.json`.

## Fresh-Lineage Training-Preparation Gap

The accepted reference interception is **not** a GO for a new sensing-training
launch. Fresh-lineage training preparation is `INCOMPLETE_NO_LAUNCH` until all
of the following are bound and verified without using the reference fixture:

- A new task-scoped profile must pin the selected manifest, parent checkpoint,
  generated cache index and receipt, teacher parameters, source/target Doppler
  paths, generated label CSV, recovered trainer parameters, device, and an
  unused output directory. No such new-run profile was found in the inspected
  evidence set; the existing profiles point to the accepted reference inputs.
- The existing teacher receipt deliberately records
  `generated_by_current_teacher=false`, while the measurement preparation
  records `fresh_source_training=false` and
  `labels_generated_by_current_teacher=false`. New cache export, teacher output,
  and their path/hash receipts are therefore actual pre-launch preparation
  gaps, not merely future production refinements.
- The reference measurement snapshot records
  `fresh_training_lineage_verified=false`,
  `original_adc_to_cache_provenance_verified=false`, and no immutable-input
  lease. A new launch needs those checks against its own inputs before it can
  enter training.
- The active launch boundary already excludes Test roles: `tasks/uav/training.json`
  requires `--postfit-roles source_development support_dev development_query`,
  `uav_training_preflight.compile_training_arguments` emits that exact argv,
  and `train_cora_u_coarse_set.py` accepts only those three choices. This is
  reinforced by mainline's parser-contract test
  `tests/test_uav_adaptation_parser_contract.py`: it AST-extracts the active
  trainer's `_parse_args` without importing the training module, parses the
  compiled frozen recipe, rejects `source_test`, `locked_test`, and `test`, and
  verifies that the final evaluator consumes `args.postfit_roles`. Mainline
  reported `5 passed in 0.22s`. It is not a remaining fresh-lineage preparation
  gap.

These are training-preparation blockers for a **new** lineage. They do not
retroactively invalidate the already accepted reference-interception evidence,
and they must not be resolved by generating caches or starting training in this
audit.

## Future Authorized Production Boundary

After fresh-lineage preparation is complete, the following remain separate
production-execution requirements:

- Provide the separately approved numeric UAV promotion profile. Historical
  receipts and results are not new promotion authority.
- `TaskWorkflowRuntime` accepts only `SimulationBackend`; a task-scoped live
  backend is a future production-execution integration, not a failure of the
  reference-interception acceptance.

`training_enabled=false` and `server_runtime_verified=false` remain correct
production-status fields. They neither invalidate the reference interception
nor authorize a fresh-lineage training launch.

The server release remains unchanged and should be treated as immutable. The
source-tree correction and its updated task-asset hash require normal review and
publication into a new isolated release before any server-side acceptance is
rerun.
