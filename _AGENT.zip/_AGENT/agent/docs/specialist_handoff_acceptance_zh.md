# 专家工单接入验收

日期：2026-09-09。范围：训练前准备，不运行感知模型训练。

## 本轮修复

原生路线工单仍指向旧审计参数，已实现的无参考标签准入适配器没有接入路径。
现在 Dispatcher 可提供按原生 job ID 绑定的配置及 SHA256。必须先通过既有
准入检查，再逐项核对原生解析器得到的参数和默认值，才能生成拦截命令。
不提供绑定时仍拒绝旧入口，不绕过安全检查，不加载历史专家权重代替训练。

这次还发现任务封装清单未同步新工具配置的哈希。首次服务器回归为
361 passed / 2 failed，失败均为 Asset drift。修正的是派生文件清单，
原始配置和冻结结果没有修改。

## 已验证

- 本地相关回归：15 passed。
- 修正清单后的服务器完整回归：363 passed，15.41 秒。
- 新封装包含 1006 个文件；服务器解包前校验 ZIP 哈希和路径边界。
- 服务器目录：`/home/hyc/radar+ris/AGENT-JSAC/releases/specialist_handoff_verified_candidate_20260909`。
- ZIP SHA256：`c04376ba7ebbaf8c852eb9fda29954ceca4b2e2a4e454ad1f0480f859dcd14ed`。
- 原始回归回执：`artifacts/pretraining_acceptance/SPECIALIST_HANDOFF_REGRESSION_20260909.json`。

## 不代表完成的项目

当前测试证明连接和拒绝逻辑，不是新专家训练或数值复现。真实弱标签准入
仍需绑定已批准的方法合同；不得把待批准的通用平均覆盖率门槛自行定值。
此适配器只覆盖原生 route-specialist 家族，不能替其他专家家族背书。
剩余工作包括其他原生生产线的合同接入、当前谱系端到端工单验收，以及
需求逐项对照后的正式 GO/NO-GO 汇总。总 goal 继续保持 active。

未启动感知模型训练，未打开 Locked Test，未修改冻结结果。
